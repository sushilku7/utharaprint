<?php
ob_start();
session_start();
error_reporting (E_ALL ^ E_NOTICE);
include('includes/top_header.php');
$tempProductDAO    = new ProductDAO();
$tempProductMainCatDAO = new ProductMainCategoryDAO();
$tempProductCatDAO = new ProductCatDAO();
$tempFinalorderDAO = new FinalorderDAO();
$tempMemberDAO     = new MemberDAO();
$tempBannerDAO      = new BannerDAO();
$tempArr           = array();
$productCart       = array();
$productId         = $_POST['proId'];
$productDeliveTime = $_POST['productDeliveTime'];
$memberId=$_SESSION['memberId'];
$tempOurbrandDAO = new OurbrandDAO();
$tempOurbrandResult = $tempOurbrandDAO->OurbrandList();
$tempMemberVO = $tempMemberDAO->getMemberDetails($memberId);
//print_r($tempMemberVO);
$memberName=$tempMemberVO->getFirstName();
$memberEmail=$tempMemberVO->getMemberEmail();
$memberAddress=$tempMemberVO->getMemberAddress1();
$memberPostalCode=$tempMemberVO->getMemberPostalCode();
$memberCity=$tempMemberVO->getMemberCounty();
$memberCountry=$tempMemberVO->getMemberCountry();
$totalProductAmt=$_POST['productAmount'];
$productName=$_POST['productName'];
$productAmount=$_POST['productAmount'];
$paymentMethod = $_POST['payment'];
if(isset($_SESSION['shoppingCart'])  && count($_SESSION['shoppingCart'])>0)
                                                 {
                                                         $shoppingCart     = $_SESSION['shoppingCart'];
                                                         $totalNetAmount   = 0.00;
                                                         $totalVatPrice    = 0.00;
                                                         $designCharges    = 0.00;
                                                         $ttllDsgnChrges   = 0.00;
                                                         //$productNumSets = "NA";
                                                         for($j=0;$j<count($shoppingCart);$j++)
                                                         {
                                                                 $productId                  = $shoppingCart[$j]['PID'];
                                                                 $productName                = $shoppingCart[$j]['PNAME'];
                                                                 $productImage                = $shoppingCart[$j]['PIMAGE'];
                                                                 $productFinish              = $shoppingCart[$j]['PFINISH'];
                                                                 $productPrintType           = $shoppingCart[$j]['PPRINTTYPE'];
                                                                 $productPaperType           = $shoppingCart[$j]['PPAPERTYPE'];
                                                                 $productDeliveryTime      = $shoppingCart[$j]['PDTIME'];
                                                                 $productNumSets             = $shoppingCart[$j]['PNOFSETS'];

                                                                 $productQty        = $shoppingCart[$j]['PQTY'];

                                                                 $productDesc       = $shoppingCart[$j]['PRODUCTDESCRIPTION'];

                                                                 $designCharges     = $shoppingCart[$j]['DESIGNCHARGES'];
                                                                 $ttllDsgnChrges   += $shoppingCart[$j]['DESIGNCHARGES'];

                                                                 $productPrice      = $shoppingCart[$j]['PPRICEWOUTVAT'];
                                                                 $totalNetAmount   += $shoppingCart[$j]['PPRICEWOUTVAT'];

                                                                 $prdcttprcewthvt   = $shoppingCart[$j]['PPRICEWITHVAT'];
                                                                 $totalAmount      += $shoppingCart[$j]['PPRICEWITHVAT'];
                                                                 $vatflag           = $shoppingCart[$j]['VATFLAG'];
                                                                 $totalVatAmt      += $shoppingCart[$j]['VATAMT'];

                                                                 $ttlPrice         =  $productPrice;
                                                                 $netTotal        += $ttlPrice;
                                                                 $ttlPrice         = number_format($ttlPrice, 2);

                                                                 if($vatflag=="Yes")
                                                                     $vatRate        = $shoppingCart[$j]['VATRATE'];

                                                                 //$vatAmount          = $totalAmount - $totalNetAmount;



                                                                 $totalPriceWithVat  = $netTotal+$totalVatAmt;

                                                                 $productNameWOsize  = explode("_", $productName);
                                                                 $productName = $productNameWOsize[0];
                                                                 $item_name = $productName;
                                                                 if(isset($productNameWOsize[1]) && $productNameWOsize[1]!="")
                                                                 {
                                                                              $productSize = $productNameWOsize[1];
                                                                 }
                                                                 else
                                                                 {
                                                                                             if(strstr($productName, "("))
                                                                                             {
                                                                                                 $ftbkt       = strpos($productName, "(");                                                    
                                                                                                 $ltbkt       = strpos($productName, ")");
                                                                                                 $ltbkt       = $ltbkt - $ftbkt;
                                                                                                 $productSize = substr($productName,$ftbkt+1,$ltbkt-1);                                                    
                                                                                                 $hidProductSize = substr($productName,$ftbkt,$ltbkt+1);
                                                                                                 $productName = str_replace($hidProductSize, " ", $productName);
                                                                                             }
                                                                                             else
                                                                                             {
                                                                                                 $productSize = $productName;
                                                                                             }

                                                                 }

                                                                        
                                                             $netTotal    = number_format($totalNetAmount, 2);
                                                            $totalVatAmt = number_format($totalVatAmt, 2);
                                                            $totalPriceWithVat = number_format($totalPriceWithVat, 2);
                                                         }
                                                 }


if(isset($_POST['PayNow']) && $_POST['PayNow']=='Proceed to pay') 
{
   $paymentMethod = $_POST['payment'];
          /*  if($paymentMethod=="Card Payment")
                {
                
                //header('location: paynow.php');
                //exit();
                        $totalAmountWithVat=$product_amount;
                        $finalPrice = $totalAmountWithVat+($totalAmountWithVat*3)/100;
                        $item_amount = number_format($finalPrice, 2, '.', '');
                        $orderId =  $tempFinalorderDAO->addFinalOrder($memberId, $memberName, $memberEmail, $shoppingCart, $paymentMethod, $cartInsertId, $item_name);
                        $custom = $orderId;
                        $paypal_email = "sales@utharaprint.co.uk";
                        $return_url   = "http://utharaprint.co.uk/payment-success.php?cusId=".$orderId;
                        $cancel_url   = "http://utharaprint.co.uk/payment-unsuccess.php?cusId=".$orderId;
                        $notify_url   = "http://utharaprint.co.uk/payment-process.php";
                        // Check if paypal request or response
                   
				$instId="1255565";
                                $cartId="10";
                                $accId1="10";
                                $amount=$item_amount;
                                $currency="GBP";
                                $authMode="A";
                                $testMode="100";
                                $desc=$item_name;
                                $name=$memberName;
                                $address1=$memberAddress;
                                $town    =$memberCity;
                                $postcode=$memberPostalCode;
                                $country ="UK";
                        //$url = "https://secure-test.worldpay.com/wcc/purchase?instId=123456&cartId=WorldPay+Test
//&amount=40.00&currency=GBP&desc=WorldPay+Test&testMode=100";
                        if(!isset($_POST["txn_id"]) && !isset($_POST["txn_type"]))
                        {	
                                $querystring .= "?instId=".$instId."&";								
                                $querystring .= "cartId=".$cartId."&";
                                $querystring .= "accId1=".$accId1."&";
                                $querystring .= "amount=".$amount."&";
                                $querystring .= "currency=".$currency."&";
                                $querystring .= "authMode=".$authMode."&";
                                $querystring .= "testMode=".$testMode."&";
                                $querystring .= "desc=".$desc."&";
                                $querystring .= "name=".$name."&";
                                $querystring .= "address1=".$address1."&";
                                $querystring .= "town=".$town."&";
                                $querystring .= "postcode=".$postcode."&";
                                $querystring .= "country=".$country;
                                //echo $querystring;die();
                                header('location: https://secure-test.worldpay.com/wcc/purchase'.$querystring);
                                exit();		
                         
                         }		
                        }  */
                        
        if($paymentMethod=="Paypal")
        {
                $totalAmountWithVat=$totalPriceWithVat;
                $finalPrice = $totalAmountWithVat+($totalAmountWithVat*3.5)/100;
		$item_amount = number_format($finalPrice, 2, '.', '');
                $orderId =  $tempFinalorderDAO->addFinalOrder($memberId, $memberName, $memberEmail, $shoppingCart, $paymentMethod, $cartInsertId, $item_name);
                $custom = $orderId;
                $orderId= base64_encode($orderId);
                $paypal_email = "sales@utharaprint.com";
                $return_url   = "https://utharaprint-london.co.uk/payment-success.php?".$orderId;
                $cancel_url   = "https://utharaprint-london.co.uk/payment-unsuccess.php?".$orderId;
                $notify_url   = "https://utharaprint-london.co.uk/payment-process.php";
                // https://www.paypal.com/
                //https://www.sandbox.paypal.com
                if(!isset($_POST["txn_id"]) && !isset($_POST["txn_type"]))
                {	
                        $querystring .= "?business=".urlencode($paypal_email)."&";								
                        $querystring .= "item_name=".urlencode($item_name)."&";
                        $querystring .= "amount=".urlencode($item_amount)."&";
                        $querystring .= "cmd=_xclick&lc=UK&currency_code=GBP&first_name=".$firstName."&last_name=".$lastName."&payer_email=".$memberEmail."&item_number=".$orderId."&";
                        $querystring .= "notify_url=".urlencode($notify_url)."&";
                        $querystring .= "cancel_return=".urlencode($cancel_url)."&";
                        $querystring .= "custom=".urlencode($custom)."&";
                        $querystring .= "return=".urlencode($return_url);
                        header('location: https://www.paypal.com/cgi-bin/webscr'.$querystring);
                        exit();					
                }
       }
       if($paymentMethod=="Bank Transfer")
       {
          // echo "hi";die();
           $orderId =  $tempFinalorderDAO->addFinalOrder($memberId, $memberName, $memberEmail, $shoppingCart, $paymentMethod, $cartInsertId, $item_name);
           $orderId = base64_encode($orderId);
           //die();
           header("Location:bank-transfer.php?$orderId");
           exit();
       }
       if($paymentMethod=="paybyphone")
       {
          // echo "hi";die();
           $orderId =  $tempFinalorderDAO->addFinalOrder($memberId, $memberName, $memberEmail, $shoppingCart, $paymentMethod, $cartInsertId, $item_name);
           $orderId = base64_encode($orderId);
           //die();
           header("Location:paybyphone.php?$orderId");
           exit();
       }
   }
   
        
   
   
   
  
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width; initial-scale=1.0; maximum-scale=1.0">
    <!--css-->
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/responsive.css">
    
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
   
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <script lang="javascript">
        function validatePayment()
        {
            
            if(document.getElementById('terms').checked == true){
               
            }
            else
            {
            alert('Please select Terms & conditions');
            return false;
            }
          
          
          var category = document.getElementsByName("payment");
          var check1 = 0;
          var a=(category.length);
          if(category[0].checked){
        
          return true;
          }
          if(category[1].checked){
           
          return true;
          }
          if(category[2].checked){
             
          return true;
          }
           var i;
          for(i=0;i<a;i++){
            if(category[i].checked){
              check1++;
              break;
            }
            
          if(check1)
          {
              return true;
          }
          else
          {
              alert('Please select payment Method!');
              return false;
          }
         
           
        }
        }
        
  </script>
<link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
    <!--css-->
	<style>
	
		
		.midiv{
			position:relative; top:40%;z-index: 1;color: #333;
		}
		
		
	</style>
                <title>Uthara Print</title>

</head>

<body>

    <body><div class="mainCon">
         <?php include 'header.php'; ?>
                
    <br/><div class="lineheight" ></div>
			
			
             <div class="bannerBox" style="background: url(images/payment1.jpg)">
                <div class="container-sm bannerBoxInner">
                    <div class="bannerContent">
                        
                        <div class="bannerSubtitle">
                            <form name="payForm" method="post" action="" enctype="form/data">
                                <span class="Product3">Total Amount &nbsp;&pound;<?php echo $totalPriceWithVat; ?></span><?php if(isset($_POST['payment'])){echo "Please Select Payment Method";} ?><br />		
                                <span class="shophead" style="color: #333;"><a href="#">Click here to accept terms and conditions</a> <input type="checkbox" name="terms" id="terms" value="terms" checked/></span>
								<div class="lineh"></div>
					<div style="display: flex-end"><img src="images/c1.png" alt="" class="paymentimage"/> <span > </span>No Extra Cost&nbsp;&nbsp;<input type="radio" value="paybyphone" id="Paypal" name="payment"/></div>
					<div class="lineh"></div>
					<div style="display: flex-end"><img src="images/c2.png" alt="" class="paymentimage"/> <span style="font-size: 14px">3.5 % Extra </span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" value="Paypal" id="Paypal" name="payment"/></div>
					<div class="lineh"></div>
					<div style="display: flex-end"><img src="images/c3.png" alt="" class="paymentimage"/> <span style="font-size: 14px"> No Extra Cost</span> &nbsp;&nbsp;<input type="radio" value="Bank Transfer" id="BankTransfer" name="payment"/></div>
					<br/>
                                        <a href="#"><input type="submit" name="PayNow" value="Proceed to pay" class="productPrice" onclick="javascript:return validatePayment();"></a>
				
                            </form>
                        </div>
                    </div>
                    
                </div>
            </div>
			
		  	<div class="content">
				
				<div class="container-sm productOffers">
			
				<div class="productContainet">
               
                 
					
				<?php
                                $bid = 17;
                                $tempBannerVO = $tempBannerDAO->getBannerDetails($bid);
                                $bannerName17=$tempBannerVO->getBannerName();
                                $bannerImage17=$tempBannerVO->getImage();
                                echo "<div class='productBox transition'>
                                        <div class='productImage' style='height: auto;'>
                                         <img src='upload/banner/$bannerImage17' alt='$bannerName17' />
                                        </div>
                                        </div>";
                                ?>
                          
		
                 
                </div>
				<!----------------------->
				<div class="lineh" ></div>
				<div class="lineh" ></div>
		<!------------------------------->
				
				<div class="productContainet">
				<div class="productBox shopwidth">
				<div class="productImage"  >
						<p style="text-align: left;padding:15px 20px;font-size: 14px;"> Action fraud is the UK's national fraud and cyber crime reporting center.  We provide a central point of contact for information about fraud and cyber crime.  The easiest way to report fraud and cyber crime is by using online reporting tool .</p>
							
				</div>
				</div>
					<!--------------------------->
					<div class="productBox shopwidth">
				<div class="productImage"  >
						<p style="text-align: left;padding:15px 20px;font-size: 14px;">With the UK's largest cross-sector fraud sharing databases, Cifas is a not-for profit organisation working to reduce and prevent fraud financial crime in the UK. Identity protection.  Individuals Nation Fraud Dtabse. Internal Fraud Database
                    </p>
				</div>
				</div>
				</div>
					<div class="lineh" ></div>	<div class="lineh" ></div>
		<!----------------------------------->
					<div class="productContainet">
				<?php
                                $bid = 19;
                                $tempBannerVO = $tempBannerDAO->getBannerDetails($bid);
                                $bannerName19=$tempBannerVO->getBannerName();
                                $bannerImage19=$tempBannerVO->getImage();
                                $bannerURL19=$tempBannerVO->getBannerUrl();
                                echo "<div class='productBox shopwidth'>
				<div class='productImage'  >
				<img src='upload/banner/$bannerImage19' alt='$bannerName19'/>
							 
				</div><br/>
				<span class='productshortInfo'>$bannerURL19</span>
				</div>";
                                ?>
					<!--------------------------->
                               <?php
                               $bid = 20;
                                $tempBannerVO = $tempBannerDAO->getBannerDetails($bid);
                                $bannerName20=$tempBannerVO->getBannerName();
                                $bannerImage20=$tempBannerVO->getImage();
                                $bannerURL20=$tempBannerVO->getBannerUrl();
                                echo "<div class='productBox shopwidth'>
				<div class='productImage'  >
				<img src='upload/banner/$bannerImage20' alt='$bannerName20' style='margin:19px 0px' />
							 
				</div><br/>
				<span class='productshortInfo'>$bannerURL20</span>
				</div>";
                                ?>         
				
				</div>
					<!--------------------->
			</div>
			</div>
			
			
			
        </div>
	
         <?php include 'footer.php'; ?>
		</div>
		<script type="text/javascript" src="js/jquery.min.js"></script>
    <script type="text/javascript" src="js/function.js"></script>

		</body>

</html>