$(function(){

$("#form-total").steps({

headerTag: "h2",

bodyTag: "section",

transitionEffect: "fade",

enableAllSteps: true,

enableFinishButton: true,

onFinished: function (event, currentIndex) {

/*alert(JSON.stringify($("#website-order").serializeArray()));
alert('dddd');*/
var newData = new FormData(document.getElementById('website-order'));

                   // var servername = "http://localhost/utharaprint-australia/showPriceForProductSubCat.php"; //For Localhost
                   var servername = "design-artwork.php"; //For Localhost
                   //alert(servername);
                   
                            $("#form-response").html("");
                    $.ajax({        
                        type: "POST",
                        url: servername,
                        data: newData,
                        processData: false,
                        contentType: false,
                        success: function(data) 
                         {            
                            //alert(data);
                            $("#form-response").html(data);
                            window.location="thank-you.php";
                                 //Turn Around
                         }
                    });

},

stepsOrientation: "vertical",

autoFocus: true,

transitionEffectSpeed: 500,

titleTemplate : '<div class="title">#title#</div>',

labels: {

previous : 'Back Step',

next : '<i class="zmdi zmdi-arrow-right"></i>',

finish : '<i class="zmdi zmdi-check"></i>',

current : ''

},

});

});