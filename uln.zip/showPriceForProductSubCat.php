<?php
//session_start();
//Get Product Paper List Based on Product Size
include('DAO/DbConnection.php');
include('DAO/VatDAO.php');
include('valueobjects/VatVO.php');
include('library/Dropdown.php');
include('DAO/ProductDAO.php');
include('valueobjects/ProductVO.php');
$tempVatDAO   = new VatDAO();
$tempProductDAO = new ProductDAO();

DbConnection::CreateConnection();

$productName       = $_POST['productCatName'];
$prodcutSubCatId       = $_POST['prodcutSubCatId'];
$productPaperSize      = $_POST['productPaperSize'];
$productPrintType      = $_POST['productPrintType'];
$productPaperType      = $_POST['productPaperType'];
$productFinishSize     = $_POST['productFinishSize'];
//echo $productFinishSize;die();
$printoption           = $_POST['printoption'];
$workingDays           = "7-10 Working Days";
$prodcutMainCatId      = $_POST['prodCatId'];
?><?php
$prodcutSubCatId       = $_POST['prodcutSubCatId'];
$productPaperSize      = $_POST['productPaperSize'];
$proPaperType          = $_POST['productPaperType'];
//echo "select distinct(productPaper) from tbl_product where productCatId='$prodcutMainCatId' and productSize='$prodcutSubCatId' and productStatus='1' order by productCatId";
//die();//echo "select distinct(productPaperType) from tbl_product where productSubCat='$prodcutSubCatId'";
$productPaperTypeQuery  = "select distinct(productPaper) from tbl_product where productCatId='$prodcutMainCatId' and productSize='$prodcutSubCatId' and productStatus='1' order by productCatId";
//$productPaperTypeQuery  = "select distinct(productPaper) from tbl_product where productSize='$prodcutSubCatId'";
$productPaperTypeResult = mysql_query($productPaperTypeQuery);
$dropDown = "";
$ddstr="";
        while($row1=mysql_fetch_assoc($productPaperTypeResult))
        { 
    
                $productPaperType = $row1['productPaper'];
                 //$price         = $row1['productPrice'];
                 //$productId = $row1['productId'];
                // $dropDown     .='<div class="turnAround" style="float: left;">
                    //             <a style="cursor: pointer;"  onclick="javascript: submitForm('."'".$productPaperType."'".')">';   
                if($proPaperType==$productPaperType)
                {
                    $ddstr         .= '<li><label><input type="radio" checked name="proPaperType1" value="'.$productPaperType.'"  onclick="javascript: submitForm('."'".$productPaperType."'".')"/> <span > '.$productPaperType.'</span></label></li>';	
                }
                else
                {
                     $ddstr         .= '<li><label><input type="radio" name="proPaperType1" value="'.$productPaperType.'"  onclick="javascript: submitForm('."'".$productPaperType."'".')"/> <span > '.$productPaperType.'</span></label></li>';
                }
                              
        }
       //echo $productPaperType;
echo $ddstr;

echo "--------------------";

//echo "<br />Test - $dsgnCharges";
?>
<?php
$proPaperType      = $_POST['productPaperType'];
$proPrintType      = $_POST['productPrintType'];
$prodcutMainCatId   = $_POST['prodCatId'];
$productFinishSize     = $_POST['productFinishSize'];
//echo "select distinct(productPages) from tbl_product where productCatId='$prodcutMainCatId' and productSize='$prodcutSubCatId' and productPaper='$proPaperType' and productStatus='1' order by productCatId";
//die();
 

$productPrintTypeQuery  = "select distinct(productPages) from tbl_product where productCatId='$prodcutMainCatId' and productSize='$prodcutSubCatId' and productPaper='$proPaperType' and productStatus='1' order by productCatId";
//$productPrintTypeSelect = "select distinct(productPages) from tbl_product where productCatId='$prodcutMainCatId' and productSize='$prodcutSubCatId' and productPaper='$proPaperType' and productStatus='1' order by productCatId limit 0,1";
$productPrintTypeResult = mysql_query($productPrintTypeQuery);
$dropDown = "";
$ddstr ="";
        while($row1=mysql_fetch_assoc($productPrintTypeResult))
        { 
    
                $productPrintType = $row1['productPages'];
                 //$price         = $row1['productPrice'];
                
                // $dropDown     .='<div class="turnAround" style="float: left;">
                    //             <a style="cursor: pointer;"  onclick="javascript: submitForm('."'".$productPaperType."'".')">';   
                        if($proPrintType==$productPrintType)
                        {
                            $ddstr         .= '<li><label><input type="radio" checked name="productPrintingType1" value="'.$productPrintType.'"  onclick="javascript: submitProductPrintTypeForm('."'".$productPrintType."'".')"/> <span > '.$productPrintType.'</span></label></li>';
                        }
                        else
                        {
                            $ddstr         .= '<li><label><input type="radio" name="productPrintingType1" value="'.$productPrintType.'"  onclick="javascript: submitProductPrintTypeForm('."'".$productPrintType."'".')"/> <span > '.$productPrintType.'</span></label></li>';
                        }
                              
        }
       //echo $productPaperType;
echo $ddstr;


echo "--------------------";
?>
 <?php	
$prodcutSubCatId       = $_POST['prodcutSubCatId'];
$productPaperSize      = $_POST['productPaperSize'];
$productPrintType      = $_POST['productPrintType'];
$productPaperType      = $_POST['productPaperType'];
$productCatName        = $_POST['productCatName'];
$printoption           = $_POST['printoption'];
$workingDays           = "7-10 Working Days";   
$product_id             = $_POST['prodId1'];   
$product_qty1           = '';//$_POST['producQty1'];
$productDeliveTime       = $_POST['productDeliveTimeVal'];
$thumbImage = $_POST['prodImage'];
$productDesc = $_POST['prodDescription'];
$productionTime = $_POST['productionTime1'];
$url = $_POST['prodUrl'];
echo "<label>$productPaperType</label>";
                                                
           
    echo "--------------------";       
        ?>
<?php

$productVatStatus      = $_POST['vatStatus'];
/*$prodcutSubCatId       = $_POST['prodcutSubCatId'];
$productPaperSize      = $_POST['productPaperSize'];
$productPrintType      = $_POST['productPrintType'];
$productPaperType      = $_POST['productPaperType'];
$printoption           = $_POST['printoption'];
$workingDays           = "7-10 Working Days";
$prodcutMainCatId       = $_POST['prodCatId'];
*/
//echo "select DISTINCT productQty, productId, productPrice, profiteMargine  from tbl_product where productSize='$prodcutSubCatId' and productPages='$productPrintType' and productPaper='$productPaperType' order by productQty asc";
//die();
$tempProductPagesSelect        =  $tempProductDAO->getDefaultProductPagesSelection($prodcutMainCatId,$prodcutSubCatId,$proPaperType);
//$proPrintType                  = $tempProductPagesSelect->getProductPages();
$defaultProductPaperSize       =  $tempProductPagesSelect->getProductSize();

if($productFinishSize=='')
{
$qury  = "select DISTINCT productQty, productId, productPrice, profiteMargine  from tbl_product where productCatId='$prodcutMainCatId' and productSize='$prodcutSubCatId' and productPaper='$productPaperType' and productPages='$productPrintType' order by productQty asc";
//echo "running_query";
}
else
{
$qury  = "select DISTINCT productQty, productId, productPrice, profiteMargine  from tbl_product where productCatId='$prodcutMainCatId' and productSize='$prodcutSubCatId' and productPaper='$productPaperType' and productPages='$productPrintType' and finishSize='$productFinishSize' order by productQty asc";
}
//echo $qury;die();
//$qury  = "select DISTINCT productQty, productId, productPrice, profiteMargine  from tbl_product where productCatId='$prodcutMainCatId' and productSize='$prodcutSubCatId' and productPaper='$productPaperType' and productPages='$productPrintType' and finishSize='$productFinishSize' order by productQty asc";
$rs    = mysql_query($qury);
$ddstr = "<select class='put2' name='productPrice' id='productPrice' onchange='javascript: submitPriceForm();'>";
        $count = 0;
        while($rows=mysql_fetch_assoc($rs))
        {             
                //$product_id       = $rows['productId'];
                $productId        = $rows['productId'];
                $qty              = $rows['productQty'];
                $proBuyPrice      = $rows['productPrice'];
                $profitMargin     = $rows['profiteMargine'];
                $margin                = ($proBuyPrice * $profitMargin)/100;
                $finalPriceWithOutVat  =  $proBuyPrice + $margin;                
                if($productVatStatus=="Yes")
                {
                    $qryForVatDetail   = "SELECT rId, vatvalue  FROM tbl_vat";
                    $result2           = mysql_query($qryForVatDetail);
                    $rs2               = mysql_fetch_assoc($result2);
                    $vatRate           = $rs2['vatvalue'];
                    $productVatPrice   = ($finalPriceWithOutVat*$vatRate)/100;
                    $productVatPrice   = round($productVatPrice, 2);

                    $finalPriceWithVat = $finalPriceWithOutVat + $productVatPrice;
                    //echo "Product Price - ".$productPrice;
                }
                else
                {
                    $finalPriceWithVat = $finalPriceWithOutVat;
                }
                if($product_qty1==$qty)
                {
                 $select="selected";
                }
                else
                {
                 $select="";
                }
                $finalPrice = number_format($finalPriceWithVat, 2);
                
                $ddstr.="<option value='$productId' $select>$qty</option>";
                $count = $count + 1;
        }
        $ddstr   .= "</select>";
        
echo $ddstr;

echo "--------------------"; 
?>
<?php
$tempProductDAO = new ProductDAO();

/*$prodcutSubCatId       = $_POST['prodcutSubCatId'];
$productPaperSize      = $_POST['productPaperSize'];
$productPrintType      = $_POST['productPrintType'];
$productPaperType          = $_POST['productPaperType'];
$productLaminationType = $_POST['productLaminationType'];
//$productId             = $_POST['productId'];
$productNumSets        = @$_POST['productNumSets'];
$productFoldType       = @$_POST['productFoldType'];
$productPrintPageNum   = @$_POST['productPrintPageNum'];
$productCoverType      = @$_POST['productCoverType'];
$productCutType        = @$_POST['productCutType'];
$printoption           = $_POST['printoption'];
$workingDays           = "7-10 Working Days";
*/
//echo $_POST['productPrintType'];
$productFinishSize     = $_POST['productFinishSize'];

//echo "select DISTINCT productQty, productId, productPrice, profiteMargine  from tbl_product where productCatId='$prodcutMainCatId' and productSize='$prodcutSubCatId' and productPaper='$productPaperType' and productPages='$productPrintType' order by productQty asc";
//die();
$productVatStatus   =$_POST['vatStatus'];
$productVatPrice="0.00";
$designCharges="0.00";
$finalPriceWithOutVat="0.00";
$totalPrice="0.00";
//echo $prodcutMainCatId.", ".$prodcutSubCatId.", ".$productPaperType.", ".$productPrintType.", ".$productFinishSize.", ".$product_id;

//echo "select DISTINCT productQty, productId, productCatId, productPrice, profiteMargine from tbl_product where productCatId='$prodcutMainCatId' and productSize='$prodcutSubCatId' and productPaper='$productPaperType' and productPages='$productPrintType' and finishSize='$productFinishSize' order by productQty asc limit 0, 1";
//die();
if($productFinishSize=='')
{
    //print_r($_POST);
    $qury  = "select DISTINCT productQty, productId, productCatId, productPrice, profiteMargine from tbl_product where productCatId='$prodcutMainCatId' and productSize='$prodcutSubCatId' and productPaper='$productPaperType' and productPages='$productPrintType' order by productQty asc limit 0, 1";
}
else
{
    $qury  = "select DISTINCT productQty, productId, productCatId, productPrice, profiteMargine from tbl_product where productCatId='$prodcutMainCatId' and productSize='$prodcutSubCatId' and productPaper='$productPaperType' and productPages='$productPrintType' and finishSize='$productFinishSize'  order by productQty asc limit 0, 1";
}
//echo $qury;die();
$rs    = mysql_query($qury);
     $count = 0;
        while($rows=mysql_fetch_assoc($rs))
        {             
                //$product_id       = $rows['productId'];
                $productId        = $rows['productId'];
                $productCatId    = $rows['productCatId'];
                $qty              = $rows['productQty'];
                $proBuyPrice      = $rows['productPrice'];
                $profitMargin     = $rows['profiteMargine'];
                
                //Add margin in buying price 
                $margin                = ($proBuyPrice * $profitMargin)/100;
                $finalPriceWithOutVat  =  $proBuyPrice + $margin;
                
                if($productVatStatus=="Yes")
                {
                    
                    $qryForVatDetail   = "SELECT rId, vatvalue FROM tbl_vat";
                    $result2           = mysql_query($qryForVatDetail);
                    $rs2               = mysql_fetch_array($result2);
                    $vatRate           = $rs2['vatvalue'];
                    $productVatPrice   = ($finalPriceWithOutVat*$vatRate)/100;
                    $productVatPrice   = round($productVatPrice, 2);

                    $finalPriceWithVat = $finalPriceWithOutVat + $productVatPrice;
                    //echo "Product Price - ".$productPrice;
                }
                else
                {
                    $finalPriceWithVat = $finalPriceWithOutVat;
                }
                
                
                if($printoption=="free") 
                    {
                        $designCharges  = 0;
                    }
                    if($printoption=="paid")
                    {
                    $designCharges  = $tempProductDAO->getDesignCharges($productCatId);
                    }
                 
                $totalPricewithdesigncharges = $finalPriceWithVat + $designCharges + $productDeliveTime ;
                $totalPriceWithDesignCharge= $finalPriceWithOutVat + $designCharges;   
                $finalPrice = number_format($totalPriceWithDesignCharge, 2);
                $totalPrice = $totalPriceWithDesignCharge+$productVatPrice+$productDeliveTime;
				echo "<input type='hidden' name='proId' value='$productId'>
                        <input type='hidden' name='qty' id='qty'        value='$qty'>
                        <input type='hidden' name='pCatId'                  value='$productCatId'>    
                        <input type='hidden' name='productName'             value='$productName'>
                        <input type='hidden' name='productPaperSize'        value='$prodcutSubCatId'>
                        <input type='hidden' name='productPrintType'        value='$productPrintType'>
                        <input type='hidden' name='productPaperType'        value='$productPaperType'>
						<input type='hidden' name='productImage'            value='".$thumbImage."'>
                
                        <input type='hidden' name='productPriceWOutVat'     value='$totalPriceWithDesignCharge'> 
                        <input type='hidden' name='productPriceWithVat'     value='$finalPriceWithVat'>
						<input type='hidden' name='url'                     value='".$url."'>

						<input type='hidden' name='productDeliveTime' id='productionTime' value='".$productionTime."'  />
                        <input type='hidden' name='vatFlag'  value='No'>
                        <input type='hidden' name='vatStatus'   value='$productVatStatus'>
                        <input type='hidden' name='vatAmount'   value='$productVatPrice'>
					    <input type='hidden' id='vatAmt' name='vatAmt' value='$productVatPrice'  />
                        <input type='hidden' name='designCharges' value='$designCharges'>
                		<input type='hidden' name='totalpricewithdesign' value='$totalPricewithdesigncharges'>
                		<input type='hidden' id='sushil' name='sushil' value='$finalPriceWithOutVat'  />
                		
                        <input type='hidden' name='productDescription' value='$productDesc'>"; 
                        
                echo "<div class='productInfo' style='padding-left: 16px;'>
                                <div class='productLink' > 
								<span> Design Fee : <strong>&#163;".number_format($designCharges, 2)."</strong></span><br/>
								<span> Product  Price : <strong>&#163;".number_format($finalPriceWithOutVat, 2)."</strong></span><br/>
								<span> VAT : <strong>&#163;".number_format($productVatPrice, 2)."</strong></span><br/><br/>
								</div>
                               
							   <label class='pricelit' style='margin-bottom: 0px'>Total Amount:</label>
		                        <span class='pricing' style='padding-top: 0px'>&#163;".number_format($totalPrice, 2)."</span>
							   </div>
                            </div>";
               /*<a href='#'	class='order' style='margin-top: 10px' name='cart' value='addtocart'><i class='fa fa-cart-plus' style='font-size: 30px'></i>Order Now</a><table class='tabl' style='margin-bottom: 10px'>
                                <tr class='tri' >
				<td class='in'><a href='#'><div class='productPrice' style='text-align: center'><button type='submit' name='quote' class='productPrice' value='quotation' class='formbutton'>Quotation</button></div></a></td>
                                
							</tr>		
			    </table>*/
        }
       
    echo "--------------------";
?>


 <?php	
 
$prodcutSubCatId       = $_POST['prodcutSubCatId'];
$productPaperSize      = $_POST['productPaperSize'];
$productPrintType      = $_POST['productPrintType'];
$productPaperType      = $_POST['productPaperType'];
$productCatName        = $_POST['productCatName'];
$printoption           = $_POST['printoption'];
$workingDays           = "7-10 Working Days";      
echo "<label>$productPrintType</label>";

echo "--------------------";

//echo "<br />Test - ";
//die();
?>

<?php
$proPaperType      = $_POST['productPaperType'];
$proPrintType      = $_POST['productPrintType'];
$proFinishSize      = $_POST['productFinishSize'];
$prodcutMainCatId   = $_POST['prodCatId'];

//echo "select distinct(productPages) from tbl_product where productCatId='$prodcutMainCatId' and productSize='$prodcutSubCatId' and productPaper='$proPaperType' and productStatus='1' order by productCatId";
//die();
 
$productFinishSizeQuery  = "select distinct(finishSize) from tbl_product where productCatId='$prodcutMainCatId' and productSize='$prodcutSubCatId' and productPaper='$proPaperType' and productPages='$proPrintType' and productStatus='1' order by productCatId asc";
//$productPrintTypeSelect = "select distinct(productPages) from tbl_product where productCatId='$prodcutMainCatId' and productSize='$prodcutSubCatId' and productPaper='$proPaperType' and productStatus='1' order by productCatId limit 0,1";
//echo $productFinishSizeQuery;die();
$productFinishSizeResult = mysql_query($productFinishSizeQuery);
$dropDown = "";
$ddstr ="";
        while($row1=mysql_fetch_assoc($productFinishSizeResult))
        { 
    
                $productfinishSize = $row1['finishSize'];
                 //$price         = $row1['productPrice'];
                
                // $dropDown     .='<div class="turnAround" style="float: left;">
                    //             <a style="cursor: pointer;"  onclick="javascript: submitForm('."'".$productPaperType."'".')">';   
                        if($proFinishSize==$productfinishSize)
                        {
                            
                            $ddstr         .= '<li><label><input type="radio" checked name="productFinishSize1" value="'.$productfinishSize.'"  onclick="javascript: submitProductFinishSizeForm('."'".$productfinishSize."'".')"/> <span > '.$productfinishSize.'</span></label></li>';
                        }
                        else
                        {
                            $ddstr         .= '<li><label><input type="radio" name="productFinishSize1" value="'.$productfinishSize.'"  onclick="javascript: submitProductFinishSizeForm('."'".$productfinishSize."'".')"/> <span > '.$productfinishSize.'</span></label></li>';
                        }
                              
        }
       //echo $productPaperType;
echo $ddstr;
