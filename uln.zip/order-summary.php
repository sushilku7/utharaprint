<?php
ob_start();
session_start();
error_reporting (E_ALL ^ E_NOTICE);
include('includes/top_header.php');
$tempProductDAO    	  = new ProductDAO();
$tempProductMainCatDAO= new ProductMainCategoryDAO();
$tempProductCatDAO    = new ProductCatDAO();
$tempArr        	  = array();
$productCart    	  = array();
$tempFinalorderDAO = new FinalorderDAO();
$productId      	  = $_POST['proId'];
$productDeliveTime = $_POST['productDeliveTime'];
$tempOurbrandDAO   = new OurbrandDAO();
$tempOurbrandResult= $tempOurbrandDAO->OurbrandList();
$tempMemberDAO 	   = new MemberDAO();
$memberId   	   = $_SESSION['memberId'];
$tempMemberVO 	= $tempMemberDAO->getMemberDetails($memberId);
$memberEmail	= $tempMemberVO->getMemberEmail();
$samebs=$tempMemberVO->getSamebs();
$tempOurbrandDAO 	= new OurbrandDAO();
$tempOurbrandResult = $tempOurbrandDAO->OurbrandList();
$memberId   =   $_SESSION['memberId'];
$orderId= base64_decode($_POST['orderId']);
//echo $orderId;die();
######member details###############

$tempMemberVO = $tempMemberDAO->getMemberDetails($memberId);
$name=$tempMemberVO->getMemberName();
$compname=$tempMemberVO->getMemberCompanyName();
$memberEmail=$tempMemberVO->getMemberEmail();
$memberAddress1=$tempMemberVO->getMemberAddress1();
$memberAddress2=$tempMemberVO->getMemberAddress2();
$memberCity=$tempMemberVO->getMemberAddress3();
$memberCounty=$tempMemberVO->getMemberCounty();
$memberPostCode=$tempMemberVO->getMemberPostalCode();
$memberMobile=$tempMemberVO->getMemberMobile();

$sname=$tempMemberVO->getSmemberName();
$scompname=$tempMemberVO->getSmemberCompanyName();
$smemberEmail=$tempMemberVO->getSmemberEmail();
$smemberAddress1=$tempMemberVO->getSmemberAddress1();
$smemberAddress2=$tempMemberVO->getSmemberAddress2();
$smemberCity=$tempMemberVO->getSmemberAddress3();
$smemberCounty=$tempMemberVO->getSmemberCounty();
$smemberPostCode=$tempMemberVO->getSmemberPostalCode();
$smemberMobile=$tempMemberVO->getSmemberMobile();

##############order details ######################

$tempFinalOrderVO= $tempFinalorderDAO->orderdetails($orderId,$memberEmail);
//print_r($tempFinalOrderVO);die();
$orderId	=$tempFinalOrderVO->getOrderId();
$transId 	=$tempFinalOrderVO->getTxnid();
$orderDate	=$tempFinalOrderVO->getOrderDate();
$paymentMode    =$tempFinalOrderVO->getPaymentMode();
//$orderDate = date('d m Y H:i:s',strtotime($orderDate));


 if(isset($_POST['quote']) && $_POST['quote']!='')
            {
   
                $tempArr['PID']                 = $productId;
                $tempArr['PCID']                = $_POST['pCatId'];
                $tempArr['PNAME']               = $_POST['productName'];
                $tempArr['PIMAGE']              = $_POST['productImage'];
                $tempArr['PFINISH']             = $_POST['productPaperSize'];
                $tempArr['PSIZE']               = $_POST['productSize'];
                $tempArr['PPRINTTYPE']          = $_POST['productPrintType'];
                $tempArr['PPAPERTYPE']          = $_POST['productPaperType'];
                $tempArr['PDTIME']     			= $_POST['productDeliveTime'];
                $tempArr['PNOFSETS']            = $_POST['productNumSets'];
                $tempArr['PQTY']                = $_POST['qty'];
                $tempArr['PPRICEWOUTVAT']       = $_POST['productPriceWOutVat'];
                $tempArr['PPRICEWITHVAT']       = $_POST['productPriceWithVat'];
                $tempArr['VATRATE']             = $_POST['vatStatus'];
                $tempArr['VATFLAG']             = $_POST['vatStatus'];
                $tempArr['VATAMT']              = $_POST['vatAmount'];
                $tempArr['DESIGNCHARGES']       = $_POST['designCharges'];
                $tempArr['PRODUCTDESCRIPTION']  = $_POST['productDescription'];
                $tempArr['PRODUCTURL']          = $_POST['url'];


                 //echo count($_SESSION['shoppingCart']);die();
                if(count($_SESSION['shoppingCart'])>0)
                {  
                    $nof                  = count($_SESSION['shoppingCart']);
                    $productCart          = $_SESSION['shoppingCart'];
                    $productCart[$nof]    = $tempArr;
                }
                else
                {    
                    if(isset($productId) && $productId!="")
                    {
                        $productCart[0]    = $tempArr;  
                    }
                }
                $_SESSION['shoppingCart'] = $productCart;    
            header('location:quote.php');
            exit();
            }
//--./o-0/mjk,nhm-/echo $_POST['samebs'];die();

if(isset($_POST['billingAddress']) && $_POST['billingAddress']!='')
{
   
    $member=$_POST['member'];
    $result = $tempMemberDAO->updateMember($memberId);
    header('location:shopping-cart.php');
}

if(isset($_POST['shippingAddress']) && $_POST['shippingAddress']!='')
{
   
    $member=$_POST['member'];
    $result = $tempMemberDAO->updateMember($memberId);
    header('location:shopping-cart.php');
}
  
if(isset($_POST['proceed']) && $_POST['proceed']=='Order Proceed')
{
	if(count($_SESSION['shoppingCart'])>0)
        { 
    
    header('location:payment-proceed.php');
		}
		else{
		 header('location:shopping-cart.php');	
		}
}

if(isset($_POST['Remove']) && $_POST['Remove']='Remove')
{
                         $itemId = $_POST['productCatId'];
                        $shoppingCart = $_SESSION['shoppingCart'];
			$arr['shoppingCart'] = $shoppingCart;
			for($j=0;$j<count($shoppingCart);$j++)
			{
                            
			$productId = $shoppingCart[$j]['PID'];	
				if($productId==$itemId)
				{
					$rowId = $j;
				}		
			}
                        unset($shoppingCart[$rowId]);                        
			$shoppingCart = array_values($shoppingCart);
			$_SESSION['shoppingCart'] = $shoppingCart;
}

if(isset($_POST['cart']) && $_POST['cart']=="addtocart")
{   
        $tempArr['PID']                 = $productId;
        $tempArr['PCID']                = $_POST['pCatId'];
        $tempArr['PNAME']               = $_POST['productName'];
        $tempArr['PIMAGE']              = $_POST['productImage'];
        $tempArr['PFINISH']             = $_POST['productPaperSize'];
        $tempArr['PFINISHSIZE']         = $_POST['productFinishSize'];
        $tempArr['PSIZE']               = $_POST['productSize'];
        $tempArr['PPRINTTYPE']          = $_POST['productPrintType'];
        $tempArr['PPAPERTYPE']          = $_POST['productPaperType'];
        $tempArr['PDTIME']     		    = $_POST['productDeliveTime'];
        $tempArr['PNOFSETS']            = $_POST['productNumSets'];       
        $tempArr['PQTY']                = $_POST['qty'];
        $tempArr['PPRICEWOUTVAT']       = $_POST['productPriceWOutVat'];
        $tempArr['PPRICEWITHVAT']       = $_POST['productPriceWithVat'];
        $tempArr['VATRATE']             = $_POST['vatStatus'];
        $tempArr['VATFLAG']             = $_POST['vatStatus'];
        $tempArr['VATAMT']              = $_POST['vatAmount'];
        $tempArr['DESIGNCHARGES']       = $_POST['designCharges'];
        $tempArr['PRODUCTDESCRIPTION']  = $_POST['productDescription'];
        $tempArr['PRODUCTURL']          = $_POST['url'];

         //echo count($_SESSION['shoppingCart']);die();
        if(count($_SESSION['shoppingCart'])>0)
        {  
            $nof                  = count($_SESSION['shoppingCart']);
            $productCart          = $_SESSION['shoppingCart'];
            $productCart[$nof]    = $tempArr;
        }
        else
        {    
            if(isset($productId) && $productId!="")
            {
                $productCart[0]    = $tempArr;  
            }
        }
        $_SESSION['shoppingCart'] = $productCart;     
        //session_destroy($_SESSION['shoppingCart']);
        
         if(empty($_SESSION['memberId']) && $_SESSION['memberId']=='')
                { 
        
                 header('location:login.php');
                }
}


if(empty($_SESSION['memberId']) && $_SESSION['memberId']=='')
    { 
                 header('location:login.php');
                }
//print_r($_SESSION['shoppingCart']);die();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="robots" content="noodp, noydir" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width; initial-scale=1.0; maximum-scale=1.0">
    <!--css-->
    <link rel="icon" type="image/png" href="favicon-32x32.png" sizes="32x32" />
	
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/responsive.css">
    
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
   
		<script type="text/javascript" src="js/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
    <!--css-->
                
	<style>
	
		* { -webkit-box-sizing: border-box; -moz-box-sizing: border-box; box-sizing: border-box; }
*:before, *:after { -webkit-box-sizing: inherit; -moz-box-sizing: inherit; box-sizing: inherit; }


	</style>
        <title>Uthara Print order Summary | London </title>
</head>

<body>

    <body><div class="mainCon">
        <?php include 'header.php'; ?>
        
      	<div class="content">
				
				<div class="lineheight" id="line"></div><div class="lineheight"></div>
                                
            <p style="margin-left:80px; font-family: Montserrat;">Order Summary</p>                    
            <p style="font-weight: 600; color: #294b8a; font-size: 22px; font-family: Montserrat; margin-left:80px;">Your Order Placed Successfully!</p>                  
          
          <!-- Order summary start-->
          
          
          <div id="ordersummary" style="width:90%; border:solid #ccc 1px; color:#000; padding:20px; margin-left:auto; margin-right:auto; margin-top:25px; border-radius:10px; font-family: Montserrat;">
            
          <div id="ordersummaryleft" style="width:70%; border-right:solid #999 1px; float:left;">
              
              <p>
                  <?php
		 echo "<h4 style='font-family: Montserrat; font-weight:600;'>Your Order Details</h4>
                  <h5 style='font-family: Montserrat;'>Order No :UPL#$orderId</h5>
                  <h5 style='font-family: Montserrat;'>Order Date & Time : $orderDate </h5>
                  <h5 style='font-family: Montserrat;'>Payment Mode : $paymentMode</h5>
				
              </p>
              <hr>
              <p>";
                                  
                               $netTotal=0.00;
                               $totalVatAmt= 0.00;
                               $totalPriceWithVat=0.00;
                        if(isset($_SESSION['shoppingCart'])  && count($_SESSION['shoppingCart'])>0)
                                                 {
                                                         $shoppingCart     = $_SESSION['shoppingCart'];
                                                         $totalNetAmount   = 0.00;
                                                         $totalVatPrice    = 0.00;
                                                         $designCharges    = 0.00;
                                                         $ttllDsgnChrges   = 0.00;
                                                         //$productNumSets = "NA";
                                                         for($j=0;$j<count($shoppingCart);$j++)
                                                         {
                                                                 $productId                  = $shoppingCart[$j]['PID'];
                                                                 $productName                = $shoppingCart[$j]['PNAME'];
                                                                 $productImage               = $shoppingCart[$j]['PIMAGE'];
                                                                 $productFinish              = $shoppingCart[$j]['PFINISH'];
                                                                 $productPrintType           = $shoppingCart[$j]['PPRINTTYPE'];
                                                                 $productPaperType           = $shoppingCart[$j]['PPAPERTYPE'];
                                                                 $productDeliveryTime        = $shoppingCart[$j]['PDTIME'];
                                                                 $productNumSets             = $shoppingCart[$j]['PNOFSETS'];
                                                                 $url                        = $shoppingCart[$j]['PRODUCTURL'];
                                                                 $productQty                 = $shoppingCart[$j]['PQTY'];
                                                                 $productCatId                = $shoppingCart[$j]['PCID'];
                                                                 $prodSize                   = $shoppingCart[$j]['PSIZE'];
                                                                
                                                                 $productDesc       = $shoppingCart[$j]['PRODUCTDESCRIPTION'];

                                                                 $designCharges     = $shoppingCart[$j]['DESIGNCHARGES'];
                                                                 $ttllDsgnChrges   += $shoppingCart[$j]['DESIGNCHARGES'];

                                                                 $productPrice      = $shoppingCart[$j]['PPRICEWOUTVAT'];
                                                                 $totalNetAmount   += $shoppingCart[$j]['PPRICEWOUTVAT'];

                                                                 $prdcttprcewthvt   = $shoppingCart[$j]['PPRICEWITHVAT'];
                                                                 $totalAmount      += $shoppingCart[$j]['PPRICEWITHVAT'];
                                                                 $vatflag           = $shoppingCart[$j]['VATFLAG'];
                                                                 $totalVatAmt      += $shoppingCart[$j]['VATAMT'];

                                                                 $ttlPrice         =  $productPrice;
                                                                 $netTotal        += $ttlPrice;
                                                                 $ttlPrice         = number_format($ttlPrice, 2);

                                                                 if($vatflag=="Yes")
                                                                     $vatRate        = $shoppingCart[$j]['VATRATE'];

                                                                 //$vatAmount          = $totalAmount - $totalNetAmount;



                                                                 $totalPriceWithVat  = $netTotal+$totalVatAmt;

                                                                 $productNameWOsize  = explode("_", $productName);
                                                                 $productName = $productNameWOsize[0];
                                                                 if(isset($productNameWOsize[1]) && $productNameWOsize[1]!="")
                                                                 {
                                                                              $productSize = $productNameWOsize[1];
                                                                 }
                                                                 else
                                                                 {
                                                                                             if(strstr($productName, "("))
                                                                                             {
                                                                                                 $ftbkt       = strpos($productName, "(");                                                    
                                                                                                 $ltbkt       = strpos($productName, ")");
                                                                                                 $ltbkt       = $ltbkt - $ftbkt;
                                                                                                 $productSize = substr($productName,$ftbkt+1,$ltbkt-1);                                                    
                                                                                                 $hidProductSize = substr($productName,$ftbkt,$ltbkt+1);
                                                                                                 $productName = str_replace($hidProductSize, " ", $productName);
                                                                                             }
                                                                                             else
                                                                                             {
                                                                                                 $productSize = $productName;
                                                                                             }

                                                                 }

                                                               if($productNumSets=="")
                                                               {
                                                                   $productNumSets = "NA";
                                                               }
															   
								 if($productDeliveryTime==0)
									{
									$productDeliveryTime="Standard Delivery 5/6 working days";
                                                                        }
                                                                        elseif($productDeliveryTime==15)
									{
									$productDeliveryTime="3-5 working days ";  
									}
									else
									{
									$productDeliveryTime="Express same day ";   
									}
                                                             
                                                                        
                                                            //echo $productCatId;  die();                                                        
                                                            if($productCatId=='237')
                                                            {
                                                             $productSize= $prodSize;
                                                            }            
                                                            $netTotal    = number_format($totalNetAmount, 2);
                                                            $totalVatAmt = number_format($totalVatAmt, 2);
                                                            $totalPriceWithVat = number_format($totalPriceWithVat, 2);
                                                         echo "<h4 style='font-family: Montserrat; font-weight:600'>$productName</h4><div class='col-lg-12' style='border-radius: 10px; font-family:Montserrat'> 
							
					<div class='single-team-member'>
                                        <table class='tabl'>
						<tr class='tri'>
							<td rowspan='5' colspan='2'class='shopimage'><div ><a href='$url'><img src='upload/productcategory/$productImage' alt='' class='shopimage'/></a></div></td>
							<td class='Product1'>&nbsp;&nbsp;Product Spec.</td><td class='Product2'>$productSize&nbsp;</td>
						</tr>
								
						<tr class='tri'>
							<td class='Product1'>&nbsp;&nbsp;Paper Type</td><td class='Product2'> $productPaperType</td>
						</tr>
						<tr class='tri'>
							<td class='Product1'>&nbsp;&nbsp;Printing</td><td class='Product2'> $productPrintType</td>
						</tr>
						<tr class='tri'>
							<td class='Product1'>&nbsp;&nbsp;Quantity</td><td class='Product2'> $productQty</td>
						</tr>		
						<tr class='tri'>
							<td class='Product1'>&nbsp;&nbsp;Delivery Time</td><td class='Product2'> $productDeliveryTime</td>
						</tr><br/>
							</table>
								
							<div style='display: flex;justify-content: space-between'>
							
							 
							
							
							<form id='delForm'  method='POST' action='#' enctype='application/x-www-form-urlencoded'>
                            
                            <input type='hidden' id='productCatId' name='productCatId' value='$productId'  />
                            
                            
                            

							
							<div style='display: flex;justify-content: space-between'>
							
							
							
							
							</div>
						
                        
                                                            
							   </form> 
							</div>
								</div>
								
								<br/>
							     
						</div>";
                                                         }
                                                 }
                                                 else
                                                 {
                                                   //echo "Product Cart Empty,Please select product.";
                                                   echo "<div class='col-lg-12' style='border: #ccc solid 1px;padding-top: 0px; border-radius: 10px'><h3 class='shophead'></h3> 
							
					<div class='single-team-member'>
							<table class='tabl'>
							
						<tr class='tri'>
							<td class='Product1'>&nbsp;</td><td class='Product2'> &nbsp;</td>
						</tr>
						<tr class='tri'>
							<td class='Product1'>&nbsp;</td><td class='Product2'> Order Summary Empty, Please select product.</td>
						</tr>
						<tr class='tri'>
							<td class='Product1'>&nbsp;</td><td class='Product2'> &nbsp;</td>
						</tr>		
						<tr class='tri'>
							<td class='Product1'>&nbsp;</td><td class='Product2'> &nbsp;</td>
						</tr>
						</table>
						</div>
								
							
						</div>";
                                                 }
                                                 ?>
                      
				   
                    </p>
                    
              
          
             <p style="font-family: Montserrat; font-size:12px;">
                <br/> <i class="fa fa-thumbs-up" aria-hidden="true"></i> Thankyou for shopping with us!<br/>
                 <i class="fa fa-refresh" aria-hidden="true"></i> Check your mail regularly for the future update</p> 
              
              
             </div>
            
          <div id="ordersummaryright" style="width:30%; float:left; padding-left:20px; font-family: Montserrat; font-size:13px;">
              
             <?php
			 echo "<p>
                  <h4 style='font-family: Montserrat; font-weight:600; margin-top:15px;'>Your Billing Address</h4>
                  Full Name- $name,<br/>
                  Email ID- $memberEmail<br/>
                  Company Name - $compname<br/>
                  Address Line 1 -$memberAddress1<br/>
                  Address Line 2 - $memberAddress2<br/>
                  City/Town/Urban/Semi-Urban -$memberCity<br/>
                  County - $memberCounty<br/>
                  Post Code -$memberPostCode<br/>
                  Phone/Mobile - $memberMobile<br/>
                  
                  <h4 style='font-family: Montserrat; font-weight:600; margin-top:20px;'>Your shipping Address</h4>
                  Full Name- $sname,<br/>
                  Email ID- $smemberEmail<br/>
                  Company Name - $scompname<br/>
                  Address Line 1 - $smemberAddress1<br/>
                  Address Line 2 -$smemberAddress2<br/>
                  City/Town/Urban/Semi-Urban -$smemberCity<br/>
                  County - $smemberCounty<br/>
                  Post Code -$smemberPostCode<br/>
                  Phone/Mobile - $smemberMobile<br/>
              </p> ";
			 ?>
              <p align="left"><a href="#" style="font-family: Montserrat; font-weight:600;">Back To Update Address</a></p>
              
          <br/><br/>
          <p class="finished">
                  
                  <a href="thank-you.php" class="order" style="margin-top: 0px" name='finished' value='Finished'>Claim your offer!</a>
              </p>
          
          
          </div>
          
          
            <div style="clear:both"></div>
            
             
            
        </div>
        
        <!-- Order summary end-->                        
                                
             
                               
			
				
				 </div></div>
	
         <?php include 'footer.php'; ?>
		</div>
		
    <script type="text/javascript" src="js/function.js"></script>

		</body>

</html>