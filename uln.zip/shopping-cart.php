<?php
ob_start();
session_start();
error_reporting (E_ALL ^ E_NOTICE);
define("base_url","https://utharaprint-london.co.uk/");
include('includes/top_header.php');
$tempProductDAO    = new ProductDAO();
$tempProductMainCatDAO = new ProductMainCategoryDAO();
$tempProductCatDAO = new ProductCatDAO();
$tempArr        = array();
$productCart    = array();
$productId      = $_POST['proId'];
$productDeliveTime = $_POST['productDeliveTime'];
$tempOurbrandDAO = new OurbrandDAO();
$tempOurbrandResult = $tempOurbrandDAO->OurbrandList();
$tempMemberDAO = new MemberDAO();
$memberId   =   $_SESSION['memberId'];
$tempMemberVO = $tempMemberDAO->getMemberDetails($memberId);
$name=$tempMemberVO->getFirstName();
$memberEmail=$tempMemberVO->getMemberEmail();
$samebs=$tempMemberVO->getSamebs();
$tempOurbrandDAO = new OurbrandDAO();
$tempOurbrandResult = $tempOurbrandDAO->OurbrandList();
//unset($_SESSION['shoppingCart']);
//die();
//unset_session();
//session_destroy();

if(isset($_POST['billingAddress']) && $_POST['billingAddress']!='')
{
    
   
    $member=$_POST['member'];
    $result = $tempMemberDAO->updateMember($memberId);
    header('location:shopping-cart.php');
}

if(isset($_POST['shippingAddress']) && $_POST['shippingAddress']!='')
{
   
    $member=$_POST['member'];
    $result = $tempMemberDAO->updateMember($memberId);
    header('location:shopping-cart.php');
}
  
if(isset($_POST['proceed']) && $_POST['proceed']=='Order Proceed')
{
     $result = $tempMemberDAO->updateMember($memberId);
     
	if(count($_SESSION['shoppingCart'])>0)
        { 
    
    header('location:payment-proceed.php');
		}
		else{
		 header('location:shopping-cart.php');	
		}
}

if(isset($_POST['Remove']) && $_POST['Remove']='Remove')
{
                         $itemId = $_POST['productCatId'];
                        $shoppingCart = $_SESSION['shoppingCart'];
			$arr['shoppingCart'] = $shoppingCart;
			for($j=0;$j<count($shoppingCart);$j++)
			{
                            
			$productId = $shoppingCart[$j]['PID'];	
				if($productId==$itemId)
				{
					$rowId = $j;
				}		
			}
            unset($shoppingCart[$rowId]);                        
			$shoppingCart = array_values($shoppingCart);
			$_SESSION['shoppingCart'] = $shoppingCart;
}

if(isset($_POST['cart']) && $_POST['cart']=="addtocart")
{
        $tempArr['PID']                 = $productId;
        $tempArr['PCID']                = $_POST['pCatId'];
        $tempArr['PNAME']               = $_POST['productName'];
        $tempArr['PIMAGE']              = $_POST['productImage'];
        $tempArr['PFINISH']             = $_POST['productPaperSize'];
        $tempArr['PPRINTTYPE']          = $_POST['productPrintType'];
        $tempArr['PPAPERTYPE']          = $_POST['productPaperType'];
        $tempArr['PDTIME']     		= $_POST['productDeliveTime'];
        $tempArr['PNOFSETS']            = $_POST['productNumSets'];       
        $tempArr['PQTY']                = $_POST['qty'];
        $tempArr['PPRICEWOUTVAT']       = $_POST['productPriceWOutVat'];
        $tempArr['PPRICEWITHVAT']       = $_POST['productPriceWithVat'];
        $tempArr['VATRATE']             = $_POST['vatStatus'];
        $tempArr['VATFLAG']             = $_POST['vatStatus'];
        $tempArr['VATAMT']              = $_POST['vatAmount'];
        $tempArr['DESIGNCHARGES']       = $_POST['designCharges'];
        $tempArr['PRODUCTDESCRIPTION']  = $_POST['productDescription'];
        $tempArr['PRODUCTURL']          = $_POST['url'];

         //echo count($_SESSION['shoppingCart']);die();
        if(count($_SESSION['shoppingCart'])>0)
        {  
            $nof                  = count($_SESSION['shoppingCart']);
            $productCart          = $_SESSION['shoppingCart'];
            $productCart[$nof]    = $tempArr;
        }
        else
        {    
            if(isset($productId) && $productId!="")
            {
                $productCart[0]    = $tempArr;  
            }
        }
        $_SESSION['shoppingCart'] = $productCart;     
        //session_destroy($_SESSION['shoppingCart']);
        if(empty($_SESSION['memberId']) && $_SESSION['memberId']=='')
                { 
        
                 header('location:login.php');
                }
}


if(isset($_POST['quote']) && $_POST['quote']!='')
		{
			$tempArr['PID']                 = $productId;
        $tempArr['PCID']                = $_POST['pCatId'];
        $tempArr['PNAME']               = $_POST['productName'];
        $tempArr['PIMAGE']              = $_POST['productImage'];
        $tempArr['PFINISH']             = $_POST['productPaperSize'];
        $tempArr['PFINISHSIZE']         = $_POST['productFinishSize'];
        $tempArr['PSIZE']               = $_POST['productSize'];
        $tempArr['PPRINTTYPE']          = $_POST['productPrintType'];
        $tempArr['PPAPERTYPE']          = $_POST['productPaperType'];
        $tempArr['PDTIME']     		    = $_POST['productDeliveTime'];
        $tempArr['PNOFSETS']            = $_POST['productNumSets'];       
        $tempArr['PQTY']                = $_POST['qty'];
        $tempArr['PPRICEWOUTVAT']       = $_POST['productPriceWOutVat'];
        $tempArr['PPRICEWITHVAT']       = $_POST['productPriceWithVat'];
        $tempArr['VATRATE']             = $_POST['vatStatus'];
        $tempArr['VATFLAG']             = $_POST['vatStatus'];
        $tempArr['VATAMT']              = $_POST['vatAmount'];
        $tempArr['DESIGNCHARGES']       = $_POST['designCharges'];
        $tempArr['PRODUCTDESCRIPTION']  = $_POST['productDescription'];
        $tempArr['PRODUCTURL']          = $_POST['url'];

         //echo count($_SESSION['shoppingCart']);die();
        if(count($_SESSION['shoppingCart'])>0)
        {  
            $nof                  = count($_SESSION['shoppingCart']);
            $productCart          = $_SESSION['shoppingCart'];
            $productCart[$nof]    = $tempArr;
        }
        else
        {    
            if(isset($productId) && $productId!="")
            {
                $productCart[0]    = $tempArr;  
            }
        }
        $_SESSION['shoppingCart'] = $productCart; 
			header('location:quote.php');
			exit();
}

if(empty($_SESSION['memberId']) && $_SESSION['memberId']=='')
                { 
        
                 header('location:login.php');
                }
//print_r($_SESSION['shoppingCart']);die();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="robots" content="noodp, noydir" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width; initial-scale=1.0; maximum-scale=1.0">
    <!--css-->
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/responsive.css">
    
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
   <script type="text/javascript" src="js/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
    <!--css-->
    
    <script type="text/javascript">
		    $(document).ready(function(e){
				var checked = true;
				
				$("#samebs").change(function(e) {
					if($("#samebs").is(":checked")){
					    
						$("#shippAddr").fadeOut(400);
						$("#sfName").val($("#fName").val());
						$("#scompanyName").val($("#companyName").val());
						$("#saddress1").val($("#address1").val());
						$("#smemberEmail").val($("#memberEmail").val());
						$("#saddress2").val($("#address2").val());
						$("#smemberEmail").val($("#memberEmail").val());
						$("#sphoneNumber").val($("#phoneNumber").val());
						$("#scity").val($("#city").val());
						$("#scounty").val($("#county").val());
						$("#spostCode").val($("#postCode").val());
					}else{
						$("#shippAddr").slideDown(800);
					}
					
                });
				
				$("#fName").change(function(e) {
					if($("#samebs").is(":checked")){
						$("#sfName").val($("#fName").val());
					}
                });
				$("#companyName").change(function(e) {
					if($("#samebs").is(":checked")){
						$("#scompanyName").val($("#companyName").val());
					}
                });
				$("#address1").change(function(e) {
					if($("#samebs").is(":checked")){
						$("#saddress1").val($("#address1").val());
					}
                });
				
				$("#address2").change(function(e) {
					if($("#samebs").is(":checked")){
						$("#saddress2").val($("#address2").val());
					}
                });
                $("#city").change(function(e) {
					if($("#samebs").is(":checked")){
						$("#scity").val($("#city").val());
					}
                });
				$("#county").change(function(e) {
					if($("#samebs").is(":checked")){
						$("#scounty").val($("#county").val());
					}
                });
				$("#memberEmail").change(function(e) {
					if($("#samebs").is(":checked")){
						$("#smemberEmail").val($("#memberEmail").val());
					}
                });
				$("#phoneNumber").change(function(e) {
					if($("#samebs").is(":checked")){
						$("#sphoneNumber").val($("#phoneNumber").val());
					}
                });
				$("#postCode").change(function(e) {
					if($("#samebs").is(":checked")){
						$("#spostCode").val($("#postCode").val());
					}
                });
				
			});
		</script>
    
	<script src="js/html5.js"></script>
        
        <script type="text/javascript">
                    function validateBillingDetails()
                    {                        
                      //alert('hi');
						
                        if(document.getElementById('fName').value=='')
                        {
                         
                         alert("Please Enter First Name.");
                         document.getElementById('fName').focus();
                         return false;
                        }
                        if(document.getElementById('memberEmail').value=='')
                        {
                         alert("Please Enter Email Id.");
                         document.getElementById('memberEmail').focus();
                         return false;
                        }
                        if(document.getElementById('address1').value=='')
                        {
                         alert("Please Enter Address.");
                         document.getElementById('address1').focus();
                         return false;
                        }
                        if(document.getElementById('county').value=='')
                        {
                         alert("Please Enter State.");
                         document.getElementById('county').focus();
                         return false;
                        }
                        if(document.getElementById('postCode').value=='')
                        {
                         aler("Please Enter Postal Code.");
                         document.getElementById('postCode').focus();
                         return false;
                        }
                    if(document.getElementById('phoneNumber').value=='')
                        {
                         alert("Please Enter Phone Number.");
                         document.getElementById('phoneNumber').focus();
                         return false;
                        }                        
                        if(document.getElementById('sfName').value=='')
                        {
                         alert("Please Enter Shipping first Name.");
                         document.getElementById('sfName').focus();
                         return false;
                        }
                        if(document.getElementById('smemberEmail').value=='')
                        {
                         alert("Please Enter Shipping Email Id.");
                         document.getElementById('smemberEmail').focus();
                         return false;
                        }
                        if(document.getElementById('saddress1').value=='')
                        {
                         alert("Please Enter Shipping Address.");
                         document.getElementById('saddress1').focus();
                         return false;
                        }
                        if(document.getElementById('scounty').value=='')
                        {
                         alert("Please Enter Shipping County.");
                         document.getElementById('scounty').focus();
                         return false;
                        }
                        if(document.getElementById('spostCode').value=='')
                        {
                         alert("Please Enter Shipping Postal Code.");
                         document.getElementById('spostCode').focus();
                         return false;
                        }
                        if(document.getElementById('sphoneNumber').value=='')
                        {
                         alert("Please Enter Shipping Phone Number.");
                         document.getElementById('sphoneNumber').focus();
                         return false;
                        }
                         
			
                    }
        </script> 
        <script type="text/javascript">
        function deleteProdcutFromShoppingCart(pId)
        {            
            document.getElementById('productId').value = pId;
            document.getElementById("paymentForm").submit();
            
            
        }
    </script>
         <script type="text/javascript">
		
                function copyFromBillingAddress()
                {
                   
                        if(document.getElementById('samebs').checked=="1")
                        {
                           
                                document.getElementById('phoneNumber').focus();
                                //document.getElementById('abc').style.display="none";
                                
                                var fName = document.getElementById('fName').value; 
                                var memberEmail = document.getElementById('memberEmail').value;
                                var address1 = document.getElementById('address1').value;
                                var address2 = document.getElementById('address2').value;
                                var city     = document.getElementById('city').value;
                                var country  = document.getElementById('country').value;
                                var county   = document.getElementById('county').value;
                                var postCode = document.getElementById('postCode').value;
                                var phone = document.getElementById('phoneNumber').value;
                                 
                                document.getElementById('sfName').value 	            = fName;
                                document.getElementById('smemberEmail').value 	        = memberEmail;
                                document.getElementById('saddress1').value              = address1;
                                document.getElementById('saddress2').value              = address2;
                                document.getElementById('scity').value 		            = city;
                                document.getElementById('scountry').value 		        = country;
                                document.getElementById('scounty').value 		        = county;
                                document.getElementById('spostCode').value              = postCode;
                                document.getElementById('sphoneNumber').value 	        = phone;
                                
                        }
                        else
                        {
                           
                            
				                document.getElementById('sfName').value = '';
                                document.getElementById('smemberEmail').value= '';
                                document.getElementById('saddress1').value= '';
                                document.getElementById('saddress2').value= '';
                                document.getElementById('scity').value= '';
                                document.getElementById('scountry').value= '';
                                document.getElementById('scounty').value= '';
                                document.getElementById('spostCode').value= '';
                                document.getElementById('sphoneNumber').value= '';
                                
                        }
                 
                }
                
                
                 function checkCheckboxFromBillingAddress()
                {
                   
                        if(document.getElementById('samebs').checked=="1")
                        {
                           
                                document.getElementById('phoneNumber').focus();
                                
                                var fName = document.getElementById('fName').value; 
                                var memberEmail = document.getElementById('memberEmail').value;
                                var address1 = document.getElementById('address1').value;
                                var address2 = document.getElementById('address2').value;
                                var city     = document.getElementById('city').value;
                                var country  = document.getElementById('country').value;
                                var county   = document.getElementById('county').value;
                                var postCode = document.getElementById('postCode').value;
                                var phone = document.getElementById('phoneNumber').value;
                                 
                                document.getElementById('sfName').value 	            = fName;
                                document.getElementById('smemberEmail').value 	        = memberEmail;
                                document.getElementById('saddress1').value              = address1;
                                document.getElementById('saddress2').value              = address2;
                                document.getElementById('scity').value 		            = city;
                                document.getElementById('scountry').value 		        = country;
                                document.getElementById('scounty').value 		        = county;
                                document.getElementById('spostCode').value              = postCode;
                                document.getElementById('sphoneNumber').value 	        = phone;
                                
                        }
                }
                </script>
                <title>Uthara Print - Shopping Cart</title>
	<style>
	
		* { -webkit-box-sizing: border-box; -moz-box-sizing: border-box; box-sizing: border-box; }
*:before, *:after { -webkit-box-sizing: inherit; -moz-box-sizing: inherit; box-sizing: inherit; }

		
	</style>
       
</head>

<body>

    <body><div class="mainCon">
        <?php include 'header.php'; ?>
         
		  
		<div class="lineheight" id="line"></div><div class="lineheight"></div>
            <p style="margin-left:80px;font-family: Montserrat;">Shopping Cart</p>                    
            <p style="font-weight: 600; color: #294b8a; font-size: 22px; font-family: Montserrat; margin-left:80px;">Your Order Billing And Shipping</p>                    
			 
                                
            <div class="container-sm" style="border: 1px solid #ccc; border-radius: 10px;">
                <img src="images/bill6-london.jpg" alt="Online delivery" />
			
				
			 <div class="row"  >
				 
						 
			  <div class="col-sm-7 col-xs-12">
			<h3 class="shophead well well-md text-center" style="color: #04579A;">Your Order</h3>
		
					 
                               <?php
                                $totalNetAmount   = 0.00;
                               $totalVatPrice    = 0.00;
                               $designCharges    = 0.00;
                               $ttllDsgnChrges   = 0.00;
                               $totalVatAmt      =0.00;
                               $netTotal         = 0.00;
                               $totalPriceWithVat = 0.00;
                               $totalNetAmount   = 0.00;
                               $totalVatPrice    = 0.00;
                               $designCharges    = 0.00;
                        if(isset($_SESSION['shoppingCart'])  && count($_SESSION['shoppingCart'])>0)
                                                 {
                                                         $shoppingCart     = $_SESSION['shoppingCart'];
                                                         
                                                         //$productNumSets = "NA";
                                                         for($j=0;$j<count($shoppingCart);$j++)
                                                         {
                                                                 $productId                  = $shoppingCart[$j]['PID'];
                                                                 $productName                = $shoppingCart[$j]['PNAME'];
                                                                 $productImage               = $shoppingCart[$j]['PIMAGE'];
                                                                 $productFinish              = $shoppingCart[$j]['PFINISH'];
                                                                 $productPrintType           = $shoppingCart[$j]['PPRINTTYPE'];
                                                                 $productPaperType           = $shoppingCart[$j]['PPAPERTYPE'];
                                                                 $productDeliveryTime        = $shoppingCart[$j]['PDTIME'];
                                                                 $productNumSets             = $shoppingCart[$j]['PNOFSETS'];
                                                                 $url                        = $shoppingCart[$j]['PRODUCTURL'];
                                                                 $productQty                 = $shoppingCart[$j]['PQTY'];

                                                                 $productDesc       = $shoppingCart[$j]['PRODUCTDESCRIPTION'];

                                                                 $designCharges     = $shoppingCart[$j]['DESIGNCHARGES'];
                                                                 $ttllDsgnChrges   += $shoppingCart[$j]['DESIGNCHARGES'];

                                                                 $productPrice      = $shoppingCart[$j]['PPRICEWOUTVAT'];
                                                                 $totalNetAmount   += $shoppingCart[$j]['PPRICEWOUTVAT'];

                                                                 $prdcttprcewthvt   = $shoppingCart[$j]['PPRICEWITHVAT'];
                                                                 $totalAmount      += $shoppingCart[$j]['PPRICEWITHVAT'];
                                                                 $vatflag           = $shoppingCart[$j]['VATFLAG'];
                                                                 $totalVatAmt      += $shoppingCart[$j]['VATAMT'];

                                                                 $ttlPrice         =  $productPrice;
                                                                 $netTotal        += $ttlPrice;
                                                                 $ttlPrice         = number_format($ttlPrice, 2);

                                                                 if($vatflag=="Yes")
                                                                     $vatRate        = $shoppingCart[$j]['VATRATE'];

                                                                 //$vatAmount          = $totalAmount - $totalNetAmount;



                                                                 $totalPriceWithVat  = $netTotal+$totalVatAmt;

                                                                 $productNameWOsize  = explode("_", $productName);
                                                                 $productName = $productNameWOsize[0];
                                                                 if(isset($productNameWOsize[1]) && $productNameWOsize[1]!="")
                                                                 {
                                                                              $productSize = $productNameWOsize[1];
                                                                 }
                                                                 else
                                                                 {
                                                                                             if(strstr($productName, "("))
                                                                                             {
                                                                                                 $ftbkt       = strpos($productName, "(");                                                    
                                                                                                 $ltbkt       = strpos($productName, ")");
                                                                                                 $ltbkt       = $ltbkt - $ftbkt;
                                                                                                 $productSize = substr($productName,$ftbkt+1,$ltbkt-1);                                                    
                                                                                                 $hidProductSize = substr($productName,$ftbkt,$ltbkt+1);
                                                                                                 $productName = str_replace($hidProductSize, " ", $productName);
                                                                                             }
                                                                                             else
                                                                                             {
                                                                                                 $productSize = $productName;
                                                                                             }

                                                                 }

                                                               if($productNumSets=="")
                                                               {
                                                                   $productNumSets = "NA";
                                                               }
															   
								 if($productDeliveryTime==0)
									{
									$productDeliveryTime="Standard Delivery 5/6 working days";
                                                                        }
                                                                        elseif($productDeliveryTime==15)
									{
									$productDeliveryTime="3-5 working days ";  
									}
									else
									{
									$productDeliveryTime="Express same day ";   
									}
                                                                        
                                                            $netTotal    = number_format($totalNetAmount, 2);
                                                            $totalVatAmt = number_format($totalVatAmt, 2);
                                                            $totalPriceWithVat = number_format($totalPriceWithVat, 2);
                                                         
                    echo "<div class='col-lg-12 borderbox' >
                    <h3 class='shophead'>$productName</h3> 
							
					<div class='single-team-member'>
                                        <table class='tabl'>
						<tr class='tri'>
							<td rowspan='5' colspan='2' class='shopimage'><span ><div><a href='$url'><img src='upload/productcategory/$productImage' alt='' class='shopimage'/></a></div> </span></td>
							<td class='Product1'><span>&nbsp;&nbsp;Product Spec.</span></td><td class='Product2'>$productSize</td>
						</tr>
								
						<tr class='tri'>
							<td class='Product1'><span>&nbsp;&nbsp;Paper Type</span></td><td class='Product2'> $productPaperType</td>
						</tr>
						<tr class='tri'>
							<td class='Product1'><span>&nbsp;&nbsp;Printing</span></td><td class='Product2'> $productPrintType</td>
						</tr>
						<tr class='tri'>
							<td class='Product1'><span>&nbsp;&nbsp;Quantity</span></td><td class='Product2'> $productQty</td>
						</tr>		
						<tr class='tri'>
							<td class='Product1'><span>&nbsp;&nbsp;Delivery Time</span></td><td class='Product2'> $productDeliveryTime</td>
						</tr><br/>
							</table>
								<br/>
							<div style='display: flex;justify-content: space-between'>
							<div class='cost' style='text-align:center; font-size:18px;'>&pound;".number_format($productPrice, 2)."</div> 
							
						
                                                        <form id='delForm'  method='POST' action='#' enctype='application/x-www-form-urlencoded'>
                                                        <a href=''><input type='submit' name='Remove' value='Remove' class='cost' style='width:100px'></a>
                                                                 <input type='hidden' id='productCatId' name='productCatId' value='$productId'  />
                                                          
							   </form> 
							</div>
								</div>
								
								<br/>
							     
						</div>";
                                                         }
                                                 }
                                                 else
                                                 {
                                                   //echo "Product Cart Empty,Please select product.";
                                                   echo "<div class='col-lg-12' style='padding: 20px;border: #ccc solid 1px;padding-top: 8px;border-radius: 10px; margin-top:15px; box-shadow: 0 5px 1px rgba(0, 0, 0, 0.1);'><h3 class='shophead'></h3> 
							
					<div class='single-team-member'>
						<table class='tabl'>
							
						<tr class='tri'>
							<td class='Product1'>&nbsp;</td><td class='Product2'> &nbsp;</td>
						</tr>
						<tr class='tri'>
							<td class='Product1'>&nbsp;</td><td class='Product2'> Product Cart Empty,Please select product.</td>
						</tr>
						<tr class='tri'>
							<td class='Product1'>&nbsp;</td><td class='Product2'> &nbsp;</td>
						</tr>		
						<tr class='tri'>
							<td class='Product1'>&nbsp;</td><td class='Product2'> &nbsp;</td>
						</tr><br/>
						</table>
						</div>
								
							
						</div>";
                                                 }
                                                 ?>
				
						
				   
				<!---------------------------------->
			   <?php
                           
                           echo "<div class='col-lg-12 borderbox' >
				<form name='paymentProceed' id='paymentProceed' method='post' action='' enctype='' >
               <input type='hidden' name='member' value='$memberId'>
                          <input type='hidden' name='productAmount' value='<?php echo $totalPriceWithVat ; ?>' />
                            <input type='hidden' name='productName' value='<?php echo $productName ; ?>' />
                            <h3 class='shophead text-center well well-sm' style='color: #04579A'>Overview</h3> 
							<label class='label'>
								<span class='in'>Total articles</span><span style='text-align: right;padding-right: 30px' class='in'>&pound;$netTotal</span></label>
							<label class='label'>
								<span class='in'>Delivery</span><span style='text-align: right;padding-right: 30px' class='head'>Free</span></label><hr style='width:50%;margin:2%;float: right;color:currentColor'/>
							<label class='label'>
								<span class='in'>Sub Total</span><span style='text-align: right;padding-right: 30px' class='in'>&pound;$netTotal</span></label>
							<label class='label'>
								<span class='in'>VAT</span><span style='text-align: right;padding-right: 30px' class='in'>&pound;$totalVatAmt</span></label>
							<hr style='width:50%;margin:2%;float: right;color:currentColor'/>

							<label class='label'>
								<span class='in'> <strong>Total</strong> </span><span style='text-align: right;padding-right: 30px' class='in'><strong>&pound;$totalPriceWithVat</strong></span></label>
								
								<br/>
							
							<div class='productinfo' style='width:100%;justify-content:center;clear:both;margin:auto'>
								<div style='margin: 10px 0'>
                           <center> <a href='index.php'><input type='button' value='Shop More' class='shopmore'/></a>
							
								</div>							</div>
						
				   </form></div>";
                           ?>                
</div>  
			   
			<div class="col-sm-5 col-xs-12">
                                <h3 class="shophead well well-md text-center" style="color: #04579A">Billing and Shipping</h3>
		
         <form name="billingForm" id="billingForm" method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>" enctype="" >
			 
	
		
				
			    <div class="col-xs-13">
					    <input type="hidden" name="member" value="<?php echo $memberId; ?>">		
							
                             <div class="col-lg-6">     
                             <label style="padding-left: 10px;color: #206eac">Full Name</label><br/>  
                             <input type="text" name="fName"  id="fName" class="puts"  value="<?php echo $tempMemberVO->getMemberName(); ?>" required>
                             </div>
                             
                             <div class="col-lg-6">     
                             <label style="padding-left: 10px;color: #206eac">Email</label><br/>      
                             <input type="text" name="memberEmail"  id="memberEmail" class="puts"  value="<?php echo $tempMemberVO->getMemberEmail(); ?>" required>
                             </div>
                                            
                             <div class="col-lg-12">    
                             <label style="padding-left: 10px;color: #206eac">Address Line 1</label><br/>        
                             <input type="text" name="address1" id="address1" class="puts" value="<?php echo $tempMemberVO->getMemberAddress1(); ?>" required>
                             </div>
                                          
                             <div class="col-lg-12">        
                             <label style="padding-left: 10px;color: #206eac">Address Line 2</label><br/>  
                             <input type="text" name="address2" id="address2" class="puts"  value="<?php echo $tempMemberVO->getMemberAddress2(); ?>"> 
                             </div>
                                              
                             <div class="col-lg-6">  
                             <label style="padding-left: 10px;color: #206eac">City/Town</label><br/>   
							 <input type="text" name="city" id="city" class="puts"  value="<?php echo $tempMemberVO->getMemberAddress3(); ?>" >
							 </div>
							 
							 <div class="col-lg-6">  
                             <label style="padding-left: 10px;color: #206eac">Country</label><br/>   
							 <input type="text" name="country" id="country" class="puts"  value="<?php echo $tempMemberVO->getMemberCountry(); ?>" >
							 </div>
							 
							 <div class="col-lg-6"> 
                             <label style="padding-left: 10px;color: #206eac">County</label><br/>  
							 <input type="text" name="county" id="county" class="puts" value="<?php echo $tempMemberVO->getMemberCounty(); ?>" required>
							 </div>
                             
                             <div class="col-lg-6">  		
                             <label style="padding-left: 10px;color: #206eac">Post Code</label><br/>	
                             <input type="text" name="postCode" id="postCode" class="puts"  value="<?php echo $tempMemberVO->getMemberPostalCode(); ?>" required>
                             </div>
							     
							 <div class="col-lg-12">  
							 <label style="padding-left: 10px;color: #206eac">Phone/Mobile</label><br/>
                             <input type="text" name="phoneNumber"id="phoneNumber" class="puts" placeholder="" value="<?php echo $tempMemberVO->getMemberTelephone(); ?>" >
                             </div>
                                              
                             
						
                      
					</div> 
				        
				        <?php if($samebs=='1')
				        {  
				        $select = "checked";
				        $stylcss="style='height: auto;  margin-top: 20px;padding-bottom: 20px;display:none;'";
				        }
				        else
				        {
				        $select="";
				        $stylcss ="style='height: auto;  margin-top: 20px;padding-bottom: 20px;'";
				        }
				        ?>
				        
				        
               	<div class="panel panel-primary" id="checkForDiffAddress" style="float: left; width: 96%;margin-left: 10px;margin-top: 10px">
     		<div class="panel-body">
			<input type="checkbox" name="samebs" id="samebs" value='1' <?php if($samebs=='1'){ echo "checked";} ?> /> <label for="samebs">Check if your billing and shipping address are same.</label>
				</div></div>			    

                      	 <div class="col-xs-12" id="shippAddr" <?php echo $stylcss;?>>
                                <center><h3>Shipping Address</h3></center>
                               
 							 <div class="col-lg-6">     
                             <label style="padding-left: 10px;color: #206eac">Full Name</label><br/>  
                             <input type="text" name="sfName"  id="sfName" class="puts"  value="<?php echo $tempMemberVO->getSmemberName(); ?>" required>
                             </div>
                             
                             <div class="col-lg-6">     
                             <label style="padding-left: 10px;color: #206eac">Email</label><br/>      
                             <input type="text" name="smemberEmail"  id="smemberEmail" class="puts"  value="<?php echo $tempMemberVO->getSmemberEmail(); ?>" required>
                             </div>
                                            
                             <div class="col-lg-12">    
                             <label style="padding-left: 10px;color: #206eac">Address Line 1</label><br/>        
                             <input type="text" name="saddress1" id="saddress1" class="puts" value="<?php echo $tempMemberVO->getSmemberAddress1(); ?>" required>
                             </div>
                                          
                             <div class="col-lg-12">        
                             <label style="padding-left: 10px;color: #206eac">Address Line 2</label><br/>  
                             <input type="text" name="saddress2" id="saddress2" class="puts"  value="<?php echo $tempMemberVO->getSmemberAddress2(); ?>"> 
                             </div>
                                              
                             <div class="col-lg-6">  
                             <label style="padding-left: 10px;color: #206eac">City/Town</label><br/>   
							 <input type="text" name="scity" id="scity" class="puts"  value="<?php echo $tempMemberVO->getSmemberAddress3(); ?>" >
							 </div>
							 
							 <div class="col-lg-6">  
                             <label style="padding-left: 10px;color: #206eac">Country</label><br/>   
							 <input type="text" name="scountry" id="scountry" class="puts"  value="<?php echo $tempMemberVO->getSmemberCountry(); ?>" >
							 </div>
							 
							 <div class="col-lg-6"> 
                             <label style="padding-left: 10px;color: #206eac">County</label><br/>  
							 <input type="text" name="scounty" id="scounty" class="puts" value="<?php echo $tempMemberVO->getSmemberCounty(); ?>" required>
							 </div>
                             
                             <div class="col-lg-6">  		
                             <label style="padding-left: 10px;color: #206eac">Post Code</label><br/>	
                             <input type="text" name="spostCode" id="spostCode" class="puts"  value="<?php echo $tempMemberVO->getSmemberPostalCode(); ?>" required>
                             </div>
							     
							 <div class="col-lg-12">  
							 <label style="padding-left: 10px;color: #206eac">Phone/Mobile</label><br/>
                             <input type="text" name="sphoneNumber"id="sphoneNumber" class="puts" placeholder="" value="<?php echo $tempMemberVO->getSmemberTelephone(); ?>" >
                             </div>
                                              
                             
						
                      
					</div> 
                   
                   
                       
       <button type='submit' name='proceed' value='Order Proceed' class='orderproceed' onclick='javascript:return validateBillingDetails();' >Order Proceed</button>			 
			 
                                            </form>
				</div>

				 </div>
				 <br/>
                        </div>
		
      
	
         <?php include 'footer.php'; ?>
		</div>
		
    <script type="text/javascript" src="js/function.js"></script>

		</body>

</html>