<?php
ob_start();
session_start();
define("base_url","https://utharaprint-london.co.uk");
error_reporting (E_ALL ^ E_NOTICE);
include('includes/top_header.php');
$tempProductMainCatDAO = new ProductMainCategoryDAO();
$tempProductCatDAO = new ProductCatDAO();
$tempOurbrandDAO = new OurbrandDAO();
$tempOurbrandResult = $tempOurbrandDAO->OurbrandList();
$tempMemberDAO = new MemberDAO();

if(isset($_POST['action']) && $_POST['action']=="login")
{    
   
	$memberEmail = $_POST['emailId'];
	$password = $_POST['memberPasss'];
	if($tempMemberDAO->loginMember($memberEmail, $password))
	{	
                if(count($_SESSION['specailofferCart'])>0)
                {                  
                   header("Location: specialoffer-cart.php");
                }
                else
                {  
                   //header("Location: myaccount-dashboard.php");
                   header("Location: specialoffer-cart.php");
                }
	}
	else 
	{
                 $msg="INVALID EMAIL ADDRESS OR PASSWORD.";
	}
}

if(isset($_POST['action']) && $_POST['action']=="forgotten")
{ 
	if($tempMemberDAO->genrateNewPassword($_POST['memberEmail']))
	{		
		    $msg ="PASSWORD SEND TO YOUR EMAIL ADDRESS.";
	}
	else 
	{    
		    $msg ="INVALID DETAILS, PLEASE TRY AGAIN";
	}
}
?>
<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
<script>
function toggleResetPswd(e){
    e.preventDefault();
    $('#logreg-forms .form-signin').toggle() // display:block or none
    $('#logreg-forms .form-reset').toggle() // display:block or none
}

function toggleSignUp(e){
    e.preventDefault();
    $('#logreg-forms .form-signin').toggle(); // display:block or none
    $('#logreg-forms .form-signup').toggle(); // display:block or none
}

$(()=>{
    // Login Register Form
    $('#logreg-forms #forgot_pswd').click(toggleResetPswd);
    $('#logreg-forms #cancel_reset').click(toggleResetPswd);
    $('#logreg-forms #btn-signup').click(toggleSignUp);
    $('#logreg-forms #cancel_signup').click(toggleSignUp);
})
</script>
<!------ Include the above in your HEAD tag ---------->

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css" integrity="sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="https://utharaprint.co.uk/css/login-demo-style.css">
    <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
    
    <link rel="stylesheet" href="https://utharaprint.co.uk/css/style.css">
    <link rel="stylesheet" href="https://utharaprint.co.uk/css/responsive.css">
    <script>
        
        function facebookLoginSubmit()
        {
           
            document.getElementById('fblogin').value="Facebook";
            document.getElementById('fblogin').submit();
        }
    </script>
    
    
    <title>UtharaPrint UK Login</title>
</head>
<body>
    <?php
        include 'header.php';
         
if(isset($_POST['facebooklogin']) && $_POST['facebooklogin']!='')
{
     
     require_once("Facebook/autoload.php");
                
                
                $fb = new Facebook\Facebook([
                        'app_id'                => '464477831053654',
                        'app_secret'            => '04b92a2cd5127cc174ae5834a926e2c7',
                        'default_graph_version' => 'v2.6'
                      ]);
               
                $helper           = $fb->getRedirectLoginHelper();
                $permissions      = ['email', 'public_profile']; // optional
                $callback         = 'https://utharaprint-london.co.uk/shopping-cart.php';
                $loginUrl         = $helper->getLoginUrl($callback, $permissions);
                
                header("location: $loginUrl");
            
}
        ?>
    
    <div id="logreg-forms">
        
            <div class="alert alert-warning" style="padding:5px;"><p align="justify"><?php if($msg !==""){ echo $msg; } ?></p></div>
            
            <form class="form-signin" id="fblogin"  method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
                <input type="hidden" name="facebooklogin" id="facebooklogin" value="facebooklogin" />
            <h1 class="h3 mb-3 font-weight-normal" style="text-align: center"> Sign in</h1><br/>
            <!--<div class="social-login">
                <button class="btn facebook-btn social-btn" type="button" name="facebooklogin" id="facebooklogin" onclick="facebookLoginSubmit()"><span><i class="fa fa-facebook" aria-hidden="true"></i> Sign in with Facebook</span> </button>
                <button class="btn google-btn social-btn" type="button"><span><i class="fa fa-google" aria-hidden="true"></i> Sign in with Google</span> </button>
            </div>-->
            </form>
            <form class="form-signin" id="login-form"  method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
            <input type="hidden" name="action" id="action" value="login" />
            <!--<p style="text-align:center"> OR  </p>-->
            <input type="email" id="inputEmail" name="emailId" class="form-control" placeholder="Email address" required="" autofocus="" value="<?php echo $memberEmail; ?>"><br/>
            <input type="password" id="inputPassword" name="memberPasss" class="form-control" placeholder="Password" required="" value="<?php echo $password; ?>">
            
            
            
            <button class="btn btn-success btn-block" type="submit"><i class="fas fa-sign-in-alt"></i> Sign in</button>
            <a href="#" id="forgot_pswd">Forgot password?</a>
            <hr>
           
           
            <!-- <p>Don't have an account!</p>  -->
            <button class="btn btn-primary btn-block" type="button" id="btn-signup"><i class="fas fa-user-plus"></i> Sign up New Account</button>
            </form>

            <form action="<?php echo $_SERVER['PHP_SELF']; ?>" class="form-reset" method="post">
               <br><br>
               <h1 class="h3 mb-3 font-weight-normal" style="text-align: center">Enter Your E-mail Address</h1>
                <br>
                <input type="email" id="resetEmail" name="emailId" class="form-control" placeholder="Email address" required="" autofocus=""><br/>
                <button class="btn btn-primary btn-block" name="action" value="forgotten" type="submit">Reset Password</button>
            
                
                
                <br><br>
                <a href="#" id="cancel_reset"><i class="fas fa-angle-left"></i> Back</a>
                <br>
            </form>
            
            <form action="<?php echo $_SERVER['PHP_SELF']; ?>" class="form-signup" method="post">
              <!--  <div class="social-login">
                    <button class="btn facebook-btn social-btn" type="button" ><span><i class="fa fa-facebook" aria-hidden="true"></i> Sign up with Facebook</span> </button>
                </div>
                <div class="social-login">
                    <button class="btn google-btn social-btn" type="button"><span><i class="fa fa-twitter" aria-hidden="true"></i> Sign up with Twitter</span> </button>
                </div>-->
                
                <p style="text-align:center">Sign Up With New Account</p>

                <input type="text" id="user-name" name="fName" class="form-control" placeholder="Full name" required="" autofocus="">
                <input type="email" id="user-email" name="emailId" class="form-control" placeholder="Email address" required autofocus="">
                <input type="password" id="user-pass" name="memberPasss" class="form-control" placeholder="Password" required autofocus="">
                <input type="password" id="user-repeatpass" name="conf_memberPass" class="form-control" placeholder="Repeat Password" required autofocus="">

                <button class="btn btn-primary btn-block" name="action" value="register" type="submit" ><i class="fas fa-user-plus"></i> Sign Up</button>
                <a href="#" id="cancel_signup"><i class="fas fa-angle-left"></i> Back</a>
            </form>
            <br>
            
    </div>
    
    <?php
        include 'footer.php';
        ?>

<script type="text/javascript" src="https://utharaprint.co.uk/js/jquery.min.js"></script>
<script type="text/javascript" src="https://utharaprint.co.uk/js/function.js"></script>
    
</body>
</html>