<?php
ob_start();
session_start();
error_reporting (E_ALL ^ E_NOTICE);
include('includes/top_header.php');
$tempProductDAO     = new ProductDAO();
$tempProductCatDAO  = new ProductCatDAO();
$tempVatDAO         = new VatDAO();
$tempBannerDAO      = new BannerDAO();
$tempProductMainCatDAO = new ProductMainCategoryDAO();
$tempOurbrandDAO       = new OurbrandDAO();
if(isset($_POST['action']) && $_POST['action']!='')
{
    $designName = $_POST['design'];
    $price      = $_POST['price'];
    $designId      = $_POST['designId']   ;                                  

}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width; initial-scale=1.0; maximum-scale=1.0">
    <!--css-->
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/responsive.css">
    
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
   
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
    <!--css-->
	<script
  src="https://code.jquery.com/jquery-3.3.1.min.js">
  </script>	
	<script src="js/myjava.js"></script>
   
	<style>
		
	* { -webkit-box-sizing: border-box; -moz-box-sizing: border-box; box-sizing: border-box; }
*:before, *:after { -webkit-box-sizing: inherit; -moz-box-sizing: inherit; box-sizing: inherit; }
		.radiobutton{
			width:20px;
			height:20px;
			background: #363535;
			color: #D3D3D3;
		}
		
		.span{
			padding:20px;
			font-family: Gotham, "Helvetica Neue", Helvetica, Arial, "sans-serif";font-size: 20px;
		}
			</style>
    <title>Uthara Print London</title>
</head>

<body>
    <!--Start mainContainer-->
    <div class="mainCon">
        <?php
        include 'header.php';
        ?>
        <div class="content">
                
				
           
			<div class="lineheight" id="line"></div>	
			
           
			<div class="lineheight"></div>
           <div class="container-sm productOffers">
             
                <div class="productContainet" >
		<div class="disable">	<div class="productBox transition">
                        <div class="productImage" > <img src="images/A5 Leaflet copy.jpg"/>
						
						</div>
					</div>
					</div>
					<!------------------>
          <div class="productBox transition">
                        <div class="productImage" > <img src="images/A5 Leaflet copy.jpg"/>
						
						</div>
					</div>
               
          <!---------------->
	     <div class="productBox transition">
                 <form name="artwork" method="post" action="brief-designer.php">
                     <input type="hidden" name="briefDesigner" value="briefDesigner">
                     <input type="hidden" name="design" value="<?php echo $designName;?>">
                     <input type="hidden" name="price" value="<?php echo $price;?>">
                    <input type='hidden' name='designId' value='<?php echo $designId?>'>           
                    <div class="productImage"  style="text-align: left; padding: 18px"> 
							 <h3 > <?php echo $designName;  ?>
							</h3>
						<p>&pound;<?php echo $price;  ?><br/><br/>
					   <i class="fa fa-check-circle"></i> &nbsp;&pound;119 -&pound;269 estimated price range.<br/>
					   <i class="fa fa-check-circle"></i> &nbsp;Flxible design turnaround.<br/>
					   <i class="fa fa-check-circle"></i> &nbsp;Print-ready files and full copyright.<br/>
					   <div class="space"></div>
							</p><br/>
 						<label style="float: left;position: relative;">
                                                    <button type="submit" class="productPrice" style="padding:9px 17px"> Breif Designer &rarr;</button>
                        
				</label>
						 </div>
                     </form>
						
                    </div>
					
		<!------------------>
		<div class="disable">	<div class="productBox transition">
                        <div class="productImage" > <img src="images/A5 Leaflet copy.jpg"/>
						
						</div>
					</div>
					</div>

					<!------------------>
		        </div>
				
			      <div class="lineheight"></div>
			<!---------------------------------------------------------------->
			<div style="display: flex">  <div class="productPrice" style=" padding: 10px; border-radius: 20px ; width: 270px;color:#fff;justify-content: center;background-color: #386DE8">View Portfolio</div> 
			<div style=" padding: 10px; border-radius: 10px ; width: 100px;color:#386DE8;justify-content: center;">Showing</div> <input type="search" placeholder="Business Card"/>
			</div>
			<br/>
			   <div class="productContainet">
				      
                    <div class="productBox transition">
						
                        <a href="#"><div class="productImage" style="height: auto;"> <img src="images/A5 Leaflet copy.jpg"/>
							</div></a>
						</div>
				   <div class="productBox transition">
						
                        <a href="#"><div class="productImage" style="height: auto;"> <img src="images/A5 Leaflet copy.jpg"/>
							</div></a>
						</div>
				   <div class="productBox transition">
						
                        <a href="#"><div class="productImage" style="height: auto;"> <img src="images/A5 Leaflet copy.jpg"/>
							</div></a>
						</div>
				   <div class="productBox transition">
						
                        <a href="#"><div class="productImage" style="height: auto;"> <img src="images/A5 Leaflet copy.jpg"/>
							</div></a>
						</div>
			   </div>
	                <!------------------>
			   <div class="lineheight"></div>
			   <div class="productContainet">
				
				   <div class="productBox transition">
						
                        <a href="#"><div class="productImage" style="height: auto;"> <img src="images/A5 Leaflet copy.jpg"/>
							</div></a>
						</div>
				  
				   <!------------------->
				    <div class="productBox transition">
						
                        <a href="#"><div class="productImage" style="height: auto;"> <img src="images/A5 Leaflet copy.jpg"/>
							</div></a>
						</div>
					<div class="productBox transition">
						
                        <a href="#"><div class="productImage" style="height: auto;"> <img src="images/A5 Leaflet copy.jpg"/>
							</div></a>
						</div>
					<div class="productBox transition">
						
                        <a href="#"><div class="productImage" style="height: auto;"> <img src="images/A5 Leaflet copy.jpg"/>
							</div></a>
						</div>
             	
                </div>
			   <div class="lineheight"></div>
			   <div class="productContainet">
				
				   <div class="productBox transition">
						
                        <a href="#"><div class="productImage" style="height: auto;"> <img src="images/A5 Leaflet copy.jpg"/>
							</div></a>
						</div>
				  
				   <!------------------->
				    <div class="productBox transition">
						
                        <a href="#"><div class="productImage" style="height: auto;"> <img src="images/A5 Leaflet copy.jpg"/>
							</div></a>
						</div>
					<div class="productBox transition">
						
                        <a href="#"><div class="productImage" style="height: auto;"> <img src="images/A5 Leaflet copy.jpg"/>
							</div></a>
						</div>
					<div class="productBox transition">
						
                        <a href="#"><div class="productImage" style="height: auto;"> <img src="images/A5 Leaflet copy.jpg"/>
							</div></a>
						</div>
             	
                </div>
				<!---------------------------------------------------------------->
			<div class="lineheight"></div>
				<div class="productContainet">
				
				   <div class="productBox transition">
						
                        <a href="#"><div class="productImage" style="height: auto;"> <img src="images/A5 Leaflet copy.jpg"/></a></div>
						
						</div>
				  
				   <!------------------->
				    <div class="productBox transition">
						
                        <a href="#"><div class="productImage" style="height: auto;"> <img src="images/A5 Leaflet copy.jpg"/>
							</div></a>
						</div>
					<div class="productBox transition">
						
                        <a href="#"><div class="productImage" style="height: auto;"> <img src="images/A5 Leaflet copy.jpg"/>
							</div></a>
						</div>
					<div class="productBox transition">
						
                        <a href="#"><div class="productImage" style="height: auto;"> <img src="images/A5 Leaflet copy.jpg"/>
							</div></a>
						</div>
             	
                </div>
			<!------------------------------->
			<div class="lineheight"></div>
 <button class="productPrice" style="padding:9px 17px"> Breif Designer &rarr;</button>
			</div>
            </div>
			
            <div class="visaCard">
            <img src="images/worldpay.jpg"/>
            <div style="display:flex-start;">
                <img src="images/visa.png">
                </div>
            </div>
        </div>
	
        <?php
        include 'header.php';
        ?>
    </div>
    
    <script type="text/javascript" src="js/jquery.min.js"></script>
    <script type="text/javascript" src="js/function.js"></script>

</body>

</html>