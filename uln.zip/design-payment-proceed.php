<?php
ob_start();
session_start();
error_reporting (E_ALL ^ E_NOTICE);
include('includes/top_header.php');
$tempProductDAO    = new ProductDAO();
$tempProductMainCatDAO = new ProductMainCategoryDAO();
$tempProductCatDAO = new ProductCatDAO();
$tempOrderDesignLogoWebDAO = new OrderDesignLogoWebDAO();

$tempMemberDAO     = new MemberDAO();
$tempBannerDAO      = new BannerDAO();
$tempArr           = array();
$productCart       = array();
$productId         = $_POST['proId'];
$productDeliveTime = $_POST['productDeliveTime'];
$memberId=$_SESSION['memberId'];
$tempOurbrandDAO = new OurbrandDAO();
$tempOurbrandResult = $tempOurbrandDAO->OurbrandList();
$tempMemberVO = $tempMemberDAO->getMemberDetails($memberId);
$memberEmail=$tempMemberVO->getMemberEmail();
$memberAddress=$tempMemberVO->getMemberAddress1();
$memberPostalCode=$tempMemberVO->getMemberPostalCode();
//$memberCity=$tempMemberVO->getMemberCounty();
//$memberCountry=$tempMemberVO->getMemberCountry();
if(isset($_POST['productPrice']) && $_POST['productPrice']!='')
{
 $productName=$_POST['productName'];
 $productAmount=$_POST['productPrice'];
 $packageName = $_POST['packageName'];
 $productCatId = $_POST['productCatId'];

$qryForVatDetail   = "SELECT rId, vatvalue FROM tbl_vat";
	$result2           = mysql_query($qryForVatDetail);
	$rs2               = mysql_fetch_array($result2);
	$vatRate           = $rs2['vatvalue'];
	$productVatPrice   = ($productAmount*$vatRate)/100;
	$productVatPrice   = round($productVatPrice, 2);
	$finalPriceWithVat = $productAmount + $productVatPrice;

}
$orderId = $tempOrderDesignLogoWebDAO->getLastOrderNumber();


if(isset($_POST['action']) && $_POST['action']=="register")
{     
     
    if(!$tempMemberDAO->checkMemberAlreadyRegister($_POST['emailId']))
    {
       
        $result = $tempMemberDAO->insertMember($_POST['fName'], $_POST['emailId'], $_POST['memberPasss']);
        $firstName = ucfirst($_POST['fName']);
        $password = $_POST['memberPasss'];
        $email_to = $_POST['emailId'];
        
        $email_from = "sales@utharaprint-london.co.uk";						
        $email_subject = "Welcome to utharaprint-london.co.uk";
        $headers  = "From: Utharaprint <".$email_from.">\r\n";
        $headers .= "Reply-To: " . $email_from . "\r\n";
        $headers .= "Content-type: text/html";
        $currDate = date("d/m/Y h:i a");
        $message  =  "<table style='width: 60%;line-height: 1;' >
  <tr>
  <td>
       <img src='https://utharaprint-london.co.uk/images/logo.png'>   
  </td>
  </tr >      
      <tr ><td><h3>Hello! Mr $firstName, and welcome to Utharaprint-london.co.uk</h3></td></tr> 
      <tr ><td><p style='font-size:18px;line-height:2'>Thank you for choosing to register with our website – the first step to saving £££ on your design and printing requirements.<br> 
We understand that buying design and print online can seem a little daunting – however we can assure you, we are one of the good guys. Based in the UK, we are quick and efficient and buying design is simply three easy steps.<br>
And for added peace of mind we will update the status on your order at every step we take on the job.</p></td></tr>
      <tr ><td><h3>What next...?</h3></td></tr>
       <tr ><td><p style='font-size:18px;line-height:2'>To sign into your account during checkout or on the My Account page, use the following:</p></td></tr> 
       <tr ><td><Strong>Email: </strong>$email_to<p style='font-size:18px;line-height:2'></p></td></tr> 
      <tr ><td><Strong>Password: </strong>Password you set when creating account<p style='font-size:18px;line-height:2'></p></td></tr> 
	  <tr><td>&nbsp;</td></tr>
      <tr ><td>Forgot your account password? Don't worry - simply click <a href='https://utharaprint-london.co.uk/login.php'>here</a> to reset it</td></tr>
	   <tr><td>&nbsp;</td></tr>
	   <tr ><td style='line-height:2'>At Utharaprint-london.co.uk we love to design and print – so let us know all about your business requirements. And if you don't mind hearing from us every now and again, sign up to our marketing for special offers and much, much more – all bespoke to your business and we can help you to take your business to the next level.</td></tr>
	   <tr ><td style='line-height:2'><strong>Ordering online!</strong></td></tr>
	   <tr ><td style='line-height:2'>Be it artwork, website or print, we have it all covered and we have various options and we have made life easy.
Thank you, Kind regards.</td></tr>
 <tr ><td><h3>The team @ Utharaprint-london.co.uk</h3></td></tr>
	 </table>";
        //ini_set("sendmail_from", $email_from);
	$sent = mail($email_to, $email_subject, $message, $headers);
        //$sent = mail("sales@utharaprint.com.au", $email_subject, $message, $headers);
        //header("Location: order-design.php");
    }
    else 
    {
      header("Location: order-design-login.php?msg=2&pn=$productName&ppa=$packageName&pp=$productAmount&pci=$productCatId");
    }    
   // header("Location: register.php?msg=$msg");
}

if(isset($_POST['action']) && $_POST['action']=="login")
{    
   
	$memberEmail = $_POST['emailId'];
	$password = $_POST['memberPasss'];
	if($tempMemberDAO->loginMember($memberEmail, $password))
	{	
	  $msg = "successfully login";
               
	}
	else 
	{
             header("Location: order-design-login.php?msg=1&pn=$productName&ppa=$packageName&pp=$productAmount&pci=$productCatId");
                 
	}
}
?>
<!DOCTYPE html>
<html lang="en">

<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width; initial-scale=1.0; maximum-scale=1.0">
    <!--css-->
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    
    <link rel="canonical" href="https://utharaprint-london.co.uk/payment-proceed.php"/>
    <meta name="robots" content="index,follow" />
    
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/responsive.css">
    
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
   	<script type="text/javascript" src="js/jquery.min.js"></script>
    <script type="text/javascript" src="js/function.js"></script>

    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <script lang="javascript">
    function submitPaymentForm()
    {
        if ($('#terms2:checked').val()=='terms2')
		{
                    document.getElementById('paypalform').submit();
		
		} 
		else {
			alert('Please Select Terms and Conditions.');
			return false;
		}
        
    }
	
	function checkTermsCond()
	{
		if ($('#terms1:checked').val()=='terms1')
		{
			return true;
		} 
		else {
			alert('Please Select Terms and Conditions.');
			return false;
		}
		
	}
	
        function submitTermCond3()
	{
		if ($('#terms3:checked').val()=='terms3')
		{
			return true;
		} 
		else {
			alert('Please Select Terms and Conditions.');
			return false;
		}
		
	}

    </script>
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css" >
	<link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
   
	<style>
	
		* { -webkit-box-sizing: border-box; -moz-box-sizing: border-box; box-sizing: border-box; }
*:before, *:after { -webkit-box-sizing: inherit; -moz-box-sizing: inherit; box-sizing: inherit; }


	</style>
         <title>Uthara Print London</title>
</head>

<body>

    <body><div class="mainCon">
         <?php include 'header.php'; ?>
                
    <div class="lineheight" ></div><div class="lineheight" ></div>
			
			<p style="margin-left:80px;font-family: Montserrat;">Payment Option</p>                    
            <p style="font-weight: 600; color: #294b8a; font-size: 22px; font-family: Montserrat; margin-left:80px;">Select your payment mode for</p>                    
			
			
   		  	<div class="content">
				
				<div class="container-sm ">
			
			
		
			<br/>
					
					
					<div class="row" style="  border: 1px solid #999; border-radius:10px; padding:1%;" id="#">
					<div id="PaymentOrderNo">
					    <h4>Order No.</h4>
					    <p><?php echo "UPLND#".$orderId;?></p>
					</div>
					<div id="PaymentProduct">
					    <h4>Product:</h4>
						<?php 
						echo "<p>$productName</p><p>$packageName</p>";
						?>
					    
					</div>
					<div id="PaymentTotel">
					    <h4>Price + Vat = Total Amount</h4>
					    <p>&pound;<?php echo $productAmount." + &pound;".$productVatPrice." = &pound;".$finalPriceWithVat; ?></p>
					</div>
					<div style="clear:both"></div>    
					</div>    
					    
					    
					<div class="row" style="  border: 1px solid #999; border-radius:10px; margin-top:1%;" id="paymentproceed">
					    
			<div style="width: 100%"><h3 style="float: left;padding-left: 20px;padding-top: 0px;width: 30%;"><strong><font style="font-family: 'Montserrat'"></font></strong></h3></div>
						
<div class="tab1">
  <button class="tablinks active" onclick="openCity(event, 'London')" ><img src="images/pay-by-phone.png" alt="" style="margin-left:7px"/></button>
 <button class="tablinks" onclick="openCity(event, 'Paris')"> <img src="images/pay-pal.png" alt="" style="margin-left:16px"/></button>
  <button class="tablinks" onclick="openCity(event, 'Tokyo')" ><img src="images/Bank-transfer.png" alt=""/></button>
<p style="color: #336699; font-family: Montserrat; font-size:26px; float:right; padding-right:10px; font-weight:600;"><span style="font-size:20px"> Total Amount </span>
&pound;<?php echo $productAmount; ?></p>
		
	
</div>
<div id="London" class="tabcontents"  style="font-family: 'Montserrat', sans-serif;padding-left:20px;padding-right:20px">

				

	<br/><br/>
<img src="images/pay-by-phone.png" alt="">
 
<p style="padding-left:20px; text-align:justify; font-family: Montserrat;">At Uthara Print, we accept card payments over the phone using the latest technology. A member of our accounts team will call you. Should you wish to make a call then the phone 
number to call and make a payment is</p>

<h2 align="center"><strong><span style="color:#253b80"><font style="font-family: 'Montserrat'"  font-weight="600"> 020 3239 9280 </font> </span>  <span style="color:#169bd7"> 
<font style="font-family: 'Montserrat'">  </font></span></strong></h2>

<p style="padding-left:20px; text-align:justify; font-family: Montserrat;">
We accept the latest Visa, Mastercard debit and credit card, American express card payments, safe in the knowledge all our phone payment solutions are secured to the highest PCI DSS Level 1 standards.</p>

<p style="font-family: 'Montserrat'; font-size:14px; padding-left:20px;"> 
<span class="shophead" style="color: #333;display: flex; ">
    
<form method="post" action="design-payment-process.php">    
<input type='hidden' name='productCatId' value='<?php echo $productCatId; ?>'>         
<input type='hidden' name='productName' value='<?php echo $productName; ?>'> 
<input type='hidden' name='productPrice' value='<?php echo $finalPriceWithVat; ?>'>
<input type='hidden' name='vatPrice' value='<?php echo $productVatPrice; ?>'>
<input type='hidden' name='packageName' value='<?php echo $packageName; ?>'> 
<input type="checkbox" value="terms3" style="margin-right: 00px" name="terms3" id="terms3" checked/> 
<a href="https://utharaprint-london.co.uk/privacy-policy.php" target="blanck" style="">
Click here to accept terms and conditions</a> </span>
<input type="submit" name="paybyphone" value="Proceed to Next" class="btn btn-primary btn-lg" onclick='javascript:return submitTermCond3()'style="font-family: 'Roboto' sans-serif;margin: 20px;float: right;display: flex-end;"/>
</form>		
		
	
</div>
	

<div id="Tokyo" class="tabcontents" style="display: none;font-family: 'Lato', sans-serif;">
<br/><br/>
<label style="width: 100%"><img src="images/Bank-transfer.png" ></label>
 	

<p style="font-family: 'Montserrat', sans-serif;">You have choosen "bank transfer/prepayment" as the payment method for your order. Please transfer the invoice amount to our bank account (bank details given below). The job will be printed and despatched as soon as the payment is received. Please choose immediate bank transfer and always use your order number as reference while making the payment. Do inform us by email when you have made the payment by the bank transfer to expedite the process. Please be aware that bank transfers can sometimes take up to a couple of working days to be registered within our bank account if you have not choosen to transfer the payment immediately.</p>


 <table class="table-striped table-hover" style="width:100%">
						<tr class="" style="height: 35px;line-height: 30px; ">
							<td scope="row" style="padding-left: 20px;font-family: 'Montserrat', sans-serif; font-weight:600;">Name</td><td class="Product1">Bumboom Ltd trading as Uthara Print</td>
						</tr>
								
						<tr style="height: 35px;line-height: 30px; ">
							<td scope="row" style="padding-left: 20px;font-family: 'Montserrat', sans-serif; font-weight:600;">Bank Name</td><td class="Product1"> Barclays</td>
						</tr>
						<tr style="height: 35px;line-height: 30px; ">
							<td scope="row" style="padding-left: 20px;font-family: 'Montserrat', sans-serif; font-weight:600;">Account no.</td><td class="Product1">5380 5638</td>
						</tr>
						<tr style="height: 35px;line-height: 30px; ">
							<td scope="row" style="padding-left: 20px;font-family: 'Montserrat', sans-serif; font-weight:600;">Sort Code</td><td class="Product1">20-11-43</td>
						</tr>		
						<br/>
							</table>

<br/>
<form method="post" action="design-payment-process.php">
<span class="shophead" style="color: #333;display: flex;">
<input type='hidden' name='productCatId' value='<?php echo $productCatId; ?>'>         
<input type='hidden' name='productName' value='<?php echo $productName; ?>'>  
<input type='hidden' name='productPrice' value='<?php echo $finalPriceWithVat; ?>'>
<input type='hidden' name='vatPrice' value='<?php echo $productVatPrice; ?>'>
<input type='hidden' name='packageName' value='<?php echo $packageName; ?>'> 
<input type="checkbox" value="terms1" checked style="margin-left: 00px;" name="terms1" id="terms1"/> <a href="privacy-policy.php" target="blank" style="">Click here to accept terms and conditions</a> </span>
<input type="submit" name="bankpayment" id='tc' value="Proceed to Next"  class="btn btn-primary btn-lg" onclick="javascript:return checkTermsCond()" style="font-family: 'Roboto' sans-serif;margin: 20px;float: right;display: flex-end;"/>
 

</form>
</div>

<form name='paypalform' id='paypalform' action="design-payment-process.php" method="post" > 
<div id="Paris" class="tabcontents" style="display:none; width:100%; padding-left:20px;">
<input type='hidden' name='productCatId' value='<?php echo $productCatId; ?>'>         
  <input type='hidden' name='productName' value='<?php echo $productName; ?>'>  
<input type='hidden' name='productPrice' value='<?php echo $finalPriceWithVat; ?>'>
<input type='hidden' name='vatPrice' value='<?php echo $productVatPrice; ?>'>
<input type='hidden' name='packageName' value='<?php echo $packageName; ?>'> 
  	
	<br/><br/>
  <img src="images/pay-pal.png" alt=""><br/>
 <p style="color: #336699; font-family: Montserrat; font-size:18px;padding:10px; font-weight:600;"> 3.5% Extra</p>
 <span class="shophead" style="color: #333;display: flex;"> 
<input type="checkbox" value="terms2" checked style="margin-left: 00px;" name="terms2" id="terms2"/> <a href="privacy-policy.php" target="blank" style="">Click here to accept terms and conditions</a> </span>
<br/><br/>
  
 <button class="btn btn-primary btn-lg" name='paypal' target="_blank" onclick='javascript:return submitPaymentForm()' style="font-family: 'Roboto', sans-serif;">Pay Through Paypal</button>

  </form>
  

<div class="nextproceed" style="">
<p align="right"><form method="post" action="design-payment-process.php">
<input type='hidden' name='productCatId' value='<?php echo $productCatId; ?>'>         
<input type='hidden' name='productName' value='<?php echo $productName; ?>'>  
<input type='hidden' name='productPrice' value='<?php echo $finalPriceWithVat; ?>'>
<input type='hidden' name='vatPrice' value='<?php echo $productVatPrice; ?>'>
<input type='hidden' name='packageName' value='<?php echo $packageName; ?>'> 

<input type="submit" value="Proceed to Next" name="paypal" class="btn btn-primary btn-lg" style="font-family: 'Roboto' sans-serif;margin: 20px;"/>
</form></p>
</div>

</div>




<p style="font-family: 'Montserrat'; padding: 25px;padding-bottom: 10px; background-color:#fff; font-size:11px;" align="left">
   <i class="fa fa-thumbs-up" aria-hidden="true"></i> <b> Thank you very much for your order!
   We will contact you within the next working day and confirm a delivery time for your order. 
    A confirmation email has been sent to  <i class="fa fa-envelope" aria-hidden="true"></i> <a href="mailto:sales@utharaprint-london.co.uk"><b>sales@utharaprint-london.co.uk</b></a><br/>
   <i class="fa fa-refresh" aria-hidden="true"></i> Please keep a regular check on your email to view the progress of your order and any order updates. All contact will be made via your online account.</b>
    </p>


	
<script>
		
		
function openCity(evt, cityName) {
  // Declare all variables
  var i, tabcontent, tablinks;

  // Get all elements with class="tabcontent" and hide them
  tabcontent = document.getElementsByClassName("tabcontents");
  for (i = 0; i < tabcontent.length; i++) {
    tabcontent[i].style.display = "none";
  }

  // Get all elements with class="tablinks" and remove the class "active"
  tablinks = document.getElementsByClassName("tablinks");
  for (i = 0; i < tablinks.length; i++) {
    tablinks[i].className = tablinks[i].className.replace(" active", "");
  }

  // Show the current tab, and add an "active" class to the link that opened the tab
  document.getElementById(cityName).style.display = "block";
  evt.currentTarget.className += " active";
}
		
		
		
		</script>
				
		</div>
	<div class="lineh"></div>
			<div class="lineh"></div>
		
	    </div>
					
			</div>
			</div>
		
        </div>
	
         <?php include 'footer.php'; ?>
		</div>
	
		</body>

</html>