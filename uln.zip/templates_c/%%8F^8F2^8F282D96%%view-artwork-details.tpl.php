<?php /* Smarty version 2.6.19, created on 2019-10-29 11:41:02
         compiled from siteadmin/ordermanagement/view-artwork-details.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'StripSlash', 'siteadmin/ordermanagement/view-artwork-details.tpl', 13, false),)), $this); ?>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => 'siteadmin/header.tpl', 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => 'siteadmin/left.tpl', 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
<table width="100%" cellspacing="0" cellpadding="0" border="0">
  <tr>
    <td><h1>View Artwordk Details</h1></td>
  </tr>
</table>
<table width="100%" border="0" cellspacing="3" cellpadding="3" class="listdata">

    <tr>
      <td valign="top"><div align="right">Product :</div></td>
      <td>&nbsp;</td>
      <td>&nbsp;<?php echo StripSlash($this->_tpl_vars['productName']); ?>
</td>
  </tr>
  <tr>
      <td valign="top"><div align="right">Size :</div></td>
      <td>&nbsp;</td>
      <td>&nbsp;<?php echo StripSlash($this->_tpl_vars['productSize']); ?>
</td>
  </tr>
  <tr>
      <td valign="top"><div align="right">Paper :</div></td>
      <td>&nbsp;</td>
      <td>&nbsp;<?php echo StripSlash($this->_tpl_vars['productPaper']); ?>
</td>
  </tr>
   <tr>
      <td valign="top"><div align="right">Page :</div></td>
      <td>&nbsp;</td>
      <td>&nbsp;<?php echo StripSlash($this->_tpl_vars['productPages']); ?>
</td>
  </tr>
   <tr>
      <td valign="top"><div align="right">Quantity :</div></td>
      <td>&nbsp;</td>
      <td>&nbsp;<?php echo StripSlash($this->_tpl_vars['productQty']); ?>
</td>
  </tr>
  
  <tr>
      <td valign="top"><div align="right">Artwork Check :</div></td>
      <td>&nbsp;</td>
      <td>&nbsp;<?php echo StripSlash($this->_tpl_vars['artworkName']); ?>
</td>
  </tr>
   <tr>
      <td valign="top"><div align="right">Delivery Time :</div></td>
      <td>&nbsp;</td>
      <td>&nbsp;<?php echo StripSlash($this->_tpl_vars['deliveryTime']); ?>
</td>
  </tr>
   <tr>
      <td valign="top"><div align="right">Resllers :</div></td>
      <td>&nbsp;</td>
      <td>&nbsp;0</td>
  </tr>
  
   <tr>
      <td valign="top"><div align="right">Artwork Option :</div></td>
      <td>&nbsp;</td>
      <td>&nbsp;Upload Your Artwork</td>
  </tr>
   <?php $this->assign($this->_tpl_vars['i'], 0); ?>

     <?php $_from = $this->_tpl_vars['clientArtwork_arr']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['k'] => $this->_tpl_vars['v']):
?>

         <?php $this->assign('i', $this->_tpl_vars['i']+1); ?>
		 <tr>

      <td valign="top"><div align="right">&nbsp;&nbsp;</div></td>

      <td>&nbsp;</td>
	  
	  <td><a href='user-artwork-download.php?filename=<?php echo StripSlash($this->_tpl_vars['v']['artworkDesign1']); ?>
'>Download Design </a></td>

		</tr>

     <?php endforeach; endif; unset($_from); ?>
  
</table>

<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => 'siteadmin/footer.tpl', 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>