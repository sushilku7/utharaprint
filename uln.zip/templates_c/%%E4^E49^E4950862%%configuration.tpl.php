<?php /* Smarty version 2.6.19, created on 2019-11-13 12:21:59
         compiled from siteadmin/admin/configuration.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'StripSlash', 'siteadmin/admin/configuration.tpl', 15, false),)), $this); ?>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => 'siteadmin/header.tpl', 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => 'siteadmin/left.tpl', 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
<h1>Site Configuration</h1>
<form method="post" action="" name="frm" enctype="multipart/form-data">
  <?php if ($this->_tpl_vars['show_msg'] != ''): ?>
  	<?php echo $this->_tpl_vars['show_msg']; ?>

  <?php endif; ?>
  <table width="100%" border="0" cellspacing="0" cellpadding="0" class="listdata">
    <tr>
      <th style="border-right:none;">Site Variables</th>
      <th style="text-align:right;"><button type="submit" name="cmdupdate" id="cmdupdate">Update</button></th>
    </tr>
    <tr>
      <td>Site Title</td>
      <td><input type="text" name="site_title" id="site_title" value="<?php echo StripSlash($this->_tpl_vars['site_title']); ?>
" size="60" />
        &nbsp;<em>(Default Site Title)</em></td>
    </tr>
    <tr>
      <td>Site Logo</td>
      <td><input type="file" name="site_logo" id="site_logo" value="<?php echo StripSlash($this->_tpl_vars['site_lvogo']); ?>
"  size="60" /><img src="<?php echo $this->_tpl_vars['_conf_vars']['ROOT_URL']; ?>
/images/<?php echo StripSlash($this->_tpl_vars['site_logo']); ?>
" />
      </td>
    </tr>
    <tr>
      <td>Site Christmas Effect</td>
      <td><input type="radio" name="site_christmas_effect" id="site_effect" value="No"  <?php if ($this->_tpl_vars['site_christmas_effect'] == 'No'): ?> checked="checked"<?php endif; ?> size="60" / >OFF
          <input type="radio" name="site_christmas_effect" id="site_effect" value="Yes" size="60" <?php if ($this->_tpl_vars['site_christmas_effect'] == 'Yes'): ?> checked="checked"<?php endif; ?> />ON
          <input type="hidden" name="configID" value="<?php echo StripSlash($this->_tpl_vars['configID']); ?>
">
    </tr>  
    <tr>
      <td>Contact Number</td>
      <td><input type="text" name="admin_name" id="admin_name" value="<?php echo StripSlash($this->_tpl_vars['admin_name']); ?>
" size="60" /></td>
    </tr>
    <tr>
      <td>Email ID</td>
      <td><input type="text" name="admin_email" id="admin_email" value="<?php echo StripSlash($this->_tpl_vars['admin_email']); ?>
" size="60" />
        <em>(This address is used only for admin purposes.)</em></td>
    </tr>
   <tr>
      <td>Registered Address</td>
      <td><textarea name="registered_address" rows="8" cols="60"><?php echo StripSlash($this->_tpl_vars['registered_address']); ?>
</textarea></td>
    </tr>
    <tr>
      <td>Business Address</td>
      <td><textarea name="business_communitation_add" rows="8" cols="60"><?php echo StripSlash($this->_tpl_vars['business_communitation_add']); ?>
</textarea></td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
  </table>
</form>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => 'siteadmin/footer.tpl', 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>