<?php /* Smarty version 2.6.19, created on 2019-04-09 12:05:58
         compiled from siteadmin/specialoffermanagement/specialoffer.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'StripSlash', 'siteadmin/specialoffermanagement/specialoffer.tpl', 13, false),)), $this); ?>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => 'siteadmin/header.tpl', 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => 'siteadmin/left.tpl', 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
<table width="100%" cellspacing="0" cellpadding="0" border="0">
  <tr>
    <td><h1><?php if ($this->_tpl_vars['action'] == 'add'): ?>Add<?php else: ?>Edit<?php endif; ?> Special Offer </h1></td>
  </tr>
</table>
<?php if ($this->_tpl_vars['show_msg'] != ''): ?>
  <?php echo $this->_tpl_vars['show_msg']; ?>

  <?php endif; ?>
<form name="frm" id="frm" action="" method="post" enctype="multipart/form-data">
<input type="hidden" name="btn" id="btn" value="<?php echo $this->_tpl_vars['action']; ?>
" />
<input  type="hidden" name="oldImage" id="oldImage" value="<?php echo StripSlash($this->_tpl_vars['imagePath']); ?>
" />

<table width="100%" border="0" cellspacing="3" cellpadding="3" class="listdata">
  <tr>
      <td width="30%"><div align="right">Offer HeadLine:<span class="star">*</span></div></td>
      <td width="1%">&nbsp;</td>
      <td width="69%" colspan="2">
      <input type="text" id="offerHeadline" name="offerHeadline" value="<?php echo StripSlash($this->_tpl_vars['offerHeadline']); ?>
"  style="width:288px;" maxlength="100" />      </td>
  </tr>
  <tr>
      <td width="30%"><div align="right">Cat Alias:<span class="star">*</span></div></td>
      <td width="1%">&nbsp;</td>
      <td width="69%" colspan="2">
      <input type="text" id="alias" name="alias" value="<?php echo StripSlash($this->_tpl_vars['alias']); ?>
"  style="width:288px;" maxlength="100" />      </td>
  </tr>
  <tr>
      <td width="30%"><div align="right">Product Size:<span class="star">*</span></div></td>
      <td width="1%">&nbsp;</td>
      <td width="69%" colspan="2">
      <input type="text" id="size" name="size" value="<?php echo StripSlash($this->_tpl_vars['size']); ?>
"  style="width:288px;" maxlength="100" />      </td>
  </tr>
  <tr>
      <td width="30%"><div align="right">Paper:<span class="star">*</span></div></td>
      <td width="1%">&nbsp;</td>
      <td width="69%" colspan="2">
      <input type="text" id="paper" name="paper" value="<?php echo StripSlash($this->_tpl_vars['paper']); ?>
"  style="width:288px;" maxlength="100" />      </td>
  </tr>
  <tr>
      <td width="30%"><div align="right">Pages:<span class="star">*</span></div></td>
      <td width="1%">&nbsp;</td>
      <td width="69%" colspan="2">
      <input type="text" id="pages" name="pages" value="<?php echo StripSlash($this->_tpl_vars['pages']); ?>
"  style="width:288px;" maxlength="100" />      </td>
  </tr>
  <tr>
      <td width="30%"><div align="right">Qty:<span class="star">*</span></div></td>
      <td width="1%">&nbsp;</td>
      <td width="69%" colspan="2">
      <input type="text" id="qty" name="qty" value="<?php echo StripSlash($this->_tpl_vars['qty']); ?>
"  style="width:288px;" maxlength="100" />      </td>
  </tr>
  <tr>
    <td><div align="right">Offer Text:<span class="star"></span></div></td>
    <td>&nbsp;</td>
    <td>
    <textarea name="offerText" id="offerText"  cols="43" rows="8" ><?php echo StripSlash($this->_tpl_vars['offerText']); ?>
</textarea>
    </td>
  </tr>
  <tr>
    <td><div align="right">Offer Price:<span class="star"></span></div></td>
    <td>&nbsp;</td>
    <td>
    <input type="text" id="offerPrice" name="offerPrice" value="<?php echo StripSlash($this->_tpl_vars['offerPrice']); ?>
"  style="width:288px;" maxlength="100" />
    </td>
  </tr>
  
   <tr>
    <td><div align="right">Vat Applicable:<span class="star"></span></div></td>
    <td>&nbsp;</td>
    <td>
     <input type="radio" value="Yes" id="vatApplicable" name="vatApplicable"  <?php if ($this->_tpl_vars['vatApplicable'] == 'yes'): ?> checked="checked"<?php endif; ?>/> Yes
  	<input type="radio" value="No" id="vatApplicable" name="vatApplicable" <?php if ($this->_tpl_vars['vatApplicable'] == 'no'): ?> checked="checked"<?php endif; ?>/> No
    </td>
  </tr>

  <tr>
    <td><div width="30%" align="right">Image :<span class="star"></span></div></td>
    <td width="1%">&nbsp;</td>
    <td valign="middle" width="39%">      
      <input type="file" name="imagePath" id="imagePath" />    </td>
      <td valign="top" width="30%">  
      	<?php echo StripSlash($this->_tpl_vars['specialOfferImage']); ?>

      </td>
  </tr>  
  <tr>
      <td  colspan="3" align="center"><input type="hidden" name="offerId" id="offerId" value="<?php echo $this->_tpl_vars['offerId']; ?>
" />
            
        <?php if ($this->_tpl_vars['action'] == 'add'): ?>
              <button type="submit" onclick="document.frm.btn.value = 'success';"  style="width:100px;">Add</button>
          <?php else: ?>
            <button type="submit" onclick="document.frm.btn.value = 'update';" style="width:100px;">Update</button>
          <?php endif; ?>
        &nbsp;&nbsp;&nbsp;
        <input type="button" onclick="self.location='<?php echo $this->_tpl_vars['_conf_vars']['ADMIN_URL']; ?>
index.php?opt=<?php echo $this->_tpl_vars['opt']; ?>
<?php echo $this->_tpl_vars['qstr']; ?>
'" name="button" value="Back" class="button"/>   </td>
    </tr>
</table>
</form>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => 'siteadmin/footer.tpl', 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>