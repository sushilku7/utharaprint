<?php /* Smarty version 2.6.19, created on 2019-11-13 12:24:36
         compiled from siteadmin/left.tpl */ ?>
<?php if ($this->_tpl_vars['sess_username'] != ''): ?>
<td class="sidebar">
	 
	<div class="leftmenu">
        <div class="look">
            <img src="<?php echo $this->_tpl_vars['_conf_vars']['ADMIN_URL']; ?>
images/page_go.png"  class="folding" style="vertical-align:middle; margin-right: 2px;" alt="" />
            <a href="index.php?a=config">Settings</a>
        </div>
  	</div> 
  	<div class="leftmenu">
        <div class="look">
            <img src="<?php echo $this->_tpl_vars['_conf_vars']['ADMIN_URL']; ?>
images/page_go.png"  class="folding" style="vertical-align:middle; margin-right: 2px;" alt="" />
            <a href='index.php?opt=ordermanagement'>Manage Orders</a>
        </div>
  	</div> 

        <div class="leftmenu">
        <div class="look">
            <img src="<?php echo $this->_tpl_vars['_conf_vars']['ADMIN_URL']; ?>
images/page_go.png"  class="folding" style="vertical-align:middle; margin-right: 2px;" alt="" />
            <a href='index.php?opt=orderdesignmanagement'>Manage Orders Design</a>
        </div>
  	</div> 
        <div class="leftmenu">
        <div class="look">
            <img src="<?php echo $this->_tpl_vars['_conf_vars']['ADMIN_URL']; ?>
images/page_go.png"  class="folding" style="vertical-align:middle; margin-right: 2px;" alt="" />
            <a href='index.php?opt=productmothermanagement'>Manage Main Category</a>
        </div>
        </div>   
  	<div class="leftmenu">
        <div class="look">
            <img src="<?php echo $this->_tpl_vars['_conf_vars']['ADMIN_URL']; ?>
images/page_go.png"  class="folding" style="vertical-align:middle; margin-right: 2px;" alt="" />
            <a href='index.php?opt=productcatmanagement'>Manage Main Products</a>
        </div>
  	</div> 	
  	
  	<div class="leftmenu">
        <div class="look">
            <img src="<?php echo $this->_tpl_vars['_conf_vars']['ADMIN_URL']; ?>
images/page_go.png"  class="folding" style="vertical-align:middle; margin-right: 2px;" alt="" />
            <a href='index.php?opt=productsubcatmanagement'>Manage Sub Products</a>
        </div>
  	</div> 
        
        <div class="leftmenu">
        <div class="look">
            <img src="<?php echo $this->_tpl_vars['_conf_vars']['ADMIN_URL']; ?>
images/page_go.png"  class="folding" style="vertical-align:middle; margin-right: 2px;" alt="" />
            <a href='index.php?opt=productmanagement'>Manage All Product Details</a>
        </div>
  	</div>
        
        <div class="leftmenu">
        <div class="look">
            <img src="<?php echo $this->_tpl_vars['_conf_vars']['ADMIN_URL']; ?>
images/page_go.png"  class="folding" style="vertical-align:middle; margin-right: 2px;" alt="" />
            <a href='index.php?opt=designpackagemanagement'>Manage Design Package</a>
        </div>
  	</div> 
       <div class="leftmenu">
        <div class="look">
            <img src="<?php echo $this->_tpl_vars['_conf_vars']['ADMIN_URL']; ?>
images/page_go.png"  class="folding" style="vertical-align:middle; margin-right: 2px;" alt="" />
            <a href='index.php?opt=designmanagement'>Manage Design</a>
        </div>
  	</div>   
        <!--
        <div class="leftmenu">
        <div class="look">
            <img src="<?php echo $this->_tpl_vars['_conf_vars']['ADMIN_URL']; ?>
images/page_go.png"  class="folding" style="vertical-align:middle; margin-right: 2px;" alt="" />
            <a href='index.php?opt=relevantproductmanagement'>Manage Relevant Product</a>
        </div>
  	</div> -->
        <div class="leftmenu">
        <div class="look">
            <img src="<?php echo $this->_tpl_vars['_conf_vars']['ADMIN_URL']; ?>
images/page_go.png"  class="folding" style="vertical-align:middle; margin-right: 2px;" alt="" />
            <a href='index.php?opt=ourservicemanagement'>Manage Our Service</a>
        </div>
  	</div> 
         <div class="leftmenu">
        <div class="look">
            <img src="<?php echo $this->_tpl_vars['_conf_vars']['ADMIN_URL']; ?>
images/page_go.png"  class="folding" style="vertical-align:middle; margin-right: 2px;" alt="" />
            <a href='index.php?opt=portfoliomanagement'>Manage Portfolio</a>
        </div>
  	</div>    
        <div class="leftmenu">
        <div class="look">
            <img src="<?php echo $this->_tpl_vars['_conf_vars']['ADMIN_URL']; ?>
images/page_go.png"  class="folding" style="vertical-align:middle; margin-right: 2px;" alt="" />
            <a href='index.php?opt=bannermanagement'>Manage Banner</a>
        </div>
  	</div> 
          <div class="leftmenu">
        <div class="look">
            <img src="<?php echo $this->_tpl_vars['_conf_vars']['ADMIN_URL']; ?>
images/page_go.png"  class="folding" style="vertical-align:middle; margin-right: 2px;" alt="" />
            <a href='index.php?opt=featuresmanagement'>Manage Slider</a>
        </div>
  	</div> 
        <div class="leftmenu">
        <div class="look">
            <img src="<?php echo $this->_tpl_vars['_conf_vars']['ADMIN_URL']; ?>
images/page_go.png"  class="folding" style="vertical-align:middle; margin-right: 2px;" alt="" />
            <a href='index.php?opt=specialoffermanagement'>Manage Special Offers</a>
        </div>
  	</div>
        <!--<div class="leftmenu">
        <div class="look">
            <img src="<?php echo $this->_tpl_vars['_conf_vars']['ADMIN_URL']; ?>
images/page_go.png"  class="folding" style="vertical-align:middle; margin-right: 2px;" alt="" />
            <a href='index.php?opt=productcatmanagement'>Manage Related Product</a>
        </div>
  	</div>-->
  	<div class="leftmenu">
        <div class="look">
            <img src="<?php echo $this->_tpl_vars['_conf_vars']['ADMIN_URL']; ?>
images/page_go.png"  class="folding" style="vertical-align:middle; margin-right: 2px;" alt="" />
            <a href='index.php?opt=vatmanagement'>VAT</a>
        </div>
  	</div>  
  	 
        <div class="leftmenu">
        <div class="look">
            <img src="<?php echo $this->_tpl_vars['_conf_vars']['ADMIN_URL']; ?>
images/page_go.png"  class="folding" style="vertical-align:middle; margin-right: 2px;" alt="" />
            <a href='index.php?opt=member'>Registered Clients</a>
        </div>
  	</div>  
  	<!--
        <div class="leftmenu">
        <div class="look">
            <img src="<?php echo $this->_tpl_vars['_conf_vars']['ADMIN_URL']; ?>
images/page_go.png"  class="folding" style="vertical-align:middle; margin-right: 2px;" alt="" />
            <a href='index.php?opt=productsubchildmanagement'>Sub Child Product Management</a>
        </div> 
         </div>   
        -->
            
         
  	</div> 	            
  	<div class="leftmenu">
        <div class="look">
            <img src="<?php echo $this->_tpl_vars['_conf_vars']['ADMIN_URL']; ?>
images/page_go.png"  class="folding" style="vertical-align:middle; margin-right: 2px;" alt="" />
            <a href='index.php?opt=featuredproductmanagement'>Feature Products</a>
        </div>
  	</div>
  	
        <!--    
  	<div class="leftmenu">
        <div class="look">
            <img src="<?php echo $this->_tpl_vars['_conf_vars']['ADMIN_URL']; ?>
images/page_go.png"  class="folding" style="vertical-align:middle; margin-right: 2px;" alt="" />
            <a href='index.php?opt=freeproductmanagement'>Free Product Management</a>
        </div>
  	</div> 	
  	-->
  	
  	
  	<div class="leftmenu">
        <div class="look">
            <img src="<?php echo $this->_tpl_vars['_conf_vars']['ADMIN_URL']; ?>
images/page_go.png"  class="folding" style="vertical-align:middle; margin-right: 2px;" alt="" />
            <a href='index.php?opt=productsizewisedetails'>Artwork Guidelines</a>
        </div>
  	</div>
  	
  	<div class="leftmenu">
        <div class="look">
            <img src="<?php echo $this->_tpl_vars['_conf_vars']['ADMIN_URL']; ?>
images/page_go.png"  class="folding" style="vertical-align:middle; margin-right: 2px;" alt="" />
            <a href='index.php?opt=artworkoptions'>Artwork Options</a>
        </div>
  	</div>  
  	 
        <div class="leftmenu">
        <div class="look">
            <img src="<?php echo $this->_tpl_vars['_conf_vars']['ADMIN_URL']; ?>
images/page_go.png"  class="folding" style="vertical-align:middle; margin-right: 2px;" alt="" />
            <a href='index.php?opt=designcharges'>Artword Charges</a>
        </div>
  	</div>    
            
        <!--    
  	<div class="leftmenu">
        <div class="look">
            <img src="<?php echo $this->_tpl_vars['_conf_vars']['ADMIN_URL']; ?>
images/page_go.png"  class="folding" style="vertical-align:middle; margin-right: 2px;" alt="" />
            <a href='index.php?opt=taylormadedesign'>Taylor Made Design</a>
        </div>
  	</div>
  	<div class="leftmenu">
        <div class="look">
            <img src="<?php echo $this->_tpl_vars['_conf_vars']['ADMIN_URL']; ?>
images/page_go.png"  class="folding" style="vertical-align:middle; margin-right: 2px;" alt="" />
            <a href='index.php?opt=specialoffermanagement'>Special Offer Managements</a>
        </div>
  	 </div>
  	-->  		
    <div class="leftmenu">
        <div class="look">
            <img src="<?php echo $this->_tpl_vars['_conf_vars']['ADMIN_URL']; ?>
images/page_go.png"  class="folding" style="vertical-align:middle; margin-right: 2px;" alt="" />
            <a href='index.php?opt=seo'>SEO</a>
        </div>
  	</div>
    
	<!-- 
	
	 <div class="leftmenu">
        <div class="look">
            <img src="<?php echo $this->_tpl_vars['_conf_vars']['ADMIN_URL']; ?>
images/page_go.png"  class="folding" style="vertical-align:middle; margin-right: 2px;" alt="" />
            <a href='index.php?opt=contact'>Contact Management</a>
        </div>
  	</div>   
  	<div class="leftmenu">
        <div class="look">
            <img src="<?php echo $this->_tpl_vars['_conf_vars']['ADMIN_URL']; ?>
images/page_go.png"  class="folding" style="vertical-align:middle; margin-right: 2px;" alt="" />
            <a href='index.php?opt=suggestions'>Suggestions Management</a>
        </div>
  	</div>
   --> 
        <!-- 
        <div class="leftmenu">
        <div class="look">
            <img src="<?php echo $this->_tpl_vars['_conf_vars']['ADMIN_URL']; ?>
images/page_go.png"  class="folding" style="vertical-align:middle; margin-right: 2px;" alt="" />
            <a href='index.php?opt=page'>Page Management</a>
        </div>
  	</div> 
         
        <div class="leftmenu">
        <div class="look">
            <img src="<?php echo $this->_tpl_vars['_conf_vars']['ADMIN_URL']; ?>
images/page_go.png"  class="folding" style="vertical-align:middle; margin-right: 2px;" alt="" />
            <a href='index.php?opt=combooffermanagement'>Combo Offer</a>
        </div>
  	</div>
        -->   
        <div class="leftmenu">
        <div class="look">
            <img src="<?php echo $this->_tpl_vars['_conf_vars']['ADMIN_URL']; ?>
images/page_go.png"  class="folding" style="vertical-align:middle; margin-right: 2px;" alt="" />
            <a href='index.php?opt=productbackup'>Product Table Upload</a>
        </div>
  	</div>
        <!--
       <div class="leftmenu">
        <div class="look">
            <img src="<?php echo $this->_tpl_vars['_conf_vars']['ADMIN_URL']; ?>
images/page_go.png"  class="folding" style="vertical-align:middle; margin-right: 2px;" alt="" />
            <a href='index.php?opt=resellermanagement'>Reseller Management </a>
        </div>
  	</div>
         -->  
         <div class="leftmenu">
        <div class="look">
            <img src="<?php echo $this->_tpl_vars['_conf_vars']['ADMIN_URL']; ?>
images/page_go.png"  class="folding" style="vertical-align:middle; margin-right: 2px;" alt="" />
            <a href='index.php?opt=productpricemanagement'>Price Margin</a>
        </div>
  	</div>   
       <div class="leftmenu">
        <div class="look">
            <img src="<?php echo $this->_tpl_vars['_conf_vars']['ADMIN_URL']; ?>
images/page_go.png"  class="folding" style="vertical-align:middle; margin-right: 2px;" alt="" />
            <a href='index.php?opt=suppliermanagement'>Suppliers </a>
        </div>
  	</div>  
        <div class="leftmenu">
        <div class="look">
            <img src="<?php echo $this->_tpl_vars['_conf_vars']['ADMIN_URL']; ?>
images/page_go.png"  class="folding" style="vertical-align:middle; margin-right: 2px;" alt="" />
            <a href='index.php?opt=deliverytimemanagement'>Delivery Options</a>
        </div>
  	</div>  
        <div class="leftmenu">
        <div class="look">
            <img src="<?php echo $this->_tpl_vars['_conf_vars']['ADMIN_URL']; ?>
images/page_go.png"  class="folding" style="vertical-align:middle; margin-right: 2px;" alt="" />
            <a href='index.php?opt=salesreportmanagement'>Sales Report</a>
        </div>
  	</div>  
        <div class="leftmenu">
        <div class="look">
            <img src="<?php echo $this->_tpl_vars['_conf_vars']['ADMIN_URL']; ?>
images/page_go.png"  class="folding" style="vertical-align:middle; margin-right: 2px;" alt="" />
            <a href='index.php?opt=invoicemanagement'>Invoicing </a>
        </div>
  	</div>  
  </td>
<?php endif; ?>
<td class="mainbar" height="400">