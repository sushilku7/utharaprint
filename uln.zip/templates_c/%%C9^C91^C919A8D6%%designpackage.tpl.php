<?php /* Smarty version 2.6.19, created on 2019-11-13 12:34:26
         compiled from siteadmin/designpackagemanagement/designpackage.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'StripSlash', 'siteadmin/designpackagemanagement/designpackage.tpl', 20, false),)), $this); ?>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => 'siteadmin/header.tpl', 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => 'siteadmin/left.tpl', 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
<table width="100%" cellspacing="0" cellpadding="0" border="0">
  <tr>
    <td><h1><?php if ($this->_tpl_vars['action'] == 'add'): ?>Add<?php else: ?>Edit<?php endif; ?> Design </h1></td>
  </tr>
</table>
<?php if ($this->_tpl_vars['show_msg'] != ''): ?>
  <?php echo $this->_tpl_vars['show_msg']; ?>

  <?php endif; ?>
<form name="frm" id="frm" action="" method="post" enctype="multipart/form-data">


<table width="100%" border="0" cellspacing="3" cellpadding="3" class="listdata">
   
  <tr>
      <td width="30%"><div align="right">Product Cat Name:<span class="star">*</span></div></td>
      <td width="1%">&nbsp;</td>
      <td width="69%" colspan="2">
          <?php echo StripSlash($this->_tpl_vars['product_sub_catname']); ?>


         
      </td>
  </tr>
  
  <tr>
      <td width="30%"><div align="right">Package Name:<span class="star">*</span></div></td>
      <td width="1%">&nbsp;</td>
      <td width="69%" colspan="2">
          <textarea id="package" name="package" rows="6" cols="50"><?php echo StripSlash($this->_tpl_vars['package']); ?>
</textarea>
      </td>
  </tr>
  <tr>
      <td width="30%"><div align="right">Product Name:<span class="star">*</span></div></td>
      <td width="1%">&nbsp;</td>
      <td width="69%" colspan="2">
          <textarea id="design_name" name="design_name" rows="6" cols="50"><?php echo StripSlash($this->_tpl_vars['design_name']); ?>
</textarea>
      </td>
  </tr>
  <tr>
      <td width="30%"><div align="right">Product Price:<span class="star">*</span></div></td>
      <td width="1%">&nbsp;</td>
      <td width="69%" colspan="2">
      <input type="text" id="design_price" name="design_price" value="<?php echo StripSlash($this->_tpl_vars['design_price']); ?>
"  style="width:200px;" maxlength="100" />
      </td>
  </tr>
  <tr>
      <td width="30%"><div align="right">Support Option:<span class="star">*</span></div></td>
      <td width="1%">&nbsp;</td>
      <td width="69%" colspan="2">
          <textarea id="support" name="support" rows="10" cols="50"><?php echo StripSlash($this->_tpl_vars['support']); ?>
</textarea>
      </td>
  </tr>
  <tr>
      <td width="30%"><div align="right">Advanced Option:<span class="star">*</span></div></td>
      <td width="1%">&nbsp;</td>
      <td width="69%" colspan="2">
          <textarea id="advance" name="advance" rows="10" cols="50"><?php echo StripSlash($this->_tpl_vars['advance']); ?>
</textarea>
      </td>
  </tr>
  <tr>
      <td width="30%"><div align="right">Storage Option:<span class="star">*</span></div></td>
      <td width="1%">&nbsp;</td>
      <td width="69%" colspan="2">
          <textarea id="storage" name="storage" rows="10" cols="50"><?php echo StripSlash($this->_tpl_vars['storage']); ?>
</textarea>
      </td>
  </tr>
<tr>
      <td width="30%"><div align="right">Band Width:<span class="star">*</span></div></td>
      <td width="1%">&nbsp;</td>
      <td width="69%" colspan="2">
          <textarea id="storage" name="bandWidth" rows="10" cols="50"><?php echo StripSlash($this->_tpl_vars['bandWidth']); ?>
</textarea>
      </td>
  </tr>
<tr>
      <td width="30%"><div align="right">Option5:<span class="star">*</span></div></td>
      <td width="1%">&nbsp;</td>
      <td width="69%" colspan="2">
          <textarea id="bandWidth" name="option5" rows="10" cols="50"><?php echo StripSlash($this->_tpl_vars['option5']); ?>
</textarea>
      </td>
  </tr>
 </tr><tr>
      <td width="30%"><div align="right">option6:<span class="star">*</span></div></td>
      <td width="1%">&nbsp;</td>
      <td width="69%" colspan="2">
          <textarea id="option6" name="option6" rows="10" cols="50"><?php echo StripSlash($this->_tpl_vars['option6']); ?>
</textarea>
      </td>
  </tr>
 </tr><tr>
      <td width="30%"><div align="right">option7:<span class="star">*</span></div></td>
      <td width="1%">&nbsp;</td>
      <td width="69%" colspan="2">
          <textarea id="option7" name="option7" rows="10" cols="50"><?php echo StripSlash($this->_tpl_vars['option7']); ?>
</textarea>
      </td>
  </tr>
 </tr><tr>
      <td width="30%"><div align="right">option8:<span class="star">*</span></div></td>
      <td width="1%">&nbsp;</td>
      <td width="69%" colspan="2">
          <textarea id="option8" name="option8" rows="10" cols="50"><?php echo StripSlash($this->_tpl_vars['option8']); ?>
</textarea>
      </td>
  </tr>
 </tr><tr>
      <td width="30%"><div align="right">option9:<span class="star">*</span></div></td>
      <td width="1%">&nbsp;</td>
      <td width="69%" colspan="2">
          <textarea id="option9" name="option9" rows="10" cols="50"><?php echo StripSlash($this->_tpl_vars['option9']); ?>
</textarea>
      </td>
  </tr>
 </tr><tr>
      <td width="30%"><div align="right">option10:<span class="star">*</span></div></td>
      <td width="1%">&nbsp;</td>
      <td width="69%" colspan="2">
          <textarea id="option10" name="option10" rows="10" cols="50"><?php echo StripSlash($this->_tpl_vars['option10']); ?>
</textarea>
      </td>
  </tr>
 </tr><tr>
      <td width="30%"><div align="right">option11:<span class="star">*</span></div></td>
      <td width="1%">&nbsp;</td>
      <td width="69%" colspan="2">
          <textarea id="option11" name="option11" rows="10" cols="50"><?php echo StripSlash($this->_tpl_vars['option11']); ?>
</textarea>
      </td>
  </tr>
 </tr><tr>
      <td width="30%"><div align="right">option12:<span class="star">*</span></div></td>
      <td width="1%">&nbsp;</td>
      <td width="69%" colspan="2">
          <textarea id="option12" name="option12" rows="10" cols="50"><?php echo StripSlash($this->_tpl_vars['option12']); ?>
</textarea>
      </td>
  </tr>
 </tr><tr>
      <td width="30%"><div align="right">option13:<span class="star">*</span></div></td>
      <td width="1%">&nbsp;</td>
      <td width="69%" colspan="2">
          <textarea id="option13" name="option13" rows="10" cols="50"><?php echo StripSlash($this->_tpl_vars['option13']); ?>
</textarea>
      </td>
  </tr>
 </tr><tr>
      <td width="30%"><div align="right">option14:<span class="star">*</span></div></td>
      <td width="1%">&nbsp;</td>
      <td width="69%" colspan="2">
          <textarea id="option14" name="option14" rows="10" cols="50"><?php echo StripSlash($this->_tpl_vars['option14']); ?>
</textarea>
      </td>
  </tr>
  <tr>
      <td  colspan="3" align="center">
 
      
        <?php if ($this->_tpl_vars['action'] == 'add'): ?>
              <button type="submit" onclick="document.frm.btn.value = 'success';"  style="width:100px;">Add</button>
          <?php else: ?>
            <button type="submit" onclick="document.frm.btn.value = 'update';" style="width:100px;">Update</button>
          <?php endif; ?>
        &nbsp;&nbsp;&nbsp;
        <input type="button" onclick="self.location='<?php echo $this->_tpl_vars['_conf_vars']['ADMIN_URL']; ?>
index.php?opt=<?php echo $this->_tpl_vars['opt']; ?>
<?php echo $this->_tpl_vars['qstr']; ?>
&sltMemberType=<?php echo $this->_tpl_vars['sltMemberType']; ?>
'" name="button" value="Back" class="button"/>   </td>
    </tr>
</table>
</form>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => 'siteadmin/footer.tpl', 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>