<?php /* Smarty version 2.6.19, created on 2019-08-02 11:34:38
         compiled from siteadmin/admin/login.tpl */ ?>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => 'siteadmin/header.tpl', 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => 'siteadmin/left.tpl', 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
<form action="" method="post" onsubmit="return Validate_Admin(this);">
  <table border="0" align="center" cellpadding="0" cellspacing="0" class="logintable">
   
    <?php if ($this->_tpl_vars['show_msg'] != ''): ?> <?php echo $this->_tpl_vars['show_msg']; ?>
 <?php endif; ?>
    <tr>
      <td colspan="2">User ID</td>
    </tr>
    <tr>
      <td colspan="2"><input name="username" type="text" size="40" /></td>
    </tr>
    <tr>
      <td colspan="2">Password</td>
    </tr>
    <tr>
      <td colspan="2"><input name="password" type="password" size="40" /></td>
    </tr>
    <tr>
      <td width="95"><input type="submit" name="Submit" value="LOGIN" class="button"/></td>
      <td>&nbsp;<a href="?a=fgt_pwd">Forgot Password?</a></td>
    </tr>
  </table>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
</form>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => 'siteadmin/footer.tpl', 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>