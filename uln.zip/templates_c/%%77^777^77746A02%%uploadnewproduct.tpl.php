<?php /* Smarty version 2.6.19, created on 2017-03-18 07:08:55
         compiled from siteadmin/productbackup/uploadnewproduct.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'StripSlash', 'siteadmin/productbackup/uploadnewproduct.tpl', 8, false),)), $this); ?>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => 'siteadmin/header.tpl', 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => 'siteadmin/left.tpl', 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
<table width="100%" cellspacing="0" cellpadding="0" border="0">  
    <tr>    <td><h1>Upload Product In CSV Format </h1></td>  
    </tr></table>
<form name="frm" id="frm" action="" method="post" enctype="multipart/form-data">
        <input type="hidden" name="btn" id="btn" value="<?php echo $this->_tpl_vars['action']; ?>
" />
        <input  type="hidden" name="oldImage" id="oldImage" value="<?php echo StripSlash($this->_tpl_vars['imagePath']); ?>
" />
        <table width="100%" border="0" cellspacing="3" cellpadding="3" class="listdata"> 
            <tr>    
                <td width="99%" align="center" colspan="4"><div style="color:green;font-size: 15px;font-weight: bold;">        
                        <?php if ($this->_tpl_vars['scsPrUpMsg'] != ''): ?>        
                            <?php echo $this->_tpl_vars['scsPrUpMsg']; ?>
        
                        <?php endif; ?>     
                    </div>    
                </td> 
            </tr>    
            
            <tr>      
                <td width="55%" align="right"><div >Product Name :<span class="star"></span></div></td> 
                <td width="45%"  colspan="2" align="left">        
                    &nbsp; <?php echo StripSlash($this->_tpl_vars['product_catname']); ?>

                </td>    
            </tr>
            
             <tr>  
                <td width="55%" align="right"><div >Sub Product Name :<span class="star"></span></div></td>  
                <td width="45%" colspan="2" align="left">        
                   <div id="productSizeDiv"> <?php echo StripSlash($this->_tpl_vars['product_sub_catname']); ?>
</div>
                </td>    
            </tr>
            
            <tr>      
                <td  colspan="3" align="center">        
                    <?php if ($this->_tpl_vars['action'] == 'add'): ?>              
                        <button type="submit" onclick="document.frm.btn.value = 'delete';"  style="width:100px;">Delete</button>                   
                    <?php endif; ?>
                </td>    
            </tr>
            
            <tr>    
                <td width="55%" align="right"><div >Upload New Product :<span class="star"></span></div></td>
                <td valign="middle" width="40%">            
                    <input type="file" name="productcsvform" id="productcsvform" />
                </td>      
                <td valign="top" width="5%">        
                    &nbsp;      	
                    <?php echo StripSlash($this->_tpl_vars['product']); ?>

                </td>  
            </tr>        
            <tr>      
                <td  colspan="3" align="center">        
                    <?php if ($this->_tpl_vars['action'] == 'add'): ?>              
                        <button type="submit" onclick="document.frm.btn.value = 'success';"  style="width:100px;">Add</button>
                    <?php else: ?>            
                        <button type="submit" onclick="document.frm.btn.value = 'update';" style="width:100px;">Update</button> 
                    <?php endif; ?>        
                    &nbsp;&nbsp;&nbsp;        
                    <input type="button" onclick="self.location='<?php echo $this->_tpl_vars['_conf_vars']['ADMIN_URL']; ?>
index.php?opt=<?php echo $this->_tpl_vars['opt']; ?>
<?php echo $this->_tpl_vars['qstr']; ?>
'" name="button" value="Back" class="button"/>   
                </td>    
            </tr>
        </table>
    </form>
  <?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => 'siteadmin/footer.tpl', 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>