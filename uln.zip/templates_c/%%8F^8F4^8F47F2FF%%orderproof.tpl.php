<?php /* Smarty version 2.6.19, created on 2017-01-07 04:23:26
         compiled from siteadmin/ordermanagement/orderproof.tpl */ ?>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => 'siteadmin/header.tpl', 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => 'siteadmin/left.tpl', 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
<table width="100%" cellspacing="0" cellpadding="0" border="0">
  <tr>
    <td><h1>Upload Proof</h1></td>
  </tr>
</table>
<?php if ($this->_tpl_vars['show_msg'] != ''): ?>
  <?php echo $this->_tpl_vars['show_msg']; ?>

  <?php endif; ?>
 
 <form name="frm" id="frm" action="" method="post" enctype="multipart/form-data">
<input type="hidden" name="btn" id="btn" value="<?php echo $this->_tpl_vars['action']; ?>
" />
<input  type="hidden" name="action" id="action" value="Proof Upload" />
<input  type="hidden" name="orderId" id="orderId" value="<?php echo $this->_tpl_vars['orderId']; ?>
" />

<table width="100%" border="0" cellspacing="3" cellpadding="3" class="listdata">
  
    <tr>
    <td width="39"><div align="right">Proof File :<span class="star"></span></div></td>
    <td width="2%">&nbsp;</td>
    <td valign="middle" width="58%">      
      <input type="file" name="proofFileName" id="proofFileName" />
    </td>
  </tr>  
  
   <tr>
    <td><div align="right">Remarks :</div></td>
    <td>&nbsp;</td>
    <td>
     <textarea name="remark" cols="62" rows="5"></textarea>
    </td>
  </tr>
  
  <tr>
      <td  colspan="3" align="center">
         <button type="submit" onclick="document.frm.btn.value = 'success';"  style="width:100px;">Upload Proof</button>
         &nbsp;&nbsp;&nbsp;
        <input type="button" onclick="self.location='<?php echo $this->_tpl_vars['_conf_vars']['ADMIN_URL']; ?>
index.php?opt=<?php echo $this->_tpl_vars['opt']; ?>
<?php echo $this->_tpl_vars['qstr']; ?>
'" name="button" value="Back" class="button"/>   </td>
    </tr>
</table>
</form>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => 'siteadmin/footer.tpl', 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>