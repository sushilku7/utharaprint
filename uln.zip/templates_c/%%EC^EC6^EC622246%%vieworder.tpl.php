<?php /* Smarty version 2.6.19, created on 2019-08-02 12:02:22
         compiled from siteadmin/ordermanagement/vieworder.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'StripSlash', 'siteadmin/ordermanagement/vieworder.tpl', 17, false),array('modifier', 'sizeof', 'siteadmin/ordermanagement/vieworder.tpl', 107, false),array('function', 'html_options', 'siteadmin/ordermanagement/vieworder.tpl', 271, false),)), $this); ?>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => 'siteadmin/header.tpl', 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => 'siteadmin/left.tpl', 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>


<div style="text-align:center;background-color:#006699;color:#FFFFFF;line-height:35px;font-size:17px;">View Order</div>
<table width="100%" border="0" cellspacing="3" cellpadding="3" class="listdata">
    <tr>
        <td colspan="3">
            <?php echo $this->_tpl_vars['msg']; ?>

            <div style="color: green; font-size: 15px; clear: both; font-weight: bold;">Order Status has been send successfully</div>
        </td>
    </tr>
  <tr>
      <td width="30%"><div align="right">Order id :</div></td>
      <td width="1%">&nbsp;</td>
      <td width="69%" colspan="2">
     <?php echo StripSlash($this->_tpl_vars['orderId']); ?>

      </td>
  </tr>
  
  <tr>
      <td width="30%"><div align="right">Order Date :</div></td>
      <td width="1%">&nbsp;</td>
      <td width="69%" colspan="2">
     <?php echo StripSlash($this->_tpl_vars['order_date']); ?>

      </td>
  </tr>
  
  <tr>
      <td width="30%"><div align="right">Member Name  :</div></td>
      <td width="1%">&nbsp;</td>
      <td width="69%" colspan="2">
        <?php echo StripSlash($this->_tpl_vars['memberName']); ?>

      </td>
  </tr>
 
  <tr>
    <td><div align="right">Billing Company :</div></td>
    <td>&nbsp;</td>
    <td>
  <?php echo StripSlash($this->_tpl_vars['memberCompanyName']); ?>

    </td>
  </tr>
  
  <tr>
    <td><div align="right">Billing Address :</div></td>
    <td>&nbsp;</td>
    <td>
     <?php echo StripSlash($this->_tpl_vars['memberAddress1']); ?>
<br />
     <?php echo StripSlash($this->_tpl_vars['memberAddress2']); ?>
<br />
     <?php echo StripSlash($this->_tpl_vars['memberAddress3']); ?>

     <?php echo StripSlash($this->_tpl_vars['memberCountry']); ?>
 - <?php echo StripSlash($this->_tpl_vars['memberCounty']); ?>
<br />
     <?php echo StripSlash($this->_tpl_vars['memberPostalCode']); ?>

    </td>
     
  </tr>
  
  <tr>
    <td><div align="right">Shipping Company:</div></td>
    <td>&nbsp;</td>
    <td>
     <?php echo StripSlash($this->_tpl_vars['memberCompanyName']); ?>

    </td>
  </tr>
  
  <tr>
    <td><div align="right">Shipping Address :</div></td>
    <td>&nbsp;</td>
    <td>
     <?php echo StripSlash($this->_tpl_vars['memberAddress1']); ?>
<br />
     <?php echo StripSlash($this->_tpl_vars['memberAddress2']); ?>
<br />
     <?php echo StripSlash($this->_tpl_vars['memberAddress3']); ?>

     <?php echo StripSlash($this->_tpl_vars['memberCountry']); ?>
 - <?php echo StripSlash($this->_tpl_vars['memberCounty']); ?>
<br />
     <?php echo StripSlash($this->_tpl_vars['memberPostalCode']); ?>

    </td>
  </tr>
  
  <tr>
    <td><div align="right">E Mail Id:</div></td>
    <td>&nbsp;</td>
    <td>
  	<?php echo StripSlash($this->_tpl_vars['memberEmail']); ?>

    </td>
  </tr>
</table>

<div style="text-align:center;background-color:#006699;color:#FFFFFF;line-height:35px;font-size:17px;">The Order Contains the following Products</div>
<table width="100%" border="0" cellspacing="3" cellpadding="3" class="listdata">
			  <tr>
			      <td width="30%"><div align="right">
			      <a href="<?php echo $this->_tpl_vars['_conf_vars']['ADMIN_URL']; ?>
index.php?opt=<?php echo $this->_tpl_vars['opt']; ?>
&a=upload-view-proof&orderId=<?php echo $this->_tpl_vars['orderId']; ?>
<?php echo $this->_tpl_vars['qstr']; ?>
">Upload / View Proof</a>
			          </div></td>
			      <td width="1%">&nbsp;</td>
			      <td width="69%" colspan="2">
			      <a href="<?php echo $this->_tpl_vars['_conf_vars']['ADMIN_URL']; ?>
index.php?opt=<?php echo $this->_tpl_vars['opt']; ?>
&a=generateInvoice&orderId=<?php echo $this->_tpl_vars['orderId']; ?>
<?php echo $this->_tpl_vars['qstr']; ?>
">Generate Invoice</a>
			      </td>
			  </tr> 
</table>
		

<div style="text-align:center;"><h3>Shopping From Main site:</h3></div>
<div style="text-align:center;">
	  <table align="center" width="95%" border="0" cellspacing="3" cellpadding="3" class="listdata">
	      <tr>
	      <td width="99%" colspan="4">
				    <table width="100%" border="0" cellspacing="5" cellpadding="5" class="listdata">
				    <?php if (sizeof($this->_tpl_vars['cartArr']) > 0): ?>
				    <tr>
                                      <th width="15%" style="text-align:left;" rowspan="2">Product</th>			      
				      <th width='10%' style="text-align:left;" rowspan="2">Quantity</th>  
                                      <th width='8%' style="text-align:left;" rowspan="2">Design Charges</th>  
				      <th width="12%" style="text-align:left;" rowspan="2">Net Amount</th>
                                      <th width="25%" style="text-align:center;" >Supplier</th>
				      <th width="20%" style="text-align:left;" rowspan="2">Action</th>
				    </tr>
                                    <tr>
				
                                      <td width="10%" style="text-align:left;">Name&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Rating&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Email ID&nbsp;&nbsp;</td>
				      
				    </tr>&nbsp;&nbsp;&nbsp;&nbsp;
				    <?php $this->assign($this->_tpl_vars['i'], 0); ?>
				    <?php $_from = $this->_tpl_vars['cartArr']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['k'] => $this->_tpl_vars['v']):
?>
				         <?php $this->assign('i', $this->_tpl_vars['i']+1); ?>
				    <tr class="<?php if ($this->_tpl_vars['v']['sno']%2 == '0'): ?>odd<?php else: ?>even<?php endif; ?>">
				      <td style="text-align:left;"><?php echo $this->_tpl_vars['v']['catName']; ?>
 <?php echo $this->_tpl_vars['v']['productName']; ?>
</td>
				      <td style="text-align:left;"><?php echo $this->_tpl_vars['v']['quantity']; ?>
</td>
                                      <td style="text-align:left;">&pound; <?php echo $this->_tpl_vars['v']['designCharges']; ?>
</td>
				      <td style="text-align:left;">&pound; <?php echo $this->_tpl_vars['v']['price']; ?>
</td>
                                      <td style="text-align:left;"><table width="100%" border="0" cellspacing="5" cellpadding="5" class="listdata"> <tr>                                         
                                         <?php if (sizeof($this->_tpl_vars['v']['supplierArr']) > 0): ?>
                                             <?php $_from = $this->_tpl_vars['v']['supplierArr']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['k2'] => $this->_tpl_vars['v2']):
?>
				             <?php $this->assign('l', $this->_tpl_vars['l']+1); ?>
                                             <td style="text-align:left;"><?php echo $this->_tpl_vars['v2']['supplierName']; ?>
 -</td> <td style="text-align:left;"> <?php echo $this->_tpl_vars['v2']['supplierRating']; ?>
 </td> <td style="text-align:left;"> <?php echo $this->_tpl_vars['v2']['supplierEmail']; ?>
</td></tr>
                                             <?php endforeach; endif; unset($_from); ?>
                                         <?php endif; ?>
                                          </table>
                                      </td>
				      <td style="text-align:left;">
				      <a href="<?php echo $this->_tpl_vars['_conf_vars']['ADMIN_URL']; ?>
index.php?opt=<?php echo $this->_tpl_vars['opt']; ?>
&a=view-artwork-details&orderId=<?php echo $this->_tpl_vars['orderId']; ?>
&id=<?php echo $this->_tpl_vars['v']['rId']; ?>
<?php echo $this->_tpl_vars['qstr']; ?>
"  title="View Artwork Details">
				      More Details
				      </a>
                                      &nbsp;|&nbsp;
                                      <a href="<?php echo $this->_tpl_vars['_conf_vars']['ADMIN_URL']; ?>
index.php?opt=<?php echo $this->_tpl_vars['opt']; ?>
&a=view-Design-details&orderId=<?php echo $this->_tpl_vars['orderId']; ?>
&id=<?php echo $this->_tpl_vars['v']['rId']; ?>
<?php echo $this->_tpl_vars['qstr']; ?>
"  title="View Artwork Details">
				      View User Design
				      </a>
				      </td>
				    </tr>
                                    <?php if (sizeof($this->_tpl_vars['cart_offer_arr']) > 0): ?>
                                         <?php $this->assign($this->_tpl_vars['j'], 0); ?>
                                        <?php $_from = $this->_tpl_vars['cart_offer_arr']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['k1'] => $this->_tpl_vars['v1']):
?>
				         <?php $this->assign('j', $this->_tpl_vars['j']+1); ?>
                                           <tr class="<?php if ($this->_tpl_vars['v']['sno']%2 == '0'): ?>odd<?php else: ?>even<?php endif; ?>">
                                            <td style="text-align:left;"><?php echo $this->_tpl_vars['v1']['product_name']; ?>
</td>
                                            <td style="text-align:left;"><?php echo $this->_tpl_vars['v1']['product_qty']; ?>
</td>
                                            <td style="text-align:left;">&pound; <?php echo $this->_tpl_vars['v1']['product_final_price']; ?>
</td>
                                            <td style="text-align:left;">&nbsp;</td>
                                           </tr>
                                         <?php endforeach; endif; unset($_from); ?>
                                    <?php endif; ?>
				    <?php endforeach; endif; unset($_from); ?>
				    <?php else: ?>
				    <tr>
				      <td colspan="4">Record not available.</td>
				    </tr>
				    <?php endif; ?>
				  </table>
	      </td>	     
	      </tr> 
	</table>
	  <table width="100%" border="0" cellspacing="2" cellpadding="2">
	  <tr>
	      <td width="70%"><div align="right">Main Product Amount :</div></td>
	      <td width="1%">&nbsp;</td>
	      <td width="29%" align="left">
                  &pound; <?php echo StripSlash($this->_tpl_vars['totalProductPrice']); ?>
                                    
              </td>
	  </tr> 	 
          
          <tr>
	      <td width="70%"><div align="right">Design Charges :</div></td>
	      <td width="1%">&nbsp;</td>
	      <td width="29%" align="left">
                  &pound; <?php echo StripSlash($this->_tpl_vars['totalDesignCharges']); ?>
                                    
              </td>
	  </tr> 
          
	  <tr>
	      <td width="70%"><div align="right">E-Mail Charges :</div></td>
	      <td width="1%">&nbsp;</td>
	      <td width="29%" align="left">&pound; <?php echo StripSlash($this->_tpl_vars['emailCharges']); ?>
</td>
	  </tr> 
	  <tr>
	      <td width="70%"><div align="right">Net Amount :</div></td>
	      <td width="1%">&nbsp;</td>
	      <td width="29%" align="left">
                  &pound; <?php echo StripSlash($this->_tpl_vars['totalNetAmount']); ?>
                                    
              </td>
	  </tr> 
	   <tr>
	      <td width="70%"><div align="right">VAT @ 20.00 % :</div></td>
	      <td width="1%">&nbsp;</td>
	      <td width="29%" align="left">&pound; <?php echo StripSlash($this->_tpl_vars['vatAmount']); ?>
</td>
	  </tr>
          
          <tr>
	      <td width="70%"><div align="right">Cobmo Offer Product Amount:</div></td>
	      <td width="1%">&nbsp;</td>
	      <td width="29%" align="left"> &pound; <?php echo StripSlash($this->_tpl_vars['offerTotalPrice']); ?>
</td>
	  </tr>
          
	  
	  <tr>
	      <td width="70%"><div align="right"><font color="red" size="3pt"><b>Total  Amount :</b></font></div></td>
	      <td width="1%">&nbsp;</td>
	      <td width="29%" align="left"><font color="red" size="3pt"><b>&pound; <?php echo StripSlash($this->_tpl_vars['totalAmout']+$this->_tpl_vars['vatAmount']); ?>
</b></font></td>
	  </tr> 
</table>


<table align="center" width="80%" border="0" cellspacing="3" cellpadding="3" >
  <tr>
      <td width="40%"><div align="right">Discount (-) :</div></td>
      <td width="1%">&nbsp;</td>
      <td width="59%" align="left"><?php echo StripSlash($this->_tpl_vars['discountAmt']); ?>
</td>
  </tr> 
  <tr>
      <td width="40%"><div align="right"><font color="red" size="3pt"><b>Gross Amount :</b></font></div></td>
      <td width="1%">&nbsp;</td>
      <td width="59%" align="left" ><font color="red" size="3pt"><b>Not Displaying</b></font></td>
  </tr>   
  <tr>
      <td width="40%"><div align="right">Promotional Code :</div></td>
      <td width="1%">&nbsp;</td>
      <td width="49%" align="left"><?php echo StripSlash($this->_tpl_vars['promoCode']); ?>
</td>
  </tr> 
  <tr>
      <td width="40%"><div align="right">Payment Status :</div></td>
      <td width="1%">&nbsp;</td>
      <td width="59%" align="left"><?php echo StripSlash($this->_tpl_vars['paymentStatus']); ?>
</td>
  </tr> 
  <tr>
      <td width="40%"><div align="right">Order Status :</div></td>
      <td width="1%">&nbsp;</td>
      <td width="59%" align="left"><?php echo StripSlash($this->_tpl_vars['orderStats']); ?>
</td>
  </tr> 
  <tr>
      <td width="40%"><div align="right">Payment  Mode :</div></td>
      <td width="1%">&nbsp;</td>
      <td width="59%" align="left"><?php echo StripSlash($this->_tpl_vars['paymentMode']); ?>
</td>
  </tr> 
  <tr>
      <td width="40%"><div align="right">Invoice Sent :</div></td>
      <td width="1%">&nbsp;</td>
      <td width="59%" align="left"><?php echo StripSlash($this->_tpl_vars['flagInvoice']); ?>
</td>
  </tr> 
</table>
<div style="text-align:center;background-color:#006699;color:#FFFFFF;line-height:35px;font-size:17px;">Update Order</div>
			
			<form name="frm" id="frm" action="" method="post" enctype="multipart/form-data">
			<input type="hidden" name="btn" id="btn" value="<?php echo $this->_tpl_vars['action']; ?>
" />
			<input  type="hidden" name="orderId" id="orderId" value="<?php echo StripSlash($this->_tpl_vars['orderId']); ?>
" />
			<table align="center" width="80%" border="0" cellspacing="3" cellpadding="3" >
			<tr>
			      <td width="100%" colspan="3"><div style="padding:20px 10px;color:green;font-size:16px;font-weight:bold;text-align:center;"><?php if ($this->_tpl_vars['show_msg'] != ''): ?><?php echo $this->_tpl_vars['show_msg']; ?>
<?php endif; ?></div></td>			     
			  </tr>
			  <tr>
			      <td width="40%" align="right" valign="top">Order Status :</td>
			      <td width="1%">&nbsp;</td>
			      <td width="59%" align="left">			     
				     <select name="orderStats" id="orderStats">
			        	  <?php echo smarty_function_html_options(array('options' => $this->_tpl_vars['_conf_vars']['ORDER_STATUS'],'selected' => $this->_tpl_vars['orderStats']), $this);?>

			             </select>
			         <br /><br />
			         <input type="hidden" name="memberName" id="memberName" value="<?php echo StripSlash($this->_tpl_vars['memberName']); ?>
" />
			         <input type="hidden" name="memberEmailId" id="memberEmailId" value="<?php echo StripSlash($this->_tpl_vars['memberEmail']); ?>
" />
			         <input type="submit" name="Submit" id="Submit" value="Email Order Status">
                                 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;                                 
                                 <?php if (sizeof($this->_tpl_vars['emailStatus']) == ''): ?>
                                    No
                                    <?php else: ?>
                                    Yes
                                 <?php endif; ?>
			      </td>
                              
			  </tr> 
			  <tr>
			      <td width="40%"><div align="right">Payment Received :</div></td>
			      <td width="1%">&nbsp;</td>
			      <td width="59%" align="left">
			        <select name="paymentStatus" id="paymentStatus">
			        	  <?php echo smarty_function_html_options(array('options' => $this->_tpl_vars['_conf_vars']['PAYMENT_STATUS'],'selected' => $this->_tpl_vars['paymentStatus']), $this);?>

			         </select>
			      </td>
			  </tr> 
			  <tr>
			      <td width="40%"><div align="right">Expected Delivery Date :</div></td>
			      <td width="1%">&nbsp;</td>
			      <td width="59%" align="left" >
			      <input type="text" id="expectDate" name="expectDate" value="<?php echo StripSlash($this->_tpl_vars['expect_date']); ?>
"  style="width:100px;" maxlength="100" onclick="if(self.gfPop)gfPop.fPopCalendar(document.frm.expectDate);return false;" />
			      <img src="<?php echo $this->_tpl_vars['_conf_vars']['ADMIN_URL']; ?>
images/calbtn.gif" alt=""  align="absmiddle" onclick="if(self.gfPop)gfPop.fPopCalendar(document.frm.expectDate);return false;"   />
			      </td>
			  </tr>
			   <tr>
			      <td width="40%"><div align="right">Shipping Tracking Link :</div></td>
			      <td width="1%">&nbsp;</td>
			      <td width="59%" align="left" ><input type="text" name="track" id="track" value="<?php echo StripSlash($this->_tpl_vars['track']); ?>
" /></td>
			  </tr>
			  <tr>
			      <td width="40%"><div align="right">Comments :</div></td>
			      <td width="1%">&nbsp;</td>
			      <td width="59%" align="left"><textarea name="orderComment" id="orderComment" rows="5" cols="62"><?php echo StripSlash($this->_tpl_vars['orderComment']); ?>
</textarea></td>
			  </tr>
			  <tr>
			      <td width="40%"><div align="right">Internal Comment :</div></td>
			      <td width="1%">&nbsp;</td>
			      <td width="59%" align="left"><textarea name="internalComment" id="internalComment" rows="5" cols="62"><?php echo StripSlash($this->_tpl_vars['internalComment']); ?>
</textarea></td>
			  </tr>
			  <tr>
			      <td width="40%"><div align="right">&nbsp;&nbsp;</div></td>
			      <td width="1%">&nbsp;</td>
			      <td width="59%" align="left">
			      <input type="submit" name="Submit" id="Submit" value="Update Order">
			      &nbsp;&nbsp;&nbsp;
	        <input type="button" onclick="self.location='<?php echo $this->_tpl_vars['_conf_vars']['ADMIN_URL']; ?>
index.php?opt=<?php echo $this->_tpl_vars['opt']; ?>
<?php echo $this->_tpl_vars['qstr']; ?>
'" name="button" value="Back" class="button"/>   
			      </td>
			  </tr>			  
			</table>     
			</form>



</div>
		
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => 'siteadmin/footer.tpl', 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>