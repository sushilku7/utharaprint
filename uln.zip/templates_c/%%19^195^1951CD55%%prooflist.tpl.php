<?php /* Smarty version 2.6.19, created on 2019-10-28 16:25:51
         compiled from siteadmin/ordermanagement/prooflist.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'sizeof', 'siteadmin/ordermanagement/prooflist.tpl', 15, false),array('modifier', 'StripSlash', 'siteadmin/ordermanagement/prooflist.tpl', 43, false),)), $this); ?>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => 'siteadmin/header.tpl', 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => 'siteadmin/left.tpl', 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
<h1>Proof Listing</h1>
  <form method="post" action="<?php echo $this->_tpl_vars['_conf_vars']['ADMIN_URL']; ?>
index.php?opt=<?php echo $this->_tpl_vars['opt']; ?>
&a=order<?php echo $this->_tpl_vars['qstr']; ?>
" name="frm" id="frm" enctype="multipart/form-data">
  <input type="hidden" name="orderId" id="orderId" value="<?php echo $this->_tpl_vars['orderId']; ?>
" />
  <input type="hidden" name="p" id="p" value="1" />
  <?php if ($this->_tpl_vars['show_msg'] != ''): ?>
  <?php echo $this->_tpl_vars['show_msg']; ?>

  <?php endif; ?>
  <?php if ($this->_tpl_vars['error'] != ''): ?><ul class="successbox"><li><?php echo $this->_tpl_vars['error']; ?>
</li></ul><?php endif; ?>
  
  <table width="100%" border="0" cellspacing="2" cellpadding="2">
    <tr>
      <td align="left">�
        <?php if (sizeof($this->_tpl_vars['proof_upload_arr']) > 0): ?>
        <button type="button" name="cmddelete" id="cmddelete" onclick="javascript: return fnDelete('<?php echo $this->_tpl_vars['_conf_vars']['ADMIN_URL']; ?>
index.php?opt=<?php echo $this->_tpl_vars['opt']; ?>
&a=delete<?php echo $this->_tpl_vars['qstr']; ?>
', 'Are you sure you want to delete selected Order (s)?');">Remove Selected Record(s)</button>
        <?php endif; ?>
        <button type="button" onclick="document.location.href='<?php echo $this->_tpl_vars['_conf_vars']['ADMIN_URL']; ?>
index.php?opt=<?php echo $this->_tpl_vars['opt']; ?>
&orderId=<?php echo $this->_tpl_vars['orderId']; ?>
&a=add-proof';">Add Proof</button>
        </td>
        <td align="right">&nbsp;
        </td>
    </tr>
  </table>
  <table width="100%" border="0" cellspacing="0" cellpadding="0" class="listdata">
    <?php if (sizeof($this->_tpl_vars['proof_upload_arr']) > 0): ?>
    <tr>
      <th width="8%" style="text-align:right;">Sr. No.</th>
      <th width='2%'><input type="checkbox" name="checkall" value='1' onClick='checkREC(document.frm);' id='checkall'/></th>
      <th width='15%'>Order No.</th> 
      <th width='15%'>Download File</th> 
      <th width='40%'>Remark</th>
      <th width="20%">Action</th>
      </tr>
    <?php $this->assign($this->_tpl_vars['i'], 0); ?>
    <?php $_from = $this->_tpl_vars['proof_upload_arr']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['k'] => $this->_tpl_vars['v']):
?>
         <?php $this->assign('i', $this->_tpl_vars['i']+1); ?>
         
                 
    <tr style="">
    
      <td style="text-align:right;"><?php echo $this->_tpl_vars['i']; ?>
</td>
	  <td><input type="checkbox" name="record[]" id="chk<?php echo $this->_tpl_vars['v']['proofId']; ?>
" value='<?php echo $this->_tpl_vars['v']['proofId']; ?>
' /></td>
      <td><?php echo StripSlash($this->_tpl_vars['v']['orderId']); ?>
</td>   
      <td>
      <?php if ($this->_tpl_vars['v']['proofFileName'] != ''): ?>          				
	          <a href='file_download.php?filename=<?php echo $this->_tpl_vars['v']['proofFileName']; ?>
' target="_blank">Download File</a>
      <?php else: ?>			
      <span class='error-msg'>File Not Exist</span>
 	  <?php endif; ?> 
      </td>   
      <td><?php echo StripSlash($this->_tpl_vars['v']['remark']); ?>
</td>   
      <td nowrap="nowrap">
      <a href="<?php echo $this->_tpl_vars['_conf_vars']['ADMIN_URL']; ?>
index.php?opt=<?php echo $this->_tpl_vars['opt']; ?>
&a=del&id=<?php echo $this->_tpl_vars['v']['proofId']; ?>
<?php echo $this->_tpl_vars['qstr']; ?>
" onclick="return confirm('Are you sure you want to remove this Proof ?');" title="Remove">
      Delete
      </a>
      </td>
    </tr>
    <?php endforeach; endif; unset($_from); ?>
    <tr>
      <td colspan="5"><?php echo $this->_tpl_vars['navigation']; ?>
</td>
    </tr>
    <?php else: ?>
    <tr>
      <td colspan="5">Record not available.</td>
    </tr>
    <?php endif; ?>
  </table>
</form>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => 'siteadmin/footer.tpl', 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>