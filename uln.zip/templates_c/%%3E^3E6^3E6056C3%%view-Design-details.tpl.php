<?php /* Smarty version 2.6.19, created on 2019-10-28 13:45:35
         compiled from siteadmin/ordermanagement/view-Design-details.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'StripSlash', 'siteadmin/ordermanagement/view-Design-details.tpl', 13, false),)), $this); ?>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => 'siteadmin/header.tpl', 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => 'siteadmin/left.tpl', 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
<table width="100%" cellspacing="0" cellpadding="0" border="0">
  <tr>
    <td><h1>View Design Details</h1></td>
  </tr>
</table>
<table width="100%" border="0" cellspacing="3" cellpadding="3" class="listdata">

    <tr>
      <td valign="top"><div align="right">Order Number :</div></td>
      <td>&nbsp;</td>
      <td>&nbsp;<?php echo StripSlash($this->_tpl_vars['orderId']); ?>
</td>
  </tr>
  <tr>
      <td valign="top"><div align="right">Member Company Name :</div></td>
      <td>&nbsp;</td>
      <td>&nbsp;<?php echo StripSlash($this->_tpl_vars['memberCompanyName']); ?>
</td>
  </tr>
  <tr>
      <td valign="top"><div align="right">Member Address :</div></td>
      <td>&nbsp;</td>
      <td>&nbsp;<?php echo StripSlash($this->_tpl_vars['memberAddress']); ?>
</td>
  </tr>
   <tr>
      <td valign="top"><div align="right">Member Address 2 :</div></td>
      <td>&nbsp;</td>
      <td>&nbsp;<?php echo StripSlash($this->_tpl_vars['memberAddress2']); ?>
</td>
  </tr>
  
   <tr>
      <td valign="top"><div align="right">Designs :</div></td>
      <td>&nbsp;</td>
      <td>&nbsp;Download Your Design</td>
  </tr>
   <tr>
      <td valign="top"><div align="right">&nbsp;&nbsp;</div></td>
      <td>&nbsp;</td>
      <?php if ($this->_tpl_vars['image1'] != ''): ?>
	  <td><a href='user-design-download.php?filename=<?php echo $this->_tpl_vars['image1']; ?>
'>Download Design 1</a>
	  <?php endif; ?>
	  
	  <?php if ($this->_tpl_vars['image2'] != ''): ?>
	  | <a href='user-design-download.php?filename=<?php echo $this->_tpl_vars['image2']; ?>
'>Download Design 2</a>
	  <?php endif; ?>
          
          <?php if ($this->_tpl_vars['image3'] != ''): ?>
	  | <a href='user-design-download.php?filename=<?php echo $this->_tpl_vars['image3']; ?>
'>Download Design 3</a>
	  <?php endif; ?>
          
          <?php if ($this->_tpl_vars['image4'] != ''): ?>
	  | <a href='user-design-download.php?filename=<?php echo $this->_tpl_vars['image4']; ?>
'>Download Design 4</a>
	  <?php endif; ?>
          
          <?php if ($this->_tpl_vars['image5'] != ''): ?>
	  | <a href='user-design-download.php?filename=<?php echo $this->_tpl_vars['image5']; ?>
'>Download Design 5</a>
	  <?php endif; ?>
     </td>
  </tr>
  
</table>

<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => 'siteadmin/footer.tpl', 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>