<?php /* Smarty version 2.6.19, created on 2017-04-14 11:43:22
         compiled from siteadmin/invoicemanagement/view.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'StripSlash', 'siteadmin/invoicemanagement/view.tpl', 31, false),array('function', 'html_options', 'siteadmin/invoicemanagement/view.tpl', 161, false),)), $this); ?>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => 'siteadmin/header.tpl', 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
<?php echo '
<script type="text/javascript">
function yesnoCheck() 
{
    //alert(\'Test\');
    //alert(document.getElementById(\'yesCheck\').checked);
    if (document.getElementById(\'yesCheck\').checked) 
    {
        document.getElementById(\'clientDraft\').value = "Dear Custmer,<br /><br />I attach our invoice for you to make the payment. Please do check if i have entered the correct specifications, billing and shipping  address <br /> as the job will be processed based on the information provided in the invoice. Once payment has been received we will process your job<br />and advise you of a delivery date.  Please let me know if i can be of any more assistance in the meantime.<br /><br />We offer various payment methods including debit card, credit card over the phone, pay pal and instant bank transfer. Bank transfer is our<br />preferred payment choice and there are no extra surcharges to pay if you are making an instant bank transfer. Please use the invoice numbe r  <br />as a  reference while making a payment. You will find our bank details on the invoice.<br /><br />If you wish to pay by card over the phone then please drop me an email for a call back request and a member staff will call you to process your payment. <br /><br />Thank you for your business, very much appreciated. <br /><br />Thanks & Regards,<br />Sales Team";        
    } 
    else 
    {
        document.getElementById(\'clientDraft\').value = "";
    }
}

</script>
'; ?>

<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => 'siteadmin/left.tpl', 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
<table width="100%" cellspacing="0" cellpadding="0" border="0">
  <tr>
    <td><h1> Invoice Details </h1></td>
  </tr>
</table>
<?php if ($this->_tpl_vars['show_msg'] != ''): ?>
  <div style="padding:20px 0px 0px 260px;color:green;font-size:16px;font-weight:bold;text-align:left;"><?php echo $this->_tpl_vars['show_msg']; ?>
</div>
  <?php endif; ?>
<form name="frm" id="frm" action="" method="post" enctype="multipart/form-data">
    
    <input type="hidden" name="invoice_id" value="<?php echo StripSlash($this->_tpl_vars['invoice_id']); ?>
">
<table width="100%" border="0" cellspacing="3" cellpadding="3" class="listdata">
    
    <tr>
    <td><div align="right">Customer Name:<span class="star"></span></div></td>
    <td>&nbsp;</td>
    <td>
        <input type="text" name="invoice_to" value="<?php echo StripSlash($this->_tpl_vars['invoice_to']); ?>
" />
    </td>
    </tr>
    <tr>
      <td width="30%"><div align="right"> Email Id:</div></td>
      <td width="1%">&nbsp;</td>
      <td width="69%" colspan="2">
          <input type="text" name="email_id" value="<?php echo StripSlash($this->_tpl_vars['email_id']); ?>
" />
      </td>
    </tr>   
    <tr>
      <td width="30%"><div align="right">Email Cc:</div></td>
      <td width="1%">&nbsp;</td>
      <td width="69%" colspan="2">
          <input type="text" name="email_cc1" value="<?php echo StripSlash($this->_tpl_vars['email_cc1']); ?>
" />&nbsp;&nbsp;&nbsp;&nbsp;Email Cc:&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" name="email_cc2" value="<?php echo StripSlash($this->_tpl_vars['email_cc2']); ?>
" />
      </td>
    </tr>   
    <tr>
      <td width="30%"><div align="right">Billing Address :</div></td>
      <td width="1%">&nbsp;</td>
      <td width="69%" colspan="2">
          <textarea name="billingAddress" cols="120" rows="10"><?php echo StripSlash($this->_tpl_vars['billingAddress']); ?>
</textarea> 
      </td>
    </tr>
    <tr>
      <td width="30%"><div align="right">Shipping Address :</div></td>
      <td width="1%">&nbsp;</td>
      <td width="69%" colspan="2">
          <textarea name="shippingAddress" cols="120" rows="10"><?php echo StripSlash($this->_tpl_vars['shippingAddress']); ?>
</textarea>
      </td>
    </tr>
    <tr>
    <td><div align="right">Invoice No:</div></td>
    <td>&nbsp;</td>
    <td>
        <?php echo StripSlash($this->_tpl_vars['cpy_invoice_no']); ?>
<?php echo StripSlash($this->_tpl_vars['refNum']); ?>

    </td>
  </tr>    
   <tr>
    <td><div align="right">Invoice Date:</div></td>
    <td>&nbsp;</td>
    <td>
      <?php echo StripSlash($this->_tpl_vars['invoice_date']); ?>
    
    </td>
  </tr>
  
     <tr>
      <td width="30%"><div align="right">Product size:</div></td>
      <td width="1%">&nbsp;</td>
      <td width="69%" colspan="2">
    <?php echo StripSlash($this->_tpl_vars['product_size']); ?>

      </td>
    </tr>
    <tr>
      <td width="30%"><div align="right">Product Paper:</div></td>
      <td width="1%">&nbsp;</td>
      <td width="69%" colspan="2">
          <?php echo StripSlash($this->_tpl_vars['product_paper']); ?>

      </td>
     </tr>
    <tr>
      <td width="30%"><div align="right">Product Pages:</div></td>
      <td width="1%">&nbsp;</td>
      <td width="69%" colspan="2">
          
          <?php echo StripSlash($this->_tpl_vars['product_pages']); ?>

      </td>
     </tr>
    <tr>
        <td width="30%"><div align="right">Product Qty:</div></td>
        <td width="1%">&nbsp;</td>
        <td width="69%" colspan="2">
            <?php if ($this->_tpl_vars['custom_product_qty'] != 0): ?>
            <?php echo StripSlash($this->_tpl_vars['custom_product_qty']); ?>

            <?php endif; ?>
            <?php if ($this->_tpl_vars['product_qty'] != ''): ?>
             <?php echo StripSlash($this->_tpl_vars['product_qty']); ?>

            <?php endif; ?>
        </td>
    </tr>
    <tr>
       <td><div align="right"> Price:</div></td>
       <td>&nbsp;</td>
       <td>
          
<?php echo StripSlash($this->_tpl_vars['product_price']); ?>

  
           </td>
    </tr>
   
    <tr>
         <td><div align="right"> Vat :</div></td>
         <td>&nbsp;</td>
         <td>
<?php echo StripSlash($this->_tpl_vars['vat_amt']); ?>

         </td>
    </tr>
     <tr>
         <td><div align="right"> Payment Surcharge :</div></td>
         <td>&nbsp;</td>
         <td>
<?php echo StripSlash($this->_tpl_vars['flat_margin']); ?>

         </td>
    </tr>
    <tr>
       <td><div align="right"> Total Amount:</div></td>
       <td>&nbsp;</td>
       <td>
           &pound; <?php echo StripSlash($this->_tpl_vars['total_amount']+$this->_tpl_vars['flat_margin']); ?>

       </td>
    </tr>
    <tr>
        <td width="30%"><div align="right">Invoice send status:</div></td>
        <td width="1%">&nbsp;</td>
        <td width="69%" colspan="2">
           <?php echo StripSlash($this->_tpl_vars['invceSentStatus']); ?>

        </td>
    </tr>
   <tr>
        <td width="30%"><div align="right">Payment status:</div></td>
        <td width="1%">&nbsp;</td>
        <td width="69%" colspan="2">
           <select name="paymentStatus" id="paymentStatus">
			  <?php echo smarty_function_html_options(array('options' => $this->_tpl_vars['_conf_vars']['PAYMENT_STATUS'],'selected' => $this->_tpl_vars['paymentStatus']), $this);?>

	   </select>            
        </td>
   </tr>
   <tr>
        <td width="30%"><div align="right">Payment mode:</div></td>
        <td width="1%">&nbsp;</td>
        <td width="69%" colspan="2">
             <select name="paymentMode" id="paymentMode">
			     <?php echo smarty_function_html_options(array('options' => $this->_tpl_vars['_conf_vars']['PAYMENT_MODE'],'selected' => $this->_tpl_vars['paymentMode']), $this);?>

        </select>
        </td>
   </tr>
    <tr>
      <td width="30%"><div align="right"> Order Status :</div></td>
      <td width="1%">&nbsp;</td>
      <td width="69%" colspan="2">
         <select name="orderStatus" id="orderStatus">
                    <?php echo smarty_function_html_options(array('options' => $this->_tpl_vars['_conf_vars']['ORDER_STATUS'],'selected' => $this->_tpl_vars['orderStatus']), $this);?>

        </select>
      </td>
    </tr>
     <tr>
      <td width="30%"><div align="right"> Supplier Name :</div></td>
      <td width="1%">&nbsp;</td>
      <td width="69%" colspan="2">
          <input type="text" name="supplierName" value="<?php echo StripSlash($this->_tpl_vars['supplierName']); ?>
" />
      </td>
    </tr>
     <tr>
      <td width="30%"><div align="right"> Order place date  :</div></td>
      <td width="1%">&nbsp;</td>
      <td width="69%" colspan="2">
          <input type="text" id="orderDate" name="orderDate" value="<?php echo StripSlash($this->_tpl_vars['orderDate']); ?>
"  style="width:100px;" maxlength="100" onclick="if(self.gfPop)gfPop.fPopCalendar(document.frm.orderDate);return false;" />
			      <img src="<?php echo $this->_tpl_vars['_conf_vars']['ADMIN_URL']; ?>
images/calbtn.gif" alt=""  align="absmiddle" onclick="if(self.gfPop)gfPop.fPopCalendar(document.frm.orderDate);return false;"   />
      </td>
    </tr>
    <tr>
      <td width="30%"><div align="right">Order delivery date :</div></td>
      <td width="1%">&nbsp;</td>
      <td width="69%" colspan="2">
         <input type="text" id="delivery_date" name="delivery_date" value="<?php echo StripSlash($this->_tpl_vars['delivery_date']); ?>
"  style="width:100px;" maxlength="100" onclick="if(self.gfPop)gfPop.fPopCalendar(document.frm.delivery_date);return false;" />
            <img src="<?php echo $this->_tpl_vars['_conf_vars']['ADMIN_URL']; ?>
images/calbtn.gif" alt=""  align="absmiddle" onclick="if(self.gfPop)gfPop.fPopCalendar(document.frm.delivery_date);return false;"   />
      </td>
    </tr>
   
    <tr>
      <td width="30%"><div align="right">Email Draft :</div></td>
      <td width="1%">&nbsp;</td>
      <td width="69%" colspan="2">
          
            <?php if ($this->_tpl_vars['clientDraft'] != ''): ?>
                <input type="radio" onclick="javascript:yesnoCheck();" name="emaildraft" id="yesCheck" <?php if ($this->_tpl_vars['clientDraft'] == 'Dear Custmer,<br /><br />I attach our invoice for you to make the payment. Please do check if i have entered the correct specifications, billing and shipping  address <br /> as the job will be processed based on the information provided in the invoice. Once payment has been received we will process your job<br />and advise you of a delivery date.  Please let me know if i can be of any more assistance in the meantime.<br /><br />We offer various payment methods including debit card, credit card over the phone, pay pal and instant bank transfer. Bank transfer is our<br />preferred payment choice and there are no extra surcharges to pay if you are making an instant bank transfer. Please use the invoice numbe r  <br />as a  reference while making a payment. You will find our bank details on the invoice.<br /><br />If you wish to pay by card over the phone then please drop me an email for a call back request and a member staff will call you to process your payment. <br /><br />Thank you for your business, very much appreciated. <br /><br />Thanks & Regards,<br />Sales Team'): ?> checked<?php endif; ?> /> 
                Standard Draft &nbsp;&nbsp;
                <input type="radio" onclick="javascript:yesnoCheck();" name="emaildraft" id="noCheck" <?php if ($this->_tpl_vars['clientDraft'] != 'Dear Custmer,<br /><br />I attach our invoice for you to make the payment. Please do check if i have entered the correct specifications, billing and shipping  address <br /> as the job will be processed based on the information provided in the invoice. Once payment has been received we will process your job<br />and advise you of a delivery date.  Please let me know if i can be of any more assistance in the meantime.<br /><br />We offer various payment methods including debit card, credit card over the phone, pay pal and instant bank transfer. Bank transfer is our<br />preferred payment choice and there are no extra surcharges to pay if you are making an instant bank transfer. Please use the invoice numbe r  <br />as a  reference while making a payment. You will find our bank details on the invoice.<br /><br />If you wish to pay by card over the phone then please drop me an email for a call back request and a member staff will call you to process your payment. <br /><br />Thank you for your business, very much appreciated. <br /><br />Thanks & Regards,<br />Sales Team'): ?> checked<?php endif; ?>/>
                Custom Draft
                <br>
            <?php else: ?>
                <input type="radio" onclick="javascript:yesnoCheck();" name="emaildraft" id="yesCheck" checked  /> 
                Standard Draft &nbsp;&nbsp;
                <input type="radio" onclick="javascript:yesnoCheck();" name="emaildraft" id="noCheck" />
                Custom Draft
                <br>
            <?php endif; ?>
            
<div id="standard" >
  <?php if ($this->_tpl_vars['clientDraft'] == ''): ?>
        <textarea name="clientDraft" id="clientDraft" rows="7" cols="70" >Dear Custmer,<br /><br />I attach our invoice for you to make the payment. Please do check if i have entered the correct specifications, billing and shipping  address <br /> as the job will be processed based on the information provided in the invoice. Once payment has been received we will process your job<br />and advise you of a delivery date.  Please let me know if i can be of any more assistance in the meantime.<br /><br />We offer various payment methods including debit card, credit card over the phone, pay pal and instant bank transfer. Bank transfer is our<br />preferred payment choice and there are no extra surcharges to pay if you are making an instant bank transfer. Please use the invoice numbe r  <br />as a  reference while making a payment. You will find our bank details on the invoice.<br /><br />If you wish to pay by card over the phone then please drop me an email for a call back request and a member staff will call you to process your payment. <br /><br />Thank you for your business, very much appreciated. <br /><br />Thanks & Regards,<br />Sales Team</textarea>
  <?php else: ?>
        <textarea name="clientDraft" id="clientDraft" rows="7" cols="70" ><?php echo StripSlash($this->_tpl_vars['clientDraft']); ?>
</textarea><?php endif; ?>
</div>
            
                     
      </td>
    </tr>
     <tr>
      <td width="30%"><div align="right">Internal comments :</div></td>
      <td width="1%">&nbsp;</td>
      <td width="69%" colspan="2">
          <textarea name="internalcomment" rows="10" cols="120"><?php echo StripSlash($this->_tpl_vars['internalcomment']); ?>
</textarea>          
      </td>
    </tr>
    
        <tr>
            <td  colspan="3" align="center">
                  
                  
                 <input type="submit" name="UpdateInvoice" value="Update Invoice" > &nbsp;&nbsp;&nbsp;&nbsp;
                 <input type="submit" name="Submit" value="Send Invoice" > &nbsp;&nbsp;&nbsp;&nbsp;
             <input type="button" onclick="self.location='<?php echo $this->_tpl_vars['_conf_vars']['ADMIN_URL']; ?>
index.php?opt=<?php echo $this->_tpl_vars['opt']; ?>
<?php echo $this->_tpl_vars['qstr']; ?>
'" name="button" value="Back" class="button"/>   
          </td>        
        </tr>
</table>
</form>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => 'siteadmin/footer.tpl', 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>