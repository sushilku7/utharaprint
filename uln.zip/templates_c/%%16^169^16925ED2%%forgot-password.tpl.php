<?php /* Smarty version 2.6.19, created on 2017-04-10 08:12:10
         compiled from siteadmin/admin/forgot-password.tpl */ ?>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => 'siteadmin/header.tpl', 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => 'siteadmin/left.tpl', 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
<form action="" method="post" enctype="multipart/form-data">
  <table border="0" align="center" cellpadding="0" cellspacing="0" class="logintable">
    <tr>
      <th colspan="2">Forgot Password</th>
    </tr>
    <?php if ($this->_tpl_vars['show_msg'] != ''): ?> <?php echo $this->_tpl_vars['show_msg']; ?>
 <?php endif; ?>
    <tr>
      <td colspan="2"><strong>Enter your email adress</strong></td>
    </tr>
    <tr>
      <td colspan="2"><input name="admin_email" id="admin_email" type="text" size="40"/></td>
    </tr>
    <td width="95"><input type="submit" name="Submit" value="Process" class="button"/></td>
      <td><a href="<?php echo $this->_tpl_vars['_conf_vars']['ADMIN_URL']; ?>
">Back to Login Page</a> </td>
    </tr>
  </table>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
</form>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => 'siteadmin/footer.tpl', 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>