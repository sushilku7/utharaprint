<?php /* Smarty version 2.6.19, created on 2017-04-04 10:05:35
         compiled from siteadmin/ordermanagement/createinvoice.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'StripSlash', 'siteadmin/ordermanagement/createinvoice.tpl', 15, false),array('modifier', 'sizeof', 'siteadmin/ordermanagement/createinvoice.tpl', 49, false),)), $this); ?>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => 'siteadmin/header.tpl', 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => 'siteadmin/left.tpl', 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>

<hr />
<div style="width:auto;text-align:center;"><img src="http://www.delhiinfotech.in/utharaprint/images/logo.png" alt="Uthara Print" border="0" /></div>
<hr />
<table align="center" width="70%" border="0" cellspacing="5" cellpadding="5">
<tr>
    <td align="left" valign="middle" colspan="4"><div style="padding:20px 10px;color:green;font-size:16px;font-weight:bold;text-align:center;"><?php if ($this->_tpl_vars['show_msg'] != ''): ?><?php echo $this->_tpl_vars['show_msg']; ?>
<?php endif; ?></div></td>    
  </tr>
  <tr>
    <td align="left" valign="middle" colspan="4"><b>To</b></td>    
  </tr>
  <tr>
    <td align="left" valign="middle"><?php echo StripSlash($this->_tpl_vars['memberName']); ?>
 </td>
    <td align="right" valign="middle"><b>A/c No. :</b></td>
    <td align="left" valign="middle">&nbsp;</td>
    <td align="left" valign="middle"><?php echo $this->_tpl_vars['invoiceId']; ?>
</td>
  </tr>
  <tr>
    <td align="left" valign="middle">
     <?php echo StripSlash($this->_tpl_vars['memberAddress1']); ?>
<br />
     <?php echo StripSlash($this->_tpl_vars['memberAddress2']); ?>
<br />
     <?php echo StripSlash($this->_tpl_vars['memberAddress3']); ?>

     </td>
    <td align="right" valign="middle"> <b>Invoice No. :</b></td>
    <td align="left" valign="middle">&nbsp;</td>
    <td align="left" valign="middle">UTP-GB-ONLINE-0<?php echo StripSlash($this->_tpl_vars['payrefno']); ?>
</td>
  </tr>
  <tr>
    <td align="left" valign="middle">&nbsp;</td>
    <td align="right" valign="middle"><b>Pay Ref. No. :</b></td>
    <td align="left" valign="middle">&nbsp;</td>
    <td align="left" valign="middle"><?php echo StripSlash($this->_tpl_vars['payrefno']); ?>
</td>
  </tr>
  <tr>
    <td width="54%" align="left" valign="middle">&nbsp;</td>
    <td width="14%" align="right" valign="middle"><b>Date :</b></td>
    <td width="3%" align="left" valign="middle">&nbsp;</td>
    <td width="29%" align="left" valign="middle"><?php echo StripSlash($this->_tpl_vars['currDate']); ?>
</td>
  </tr>
</table>

<div style="text-align:center;">
	  <table align="center" width="70%" border="1" cellspacing="3" cellpadding="3" class="listdata">
	      <tr>
	      <td width="99%" colspan="4">
				    <table width="100%" border="0" cellspacing="5" cellpadding="5" class="listdata">
				    <?php if (sizeof($this->_tpl_vars['cartArr']) > 0): ?>
				    <tr>
				      <th width="10%" style="text-align:left;">Sr. No.</th>			      
				      <th width='15%' style="text-align:left;">Product Name</th>  
                                      <th width='15%' style="text-align:left;">Product Size</th>  
                                      <th width='15%' style="text-align:left;">Product Paper</th>  
                                      <th width='15%' style="text-align:left;">Product Pages</th>  
				      <th width="15%" style="text-align:left;">Quantity</th>
				      <th width="15%" style="text-align:left;">Price</th>
				    </tr>
				    <?php $this->assign($this->_tpl_vars['i'], 0); ?>
				    <?php $_from = $this->_tpl_vars['cartArr']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['k'] => $this->_tpl_vars['v']):
?>
				         <?php $this->assign('i', $this->_tpl_vars['i']+1); ?>
				    <tr class="<?php if ($this->_tpl_vars['v']['sno']%2 == '0'): ?>odd<?php else: ?>even<?php endif; ?>">
				      <td style="text-align:left;"><?php echo $this->_tpl_vars['i']; ?>
</td>
				      <td style="text-align:left;"><?php echo $this->_tpl_vars['v']['productName']; ?>
</td>
                                      <td style="text-align:left;"><?php echo $this->_tpl_vars['v']['subProductName']; ?>
</td>
                                      <td style="text-align:left;"><?php echo $this->_tpl_vars['v']['productPaper']; ?>
</td>
                                      <td style="text-align:left;"><?php echo $this->_tpl_vars['v']['productPages']; ?>
</td>                                      
				      <td style="text-align:left;"><?php echo $this->_tpl_vars['v']['quantity']; ?>
</td>
				      <td style="text-align:left;"><?php echo $this->_tpl_vars['v']['price']; ?>
</td>
				    </tr>
				    <?php endforeach; endif; unset($_from); ?>
				    <?php else: ?>
				    <tr>
				      <td colspan="4">Record not available.</td>
				    </tr>
				    <?php endif; ?>
				  </table>
	      </td>	     
	      </tr> 
	</table>
	  <table align="center" width="70%" border="0" cellspacing="2" cellpadding="2">
	  <tr>
	      <td width="70%"><div align="right"><b>Net Amount :</b></div></td>
	      <td width="2%">&nbsp;</td>
	      <td width="28%" align="left"><?php echo StripSlash($this->_tpl_vars['totalNetAmount']); ?>
</td>
	  </tr> 	 
	  <tr>
	      <td width="70%"><div align="right"><b>E-Mail Charges :</b></div></td>
	      <td width="2%">&nbsp;</td>
	      <td width="28%" align="left"><?php echo StripSlash($this->_tpl_vars['emailCharges']); ?>
</td>
	  </tr> 
	  <tr>
	      <td width="70%"><div align="right"><b>Mail Charges :</b></div></td>
	      <td width="2%">&nbsp;</td>
	      <td width="28%" align="left"><?php echo StripSlash($this->_tpl_vars['mailCharges']); ?>
</td>
	  </tr> 
	   <tr>
	      <td width="70%"><div align="right"><b>VAT @ 20.00 % :</b></div></td>
	      <td width="2%">&nbsp;</td>
	      <td width="28%" align="left"><?php echo StripSlash($this->_tpl_vars['vatAmount']); ?>
</td>
	  </tr> 
	  <tr>
	      <td width="70%"><div align="right"><font color="red" size="3pt"><b>Total  Amount :</b></font></div></td>
	      <td width="2%">&nbsp;</td>
	      <td width="28%" align="left"><font color="red" size="3pt"><b>&pound; <?php echo StripSlash($this->_tpl_vars['totalAmout']); ?>
</b></font></td>
	  </tr> 
	  
	   <tr>
	   	  <td width="70%">&nbsp;&nbsp;</td>
	      <td width="2%">&nbsp;</td>
	      <td width="28%" align="left">
	      	<b>For Utharaprint.co.uk</b><br /><br />
			<b>Authorised sign.</b><br />
			Uthara Print Ltd <br />
			Towngate House, <br />
			2-8 Parkstone Road, <br />
			Poole <br />
			BH15 2PW <br />
			e-mail: accounts@utharaprint.co.uk<br />
			website: www.utharaprint.co.uk<br />
                        <b>Company No:</b> 07934361 (England and Wales)<br />
                        <b>VAT REGISTRATION UK:</b> 142628911<br />
	      </td>
	  </tr> 
</table>

		<form name="frm" id="frm" action="" method="post" enctype="multipart/form-data">
			<input  type="hidden" name="orderId" id="orderId" value="<?php echo StripSlash($this->_tpl_vars['payrefno']); ?>
" />
			<input  type="hidden" name="acno" id="acno" value="<?php echo StripSlash($this->_tpl_vars['invoiceId']); ?>
" />
			<input  type="hidden" name="invoiceno" id="invoiceno" value="UTP-GB-ONLINE-0<?php echo StripSlash($this->_tpl_vars['payrefno']); ?>
" />
			<input  type="hidden" name="payrefno" id="payrefno" value="<?php echo StripSlash($this->_tpl_vars['payrefno']); ?>
" />
			
			<input type="submit" name="Submit" id="Submit" value="Send Invoice">
			<input type="button" onclick="self.location='<?php echo $this->_tpl_vars['_conf_vars']['ADMIN_URL']; ?>
index.php?opt=<?php echo $this->_tpl_vars['opt']; ?>
<?php echo $this->_tpl_vars['qstr']; ?>
'" name="button" value="Back" class="button"/>   
		</form>

</div>
		
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => 'siteadmin/footer.tpl', 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>