<?php /* Smarty version 2.6.19, created on 2018-07-03 13:10:51
         compiled from siteadmin/ourbrandmanagement/list.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'sizeof', 'siteadmin/ourbrandmanagement/list.tpl', 15, false),array('modifier', 'StripSlash', 'siteadmin/ourbrandmanagement/list.tpl', 38, false),)), $this); ?>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => 'siteadmin/header.tpl', 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => 'siteadmin/left.tpl', 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
<h1>Our Brand Listing</h1>
<form method="post" action="<?php echo $this->_tpl_vars['_conf_vars']['ADMIN_URL']; ?>
index.php?opt=<?php echo $this->_tpl_vars['opt']; ?>
&a=order<?php echo $this->_tpl_vars['qstr']; ?>
" name="frm" id="frm" enctype="multipart/form-data">
  <input type="hidden" name="productCatId" id="productCatId" value="" />
  <input type="hidden" name="p" id="p" value="1" />
  <?php if ($this->_tpl_vars['show_msg'] != ''): ?>
  <?php echo $this->_tpl_vars['show_msg']; ?>

  <?php endif; ?>
  <?php if ($this->_tpl_vars['error'] != ''): ?><ul class="successbox"><li><?php echo $this->_tpl_vars['error']; ?>
</li></ul><?php endif; ?>
  
  <table width="100%" border="0" cellspacing="2" cellpadding="2">
    <tr>
      <td align="left">
         <?php if (sizeof($this->_tpl_vars['ourbrand_arr']) > 0): ?>
        <button type="button" name="cmddelete" id="cmddelete" onclick="javascript: return fnDelete('<?php echo $this->_tpl_vars['_conf_vars']['ADMIN_URL']; ?>
index.php?opt=<?php echo $this->_tpl_vars['opt']; ?>
&a=delete<?php echo $this->_tpl_vars['qstr']; ?>
', 'Are you sure you want to delete selected Main Product (s)?');">Remove Selected Record(s)</button>
        <?php endif; ?> 
        <button type="button" onclick="document.location.href='<?php echo $this->_tpl_vars['_conf_vars']['ADMIN_URL']; ?>
index.php?opt=<?php echo $this->_tpl_vars['opt']; ?>
&a=add';">Add Our Brand</button></td>
        <td align="right">&nbsp;
        </td>
    </tr>
  </table>
  <table width="100%" border="0" cellspacing="0" cellpadding="0" class="listdata">
    <?php if (sizeof($this->_tpl_vars['ourbrand_arr']) > 0): ?>
    <tr>
      <th width="8%" style="text-align:right;">SL#</th>
      <th width='2%'><input type="checkbox" name="checkall" value='1' onClick='checkREC(document.frm);' id='checkall'/></th>
      <th width='40%'>Brand Or URL</th>  
      <th width='40%'>Images</th>  
      <th width="10%">Action<br /></th>
    </tr>
    <?php $this->assign($this->_tpl_vars['i'], 0); ?>
    <?php $_from = $this->_tpl_vars['ourbrand_arr']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['k'] => $this->_tpl_vars['v']):
?>
         <?php $this->assign('i', $this->_tpl_vars['i']+1); ?>
    <tr class="<?php if ($this->_tpl_vars['v']['sno']%2 == '0'): ?>odd<?php else: ?>even<?php endif; ?>">
      <td style="text-align:right;"><?php echo $this->_tpl_vars['v']['sno']; ?>
</td>
<td><input type="checkbox" name="record[]" id="chk<?php echo $this->_tpl_vars['v']['ourbrandId']; ?>
" value='<?php echo $this->_tpl_vars['v']['ourbrandId']; ?>
' /></td>
      <td><?php echo StripSlash($this->_tpl_vars['v']['ourbrandName']); ?>
</td>  
      <td><img src='<?php echo $this->_tpl_vars['_conf_vars']['ROOT_URL']; ?>
upload/ourbrand/<?php echo StripSlash($this->_tpl_vars['v']['image']); ?>
' width="150" /></td>
      <td nowrap="nowrap"><?php echo $this->_tpl_vars['v']['status']; ?>
&nbsp;
      <a href="<?php echo $this->_tpl_vars['_conf_vars']['ADMIN_URL']; ?>
index.php?opt=<?php echo $this->_tpl_vars['opt']; ?>
&a=edit&edit_id=<?php echo $this->_tpl_vars['v']['ourbrandId']; ?>
<?php echo $this->_tpl_vars['qstr']; ?>
">
      <img src='<?php echo $this->_tpl_vars['_conf_vars']['ADMIN_URL']; ?>
images/page_white_edit.png' border='0' style='vertical-align:middle;' /></a>
      <a href="<?php echo $this->_tpl_vars['_conf_vars']['ADMIN_URL']; ?>
index.php?opt=<?php echo $this->_tpl_vars['opt']; ?>
&a=del&id=<?php echo $this->_tpl_vars['v']['ourbrandId']; ?>
<?php echo $this->_tpl_vars['qstr']; ?>
" onclick="return confirm('Are you sure you want to remove this product category?');" title="Remove">
      <img src='<?php echo $this->_tpl_vars['_conf_vars']['ADMIN_URL']; ?>
images/delete.png' border='0' style='vertical-align:middle;' />
      </a>
      </td>
    </tr>
    <?php endforeach; endif; unset($_from); ?>
    <tr>
      <td colspan="5"><?php echo $this->_tpl_vars['navigation']; ?>
</td>
    </tr>
    <?php else: ?>
    <tr>
      <td colspan="5">Record not available.</td>
    </tr>
    <?php endif; ?>
  </table>
</form>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => 'siteadmin/footer.tpl', 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>