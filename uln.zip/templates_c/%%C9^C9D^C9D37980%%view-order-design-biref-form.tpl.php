<?php /* Smarty version 2.6.19, created on 2019-11-13 12:22:17
         compiled from siteadmin/orderdesignmanagement/view-order-design-biref-form.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'StripSlash', 'siteadmin/orderdesignmanagement/view-order-design-biref-form.tpl', 1, false),)), $this); ?>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => 'siteadmin/header.tpl', 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?><?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => 'siteadmin/left.tpl', 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?><table width="100%" cellspacing="0" cellpadding="0" border="0">  <tr>    <td><h1>View Design Details</h1></td>  </tr></table><table width="100%" border="0" cellspacing="3" cellpadding="3" class="listdata">    <tr>      <td valign="top"><div align="right">Order Number :</div></td>      <td>&nbsp;</td>      <td>&nbsp;<?php echo StripSlash($this->_tpl_vars['projectId']); ?>
</td>  </tr>  <tr>      <td valign="top"><div align="right"> Project Name :</div></td>      <td>&nbsp;</td>      <td>&nbsp;<?php echo StripSlash($this->_tpl_vars['projectName']); ?>
</td>  </tr>  <tr>      <td valign="top"><div align="right">name :</div></td>      <td>&nbsp;</td>      <td>&nbsp;<?php echo StripSlash($this->_tpl_vars['firstName']); ?>
&nbsp;<?php echo StripSlash($this->_tpl_vars['lastName']); ?>
</td>  </tr>   <tr>      <td valign="top"><div align="right">Email :</div></td>      <td>&nbsp;</td>      <td>&nbsp;<?php echo StripSlash($this->_tpl_vars['memberEmail']); ?>
</td>  </tr>   <tr>      <td valign="top"><div align="right">Member Mobile :</div></td>      <td>&nbsp;</td>      <td>&nbsp;<?php echo StripSlash($this->_tpl_vars['memberMobile']); ?>
</td>  </tr>   <tr>      <td valign="top"><div align="right">addition Info :</div></td>      <td>&nbsp;</td>      <td>&nbsp;<?php echo StripSlash($this->_tpl_vars['additionInfo']); ?>
</td>  </tr>   <tr>      <td valign="top"><div align="right">Logo Text :</div></td>      <td>&nbsp;</td>      <td>&nbsp;<?php echo StripSlash($this->_tpl_vars['logoText']); ?>
</td>  </tr>  <tr>      <td valign="top"><div align="right">Logo BaseLine :</div></td>      <td>&nbsp;</td>      <td>&nbsp;<?php echo StripSlash($this->_tpl_vars['logoBaseLine']); ?>
</td>  </tr>  <tr>      <td valign="top"><div align="right">logoStyle :</div></td>      <td>&nbsp;</td>      <td>&nbsp;<?php echo StripSlash($this->_tpl_vars['logoStyle']); ?>
</td>  </tr><tr>      <td valign="top"><div align="right">logoTextColor :</div></td>      <td>&nbsp;</td>      <td>&nbsp;<?php echo StripSlash($this->_tpl_vars['logoTextColor']); ?>
</td>  </tr><tr>      <td valign="top"><div align="right">logoBaselineColor :</div></td>      <td>&nbsp;</td>      <td>&nbsp;<?php echo StripSlash($this->_tpl_vars['logoBaselineColor']); ?>
</td>  </tr><tr>      <td valign="top"><div align="right">logoBackgroundColor :</div></td>      <td>&nbsp;</td>      <td>&nbsp;<?php echo StripSlash($this->_tpl_vars['logoBackgroundColor']); ?>
</td>  </tr><tr>      <td valign="top"><div align="right">referenceLogo :</div></td>      <td>&nbsp;</td>      <td>&nbsp;<?php echo StripSlash($this->_tpl_vars['referenceLogo']); ?>
</td>  </tr>  <tr>      <td valign="top"><div align="right">designDesc :</div></td>      <td>&nbsp;</td>      <td>&nbsp;<?php echo StripSlash($this->_tpl_vars['designDesc']); ?>
</td>  </tr> <tr>      <td valign="top"><div align="right">briefDesc :</div></td>      <td>&nbsp;</td>      <td>&nbsp;<?php echo StripSlash($this->_tpl_vars['briefDesc']); ?>
</td>  </tr>  <tr>      <td valign="top"><div align="right">additionComment :</div></td>      <td>&nbsp;</td>      <td>&nbsp;<?php echo StripSlash($this->_tpl_vars['additionComment']); ?>
</td>  </tr>   <tr>      <td valign="top"><div align="right">Upload files :</div></td>      <td>&nbsp;</td>	  <td><a href='user-design-download.php?filename=<?php echo StripSlash($this->_tpl_vars['uploadFiles']); ?>
'>Download Design 1</a></td>		</tr>     	   </table><?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => 'siteadmin/footer.tpl', 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>