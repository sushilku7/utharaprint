<?php /* Smarty version 2.6.19, created on 2016-09-05 12:19:32
         compiled from siteadmin/admin/change-password.tpl */ ?>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => 'siteadmin/header.tpl', 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => 'siteadmin/left.tpl', 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
<h1>Change Password</h1>
<form action="" method="post" name="frmpwd" id="frmpwd">
  <?php if ($this->_tpl_vars['show_msg'] != ''): ?>
  	<?php echo $this->_tpl_vars['show_msg']; ?>

  <?php endif; ?>
  <table border="0" align="" cellpadding="0" cellspacing="0" class="listdata" width="100%">
    <tr>
      <td width="15%">Current Password<span class="star">*</span></td>
      <td width="85%"><input id="user_password" name="user_password" type="password" size="40" value="" /></td>
    </tr>
    <tr>
      <td>New Password<span class="star">*</span></td>
      <td><input id="new_pwd" name="new_pwd" type="password" size="40" value="" /></td>
    </tr>
    <tr>
      <td>Confirm New Password<span class="star">*</span></td>
      <td><input id="repwd" name="repwd" type="password" size="40" value="" /></td>
    </tr>
    <tr>
      <td colspan="2" align="left"><button type="submit">Modify</button></td>
    </tr>
  </table>
</form>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => 'siteadmin/footer.tpl', 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>