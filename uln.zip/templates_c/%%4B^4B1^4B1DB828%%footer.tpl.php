<?php /* Smarty version 2.6.19, created on 2019-08-02 11:34:38
         compiled from siteadmin/footer.tpl */ ?>


	</td>
  </tr>
</table>

<div class="footer"></div>
<div id="filter-popup-report"></div>
<!--
<script type="text/javascript" language="javascript" src="<?php echo $this->_tpl_vars['_conf_vars']['ADMIN_URL']; ?>
js/comman.js"></script> 
-->

<!--
<script type="text/javascript" src="<?php echo $this->_tpl_vars['_conf_vars']['ADMIN_URL']; ?>
include/js/global.js"></script>
-->
<iframe width=174 height=189 name="gToday:normal:agenda.js" id="gToday:normal:agenda.js" src="<?php echo $this->_tpl_vars['_conf_vars']['SITE_ROOT_DIR']; ?>
calendar/ipopeng.htm" scrolling="no" frameborder="0" style="visibility:visible; z-index:999; position:absolute; top:-500px; left:-500px;"></iframe>
</body>
</html>