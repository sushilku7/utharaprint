<?php /* Smarty version 2.6.19, created on 2017-02-28 13:58:13
         compiled from siteadmin/productbackup/manage_product_tbl.tpl */ ?>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => 'siteadmin/header.tpl', 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?><?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => 'siteadmin/left.tpl', 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?><h1>Product Listing</h1><form method="post" action="<?php echo $this->_tpl_vars['_conf_vars']['ADMIN_URL']; ?>
index.php?opt=<?php echo $this->_tpl_vars['opt']; ?>
&a=order<?php echo $this->_tpl_vars['qstr']; ?>
" name="frm" id="frm" enctype="multipart/form-data">  <input type="hidden" name="productId" id="productId" value="" />  <input type="hidden" name="p" id="p" value="1" />  <?php if ($this->_tpl_vars['error'] != ''): ?><ul class="successbox"><li><?php echo $this->_tpl_vars['error']; ?>
</li></ul><?php endif; ?>    <table width="400px" border="0" cellspacing="2" cellpadding="2">     <tr>      <td align="left">          &nbsp;&nbsp;      </td>     </tr>      <tr>      <td align="left">      <div style="color:green;font-size: 15px;font-weight: bold;">          <?php if ($this->_tpl_vars['emptyMsg'] != ''): ?>                <?php echo $this->_tpl_vars['emptyMsg']; ?>
          <?php endif; ?>            <?php if ($this->_tpl_vars['restoreMsg'] != ''): ?>                <?php echo $this->_tpl_vars['restoreMsg']; ?>
          <?php endif; ?>      </div>      </td>     </tr>    <tr>      <td align="left">        <button type="button" onclick="document.location.href='<?php echo $this->_tpl_vars['_conf_vars']['ADMIN_URL']; ?>
index.php?opt=productbackup&a=bckprotbl';">Take Product Table Back Up      </td>     </tr>     <tr>        <td align="left">           <button type="button" onclick="document.location.href='<?php echo $this->_tpl_vars['_conf_vars']['ADMIN_URL']; ?>
index.php?opt=productbackup&a=etyprotbl';">Empty Product Table        </td>     </tr>     <tr>        <td align="left">           <button type="button" onclick="document.location.href='<?php echo $this->_tpl_vars['_conf_vars']['ADMIN_URL']; ?>
index.php?opt=productbackup&a=upldprofile';">Restore Product Table With Old Data        </td>    </tr>    <tr>        <td align="left">           <button type="button" onclick="document.location.href='<?php echo $this->_tpl_vars['_conf_vars']['ADMIN_URL']; ?>
index.php?opt=productbackup&a=add';">Upload Product Table With New Data        </td>    </tr>    <tr>        <td align="left">           <button type="button" onclick="document.location.href='<?php echo $this->_tpl_vars['_conf_vars']['ADMIN_URL']; ?>
index.php?opt=productbackup&a=custombckprotbl';">Download Product Customize Table        </td>    </tr>  </table> </form><?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => 'siteadmin/footer.tpl', 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>