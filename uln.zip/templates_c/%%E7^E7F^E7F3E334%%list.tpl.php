<?php /* Smarty version 2.6.19, created on 2017-04-01 07:48:36
         compiled from siteadmin/salesreportmanagement/list.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'StripSlash', 'siteadmin/salesreportmanagement/list.tpl', 18, false),array('modifier', 'sizeof', 'siteadmin/salesreportmanagement/list.tpl', 40, false),)), $this); ?>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => 'siteadmin/header.tpl', 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => 'siteadmin/left.tpl', 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
<h1>Sales Report</h1>
<form method="post" action="<?php echo $this->_tpl_vars['_conf_vars']['ADMIN_URL']; ?>
index.php?opt=<?php echo $this->_tpl_vars['opt']; ?>
&a=order<?php echo $this->_tpl_vars['qstr']; ?>
" name="frm" id="frm" enctype="multipart/form-data">
  <input type="hidden" name="offer_id" id="offer_id" value="" />
  <input type="hidden" name="p" id="p" value="1" />
  <?php if ($this->_tpl_vars['show_msg'] != ''): ?>
  <?php echo $this->_tpl_vars['show_msg']; ?>

  <?php endif; ?>
  <?php if ($this->_tpl_vars['error'] != ''): ?><ul class="successbox"><li><?php echo $this->_tpl_vars['error']; ?>
</li></ul><?php endif; ?>
  <table width="100%" border="0" cellspacing="2" cellpadding="2">
       
        <td>&nbsp; </td>
            <tr>
			      <td width="20%"><div align="right">Select Date From :</div></td>
			      <td width="1%">&nbsp;</td>
			      <td width="29%" align="left" >
			      <input type="text" id="expectDate" name="expectDate" value="<?php echo StripSlash($this->_tpl_vars['expect_date']); ?>
"  style="width:100px;" maxlength="100" onclick="if(self.gfPop)gfPop.fPopCalendar(document.frm.expectDate);return false;" />
			      <img src="<?php echo $this->_tpl_vars['_conf_vars']['ADMIN_URL']; ?>
images/calbtn.gif" alt=""  align="absmiddle" onclick="if(self.gfPop)gfPop.fPopCalendar(document.frm.expectDate);return false;"   />
			      </td>
                              
                              <td width="20%" ><div align="left">Select Date To :</div></td>
			     
                              <td  width="30%">
			      <input type="text" id="expectDate1" name="expectDate1" value="<?php echo StripSlash($this->_tpl_vars['expect_date1']); ?>
"  style="width:100px;" maxlength="100" onclick="if(self.gfPop)gfPop.fPopCalendar(document.frm.expectDate1);return false;" />
			      <img src="<?php echo $this->_tpl_vars['_conf_vars']['ADMIN_URL']; ?>
images/calbtn.gif" alt=""  align="absmiddle" onclick="if(self.gfPop)gfPop.fPopCalendar(document.frm.expectDate1);return false;"   />
			      </td>
			  </tr>
                          <tr align="center">
                              
                              <td colspan="5"><input type="submit" name="submit" id="submit" value="submit">
                                  &nbsp;&nbsp;&nbsp;&nbsp;
                              <input type="submit" name="gnrtecsv" id="gnrtecsv" value="Generat Report in CSV">                              
                              </td>
                          </tr>
          
   
  </table>
    <table width="100%" border="0" cellspacing="0" cellpadding="0" class="listdata">
    <?php if (sizeof($this->_tpl_vars['order_arr']) > 0): ?>
    <tr>
      <th width="8%" style="text-align:right;">Order No.#</th>
      <th width='2%'><input type="checkbox" name="checkall" value='1' onClick='checkREC(document.frm);' id='checkall'/></th>
      <th width='10%'>Order Date</th> 
      <th width='15%'>Member Name</th> 
      <th width='10%'>Total Amount</th> 
      <th width="15%">Country</th>
      <th width="10%">County</th>
      <th width="20%">Comment</th>
      <th width="10%">Action</th>
      </tr>
    <?php $this->assign($this->_tpl_vars['i'], 0); ?>
    <?php $_from = $this->_tpl_vars['order_arr']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['k'] => $this->_tpl_vars['v']):
?>
         <?php $this->assign('i', $this->_tpl_vars['i']+1); ?>
         
                 
    <tr style="<?php if ($this->_tpl_vars['v']['flagInvoice'] == 'Not Send'): ?>background-color:yellow;<?php endif; ?><?php if ($this->_tpl_vars['v']['paymentStatus'] == 'Pending'): ?>background-color:pink;<?php endif; ?><?php if ($this->_tpl_vars['v']['orderStats'] == 'Printing'): ?>background-color:green;<?php endif; ?><?php if ($this->_tpl_vars['v']['orderStats'] == 'Delivered'): ?>background-color:#990099;<?php endif; ?>
			   <?php if ($this->_tpl_vars['v']['orderStats'] == 'Artwork issue - no bleed and no crop mark'): ?>background-color:#0000CC;<?php endif; ?> 
			   <?php if ($this->_tpl_vars['v']['orderStats'] == 'Artwork issue - Low resolution file'): ?>background-color:#0000CC;<?php endif; ?> 
			   <?php if ($this->_tpl_vars['v']['orderStats'] == 'Artwork issue - Not correct size'): ?>background-color:#0000CC;<?php endif; ?> 
			   <?php if ($this->_tpl_vars['v']['orderStats'] == 'Artwork issue - completely incorrect'): ?>background-color:#0000CC;<?php endif; ?> 
			   <?php if ($this->_tpl_vars['v']['orderStats'] == 'Artwork issue - reported to customer'): ?>background-color:#0000CC;<?php endif; ?> 
			   <?php if ($this->_tpl_vars['v']['orderStats'] == 'Artwork issue- sorted and waiting for customer approval'): ?>background-color:#0000CC;<?php endif; ?> 
			   ">
    
      <td style="text-align:right;"><?php echo $this->_tpl_vars['v']['orderId']; ?>
</td>
	  <td><input type="checkbox" name="record[]" id="chk<?php echo $this->_tpl_vars['v']['orderId']; ?>
" value='<?php echo $this->_tpl_vars['v']['orderId']; ?>
' /></td>
      <td><?php echo StripSlash($this->_tpl_vars['v']['orderDate']); ?>
</td>   
      <td><?php echo StripSlash($this->_tpl_vars['v']['memberName']); ?>
</td>   
      <td><?php echo StripSlash($this->_tpl_vars['v']['totalAmout']); ?>
</td>   
      <td><?php echo StripSlash($this->_tpl_vars['v']['memberCountry']); ?>
</td>
      <td><?php echo StripSlash($this->_tpl_vars['v']['memberCounty']); ?>
</td>   
      <td><?php echo StripSlash($this->_tpl_vars['v']['orderComment']); ?>
</td>       
      <td nowrap="nowrap">
      <a href="<?php echo $this->_tpl_vars['_conf_vars']['ADMIN_URL']; ?>
index.php?opt=ordermanagement&a=vieworder&edit_id=<?php echo $this->_tpl_vars['v']['orderId']; ?>
<?php echo $this->_tpl_vars['qstr']; ?>
">
      View Order</a>
      
      </td>
    </tr>
    <?php endforeach; endif; unset($_from); ?>
    
    <?php else: ?>
    <tr>
      <td colspan="5">Record not available.</td>
    </tr>
    <?php endif; ?>
  </table>
</form>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => 'siteadmin/footer.tpl', 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>