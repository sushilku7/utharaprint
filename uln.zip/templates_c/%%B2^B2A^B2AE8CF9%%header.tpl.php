<?php /* Smarty version 2.6.19, created on 2020-01-10 12:43:23
         compiled from siteadmin/header.tpl */ ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>Uthara Print - Administrator</title>

<link rel="shortcut icon" href="<?php echo $this->_tpl_vars['_conf_vars']['SITE_ROOT_DIR']; ?>
images/favicon.png" />
<!-- Start Newly Added For Lightbox -->
<link rel="stylesheet" href="<?php echo $this->_tpl_vars['_conf_vars']['SITE_ROOT_DIR']; ?>
css/lightbox.css" type="text/css" media="screen" />
<!-- End Newly Added For Lightbox -->

<script type="text/javascript">
	var root_url = '<?php echo $this->_tpl_vars['_conf_vars']['ROOT_URL']; ?>
';
	var admin_url = '<?php echo $this->_tpl_vars['_conf_vars']['ADMIN_URL']; ?>
';
	var site_root_dir = '<?php echo $this->_tpl_vars['_conf_vars']['SITE_ROOT_DIR']; ?>
';
	var file_extn = '<?php echo $this->_tpl_vars['_conf_vars']['FILE_EXTN']; ?>
';	
</script>
<link href="<?php echo $this->_tpl_vars['_conf_vars']['ADMIN_URL']; ?>
css/style.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" href="<?php echo $this->_tpl_vars['_conf_vars']['SITE_ROOT_DIR']; ?>
fancybox/jquery.fancybox-1.3.4.css" type="text/css" media="screen" />
<script type="text/javascript" language="javascript" src="<?php echo $this->_tpl_vars['_conf_vars']['SITE_ROOT_DIR']; ?>
js/swfobject.js"></script>
<!-- <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.4/jquery.min.js"></script>
     
<script type="text/javascript" src="<?php echo $this->_tpl_vars['_conf_vars']['SITE_ROOT_DIR']; ?>
fancybox/jquery.fancybox-1.3.4.pack.js"></script>
<!-- End Newly Added For Lightbox -->

<script type="text/javascript" language="JavaScript" src="<?php echo $this->_tpl_vars['_conf_vars']['ADMIN_URL']; ?>
include/js/global.js"></script>
<!-- Start add ajax.js file -->
<script type="text/javascript" language="JavaScript" src="<?php echo $this->_tpl_vars['_conf_vars']['SITE_ROOT_DIR']; ?>
js/ajax.js"></script>
<!-- End add ajax.js file -->
<!---editor----->
<script src="<?php echo $this->_tpl_vars['_conf_vars']['ADMIN_URL']; ?>
ckeditor/ckeditor.js"></script>
<script src="<?php echo $this->_tpl_vars['_conf_vars']['ADMIN_URL']; ?>
ckeditor/samples/js/sample.js"></script>
<!---end editor----->
<?php echo '
<script language="JavaScript" type="text/JavaScript">
<!--
function wimpyPopPlayer(theFile,id,stuff) 
{
	testwindow = window.open(theFile,id,stuff);
	testwindow.moveTo(1030, 300);
}
//-->
</script> 
'; ?>

</head>
<body>
<div class="header">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="35%">
    	<a href="<?php echo $this->_tpl_vars['_conf_vars']['ROOT_URL']; ?>
" target="_blank">
        	<!-- Logo Here -->
    	</a></td>
    <td width="30%" align="center"><a href="<?php echo $this->_tpl_vars['_conf_vars']['ADMIN_URL']; ?>
" style="font-size:24px;"><img src="images/logo.png" /></a></td>
    <td width="35%" align="right" valign="top">
	<?php if ($this->_tpl_vars['sess_username'] != ''): ?>
        <div id="nav">
            <ul>  	

                <!--<li><a href="<?php echo $this->_tpl_vars['_conf_vars']['ADMIN_URL']; ?>
index.php?a=account">My Account</a></li>-->
                <li><a href="<?php echo $this->_tpl_vars['_conf_vars']['ADMIN_URL']; ?>
index.php?a=chg_pwd">Change Password</a></li>
                <li><a href="<?php echo $this->_tpl_vars['_conf_vars']['ADMIN_URL']; ?>
index.php?a=logout">Logout</a></li>
            </ul>
        </div>
	<?php endif; ?>
	</td>
    </tr>
</table>
</div>
<table width="100%" border="0" cellspacing="0" cellpadding="0" class="mainTable">
  <tr>