<?php /* Smarty version 2.6.19, created on 2017-04-05 10:16:54
         compiled from siteadmin/featuredproductmanagement/featuredproductcategory.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'StripSlash', 'siteadmin/featuredproductmanagement/featuredproductcategory.tpl', 13, false),)), $this); ?>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => 'siteadmin/header.tpl', 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => 'siteadmin/left.tpl', 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
<table width="100%" cellspacing="0" cellpadding="0" border="0">
  <tr>
    <td><h1><?php if ($this->_tpl_vars['action'] == 'add'): ?>Add<?php else: ?>Edit<?php endif; ?> Feature Product </h1></td>
  </tr>
</table>
<?php if ($this->_tpl_vars['show_msg'] != ''): ?>
  <?php echo $this->_tpl_vars['show_msg']; ?>

  <?php endif; ?>
<form name="frm" id="frm" action="" method="post" enctype="multipart/form-data">
<input type="hidden" name="btn" id="btn" value="<?php echo $this->_tpl_vars['action']; ?>
" />
<input  type="hidden" name="oldImage" id="oldImage" value="<?php echo StripSlash($this->_tpl_vars['anotherImagePath']); ?>
" />
<table width="100%" border="0" cellspacing="3" cellpadding="3" class="listdata">
  <tr>
      <td width="30%"><div align="right">Product Name:<span class="star">*</span></div></td>
      <td width="1%">&nbsp;</td>
      <td width="69%" colspan="2">
      <?php echo $this->_tpl_vars['product_catname']; ?>

      </td>
  </tr>  
   <tr>
      <td width="30%"><div align="right">Product Short Description:<span class="star">*</span></div></td>
      <td width="1%">&nbsp;</td>
      <td width="69%" colspan="2">
      		<input type="text" id="productCatDesc" name="productCatDesc" value="<?php echo StripSlash($this->_tpl_vars['productCatDesc']); ?>
"  style="width:200px;" maxlength="100" />
      </td>
  </tr> 
  <tr>
    <td width="30%"><div align="right">Feature Image :<span class="star"></span></div></td>
    <td width="1%">&nbsp;</td>
	<td valign="middle" width="30%">      
			<input type="file" name="anotherImagePath" id="anotherImagePath" />    
	</td>
    <td valign="top" width="39%">  
      		<?php echo StripSlash($this->_tpl_vars['fcImage']); ?>

    </td>
  </tr>
  
  <!-- <tr>
    <td><div align="right">Ordering:<span class="star"></span></div></td>
    <td>&nbsp;</td>
    <td><input type="text" id="ordering" name="ordering" value="<?php echo StripSlash($this->_tpl_vars['ordering']); ?>
"  style="width:200px;" maxlength="100" /></td>
  </tr>-->
  <tr>
      <td  colspan="3" align="center">
      
            
      <!-- <input type="hidden" name="catImageHidden" id="catImageHidden" value="<?php echo $this->_tpl_vars['catImageHidden']; ?>
" /> -->
      <!-- <input type="hidden" name="filmMakerImageHidden" id="filmMakerImageHidden" value="<?php echo $this->_tpl_vars['filmMakerImageHidden']; ?>
" /> -->
      
        <?php if ($this->_tpl_vars['action'] == 'add'): ?>
              <button type="submit" onclick="document.frm.btn.value = 'success';"  style="width:100px;">Add</button>
          <?php else: ?>
            <button type="submit" onclick="document.frm.btn.value = 'update';" style="width:100px;">Update</button>
          <?php endif; ?>
        &nbsp;&nbsp;&nbsp;
        <input type="button" onclick="self.location='<?php echo $this->_tpl_vars['_conf_vars']['ADMIN_URL']; ?>
index.php?opt=<?php echo $this->_tpl_vars['opt']; ?>
<?php echo $this->_tpl_vars['qstr']; ?>
&sltMemberType=<?php echo $this->_tpl_vars['sltMemberType']; ?>
'" name="button" value="Back" class="button"/>   </td>
    </tr>
</table>
</form>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => 'siteadmin/footer.tpl', 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>