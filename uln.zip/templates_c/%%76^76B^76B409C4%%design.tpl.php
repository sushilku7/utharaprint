<?php /* Smarty version 2.6.19, created on 2019-04-11 17:31:55
         compiled from siteadmin/designmanagement/design.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'StripSlash', 'siteadmin/designmanagement/design.tpl', 19, false),)), $this); ?>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => 'siteadmin/header.tpl', 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => 'siteadmin/left.tpl', 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
<table width="100%" cellspacing="0" cellpadding="0" border="0">
  <tr>
    <td><h1><?php if ($this->_tpl_vars['action'] == 'add'): ?>Add<?php else: ?>Edit<?php endif; ?> Design </h1></td>
  </tr>
</table>
<?php if ($this->_tpl_vars['show_msg'] != ''): ?>
  <?php echo $this->_tpl_vars['show_msg']; ?>

  <?php endif; ?>
<form name="frm" id="frm" action="" method="post" enctype="multipart/form-data">


<table width="100%" border="0" cellspacing="3" cellpadding="3" class="listdata">
   <tr>
      <td width="30%"><div align="right">Main Category Name:<span class="star">*</span></div></td>
      <td width="1%">&nbsp;</td>
      <td width="69%" colspan="2">
          <?php echo StripSlash($this->_tpl_vars['catName']); ?>

      </td>
  </tr>
  <tr>
      <td width="30%"><div align="right">Product Cat Name:<span class="star">*</span></div></td>
      <td width="1%">&nbsp;</td>
      <td width="69%" colspan="2">
          <?php echo StripSlash($this->_tpl_vars['product_sub_catname']); ?>


         
      </td>
  </tr>
  
  <tr>
      <td width="30%"><div align="right">header css:<span class="star">*</span></div></td>
      <td width="1%">&nbsp;</td>
      <td width="69%" colspan="2">
          <textarea id="designName" name="designName" rows="10" cols="50"><?php echo StripSlash($this->_tpl_vars['designName']); ?>
</textarea>
      </td>
  </tr>
  <tr>
      <td width="30%"><div align="right">Product Name:<span class="star">*</span></div></td>
      <td width="1%">&nbsp;</td>
      <td width="69%" colspan="2">
      <input type="text" id="productName" name="productName" value="<?php echo StripSlash($this->_tpl_vars['productName']); ?>
"  style="width:200px;" maxlength="100" />
      </td>
  </tr>
  <tr>
      <td width="30%"><div align="right">Product desc:<span class="star">*</span></div></td>
      <td width="1%">&nbsp;</td>
      <td width="69%" colspan="2">
          <textarea id="productDesc" name="productDesc" rows="10" cols="50"><?php echo StripSlash($this->_tpl_vars['productDesc']); ?>
</textarea>
      </td>
  </tr>
  <tr>
      <td width="30%"><div align="right">Order Design desc:<span class="star">*</span></div></td>
      <td width="1%">&nbsp;</td>
      <td width="69%" colspan="2">
          <textarea id="productDesc" name="orderDesignDesc" rows="10" cols="50"><?php echo StripSlash($this->_tpl_vars['orderDesignDesc']); ?>
</textarea>
      </td>
  </tr>
  <tr>
      <td width="30%"><div align="right">Product Price:<span class="star">*</span></div></td>
      <td width="1%">&nbsp;</td>
      <td width="69%" colspan="2">
      <input type="text" id="designCharges" name="designCharges" value="<?php echo StripSlash($this->_tpl_vars['designCharges']); ?>
"  style="width:200px;" maxlength="100" />
      </td>
  </tr>
  
  <tr>
      <td  colspan="3" align="center">
 
      
        <?php if ($this->_tpl_vars['action'] == 'add'): ?>
              <button type="submit" onclick="document.frm.btn.value = 'success';"  style="width:100px;">Add</button>
          <?php else: ?>
            <button type="submit" onclick="document.frm.btn.value = 'update';" style="width:100px;">Update</button>
          <?php endif; ?>
        &nbsp;&nbsp;&nbsp;
        <input type="button" onclick="self.location='<?php echo $this->_tpl_vars['_conf_vars']['ADMIN_URL']; ?>
index.php?opt=<?php echo $this->_tpl_vars['opt']; ?>
<?php echo $this->_tpl_vars['qstr']; ?>
&sltMemberType=<?php echo $this->_tpl_vars['sltMemberType']; ?>
'" name="button" value="Back" class="button"/>   </td>
    </tr>
</table>
</form>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => 'siteadmin/footer.tpl', 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>