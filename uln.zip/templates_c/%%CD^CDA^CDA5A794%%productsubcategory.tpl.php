<?php /* Smarty version 2.6.19, created on 2020-01-29 04:32:56
         compiled from siteadmin/productsubcatmanagement/productsubcategory.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'StripSlash', 'siteadmin/productsubcatmanagement/productsubcategory.tpl', 21, false),)), $this); ?>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => 'siteadmin/header.tpl', 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => 'siteadmin/left.tpl', 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
<?php echo '
<script type="text/javascript">
function submitForm()
{
	document.frm.submit();
}
</script>
'; ?>

<table width="100%" cellspacing="0" cellpadding="0" border="0">
  <tr>
    <td><h1><?php if ($this->_tpl_vars['action'] == 'add'): ?>Add<?php else: ?>Edit<?php endif; ?> Sub Product</h1></td>
  </tr>
</table>
<?php if ($this->_tpl_vars['show_msg'] != ''): ?>
  <?php echo $this->_tpl_vars['show_msg']; ?>

  <?php endif; ?>
<form name="frm" id="frm" action="" method="post" enctype="multipart/form-data">
<input type="hidden" name="btn" id="btn" value="<?php echo $this->_tpl_vars['action']; ?>
" />
<input  type="hidden" name="oldImage" id="oldImage" value="<?php echo StripSlash($this->_tpl_vars['catImage']); ?>
" />
<input  type="hidden" name="flag" id="flag" value="mainproduct" />
<table width="100%" border="0" cellspacing="3" cellpadding="3" class="listdata">

  <tr>
      <td width="30%"><div align="right">User Front-Main Product Name:<span class="star">*</span></div></td>
      <td width="1%">&nbsp;</td>
      <td width="69%" colspan="2">
      <?php echo StripSlash($this->_tpl_vars['product_catname']); ?>

      </td>
  </tr>
  
  <tr>
      <td width="30%"><div align="right">Product Directory Name:<span class="star">*</span></div></td>
      <td width="1%">&nbsp;</td>
      <td width="69%" colspan="2">
      <input type="text" id="dirName" name="dirName" value="<?php echo StripSlash($this->_tpl_vars['dirName']); ?>
"  style="width:200px;" maxlength="100"  />(use small size without any space)
      </td>
  </tr>

  <tr>
      <td width="30%"><div align="right">Sub Product Name:<span class="star">*</span></div></td>
      <td width="1%">&nbsp;</td>
      <td width="69%" colspan="2">
      <input type="text" id="catName" name="catName" value="<?php echo StripSlash($this->_tpl_vars['catName']); ?>
"  style="width:200px;" maxlength="100" />
      </td>
  </tr>
  
  <tr>
      <td width="30%"><div align="right">Heading-Text Description:<span class="star">*</span></div></td>
      <td width="1%">&nbsp;</td>
      <td width="69%" colspan="2">
      <input type="text" id="catMainDescHead" name="catMainDescHead" value="<?php echo StripSlash($this->_tpl_vars['catMainDescHead']); ?>
"  style="width:200px;" maxlength="100" />
      </td>
  </tr>
  
  <tr>
      <td width="30%"><div align="right">Description :<span class="star">*</span></div></td>
      <td width="1%">&nbsp;</td>
      <td width="69%" colspan="2">
      <textarea name="pageDesc" id="pageDesc" cols="70" rows="20"><?php echo StripSlash($this->_tpl_vars['pageDesc']); ?>
</textarea>    
      </td>
  </tr>
<tr>
    <td><div align="right">Artwork Guride line:<span class="star"></span></div></td>
    <td>&nbsp;</td>
    <td>
    <textarea name="pageRobots" id="pageRobots" cols="54" rows="4"><?php echo StripSlash($this->_tpl_vars['pageRobots']); ?>
</textarea>    
    </td>
  </tr>
  <tr>
    <td><div align="right">Template:<span class="star"></span></div></td>
    <td>&nbsp;</td>
    <td><?php echo StripSlash($this->_tpl_vars['anotherImagePath']); ?>

      <input type="file" name="anotherImagePath" id="anotherImagePath" />   
    </td>
  </tr>
  <tr>
    <td><div align="right">Page Title:<span class="star"></span></div></td>
    <td>&nbsp;</td>
    <td>
    <textarea name="pageTitle" id="pageTitle" cols="54" rows="4"><?php echo StripSlash($this->_tpl_vars['pageTitle']); ?>
</textarea>    
    </td>
  </tr>
  
  <tr>
    <td><div align="right">Meta Title:<span class="star"></span></div></td>
    <td>&nbsp;</td>
    <td>
    <textarea name="pageMetaTitle" id="pageMetaTitle" cols="54" rows="4"><?php echo StripSlash($this->_tpl_vars['pageMetaTitle']); ?>
</textarea>    
    </td>
  </tr>
  
  <tr>
    <td><div align="right">Meta Description:<span class="star"></span></div></td>
    <td>&nbsp;</td>
    <td>
    <textarea name="pageMetaDesc" id="pageMetaDesc" cols="54" rows="4"><?php echo StripSlash($this->_tpl_vars['pageMetaDesc']); ?>
</textarea>    
    </td>
  </tr>
  
  <tr>
    <td><div align="right">Page Keyword:<span class="star"></span></div></td>
    <td>&nbsp;</td>
    <td>
    <textarea name="pageKeyword" id="pageKeyword" cols="54" rows="4"><?php echo StripSlash($this->_tpl_vars['pageKeyword']); ?>
</textarea>    
    </td>
  </tr>
  
   <tr>
    <td><div align="right">Page Author:<span class="star"></span></div></td>
    <td>&nbsp;</td>
    <td>
    <textarea name="pageAuthor" id="pageAuthor" cols="54" rows="4"><?php echo StripSlash($this->_tpl_vars['pageAuthor']); ?>
</textarea>    
    </td>
  </tr>
   <tr>
    <td><div align="right">Page Verify-v1:<span class="star"></span></div></td>
    <td>&nbsp;</td>
    <td>
    <textarea name="pageVarify" id="pageVarify" cols="54" rows="4"><?php echo StripSlash($this->_tpl_vars['pageVarify']); ?>
</textarea>    
    </td>
  </tr>
   <tr>
    <td><div align="right">Main Index:<span class="star"></span></div></td>
    <td>&nbsp;</td>
    <td>
    <input type="text" id="mainIndex" name="mainIndex" value="<?php echo StripSlash($this->_tpl_vars['mainIndex']); ?>
"  style="width:200px;" maxlength="100" />
    </td>
  </tr>
   <tr>
    <td><div align="right">Show In calculater<span class="star"></span></div></td>
    <td>&nbsp;</td>
    <td>
  <input type="radio" value="Yes" id="inCalc" name="inCalc"  <?php if ($this->_tpl_vars['inCalc'] == 'Yes'): ?> checked="checked"<?php endif; ?>/> Yes
  <input type="radio" value="No" id="inCalc" name="inCalc" <?php if ($this->_tpl_vars['inCalc'] == 'No'): ?> checked="checked"<?php endif; ?>/> No
    </td>
  </tr>
   <tr>
    <td><div align="right">Vat Applicable<span class="star"></span></div></td>
    <td>&nbsp;</td>
    <td>
  <input type="radio" value="Yes" id="vat" name="vat"  <?php if ($this->_tpl_vars['vat'] == 'Yes'): ?> checked="checked"<?php endif; ?>/> Yes
  <input type="radio" value="No" id="vat" name="vat" <?php if ($this->_tpl_vars['vat'] == 'No'): ?> checked="checked"<?php endif; ?>/> No
    </td>
  </tr>
   <tr>
    <td><div align="right">Production time available* <br />
                            Select multiple values
                            Press Ctrl + Option<span class="star"></span></div></td>
    <td>&nbsp;</td>
    <td>
      <?php echo StripSlash($this->_tpl_vars['production_time_available']); ?>

    </td>
  </tr>
  
  <tr>
    <td widt>Image<span class="star"></span></td>
    <td width="1%">&nbsp;</td>
    <td valign="middle" width="10%"><?php echo StripSlash($this->_tpl_vars['imagePath']); ?>
    
      <input type="file" name="imagePath" id="imagePath" />     
    </td>
    <td valign="middle" width="10%"><?php echo StripSlash($this->_tpl_vars['thumbImage1']); ?>
    
      <input type="file" name="thumbImage1" id="thumbImage1" />     
    </td>
     <td valign="middle" width="10%">      
      <?php echo StripSlash($this->_tpl_vars['thumbImage2']); ?>

      <input type="file" name="thumbImage2" id="thumbImage2" /> 
      </td>
  </tr>
  
  <!-- <tr>
    <td><div align="right">Ordering:<span class="star"></span></div></td>
    <td>&nbsp;</td>
    <td><input type="text" id="ordering" name="ordering" value="<?php echo StripSlash($this->_tpl_vars['ordering']); ?>
"  style="width:200px;" maxlength="100" /></td>
  </tr>-->
  <tr>
      <td  colspan="3" align="center"><input type="hidden" name="productCatId" id="productCatId" value="<?php echo $this->_tpl_vars['productCatId']; ?>
" />
            
      <!-- <input type="hidden" name="catImageHidden" id="catImageHidden" value="<?php echo $this->_tpl_vars['catImageHidden']; ?>
" /> -->
      <!-- <input type="hidden" name="filmMakerImageHidden" id="filmMakerImageHidden" value="<?php echo $this->_tpl_vars['filmMakerImageHidden']; ?>
" /> -->
      
        <?php if ($this->_tpl_vars['action'] == 'add'): ?>
              <button type="submit" onclick="document.frm.btn.value = 'success';"  style="width:100px;">Add</button>
          <?php else: ?>
            <button type="submit" onclick="document.frm.btn.value = 'update';" style="width:100px;">Update</button>
          <?php endif; ?>
        &nbsp;&nbsp;&nbsp;
        <input type="button" onclick="self.location='<?php echo $this->_tpl_vars['_conf_vars']['ADMIN_URL']; ?>
index.php?opt=<?php echo $this->_tpl_vars['opt']; ?>
<?php echo $this->_tpl_vars['qstr']; ?>
&sltMemberType=<?php echo $this->_tpl_vars['sltMemberType']; ?>
'" name="button" value="Back" class="button"/>   </td>
    </tr>
</table>
</form>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => 'siteadmin/footer.tpl', 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>