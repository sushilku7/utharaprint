<?php /* Smarty version 2.6.19, created on 2017-04-14 11:43:48
         compiled from siteadmin/invoicemanagement/invoice.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'StripSlash', 'siteadmin/invoicemanagement/invoice.tpl', 13, false),array('function', 'html_options', 'siteadmin/invoicemanagement/invoice.tpl', 49, false),)), $this); ?>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => 'siteadmin/header.tpl', 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => 'siteadmin/left.tpl', 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
<table width="100%" cellspacing="0" cellpadding="0" border="0">
  <tr>
    <td><h1><?php if ($this->_tpl_vars['action'] == 'add'): ?>Create<?php else: ?>Edit<?php endif; ?> Invoice </h1></td>
  </tr>
</table>
<?php if ($this->_tpl_vars['show_msg'] != ''): ?>
  <?php echo $this->_tpl_vars['show_msg']; ?>

  <?php endif; ?>
<form name="frm" id="frm" action="" method="post" enctype="multipart/form-data">
<input type="hidden" name="btn" id="btn" value="<?php echo $this->_tpl_vars['action']; ?>
" />
<input  type="hidden" name="oldImage" id="oldImage" value="<?php echo StripSlash($this->_tpl_vars['imagePath']); ?>
" />
<table width="100%" border="0" cellspacing="3" cellpadding="3" class="listdata">    
   <tr>
    <td><div align="right">Customer Name:<span class="star"></span></div></td>
    <td>&nbsp;</td>
    <td>
      <input type="text" id="invoice_to" name="invoice_to" value="<?php echo StripSlash($this->_tpl_vars['invoice_to']); ?>
"  style="width:288px;" maxlength="100" />    
    </td>
  </tr>
  <tr>
    <td><div align="right">Email Id:<span class="star"></span></div></td>
    <td>&nbsp;</td>
    <td>
      <input type="text" id="email_id" name="email_id" value="<?php echo StripSlash($this->_tpl_vars['email_id']); ?>
"  style="width:288px;" maxlength="100" />    
    </td>
  </tr>
  <tr>
    <td><div align="right">Billing Address :<span class="star"></span></div></td>
    <td>&nbsp;</td>
    <td>
        <textarea name="billingAddress" rows="4"  cols="45"><?php echo StripSlash($this->_tpl_vars['billingAddress']); ?>
</textarea>
     
    </td>
  </tr>
  <tr>
    <td><div align="right">Shipping Address :<span class="star"></span></div></td>
    <td>&nbsp;</td>
    <td>
        <textarea name="shippingAddress" rows="4"  cols="45"><?php echo StripSlash($this->_tpl_vars['shippingAddress']); ?>
</textarea>
     
    </td>
  </tr>
   <tr>
    <td><div align="right">Company Prifix:<span class="star"></span></div></td>
    <td>&nbsp;</td>
    <td><select name="cpy_invoice_no" id="cpy_invoice_no">
			     <?php echo smarty_function_html_options(array('options' => $this->_tpl_vars['_conf_vars']['COMP_PRIFIX'],'selected' => $this->_tpl_vars['cpy_invoice_no']), $this);?>

            </select>
         
    </td>
  </tr>
    <tr>
    <td><div align="right">Invoice No:<span class="star"></span></div></td>
    <td>&nbsp;</td>
    <td>
      <input type="text" id="invoice_no" name="invoice_no" value="<?php echo StripSlash($this->_tpl_vars['invoice_no']); ?>
"  style="width:288px;" maxlength="100" />    
    </td>
  </tr>    
     <tr>
      <td width="30%"><div align="right"> Product Name:<span class="star">*</span></div></td>
      <td width="1%">&nbsp;</td>
      <td width="69%" colspan="2">
      <?php echo StripSlash($this->_tpl_vars['product_catname']); ?>

      </td>
    </tr>
     <tr>
      <td width="30%"><div align="right">Product size:<span class="star">*</span></div></td>
      <td width="1%">&nbsp;</td>
      <td width="69%" colspan="2">
          <div id="productSizeDiv"><?php echo StripSlash($this->_tpl_vars['product_size']); ?>
</div>
      </td>
    </tr>
    <tr>
      <td width="30%"><div align="right">Product Paper:<span class="star">*</span></div></td>
      <td width="1%">&nbsp;</td>
      <td width="69%" colspan="2">
          <div id="productPaperDiv"><?php echo StripSlash($this->_tpl_vars['product_paper']); ?>
</div>
      </td>
     </tr>
    <tr>
      <td width="30%"><div align="right">Product Pages:<span class="star">*</span></div></td>
      <td width="1%">&nbsp;</td>
      <td width="69%" colspan="2">
          <div id="productPagesDiv"><?php echo StripSlash($this->_tpl_vars['product_pages']); ?>
</div>
      </td>
     </tr>
    <tr>
        <td width="30%"><div align="right">Product Qty:<span class="star">*</span></div></td>
        <td width="1%">&nbsp;</td>
        <td width="69%" colspan="2">
            <div id="productQtyDiv"><?php echo StripSlash($this->_tpl_vars['product_qty']); ?>
</div>
        </td>
      </tr>
      <tr>
        <td width="30%"><div align="right">Custom Product Qty:<span class="star">*</span></div></td>
        <td width="1%">&nbsp;</td>
        <td width="69%" colspan="2">
           <input type="text" id="custom_product_qty" name="custom_product_qty" value="<?php echo StripSlash($this->_tpl_vars['custom_product_qty']); ?>
"  style="width:288px;" maxlength="100" /> 
        </td>
      </tr>
    <tr>
       <td><div align="right"> Price:<span class="star"></span></div></td>
       <td>&nbsp;</td>
       <td>
           <div id="prodcutPriceDiv">
               <input type="text" id="product_price" name="product_price" value=""  style="width:288px;" maxlength="100" />
           </div>
           </td>
     </tr>  
    <tr>
         <td><div align="right"> Vat :<span class="star"></span></div></td>
         <td>&nbsp;</td>
         <td>
             <select name="vat_amt" id="vat_amt">
			     <?php echo smarty_function_html_options(array('options' => $this->_tpl_vars['_conf_vars']['VAT_AMOUNT'],'selected' => $this->_tpl_vars['vat_amt']), $this);?>

            </select>
        
         </td>
     </tr>
     <tr>
       <td><div align="right"> Payment Surcharge:<span class="star"></span></div></td>
       <td>&nbsp;</td>
       <td>
           <div id="prodcutPriceDiv">
               <input type="text" id="flat_margin" name="flat_margin" value=""  style="width:100px;" maxlength="100" />
           </div>
           </td>
     </tr>  
   
        <tr>
            <td  colspan="3" align="center">
              <button type="submit" onclick="document.frm.btn.value = 'success';"  style="width:100px;">Add</button>
            &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
             <input type="button" onclick="self.location='<?php echo $this->_tpl_vars['_conf_vars']['ADMIN_URL']; ?>
index.php?opt=<?php echo $this->_tpl_vars['opt']; ?>
<?php echo $this->_tpl_vars['qstr']; ?>
'" name="button" value="Back" class="button"/>   
          </td>        
        </tr>
</table>
</form>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => 'siteadmin/footer.tpl', 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>