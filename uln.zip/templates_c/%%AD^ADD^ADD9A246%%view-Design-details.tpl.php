<?php /* Smarty version 2.6.19, created on 2019-11-21 09:45:38
         compiled from siteadmin/orderdesignmanagement/view-Design-details.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'StripSlash', 'siteadmin/orderdesignmanagement/view-Design-details.tpl', 13, false),)), $this); ?>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => 'siteadmin/header.tpl', 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => 'siteadmin/left.tpl', 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
<table width="100%" cellspacing="0" cellpadding="0" border="0">
  <tr>
    <td><h1>View Design Details</h1></td>
  </tr>
</table>
<table width="100%" border="0" cellspacing="3" cellpadding="3" class="listdata">

    <tr>
      <td valign="top"><div align="right">Order Number :</div></td>
      <td>&nbsp;</td>
      <td>&nbsp;#<?php echo StripSlash($this->_tpl_vars['id']); ?>
</td>
  </tr>
  <tr>
      <td valign="top"><div align="right"> Company Name :</div></td>
      <td>&nbsp;</td>
      <td>&nbsp;<?php echo StripSlash($this->_tpl_vars['companyName']); ?>
</td>
  </tr>
  <tr>
      <td valign="top"><div align="right">address On Artwork1 :</div></td>
      <td>&nbsp;</td>
      <td>&nbsp;<?php echo StripSlash($this->_tpl_vars['addressOnArtwork1']); ?>
</td>
  </tr>
   <tr>
      <td valign="top"><div align="right">address On Artwork2 :</div></td>
      <td>&nbsp;</td>
      <td>&nbsp;<?php echo StripSlash($this->_tpl_vars['addressOnArtwork2']); ?>
</td>
  </tr>   <tr>      <td valign="top"><div align="right">webSocialLink :</div></td>      <td>&nbsp;</td>      <td>&nbsp;<?php echo StripSlash($this->_tpl_vars['webSocialLink']); ?>
</td>  </tr>   <tr>      <td valign="top"><div align="right">contanct Number1 :</div></td>      <td>&nbsp;</td>      <td>&nbsp;<?php echo StripSlash($this->_tpl_vars['contanctNumber1']); ?>
</td>  </tr>   <tr>      <td valign="top"><div align="right">contanct Number2 :</div></td>      <td>&nbsp;</td>      <td>&nbsp;<?php echo StripSlash($this->_tpl_vars['contanctNumber2']); ?>
</td>  </tr>  <tr>      <td valign="top"><div align="right">emailId :</div></td>      <td>&nbsp;</td>      <td>&nbsp;<?php echo StripSlash($this->_tpl_vars['emailId']); ?>
</td>  </tr>  <tr>      <td valign="top"><div align="right">other Info :</div></td>      <td>&nbsp;</td>      <td>&nbsp;<?php echo StripSlash($this->_tpl_vars['otherInfo']); ?>
</td>  </tr>
  
   <tr>
      <td valign="top"><div align="right">Designs :</div></td>
      <td>&nbsp;</td>
      <td>&nbsp;Download Your Design</td>
  </tr>
          <?php $this->assign($this->_tpl_vars['i'], 0); ?>     <?php $_from = $this->_tpl_vars['userArtworkFiles']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['k'] => $this->_tpl_vars['v']):
?>         <?php $this->assign('i', $this->_tpl_vars['i']+1); ?>		 <tr>      <td valign="top"><div align="right">&nbsp;&nbsp;</div></td>      <td>&nbsp;</td>	  	  <td><a href='user-design-download.php?filename=<?php echo StripSlash($this->_tpl_vars['v']['uploadFiles']); ?>
'>Download Design 1</a></td>		</tr>     <?php endforeach; endif; unset($_from); ?>	 
  
</table>

<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => 'siteadmin/footer.tpl', 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>