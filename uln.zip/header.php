<?php
$tempSettingDAO= new SettingDAO();
$tempProductMainCatDAO = new ProductMainCategoryDAO();
$tempProductCatDAO = new ProductCatDAO();
$configID=1;
$tempSettingVO=$tempSettingDAO->getSiteSettingDetails($configID);
$logo		=$tempSettingVO->getSite_logo(); 
$siteTitle	=$tempSettingVO->getSite_title();  
$emailID	=$tempSettingVO->getAdmin_email(); 
$contactNumber=$tempSettingVO->getAdmin_name(); 
$tempProductMainCatResult=$tempProductMainCatDAO->getMainProductCat();
//print_r($tempProductMainCatResult);

$tempProdcutCatList= $tempProductCatDAO->ProductCatList();
define('base_url','https://utharaprint-london.co.uk');
$siteUrl=base_url;
//echo $siteUrl;die();
?>
<script>
    function submitSearchBox()
    {
        
        document.getElementById('search').submit();
    }
</script>
<div class="header" >
            <div class="topHeader" >
				 <div class="container">
					 
                    <a href="https://utharaprint-london.co.uk/"><img src="<?php echo base_url;?>/images/<?php echo $logo;?>" alt="logo" ></a>
				</div>
            </div>
            <div class="container midHeader">
            <ul>
                <form name="search" id="search" method="post" action="https://utharaprint-london.co.uk/search.php">
                    <input type="hidden" name="search" value="Search">
                    <li class="topHeader_link">
	<div class="searchbox">
		<input type="text" placeholder="Type to Search" class="search_txt" name="searchName"/>
		<a class="search_btn" href="#" onclick='submitSearchBox()'>
		<i class="fa fa-search" aria-hidden="true"></i>
		</a>
	
	</div>
					</li>
                </form>
                                <li class="topHeader_link"><a href="<?php echo base_url;?>/order-design.php">Order Design</a></li>
            <li class="topHeader_link"><a href="#">Browse all Product</a>
            	<div class="sub">
                <ul >
                    <?php
                    if(count($tempProductMainCatResult)>0)
                        {

                        for($i=0;$i<count($tempProductMainCatResult);$i++)
                        {
                            $tempProductMainCatVO=$tempProductMainCatResult[$i];
                            $mCatId=$tempProductMainCatVO->getPMainCatId();
                            $mCatName=$tempProductMainCatVO->getCatName();
                            echo "<h4>$mCatName</h4>";
                            
                          $tempProductCatRes = $tempProductCatDAO->ProductCatListorderByMcat($mCatId);

          //echo count($tempProductCatResult);die();

                            if(count($tempProductCatRes)>0)
                            {
                                for($j=0;$j<count($tempProductCatRes);$j++)
                                {
                                    $tempProductCatVO=$tempProductCatRes[$j];
                                    $catName=$tempProductCatVO->getCatName();
                                    $dirName=$tempProductCatVO->getDirName();
                                    $imagePath=$tempProductCatVO->getImagePath();
                                    $aliasName        = $tempProductCatVO->getCatAlias();
                             
                             echo "<li><a href='https://utharaprint-london.co.uk/$dirName'>$catName</a></li>";

                             
                                   }
                                   }
                                   echo "</ul><ul >";
                        }
                        }
               ?>
             
                
                </div>
            </li>
            <li class="logobox"><a href="https://utharaprint-london.co.uk/index.php"><img src="<?php echo base_url;?>/images/<?php echo $logo;?>"/></a></li>
            <?php
                            if($_SESSION['memberId']!='' && $_SESSION['userName']!='')
                               {
								   //$memberName = $tempMemberVO->getMemberName();
                          echo "<li class='topHeader_link'><a href='#' >My Account</a>
								<div class='userdashboard'>
								<ul style='display:block'>
								<li><a href='https://utharaprint-london.co.uk/user-dashboard.php'>User Dashboard</a></li>
									<li class='#'><a href='https://utharaprint-london.co.uk/logout.php'>Logout</a></li>
									
								</ul>
								</div>";
                               }
                        else {
                            echo "<li class='topHeader_link'><a href='https://utharaprint-london.co.uk/login.php'>Login /Register</a></li>";
                            }
                                   ?>
            <!--<li class="topHeader_link"><a href="http://freefiletransfer.co.uk/" target="blank">Upload Your Artwork</a></li>-->
			<li class="topHeader_link"><a href="#" ><i class="fa fa-bars" style="font-size:20px; color:#eee; " > </i></a>
				<div class="about">
				<ul>
					<li><a href="<?php echo base_url;?>/about-us.php">About Us</a></li>
                                        <li><a href="<?php echo base_url;?>/contact-us.php">Contact Us</a></li>
                                        <li><a href="<?php echo base_url;?>/enquiry.php">Enquiry</a></li>
					<li><a href="<?php echo base_url;?>/business-opportunity.php">Business - Opportunity</a></li>
					<li><a href="<?php echo base_url;?>/testimonial.php">Testimonials</a></li>
					
					</ul>
				</div>
				</li>
            <li class="topHeader_link"><a href="<?php echo base_url;?>/shopping-cart.php"><i class="fa fa-shopping-cart" style="font-size:20px; color:#eee; " ><span class="cart"><?php echo count($_SESSION['shoppingCart']);?></span></i></a></li>                   
            </ul>
                
                </div>
            <span class="menuicon" >
                        <i></i>
                        <i></i>
                        <i></i>
                    </span>
          <div class="navCon container">
                <ul class="nav">
				<?php
                   if($_SESSION['memberId']!='' && $_SESSION['userName']!='')
                    {
					echo "<li class='nav__item'><a href='#' class='topHeader_link' class='nav-link'>My Account</a></li>";?>				
                    <li class='nav__item'><a href='<?php echo base_url; ?>/user-dashboard.php' class='nav-link'>User Dashboard</a></li>
                    <li class='nav__item'><a href='<?php echo base_url; ?>/logout.php' class='nav-link'>Logout</a></li>
                        <?php  }
                        else {?>
                            <li class='nav__item'><a href='<?php echo base_url; ?>/login.php' class='nav-link'>Login/Register</a></li>
                          <?php  }
                                   ?>
                    <li class="nav__item"><a href="<?php echo base_url;?>/about-us.php" class="nav-link">About Us</a></li>  
					<li class="nav__item"><a href="<?php echo base_url;?>/business-opportunity.php" class="nav-link">Business - Opportunity</a></li>
					<li class="nav__item"><a href="<?php echo base_url;?>/enquiry.php" class="nav-link">Enquiry</a></li>
                    <li class="nav__item"><a href="<?php echo base_url;?>/contact-us.php" class="nav-link">Contact Us</a></li>
                     <li class="nav__item"><a href="<?php echo base_url;?>/order-design.php" class="nav-link">Design Order</a></li>
                    <li class="nav__item"><a href="#" class="topHeader_link" class="nav-link">Product by Category</a></li>
                        <ul class="subNav transition">
                            <?php
						 if(count($tempProdcutCatList)>0)
                            {
                                for($j=0;$j<count($tempProdcutCatList);$j++)
                                {
                                    $tempProductCatVO=$tempProdcutCatList[$j];
                                    $catName=$tempProductCatVO->getCatName();
                                    $dirName=$tempProductCatVO->getDirName();
                                    $imagePath=$tempProductCatVO->getImagePath();
                                    $aliasName        = $tempProductCatVO->getCatAlias();
                             echo "<li class='subNav__item'><a href='https://utharaprint-london.co.uk/$dirName' class='subNav-link'>$catName</a></li>";

                             
                                   }
                                   }
						?>
                        </ul>
                   
                 </ul>
            </div>
        </div>
