<div id="newsletter">
   	 <script type="text/javascript" src="https://utharaprint-london.co.uk/js/jquery.min.js"></script>	

	<script>
        $(document).ready(function(){
            $('.subsc').click(function(){
                var booking_email = $('input[name=subscripEmail]').val();
                var updUrl = "https://utharaprint-london.co.uk/subscribe.php?subscripEmail="+booking_email;
                //alert(updUrl);
                $.ajax({
			 url:updUrl,
			 method:"POST",
			 data:{cate_id:booking_email},
                         contentType: false,
			 success:function(data){
                  document.getElementById("myForm").reset();
			 }
		 });
                if( /(.+)@(.+){2,}\.(.+){2,}/.test(booking_email)){
                  $('#show_error').html("<p style='color:red'>Subscribe Successfully.</p>");
                 
                } else {
                  $('#show_error').html("<p style='color:red'>Please enter valid email id.</p>");
                }       
            });
            });
            
            
        </script>
        <script>
        $(document).ready(function(){
             $('.unsubscr').click(function(){
                 var booking_email = $('input[name=unsubscripEmail]').val();
                 var newsletter = $('input[name=newsletter]').val();
                 var dataString = "unsubscripEmail="+ booking_email + "&newsletter="+ newsletter;
                var updUrl = "https://utharaprint-london.co.uk/subscribe.php?" + dataString;
                
                //alert(updUrl);
                $.ajax({
			 url:updUrl,
			 method:"POST",
			 data:dataString,
                         contentType: false,
			 success:function(data){
                  document.getElementById("unsubscForm").reset();
			 }
		 });
                if( /(.+)@(.+){2,}\.(.+){2,}/.test(booking_email)){
                  $('#show_unsubs_error').html("<p style='color:red'>Un-subscribed Successfully.</p>");
                 
                } else {
                  $('#show_unsubs_error').html("<p style='color:red'>Please enter valid email id.</p>");
                }  
            });
        })
        </script>
<button class="tablink" onclick="openPage('Home', this, '#294b8a')" id="defaultOpen" style="width:50%;">Subscribe Our Newsletter</button>
<button class="tablink" onclick="openPage('News', this, 'red')">Un-subscribe Our Newsletter</button>


<div id="Home" class="tabcontent">
  <h3>Subscribe Our Newsletter!</h3>
  <p>Subscribe to our Newsletter & get latest update of our printing products & Offers.</p>
  
  <p>
  <form id="myForm">
          <input type="mail" id="newsletter-mail"  value="" name="subscripEmail" placeholder="Insert your mail id to subscribe our newsletter"/>
          <input type="button" class="subsc" value="Subscribe Newsletter" id="newsletter-button"/>
      </form>
  </p>
  <span id="show_error"></span>
  <p>We will never send you spam mails.</p>
</div>

<div id="News" class="tabcontent">
  <h3>Un-Subscribe Our Newsletter</h3>
  <p>After Un-Subscribe to our Newsletter you won't be able to get latest update of our printing products & Offers.</p>
  
  <p>
      <form id="unsubscForm">
          <b>NOTE -P.S. - If this isn't relevant for you right now, then please choose the options below:</b><br/>
          <input type="radio" value="I am interested but not right now, i wll back after 3-6 month" name="newsletter"/> I'm interested but not right now, i'll back after 3-6 month.<br/>
          <input type="radio" value="I am not the right person in the company (sorry - but I did love an intro to the right person)." name="newsletter"/> I'm not the right person in the company (sorry - but I'd love an intro to the right person).<br/>
          <input type="radio" value="This is not right for me please delete my details from your database." name="newsletter"/> This isn't right for me please delete my details from your database.<br/><br/><br/>
         
          <input type="mail" id="newsletter-mail" value="" name="unsubscripEmail" placeholder="Insert your mail id to Un-subscribe our newsletter"/>
          <input type="button" class="unsubscr" value="Un-Subscribe Newsletter" id="newsletter-button"/><br/><br/>
        </form>
  </p>
  <span id="show_unsubs_error"></span>
</div>

<div id="Contact" class="tabcontent">
  <h3>Contact</h3>
  <p>Get in touch, or swing by for a cup of coffee.</p>
</div>

<div id="About" class="tabcontent">
  <h3>About</h3>
  <p>Who we are and what we do.</p>
</div>

<script>
function openPage(pageName,elmnt,color) {
  var i, tabcontent, tablinks;
  tabcontent = document.getElementsByClassName("tabcontent");
  for (i = 0; i < tabcontent.length; i++) {
    tabcontent[i].style.display = "none";
  }
  tablinks = document.getElementsByClassName("tablink");
  for (i = 0; i < tablinks.length; i++) {
    tablinks[i].style.backgroundColor = "";
  }
  document.getElementById(pageName).style.display = "block";
  elmnt.style.backgroundColor = color;
}

// Get the element with id="defaultOpen" and click on it
document.getElementById("defaultOpen").click();
</script>
 

   <div style="clear:both"></div>     
   
   </div>
</div>