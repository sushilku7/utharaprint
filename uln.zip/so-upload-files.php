<?php
//error_reporting (E_ALL ^ E_NOTICE);
include('includes/top_header.php');

$tempFinalorderDAO = new FinalorderDAO();
//echo "hello";die();
$valid_extensions = array('jpg','jpeg','gif','zip','png','bmp','tiff','pdf','cdr','psd','ai'); // valid extensions

$path = 'upload/client-artworks/';
$artworkNum=$_POST['artworkNum'];
//print_r($_FILES['artworks1']['name']);
$imageUpload="imageUpload".$artworkNum;
//print_r($_FILES[$imageUpload]["tmp_name"]);die();
$orderId= base64_decode($_POST['orderId']);
$memberId= $_POST['memberId'];
$total = count($_FILES[$imageUpload]["tmp_name"]);
//echo $total;die();
	for($i = 0; $i<$total; $i++){
	
	$img = $_FILES[$imageUpload]["name"][$i];
	$tmp = $_FILES[$imageUpload]["tmp_name"][$i];
	$errorimg = $_FILES[$imageUpload]["error"][$i];
	$size = $_FILES[$imageUpload]["size"][$i];
	$bUnit = "Bytes";
	if($size>1024){
		$size = $size/1024;
		$bUnit = "KB";
	}
	$artwokHead="artwokHead".$artworkNum;
	$artwokSubHead="artwokSubHead".$artworkNum;
	$companyName="companyName".$artworkNum;
	$addressOnArt1="addressOnArt1".$artworkNum;
	$addressOnArt2="addressOnArt2".$artworkNum;
	$webSocialMed="webSocialMed".$artworkNum;
	$contactNumber1="contactNumber1".$artworkNum;
	$contactNumber2="contactNumber2".$artworkNum;
	$emailId="emailId".$artworkNum;
	$otherInfo="otherInfo".$artworkNum;
	
	$artwokHead = $_POST[$artwokHead];
	$artwokSubHead = $_POST[$artwokSubHead];
	$companyName = $_POST[$companyName];
	$addressOnArt1 = $_POST[$addressOnArt1];
	$addressOnArt2 = $_POST[$addressOnArt2];
	$webSocialMed = $_POST[$webSocialMed];
	$contactNumber1 = $_POST[$contactNumber1];
	$contactNumber2 = $_POST[$contactNumber2];
	$emailId = $_POST[$emailId];
	$otherInfo = $_POST[$otherInfo];
	
	$ext = strtolower(pathinfo($img, PATHINFO_EXTENSION));
	// can upload same image using rand function
	$final_image = $i."_".date("dmy_His").$img;
	// check's valid format
//	echo "hello";
	if(in_array($ext, $valid_extensions)) 
	{
	//	echo "bc";die();
		
			$rowId = $tempFinalorderDAO->SoAddArtwork($artwokHead,$artwokSubHead ,$companyName,$addressOnArt1,$addressOnArt2,$webSocialMed,$contactNumber1,$contactNumber2,$emailId,$otherInfo,$orderId,$memberId);
			// echo $rowId;die();
			$userFile_name = $final_image;
			//$userFile_extn = substr($userFile_name, strpos($userFile_name, '.')+1);		
		    //echo "hello";die();
			$currentDate= date('d-m-Y H:s:i');
			$alias=strtotime($currentDate);
			$final_image = $final_image;
			$destination = "upload/client-artworks/".$final_image;
			if(move_uploaded_file($tmp,$destination))
			{
				$colName = "artworkDesign1";
	            $updateId = $tempFinalorderDAO->SoupdateArtwork($rowId, $colName, $final_image);
			     //echo $updateId;
				 			}
		}
	}
?>