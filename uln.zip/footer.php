<br>
<div class="footer">
<div class="copright"> 
<div class="footerlogo"><a href="index.php"><img src="https://utharaprint-london.co.uk/images/<?php echo $logo;?>"></a></div>
		
</div>

            <div class="container-sm footercon">
                <div class="footerbox" id="service">
                    <span class="footerLink">Lithographic Printing</span >
                    <span  class="footerLink">Digital Printing</span >
                    <span  class="footerLink">Offset Single Printing</span >
                    <span  class="footerLink">Flex and Large Format Printing</span >
                    <span  class="footerLink">Plastic Printing</span >
                    <span  class="footerLink">Packaging Printing</span >
                    <span  class="footerLink">Promotional Printing</span >
                    <span  class="footerLink">Clothing Printing</span >
					<span  class="footerLink">Fabric Printing</span >
                                       
                    
                </div>
                <div class="footerbox" id="service">
                    <span  class="footerLink">Photo Printing</span >
                    <span  class="footerLink">Screen Printing</span >
                    <span  class="footerLink">Label and Sticker Printing</span >
                    <span  class="footerLink">Signage</span >
                    <span  class="footerLink">Self Ink Stamp</span >
                    <span  class="footerLink">Retail Printing</span >
                    <span  class="footerLink">About Printing in London</span >
                    <span class="footerLink">Directories of Universities in London</span >
		    <span class="footerLink">Pen Printing</span>
                   
                    </div>
                <div class="footerbox" id="service">
					<span class="footerLink">Custom and  Gifts</span>
                    <span class="footerLink">DVD CD Printing</span>
                    <span class="footerLink">Pre Press in London</span>
                    <span class="footerLink">Printing Press in London</span>
					<span class="footerLink">Art School in London</span>
                    <span class="footerLink">Graphic Course in London</span>
					<span class="footerLink">Diaries Printing</span>
                    <span class="footerLink">Calendars Printing</span>
                    <span class="footerLink">Leaflets Printing</span>
                   
                    </div>
                <div class="footerbox footerboxContactinfo">
                  
                    <div class="footercontactinfo">
                        <div class="contactInfo__title">Need More Information 24/7 Online Support </div>
                        
                        <div class="contactInfo__phone">
                            Address : <span >11A West Row, Wimborne Minster, Wimborne Dorset, BH21 1LA</span>
						<br/><i class="fa fa-phone" aria-hidden="true"></i> <a href="#"> <?php echo $contactNumber;?></a>
						</div>
						<a href="mailto:<?php echo $emailID;?>" class="contactInfo__email"><i class="fa fa-envelope" aria-hidden="true"></i> <?php echo $emailID;?></a>
                    </div>
                    <div class="sociaIcon">
                        <a href="https://www.facebook.com/utharaprintlondonservices/"><i class="fa fa-facebook-f"></i></a>
                        <a href="#"><i class="fa fa-twitter"></i></a>
                        <a href="https://www.linkedin.com/company/uthara-print-london/"><i class="fa fa-linkedin"></i></a>
						<a href="#"><i class="fa fa-pinterest-p"></i></a>
                        <a href="https://www.youtube.com/channel/UCq2C2jNEjXZ5PMwlgiT3gsg"><i class="fa fa-youtube-play"></i></a>
                        <a href="https://www.instagram.com/utharaprintlondon/"><i class="fa fa-instagram"></i></a>
                    </div>
                    <div class="link-items-right">
	<ul>
	<li><a href="https://utharaprint.co.uk" target="_blank">UK</a> </li>	
	
	<li><a href="https://utharaprint.com.au" target="_blank">Australia </a></li>	
	
	<li><a href="https://utharaprint.sg" target="_blank">Singapore</a> </li>

	</ul>	
		
	</div>
                </div>
            </div>
			<div class="copyright container-sm">
			<p align="left" style="padding-top:10px;">
			<span style="text-align: left"><a href="https://utharaprint-london.co.uk/">Home</a><a href="#">|</a><a href="https://utharaprint-london.co.uk/about-us.php">About Us</a><a href="#">|</a>
		    <a href="https://utharaprint-london.co.uk/contact-us.php" >Contact Us</a>
			<a href="#">|</a>
			<a href="https://utharaprint-london.co.uk/enquiry.php" >Enquiry</a>
			<a href="#">|</a>
		    <a href="https://utharaprint-london.co.uk/business-opportunity.php" >Business Opportunity</a>
		    </p>
			
			<P align="right">
			<img src="https://utharaprint-london.co.uk/images/paymenticon.jpg" alt="paymenticon_utharaprint"/>
			</p>
		    
		    </span>
			
			</div>
            <div class="extra-links container-sm">
	<div class="link-items">
	<ul>
	<li><a href="https://utharaprint-london.co.uk/privacy-policy.php">Privacy Policy</a> </li>	
	<li><a href="#">|</a> </li>
	<li><a href="">Terms of Service </a></li>	
	<li><a href="#">|</a> </li>
	<li><a href="">Refund Policy</a> </li>
	<li><a href="#">|</a> </li>
	<li id="sitemap"><a href="https://utharaprint-london.co.uk/sitemap.xml">Sitemap</a> </li>	
	</ul>	
		
	</div>
	
	
		
	</div>
            <div class="copright">
			<span >Copyright © 2018 Bumboom Limited. All rights reserved. Website by Uthara Print</span>
        </div>
        </div>