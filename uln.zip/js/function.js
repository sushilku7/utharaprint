$(document).ready(function(){

$(".browseBycatButton-link").click(function(){
    $(".browsecat").slideToggle(100);
     $(this).toggleClass('isActive');
})


$(".menuicon").click(function(){
     $('.navCon').toggleClass('isActive');
})

	
	});
