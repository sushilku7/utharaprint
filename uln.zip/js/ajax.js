var xmlHttp;
var divId;
///var servername = "http://"+window.location.hostname+"/utharaprint-london/"; //For Localhost
var servername = "https://"+window.location.hostname+"/"; //For Server

function stateChanged()
{
    if (xmlHttp.readyState==4)
    {
        if (xmlHttp.status == 200)
        {
            //alert(xmlHttp.responseText);
            document.getElementById(divId).innerHTML=xmlHttp.responseText;
            //document.getElementById(divId).innerHTML='Smile Please';
        }
        else
        {
            alert("There was a problem while using XMLHTTP:\n" + xmlHttp.statusText);
        }
    }
}
function GetXmlHttpObject()
{

    var xmlHttp=null;
    try
    {
    	// Firefox, Opera 8.0+, Safari
        xmlHttp=new XMLHttpRequest();
    }
    catch (e)
    {
        // Internet Explorer
        try
        {            
		xmlHttp=new ActiveXObject("Msxml2.XMLHTTP");
        }
        catch (e)
        {	
		xmlHttp=new ActiveXObject("Microsoft.XMLHTTP");
        }
    }

    return xmlHttp;
}


function showProductPriceBasedOnPaper(productSizeNPaper)
{   
  //alert('showProductPaper');
  if(productSizeNPaper!="")
  {
    divId = "productPagesDiv";
    
    xmlHttp = GetXmlHttpObject();    
    if (xmlHttp==null)
    {
        alert ("Your browser does not support AJAX!");
        return;
    }
   
    var url=servername+"/helpers/showProductPriceBasedOnPaper.php?productSizeNPaper=";
    url=url+productSizeNPaper;
    //alert(url);
    xmlHttp.onreadystatechange = stateChanged;
    xmlHttp.open("GET",url,false);
    xmlHttp.send(null);
  }
}


function configureDraftOrderForOfficer(draftvalues, cnt, divname)
{
	//alert(draftvalues);	
	divId =divname+cnt;
	//alert(divId);
    xmlHttp=GetXmlHttpObject()    
    if (xmlHttp==null)
    {
        alert ("Your browser does not support AJAX!");
        return;
    }   
    xmlHttp.onreadystatechange=stateDraftChanged;   
    xmlHttp.open("GET",draftvalues,true);
    xmlHttp.send(null); 
}


function showProductPaper(productSize)
{   
  //alert('showProductPaper');
  if(productSize!="")
  {
    divId = "productPaper";
    
    xmlHttp = GetXmlHttpObject();    
    if (xmlHttp==null)
    {
        alert ("Your browser does not support AJAX!");
        return;
    }
   
    var url=servername+"/helpers/showProductPaper.php?psize=";
    url=url+productSize;
    //alert(url);
    xmlHttp.onreadystatechange = stateChanged;
    xmlHttp.open("GET",url,false);

    xmlHttp.send(null);
  }
}

function showProductPages(productPaper)
{   
  if(productPaper!="")
  {
    divId = "productPages";
    
    xmlHttp = GetXmlHttpObject();    
    if (xmlHttp==null)
    {
        alert ("Your browser does not support AJAX!");
        return;
    }
   
    var url=servername+"/helpers/showProductPages.php?ppaper=";
    url=url+productPaper;
    xmlHttp.onreadystatechange = stateChanged;
    xmlHttp.open("GET",url,false);

    xmlHttp.send(null);
  }
}

function showProductQuantity(productPages)
{   
  if(productPages!="")
  {
    divId = "productQty";
    
    xmlHttp = GetXmlHttpObject();    
    if (xmlHttp==null)
    {
        alert ("Your browser does not support AJAX!");
        return;
    }
   
    var url=servername+"/helpers/showProductQuantity.php?ppages=";
    url=url+productPages;
    
    xmlHttp.onreadystatechange = stateChanged;
    xmlHttp.open("GET",url,false);

    xmlHttp.send(null);
  }
}

function showCounty(country)
{   
  if(country!="")
  {
    divId = "countyDiv";
    
    xmlHttp = GetXmlHttpObject();    
    if (xmlHttp==null)
    {
        alert ("Your browser does not support AJAX!");
        return;
    }
   
    var url=servername+"/helpers/showCounty.php?country=";
    url=url+country;
    xmlHttp.onreadystatechange = stateChanged;
    xmlHttp.open("GET",url,false);
    xmlHttp.send(null);
  }
}


function showProductSize(productCatId)
{   
  //alert('Function Called');
  if(productCatId!="")
  {
    divId = "productSizeDiv";
    
    xmlHttp = GetXmlHttpObject();    
    if (xmlHttp==null)
    {
        alert ("Your browser does not support AJAX!");
        return;
    }
   
    var url=servername+"/helpers/showProductSize.php?pCatId=";
    url=url+productCatId;
    //alert(url);
    xmlHttp.onreadystatechange = stateChanged;
    xmlHttp.open("GET",url,false);
    xmlHttp.send(null);
  }
}
function showProductCategory(productCatId)
{   
  //alert('Function Called');
  if(productCatId!="")
  {
    divId = "productSizeDiv";
    
    xmlHttp = GetXmlHttpObject();    
    if (xmlHttp==null)
    {
        alert ("Your browser does not support AJAX!");
        return;
    }
   
    var url=servername+"/helpers/showProductCategory.php?pCatId=";
    url=url+productCatId;
    //alert(url);
    xmlHttp.onreadystatechange = stateChanged;
    xmlHttp.open("GET",url,false);
    xmlHttp.send(null);
  }
}
function showRelevantProduct(productCatId)
{   
  //alert('Function Called');
  if(productCatId!="")
  {
    divId = "productSizeDiv";
    
    xmlHttp = GetXmlHttpObject();    
    if (xmlHttp==null)
    {
        alert ("Your browser does not support AJAX!");
        return;
    }
   
    var url=servername+"/helpers/showRelevantProduct.php?pCatId=";
    url=url+productCatId;
    //alert(url);
    xmlHttp.onreadystatechange = stateChanged;
    xmlHttp.open("GET",url,false);
    xmlHttp.send(null);
  }
}
function showProductSizeSubCat(productCatId)
{   
  //alert('Function Called');
  if(productCatId!="")
  {
    divId = "productSizeDiv";
    
    xmlHttp = GetXmlHttpObject();    
    if (xmlHttp==null)
    {
        alert ("Your browser does not support AJAX!");
        return;
    }
   
    var url=servername+"/helpers/showProductSizeSubCat.php?pCatId=";
    url=url+productCatId;
    //alert(url);
    xmlHttp.onreadystatechange = stateChanged;
    xmlHttp.open("GET",url,false);
    xmlHttp.send(null);
  }
}


function showSubProductSizeSubCat(productCatId)
{   
  //alert(productCatId);
  
  if(productCatId!="")
  {
    divId = "productSizeDiv1";
    
    xmlHttp = GetXmlHttpObject();    
    if (xmlHttp==null)
    {
        alert ("Your browser does not support AJAX!");
        return;
    }
   
    var url=servername+"/helpers/showProductSizeSubCat.php?pCatId=";
    url=url+productCatId;
    //alert(url);
    
    xmlHttp.onreadystatechange = stateChanged;
    xmlHttp.open("GET",url,false);
    xmlHttp.send(null);
  }
}


function showProductPaper(subCatId)
{   
  //alert('Function Called');
  
  if(subCatId!="")
  {
    divId = "productPaperDiv";
    
    xmlHttp = GetXmlHttpObject();    
    if (xmlHttp==null)
    {
        alert ("Your browser does not support AJAX!");
        return;
    }
   
    var url=servername+"/helpers/showProductPaper.php?subCatId=";
    url=url+subCatId;
    //alert(url);
    
    xmlHttp.onreadystatechange = stateChanged;
    xmlHttp.open("GET",url,false);
    xmlHttp.send(null);
  }
}


function showProductQtyLimit(productCatId)
{   
  //alert(productCatId);
  if(productCatId!="")
  {
    divId = "productQtyLimit";
    
    xmlHttp = GetXmlHttpObject();    
    if (xmlHttp==null)
    {
        alert ("Your browser does not support AJAX!");
        return;
    }
   
    var url=servername+"/helpers/showProductQuantityLimit.php?pCatId=";
    url=url+productCatId;
    
    xmlHttp.onreadystatechange = stateChanged;
    xmlHttp.open("GET",url,false);

    xmlHttp.send(null);
  }
}


function showSubProductSizeSubCatForInvoice(productCatId)
{   
  //alert('Function Called');
  
  if(productCatId!="")
  {
    divId = "productSizeDiv";
    
    xmlHttp = GetXmlHttpObject();    
    if (xmlHttp==null)
    {
        alert ("Your browser does not support AJAX!");
        return;
    }
   
    var url=servername+"/helpers/showProductSizeSubCatForInvoice.php?pCatId=";
    url=url+productCatId;
    //alert(url);
    
    xmlHttp.onreadystatechange = stateChanged;
    xmlHttp.open("GET",url,false);
    xmlHttp.send(null);
  }
}

function showProductPaperForInvoice(productSize)
{   
  //alert('showProductPaper');
  if(productSize!="")
  {
    divId = "productPaperDiv";
    
    xmlHttp = GetXmlHttpObject();    
    if (xmlHttp==null)
    {
        alert ("Your browser does not support AJAX!");
        return;
    }
   
    var url=servername+"/helpers/showProductPaperForInvoice.php?psize=";
    url=url+productSize;
    //alert(url);
    xmlHttp.onreadystatechange = stateChanged;
    xmlHttp.open("GET",url,false);

    xmlHttp.send(null);
  }
}

function showProductPagesForInvoice(productPaper)
{   
  //alert('showProductPaper');
  if(productSize!="")
  {
    divId = "productPagesDiv";
    
    xmlHttp = GetXmlHttpObject();    
    if (xmlHttp==null)
    {
        alert ("Your browser does not support AJAX!");
        return;
    }
   
    var url=servername+"/helpers/showProductPagesForInvoice.php?ppaper=";
    url=url+productPaper;
    //alert(url);
    xmlHttp.onreadystatechange = stateChanged;
    xmlHttp.open("GET",url,false);

    xmlHttp.send(null);
  }
}


function showProductQuantityForInvoice(productPages)
{   
  if(productPages!="")
  {
    divId = "productQtyDiv";
    
    xmlHttp = GetXmlHttpObject();    
    if (xmlHttp==null)
    {
        alert ("Your browser does not support AJAX!");
        return;
    }
   
    var url=servername+"/helpers/showProductQuantityForInvoice.php?ppages=";
    url=url+productPages;
    
    xmlHttp.onreadystatechange = stateChanged;
    xmlHttp.open("GET",url,false);

    xmlHttp.send(null);
  }
}

function showProductPriceForInvoice(productId)
{   
  if(productId!="")
  {
    divId = "prodcutPriceDiv";
    
    xmlHttp = GetXmlHttpObject();    
    if (xmlHttp==null)
    {
        alert ("Your browser does not support AJAX!");
        return;
    }
   
    var url=servername+"/helpers/showProductPriceForInvoice.php?pid=";
    url=url+productId;
    
    xmlHttp.onreadystatechange = stateChanged;
    xmlHttp.open("GET",url,false);

    xmlHttp.send(null);
  }
}

