<?php
ob_start();
session_start();
error_reporting (E_ALL ^ E_NOTICE);
include('includes/top_header.php');
$tempMemberDAO = new MemberDAO();
$tempProductMainCatDAO = new ProductMainCategoryDAO();
$tempProductCatDAO = new ProductCatDAO();
$tempOurbrandDAO = new OurbrandDAO();
$tempOurbrandResult = $tempOurbrandDAO->OurbrandList();
$tempBannerDAO = new BannerDAO();
$samplePackBanner1=6;
$tempBannerVO=$tempBannerDAO->getBannerDetails($samplePackBanner1);
$samplePackBanner1=$tempBannerVO->getImage();
$samplePackUrl1=$tempBannerVO->getBannerUrl();
$emailId=$_POST['emailId'];
if(isset($_POST['action']) && $_POST['action']=="register")
{     
     
    if(!$tempMemberDAO->checkMemberAlreadyRegister($_POST['emailId'], $_POST['memberPass']))
    {
       
        $result = $tempMemberDAO->insertMember();
        $firstName = $_POST['fName'];
        $password = $_POST['memberPass'];
        $email_to = $_POST['memberEmail'];
        
        $email_from = "sales@utharaprint-london.co.uk";						
        $email_subject = "Welcome to utharaprint-london.co.uk";
        $headers  = "From: Utharaprint <".$email_from.">\r\n";
        $headers .= "Reply-To: " . $email_from . "\r\n";
        $headers .= "Content-type: text/html";
        $currDate = date("d/m/Y h:i a");
        $message  =  "<table width='700' border='0' cellspacing='0' cellpadding='0'>
                        <tr>
                          <td align='left' valign='middle' colspan='2'>&nbsp;</td>
                        </tr>
                        <tr>
                          <td align='left' valign='middle' colspan='2'><font face='Arial' size='2'>Hi $firstName, </font></td>
                        </tr>
                        <tr>
                          <td align='left' valign='middle' colspan='2'>&nbsp;</td>
                        </tr>	
                        <tr>
                          <td align='left' valign='middle' colspan='2'>
                                You have successfully registered with us.                                          
                          </td>
                        </tr>	
                        <tr>
                          <td align='left' valign='middle' colspan='2'>&nbsp;</td>
                        </tr>	
                        <tr>
                          <td align='left' valign='middle' colspan='2'><font face='Arial' size='2'>Thank You for Register on Uthara Print</font></td>
                        </tr>
                        
                        <tr>
                          <td align='left' valign='middle' colspan='2'>&nbsp;</td>
                        </tr>
                        <tr>
                          <td align='left' valign='middle' colspan='2'><font face='Arial' size='2'>Kind regards, <br />Utharaprint Team</font></td>
                        </tr>
                        <tr>
                          <td align='left' valign='middle' colspan='2'>&nbsp;</td>
                        </tr>

              </table>";
        
        //ini_set("sendmail_from", $email_from);
	$sent = mail($email_to, $email_subject, $message, $headers);
        header("Location: shopping-cart.php");
    }
    else 
    {
        $mesge = 3;
    }    
   // header("Location: register.php?msg=$msg");
}


        if(isset($_GET['msg']) && $_GET['msg']!='')
        {
            if($_GET['msg']=='1')
            {
                $message = "Invalid email address or password";
            }  
        }                                           
                                           
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <title>Uthara Print</title>
    <meta charset="utf-8">
    <meta name="robots" content="noodp, noydir" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width; initial-scale=1.0; maximum-scale=1.0">
    <!--css-->
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/responsive.css">
    
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
   
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
    <!--css-->
	<script src="js/html5.js"></script>
	<style>
	
		* { -webkit-box-sizing: border-box; -moz-box-sizing: border-box; box-sizing: border-box; }
*:before, *:after { -webkit-box-sizing: inherit; -moz-box-sizing: inherit; box-sizing: inherit; }

		input[type="checkbox"]{
			position: relative;width: 17px;height: 17px;
			-webkit-appearance:none;border: none;
		background: linear-gradient(0deg, #000 , #6b6b6b);
			border-radius: 5px;box-shadow: 0 0 0 1px #232323;
			
			transition: .5s;
		}
		input:checked[type="checkbox"]{
		background: linear-gradient(0deg, #ff6347 , #800000);box-shadow: 0 0 5px #ff6347,0 0 12px #ff6347;
		}
		/*input[type="checkbox"]:before{
			position: absolute;content: '';width: 70px;height: 30px;top:0;left:0;
			background: linear-gradient(0deg, #000 , #6b6b6b);
			border-radius: 20px;box-shadow: 0 0 0 1px #232323;
			transform: scale(.98, .96);
			transition: .5s;
		}
		input:checked[type="checkbox"]:before{
			left:30px;
		}*/
		input[type="checkbox"]:after{
			position: absolute;content: '';width: 8px;height: 8px;top:calc(35% - 2px);left:5px;
			background: linear-gradient(0deg, #6b6b6b , #000);
			border-radius: 50%;
			
			transition: .5s;
		}
		input:checked[type="checkbox"]:after{
			background: linear-gradient(0deg, #ff6347 , #800000);
			
		}
	</style>
</head>

<body>

    <body><div class="mainCon">
         <?php include 'header.php'; ?>  
			
		  	<div class="content">
				<div class="lineheight"></div>
				<div class="lineheight"></div>
			
			  <div class="container-sm productOffers">
			
				<div class="productContainet">
                 
			    <div class="productBox transition">
                                <div class="productImage" style="height: auto;"> <center><h3>Please Sign Up</h3></center>
                        <div style="height: auto;  padding-top: 10px;padding-bottom: 20px"><span style="color:red;"><?php if($mesge!=''){ echo "Email id already Exits.";}  ?></span>
					<form id="register-form" class="form-validate form-horizontal" method="post" action="">
                                            <input type="hidden" name="action" value="register"> 
							
 						<input type="text" name="fName" class="put" placeholder="Full Name" required>
                                                <input type="text" name="emailId" class="put" placeholder="Email" value="<?php echo $_POST['emailId']; ?>" required><br/>
					        <input type="password" name="memberPass" class="put" placeholder="Create Password" required>
						<input type="password" name="confirmPass" class="put" placeholder=" Confirm Password" required><br/>
						<input type="text" name="companyName" class="put" placeholder="Comapny Name(Optional)" >	
						<input type="number" name="mobileNumber" class="put" placeholder="Mobile Number" required><br/>
						
                                                <span style="display: flex; justify-content: center">
						<input type="checkbox" name="news"/> <span style="color: #666666; font-family:actor; font-weight: 550;padding-top: 2px;padding-left: 3px">Keep me updated with news and offers</span>
						</span><br/><br/>
						
						<input type="submit" class="productPrice" value="Register Now">
					
</form>
					</div> 
					</div>
                        
                    </div>
 
				
                </div>
			
				</div>
			
			<div class="visaCard">
            <img src="images/worldpay.jpg" alt="worldpay"/>
            <div style="display:flex-start;">
                <img src="images/visa.png" alt="visa">
                </div>
            </div>
        </div>
	
         <?php include 'footer.php'; ?>
		</div>
		<script type="text/javascript" src="js/jquery.min.js"></script>
    <script type="text/javascript" src="js/function.js"></script>

		</body>

</html>