<?php
ob_start();
session_start();
error_reporting (E_ALL ^ E_NOTICE);
include('includes/top_header.php');
$tempProductDAO = new ProductDAO();
$tempProductMainCatDAO = new ProductMainCategoryDAO();
$tempProductCatDAO = new ProductCatDAO();
$tempOurserviceDAO = new OurserviceDAO();
$tempOurbrandDAO = new OurbrandDAO();
$tempBannerDAO = new BannerDAO();
$tempFeaturesDAO = new FeaturesDAO();
$tempOrderDesignLogoWebDAO = new OrderDesignLogoWebDAO();
//echo count($tempProductCatResult);die();
$tempBestsellingProductCatResult = $tempProductCatDAO->BestsellingProductCatList();
$tempTopSellerProductCatResult = $tempProductCatDAO->TopSellerProductCatList();
$tempMusthavesProductCatResult = $tempProductCatDAO->MusthavesProductCatList();
$tempProductCatResult = $tempProductCatDAO->mainProductCatList();
$tempOurserviceResult = $tempOurserviceDAO->OurServiceList();
$tempOurbrandResult = $tempOurbrandDAO->OurbrandList();
$arra1 = explode('?',$_SERVER['REQUEST_URI']);
$orderId = ($arra1[1]);
$orderNo=base64_decode($orderId);
$topBanner1=12;
$personalizeBanner1=2;
$personalizeBanner2=3;
$samplePackBanner1=4;
$samplePackBanner2=5;
$tempOrderDesignLogoWebVO=$tempOrderDesignLogoWebDAO->FinalOrderDesignDeatils($orderNo);
//print_r($tempOrderDesignLogoWebVO);die();
$projectId = $tempOrderDesignLogoWebVO->getOdlw();
$projectName = $tempOrderDesignLogoWebVO->getOrderName();
$tempFeaturesResult=$tempFeaturesDAO->FeaturesList();

$tempBannerVO=$tempBannerDAO->getBannerDetails($topBanner1);
$topBanner1=$tempBannerVO->getImage();
$topBannerDesc=$tempBannerVO->getBannerDesc();
$topBannerUrl=$tempBannerVO->getBannerUrl();

if(empty($_SESSION['memberId']) && $_SESSION['memberId']=='')
                { 
        
                 header('location:order-design-login.php');
                }
?>
<!DOCTYPE html>
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	
	<title>Uthara Print London Order Design Details</title>
	<!-- Mobile Specific Metas -->
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<!-- Font-->
	<link rel="stylesheet" type="text/css" href="orderdesign/css/opensans-font.css">
	<link rel="stylesheet" type="text/css" href="orderdesign/fonts/material-design-iconic-font/css/material-design-iconic-font.min.css">
	<!-- Main Style Css -->
    <link rel="stylesheet" href="orderdesign/css/style.css"/>
    <link rel="stylesheet" href="css/style.css"/>
    <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
</head>
<body>

   <?php
        include 'header.php';
        ?>
    
	<div class="page-content">
		<div class="form-v1-content">
			<div class="wizard-form">
		      
		      
		        <form class="form-register"  action="" method="post" id="website-order">
		        	<div id="form-total">
		        		<!-- SECTION 1 -->
                                        <input type="hidden" name="orderId" value="<?php echo $orderId;?>">
		        		 <h2>
			            	<p class="step-icon"><span></span></p>
			            	<span class="step-text">Personal Infomation</span>
			            </h2>
			           
			            <section>
			            
			                <div class="inner">
			                	<div class="wizard-header">
									<h3 class="heading">Personal Infomation</h3>
									<p>Please enter your infomation and proceed to the next step so we can design your project.  </p>
								</div>
								<div class="form-row">
									<div class="form-holder">
										<fieldset>
											<legend>Project ID</legend>
											<input type="text" class="form-control" id="projectID" name="projectID" value="<?php echo "UPLNDS#".$projectId; ?>" required>
										</fieldset>
									</div>
									<div class="form-holder">
										<fieldset>
											<legend>Project Name</legend>
											<input type="text" class="form-control" id="project_name" name="project_name" value="<?php echo $projectName; ?>" required>
										</fieldset>
									</div>
								</div>
								<div class="form-row">
									<div class="form-holder">
										<fieldset>
											<legend>First Name</legend>
											<input type="text" class="form-control" id="first_name" name="first_name" placeholder="First Name" required>
										</fieldset>
									</div>
									<div class="form-holder">
										<fieldset>
											<legend>Last Name</legend>
											<input type="text" class="form-control" id="last_name" name="last_name" placeholder="Last Name" required>
										</fieldset>
									</div>
								</div>
								<div class="form-row">
									<div class="form-holder form-holder-2">
										<fieldset>
											<legend>Your Email</legend>
											<input type="text" name="your_email" id="your_email" class="form-control" pattern="[^@]+@[^@]+.[a-zA-Z]{2,6}" placeholder="example@email.com" required>
										</fieldset>
									</div>
								</div>
								<div class="form-row">
									<div class="form-holder form-holder-2">
										<fieldset>
											<legend>Phone Number</legend>
											<input type="text" class="form-control" id="phone" name="phone" placeholder="+44 888-999-7777" required>
										</fieldset>
									</div>
								</div>
								<div class="form-row form-row-date">
									<div class="form-holder form-holder-2">
										<label class="special-label">Set Estimated Duration For Project</label>
									
									<select name="date" id="date">
											<option value="DD" disabled selected>MM</option>
											<option value="jan">Jan</option>
											<option value="Feb">Feb</option>
											<option value="Mar">Mar</option>
											<option value="Apr">Apr</option>
											<option value="May">May</option>
											<option value="jun">Jun</option>
											<option value="jul">Jul</option>
											<option value="aug">Aug</option>
											<option value="sep">Sep</option>
											<option value="oct">Oct</option>
											<option value="May">Nov</option>
											<option value="May">Dec</option>
										</select>
									
										<select name="month" id="month">
											<option value="DD" disabled selected>DD</option>
											<option value="00">--</option>
											<option value="01">01</option>
											<option value="02">02</option>
											<option value="03">03</option>
											<option value="04">04</option>
											<option value="05">05</option>
											<option value="06">06</option>
											<option value="07">07</option>
											<option value="08">08</option>
											<option value="09">09</option>
											<option value="10">10</option>
											<option value="11">11</option>
											<option value="12">12</option>
											<option value="13">13</option>
											<option value="14">14</option>
											<option value="15">15</option>
											<option value="16">16</option>
											<option value="17">17</option>
											<option value="18">18</option>
											<option value="19">19</option>
											<option value="20">20</option>
											<option value="21">21</option>
											<option value="22">22</option>
											<option value="23">23</option>
											<option value="24">24</option>
											<option value="25">25</option>
											<option value="26">26</option>
											<option value="27">27</option>
											<option value="28">28</option>
											<option value="29">29</option>
											<option value="30">30</option>
											<option value="31">31</option>
											
										</select>
										
										<select name="year" id="year">
											<option value="YYYY" disabled selected>YYYY</option>
											<option value="2019">2019</option>
											<option value="2020">2020</option>
											<option value="2021">2021</option>
											<option value="2022">2022</option>
											<option value="2023">2023</option>
											<option value="2024">2024</option>
											<option value="2025">2025</option>
											<option value="2026">2026</option>
											<option value="2027">2027</option>
											<option value="2028">2028</option>
											<option value="2029">2029</option>
											<option value="2030">2030</option>
										</select>
									</div>
								</div>
								<div class="form-row">
									<div class="form-holder form-holder-2">
										<input type="text" class="form-control input-border" id="additionalInfo" name="additionalInfo" placeholder="Additional Infomation" required>
									</div>
								</div>
								<div class="form-row">
				                	<div class="form-holder">
										<fieldset>
											<legend>Please upload high quality logo file</legend>
                                                                                        <input type="file" class="form-control" id="meterial" name="meterial" >
										</fieldset>
								</div>
								
								</div>
				
							</div>
			            </section>
						<!-- SECTION 2 -->
			            <h2>
			            	<p class="step-icon"><span></span></p>
			            	<span class="step-text">Development</span>
			            </h2>
			            <section>
			                <div class="inner">
			                	<div class="wizard-header">
									<h3 class="heading">Our Development Process</h3>
									
									<p align="left" style="margin-top:2%;">We take structured approach to web design. Our development process was created<br/> to ensure every project is delivered on-time and on-budget. Once your web design <br/>project kicks off, here’s what to expect:</p>
								    <p align="left" style="margin-top:2%;">
								    <i class="fa fa-circle-o" aria-hidden="true"></i> Initial Planning<br/>
								    <i class="fa fa-circle-o" aria-hidden="true"></i> Wireframing<br/>
								    <i class="fa fa-circle-o" aria-hidden="true"></i> Mockups<br/>
								    <i class="fa fa-circle-o" aria-hidden="true"></i> Copy & Graphics<br/>
								    <i class="fa fa-circle-o" aria-hidden="true"></i> Development<br/>
								    <i class="fa fa-circle-o" aria-hidden="true"></i> Testing<br/>
								    <i class="fa fa-circle-o" aria-hidden="true"></i> Deployment & Optimization<br/>
								    <br/>
								    
								    <h4 align="left">Our Development Process</h4>    
								    <p align="left" style="margin-top:2%;">
								        
								    1. Initial Planning – <br/>The first order of business is to sit down with our team and create a detailed set</br>
								    of design and technical specifications.These specifications serve as a roadmap<br/>
								    for the rest of the web design process.</p>
								    </p>
								    
								    <p align="left" style="margin-top:2%;">
								    2. Wireframing –<br/> Wireframes are your first chance to visualize your website. While they’re<br/> 
								    not nearly as detailed as the final site will be, they give us a visual representation of <br/>
								    the site’s overall layout.
								    </p>
								    
								    <p align="left" style="margin-top:2%;">
								    3. Mockups –<br/> Once all site mockups are completed and approved, we’ll proceed with site mockups.<br/> 
								    These add color and a bit more detail to the initial wireframes, giving us a stronger visual <br/>
								    representation of the final product.
								    </p>
								    
								    <p align="left" style="margin-top:2%;">
								    4. Copy & Graphics –<br/>Original text copies are provided by you(business owner) as you specialise  <br/>
                                                                    your business. Once we’ve agreed on a final design based on the mockups, our team will proceed with <br/>
                                                                    development, kicking off two phases in unison. The first involves  <br/>
                                                                    creating your site’s copy and graphics. Our team will get to work performing SEO and  <br/>
                                                                    competitive research and come up with the copy and images that will flesh out your final site. </p>
								    
								    <p align="left" style="margin-top:2%;">
								    5. Development –<br/> At the same time, we’ll kick off the technical side of the web design <br/>
								    process. This will include deploying your dynamic back end, creating your <br/> 
								    custom theme and page designs, and setting up your website’s analytics.
								    </p>
								    
								    <p align="left" style="margin-top:2%;">
								    6. Testing – <br/> Once our designers, and developers have finished their work, our <br/>
								    quality assurance team will get to work testing your site’s performance and <br/>
								    reliability. We’ll use various tools to benchmark your site for loading, responsiveness,<br/>
								    and speed, while also ensuring that it works reliably on all web <br/>
								    browsers and mobile phones.
								    </p>
								    
								    <p align="left" style="margin-top:2%;">
								    7. Deployment & Optimization –<br/> Once we’re sure that your site is ready to be released to the public,<br/>
								    we’ll deploy it on your public domain. Then, we’ll shift into a monthly support process <br/>
								    that will continue for 12 months. During that period, we’ll create monthly backups <br/>
								    of your site, update scripts and plugins to maintain security and reliability, <br/>
								    and perform layout and content updates at your request.
								    </p>
								
								    
								</div>
								
								<!--<div class="form-row">
									<div class="form-holder form-holder-1">
										<input type="search" name="find_bank" id="find_bank" placeholder="Search For Logo" class="form-control" required>
									</div>
								</div>-->
			

			            </section>
			            <!-- SECTION 3 -->
			            <h2>
			            	<p class="step-icon"><span></span></p>
			            	<span class="step-text">Set Project Goals</span><br/>
			            	
			            </h2>
			            
			            <section>
			                <div class="inner">
			                	<div class="wizard-header">
									<h3 class="heading">Set Project Goals</h3>
									
									<p>Please enter your infomation and proceed to the next step so we can design your project.</p>
								</div>
								<div class="form-row">
			                		<div class="form-holder form-holder-2">
			                			<input type="radio" class="radio" name="radio1" id="plan-1" value="plan-1">
			                			<label class="plan-icon plan-1-label" for="plan-1">
		                					<img src="orderdesign/images/form-v1-icon-2.png" alt="pay-1">
			                			</label>
			                			<div class="plan-total">
		                					<span class="plan-title">Look And Feel Of Design</span>
		                					<p><textarea rows="4" cols="75" placeholder="Describe The Details"></textarea></p>
		                				</div>
			                			<input type="radio" class="radio" name="radio1" id="plan-2" value="plan-2">
			                			<label class="plan-icon plan-2-label" for="plan-2">
			                					<img src="orderdesign/images/form-v1-icon-2.png" alt="pay-1">
			                			</label>
			                			<div class="plan-total">
		                					<span class="plan-title">A Brief Description About Your Business</span>
		                					<p><textarea rows="4" cols="75" name="brief_description" placeholder="Describe The Details"></textarea></p>
		                				</div>
										<input type="radio" class="radio" name="radio1" id="plan-3" value="plan-3" checked>
										<label class="plan-icon plan-3-label" for="plan-3">
		                					<img src="orderdesign/images/form-v1-icon-3.png" alt="pay-2">
										</label>
										<div class="plan-total">
		                					<span class="plan-title">Add additional Comments</span>
		                					<p><textarea rows="4" name="addtional_comment" cols="75" placeholder="Describe The Details"></textarea></p>
		                				</div>
										<div class="plan-total">
		                					
		                				</div>
		                			
			                		</div>
			                		
			            
			                	</div>
			                	
			                	
							</div>
							
							
			            </section>
			                	
			            
		        	</div>
		        
		        </form>
		        
		        
		        </div>
	
		</div>
		
		</div>
		<div class="col-lg-12" id="form-response"></div>
		
		<?php
            include 'footer.php';
        ?>



	<script src="orderdesign/js/jquery-3.3.1.min.js"></script>
	<script src="orderdesign/js/jquery.steps.js"></script>
	<script src="orderdesign/js/main.js"></script>
</body>
</html>