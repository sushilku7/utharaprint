<?php
//Get Product Paper List Based on Product Size
include "../include/config.php";
require_once("../include/functions.php");
require_once("../include/functions_db.php");
$ppaper = $_GET['ppaper'];
$temapArr = explode("_", $ppaper);
$ppaper   = $temapArr[0];
$psize    = $temapArr[1];
$qryForProductPages = "SELECT DISTINCT(productPages) FROM ".prefix("product")." WHERE productSize='$psize' AND productPaper='$ppaper' AND productStatus='1' ";
$rs = mysql_query($qryForProductPages);
echo "<div id='productPages'>";
			echo "<select name='product_pages' id='pro_pages' style='width:171px;' onchange='javascript: showProductQuantityForInvoice(this.value);'>";
			echo "<option value=''> -- Please Select -- </option>";
			while($rows=mysql_fetch_assoc($rs))
			{
                                
                                $productPages = $rows['productPages'];
                                $cstPages      = $productPages."_".$ppaper."_".$psize;
				echo "<option value='".$cstPages."'>".$rows['productPages']."</option>";
			}
			echo "</option>";
			echo "</select>";
echo "</div>";

?>