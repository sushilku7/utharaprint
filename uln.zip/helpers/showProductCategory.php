<?php
//Get County List Based on Country
include "../include/config.php";
require_once("../include/functions.php");
require_once("../include/functions_db.php");
$productCatId = $_GET['pCatId'];
//echo "select productCatId, catName from tbl_product_cat where parent='$productCatId'";
$qryForProductPages = "select productCatId, catName from tbl_product_cat where parent='$productCatId'";
$rs = mysql_query($qryForProductPages);
			echo "<select name='productSubCat' id='productSubCat' >";
			echo "<option value='-1'>--Please Select--</option>";
                        while($rows=mysql_fetch_assoc($rs))
			{
				echo "<option value='".$rows['productCatId']."'>".$rows['catName']."</option>";
			}
			echo "</option>";
			echo "</select>";

?>