<?php
//Get Product Paper List Based on Product Size
include "../include/config.php";
require_once("../include/functions.php");
require_once("../include/functions_db.php");
$psize = $_GET['psize'];
$qryForProductPaper = "SELECT DISTINCT(productPaper) FROM ".prefix("product")." WHERE productSize='$psize' AND productStatus='1' ";
$rs = mysql_query($qryForProductPaper);
echo "<div id='productPaper'>";
			echo '<select name="product_paper" id="productPaper" style="width:171px;" onchange="javascript: showProductPagesForInvoice(this.value);">';
			echo "<option value='-1'> -- Please Select -- </option>";
			while($rows=mysql_fetch_assoc($rs))
			{
                                $product_paper = $rows['productPaper'];
                                $cstPaper      = $product_paper."_".$psize;
				echo "<option value='".$cstPaper."'>".$rows['productPaper']."</option>";
			}
			echo "</option>";
			echo "</select>";
echo "</div>";

?>