<?php
//Get Product Quantity List Based on Product Pages
include "../include/config.php";
require_once("../include/functions.php");
require_once("../include/functions_db.php");
$pdctCatId = $_GET['pCatId'];
$qryreseller = "SELECT FROM ".prefix("member")."";
$rs = mysql_query($qryreseller);
echo "<div id='productPages'>";
			echo "<select name='resellerName' id='resellerName' style='width:171px;'>";
			echo "<option value=''> -- Please Select -- </option>";
			while($rows=mysql_fetch_assoc($rs))
			{
				echo "<option value='".$rows['memberName']."'>".$rows['memberName']."</option>";
			}
			echo "</option>";
			echo "</select>";
echo "</div>";

?>