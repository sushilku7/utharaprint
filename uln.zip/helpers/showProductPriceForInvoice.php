<?php
//Get County List Based on Country
include "../include/config.php";
require_once("../include/functions.php");
require_once("../include/functions_db.php");
$pid = $_GET['pid'];
$qryForProductPages = "SELECT productPrice,profiteMargine FROM ".prefix("product")." WHERE productId='$pid' AND productStatus='1' ";
$rs = mysql_query($qryForProductPages);
if($rows=mysql_fetch_assoc($rs))
$productPrice = $rows['productPrice'];
$profiteMargine = $rows['profiteMargine'];
$profit=($productPrice*$profiteMargine)/100;
$pricewithprofit=$productPrice+$profit;
			echo "<input type='text' id='product_price' name='product_price' value='$pricewithprofit'  style='width:288px;' maxlength='100'/>";			
			

?>