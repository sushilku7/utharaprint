<?php
//Get County List Based on Country
include "../include/config.php";
require_once("../include/functions.php");
require_once("../include/functions_db.php");
$productCatId = $_GET['pCatId'];
$qryForProductPages = "SELECT DISTINCT(p.productSize), pc.catName FROM tbl_product AS p INNER JOIN tbl_product_cat AS pc ON p.productSize=pc.productCatId WHERE p.productCatId='$productCatId'";
//die();
$rs = mysql_query($qryForProductPages);
			echo "<select name='size' id='size'>";
			while($rows=mysql_fetch_assoc($rs))
			{
				echo "<option value='".$rows['productSize']."'>".$rows['catName']."</option>";
			}
			echo "</option>";
			echo "</select>";

?>