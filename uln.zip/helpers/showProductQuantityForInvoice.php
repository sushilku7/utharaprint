<?php
//Get Product Quantity List Based on Product Pages
include "../include/config.php";
require_once("../include/functions.php");
require_once("../include/functions_db.php");
$ppages = $_GET['ppages'];
$temapArr = explode("_", $ppages);
$ppages    = $temapArr[0];
$ppaper    = $temapArr[1];
$psize     = $temapArr[2];


$qryForProductPages = "SELECT * FROM ".prefix("product")." WHERE productSize='$psize' AND productPaper='$ppaper' AND productPages='$ppages' AND productStatus='1' ";
$rs = mysql_query($qryForProductPages);
echo "<div id='productPages'>";
			echo "<select name='product_qty' id='productId' style='width:171px;' onchange='javascript: showProductPriceForInvoice(this.value);'>";
			echo "<option value=''> -- Please Select -- </option>";
			while($rows=mysql_fetch_assoc($rs))
			{
				echo "<option value='".$rows['productId']."'>".$rows['productQty']."</option>";
			}
			echo "</option>";
			echo "</select>";
echo "</div>";

?>