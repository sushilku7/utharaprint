<?php
//Get Product Paper List Based on Product Size
session_start();
include('../DAO/DbConnection.php');
DbConnection::CreateConnection();

$productionTimeId             = $_POST['productionTimeId'];
$_SESSION['productionTimeId'] = $_POST['productionTimeId'];

$defaultNetAmount       = $_POST['totalNetAmount'];
$defaultVatAmt          = $_POST['totalVatAmt'];
$defalutTotalAmount     = $_POST['totalAmount'];
$defaultVatRate         = $_POST['vatRate'];

$totalNetAmount       = $_POST['totalNetAmount'];
$totalVatAmt          = $_POST['totalVatAmt'];
$totalAmount          = $_POST['totalAmount'];


$productionTimeQuery  = "select * from tbl_production_time_available WHERE productionTimeId='$productionTimeId' ";
//die();
$productionTimeResult = mysql_query($productionTimeQuery);
if($rows = mysql_fetch_assoc($productionTimeResult))
{
    if($rows['productionTimeId']=="1")
    {                                                                                
                    $totalNetAmount       = $defaultNetAmount;
                    $totalVatAmt          = $defaultVatAmt;
                    $totalAmount          = $defalutTotalAmount;
    }
                                                                        
    if($rows['productionTimeId']=="2")
    {                                                                                
                    $productionPercentage   = $rows['productionPerc'];
                    
                    $extraPerc1              = ($defaultNetAmount*$productionPercentage)/100;
                    $totalNetAmount          = ($totalNetAmount+$extraPerc1);
        
                    $extraPerc2              = ($defaultVatAmt*$productionPercentage)/100;
                    $totalVatAmt             = ($defaultVatAmt+$extraPerc2);
                    
                    $extraPerc3              = ($defalutTotalAmount*$productionPercentage)/100;
                    $totalAmount             = ($totalAmount+$extraPerc3);
                    
                    
   }

   if($rows['productionTimeId']=="3")
   {
                    
                    $productionPercentage   = $rows['productionPerc'];
                    
                    $extraPerc1              = ($defaultNetAmount*$productionPercentage)/100;
                    $totalNetAmount          = ($totalNetAmount+$extraPerc1);
        
                    $extraPerc2              = ($defaultVatAmt*$productionPercentage)/100;
                    $totalVatAmt             = ($defaultVatAmt+$extraPerc2);
                    
                    $extraPerc3              = ($defalutTotalAmount*$productionPercentage)/100;
                    $totalAmount             = ($totalAmount+$extraPerc3);
   }
}



                                                          echo "<ul>
									<li>
										<span class='sub-title'>Sub Total</span>
                                                                                <input type='hidden' id='totalNetAmount' name='totalNetAmount' value='$defaultNetAmount' />
                                                                                <input type='hidden' id='totalVatAmt' name='vatRate' value='$defaultVatAmt' />
                                                                                <input type='hidden' id='totalAmount' name='totalNetAmount' value='$defalutTotalAmount' />
                                                                                <input type='hidden' id='vatRate'     name='vatRate'        value='$defaultVatRate' />
                                                                                
										<span class='sub-value'>&pound; ".number_format($totalNetAmount, 2)."</span>
									</li> 
                                                                        <li>
										<span class='sub-title'>Vat [$defaultVatRate%]</span>
										<span class='sub-value'>&pound; ".number_format($totalVatAmt, 2)."</span>
									</li> 
									<li class='grand-total'>
										<span class='sub-title'>Grand Total</span>
										<span class='sub-value'>&pound; ".number_format($totalAmount, 2)."</span>
									</li>
								</ul>
								<a href='checkout.php'><button type='button' class='gbtn btn-checkout'>Proceed Checkout</button></a>";



?>   