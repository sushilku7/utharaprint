<?php
session_start();
//Get Product Paper List Based on Product Size
include('../DAO/DbConnection.php');
include('../DAO/VatDAO.php');
include('../valueobjects/VatVO.php');
$tempVatDAO   = new VatDAO();

DbConnection::CreateConnection();
$productSizeNPaper  = $_GET['productSizeNPaper'];
$temapArr           = explode(":", $productSizeNPaper);
$paper              = $temapArr[0];
$psize              = $temapArr[1];
//$psize        = end($temapArr);


$productDetailsQuery = "select parent, vat from tbl_product_cat where productCatId='$psize'  AND catStatus='1' ";
$productDetailsResult = mysql_query($productDetailsQuery);
if($rows3=mysql_fetch_assoc($productDetailsResult))
{
    $proCatId  = $rows3['parent'];
}

$productVatQuery = "select parent, vat from tbl_product_cat where productCatId='$proCatId'  AND catStatus='1' ";
$productVatResult = mysql_query($productVatQuery);
if($rows4=mysql_fetch_assoc($productVatResult))
{
    $vatOption  = $rows4['vat'];
}



$qryForProductPages = "SELECT productId, productQty, productPages, productPrice, profiteMargine  FROM tbl_product WHERE productSize='$psize' AND productPaper='$paper' AND productStatus='1' order by  productQty";
$rs = mysql_query($qryForProductPages);
$rs1 = mysql_query($qryForProductPages);
//echo "$qryForProductPages";
$pagesPriceArr = array();
$qtyPriceArr = array();
$count = 0;
$tempArr = array();

$vatFlag = "";
if($vatOption=="Yes")
{                                                                            
    $tempVatVO = $tempVatDAO->vatDetails();
    $vatRate   = $tempVatVO->getVatValue();
    $vatFlag   = "yes";
}
else
{
    $tempVatVO = $tempVatDAO->customVatDetails($proCatId, $psize, $paper);
    $vatRate   = $tempVatVO->getVatValue();
    if($vatRate!="")
    {
        $vatFlag   = "yes";
    }
}

//echo "<br />Vat Flag - ".$vatFlag;




while($rows=mysql_fetch_assoc($rs))
     {
        //$proCatId   = $rows['productCatId'];
        $pages      = $rows['productPages'];    
        $quantity   = $rows['productQty'];
        $qty        = $rows['productQty'];                
        $price      = $rows['productPrice'];
        /*
            $margin     = ($rows['productPrice'] * $rows['profiteMargine'])/100;
            $vatPrice    = $price*20/100;
            $finalPrice = $price + $margin + $vatPrice;   
        */
        $margin     = ($rows['productPrice'] * $rows['profiteMargine'])/100;
        $finlPrice  = $price + $margin;
        
        if($vatFlag=="yes")
        {                                                                               
            $vatPrice   = $finlPrice*$vatRate/100;
            $finalPrice = $finlPrice + $vatPrice;  
        }
        else
        {    
              $finalPrice = $finlPrice;
        }
        
        //$vatPrice   = $finlPrice*20/100;
        //$finalPrice = $finlPrice + $vatPrice; 

        $productId  = $rows['productId'];
        //$idNPrice   = $productId."_".$finalPrice;
        $idNPrice   = $productId."_".$finalPrice."_".$quantity."_".$pages;
        $pagesPriceArr[$pages] = $idNPrice;
        
        if(count($pagesPriceArr)>0)
        {
            foreach($pagesPriceArr as $kval)
            {                                                                                    
                $tempQtyArr = explode("_", $kval);
                $tempQty    = $tempQtyArr[2];
                $tempPages = $tempQtyArr[3];
                if($tempQty!=$quantity)
                {                 
                    unset($pagesPriceArr[$tempPages]);
                    //$pagesPriceArr[$tempPages] = "NIL";
                }
            }
        }
        
        $tempArr[$qty] = $pagesPriceArr;    
     }
    
          
     $count = 0;
     echo "<table style='background-color:#e7e7e7' class='table table-striped'>";
     foreach($tempArr as $key => $val)
     {
            if($count==0)
            {            
               echo "<tr><th>Quantity</th>";
               foreach($val as $ky => $value)
               {
                   echo "<th>$ky</th>";
               }
               echo "</tr>";
            }           
            $count = $count + 1;
     }
    
    
     foreach($tempArr as $key1 => $val1)
     {
           echo "<tr><td>$key1</td>";
           foreach($val1 as $k1 => $v1)
           {
                 $samArr = explode("_", $v1);
                 $productId = $samArr[0];
                 $price = $samArr[1];
                 if(isset($_SESSION['printoption']) && $_SESSION['printoption']=="paid")
                 {
                          //$price =  $price + $_SESSION['designCharges'];
                 }
                 
                 echo "<td onclick='javascript: sumbitPriceForm($productId);' style='cursor: pointer;'>&pound; ".number_format($price, 2)."</td>";
           }
           echo "</tr>";
    }
    echo "</table>";
    die();
    
   
     ?>   