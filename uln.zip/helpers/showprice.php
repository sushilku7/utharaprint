<script src="js/jquery.min.js"></script> 
<script type="text/javascript" src="http://darsa.in/sly/examples/js/vendor/plugins.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/Sly/1.6.1/sly.min.js"></script>

<style>
 .frame {
  height: 95px;
  overflow: hidden;
  width: 84%;
  border: 0px solid red;
  float: left;
}
.frame ul {
  list-style: none;
  margin: 0;
  padding: 0;
  font-size: 15px;
}
.frame ul li {
  float: left;
  width: 80px;
  height: 95px;
  margin-right: 5px;
  color: #000;
  text-align: center;
   background-color: red;
  background:url(images/bg.png) no-repeat fixed; 
}

.frame ul li.selctQty {
   background:url(images/hover.png) no-repeat fixed; 
   height: 95px;
}

.frame ul li.nonactive {
   background:url(images/bg.png) no-repeat fixed; 
   height: 95px;
}
</style>

<?php
include('../library/Dropdown.php');
include('../DAO/ProductDAO.php');

$productId             = $_POST['productId'];
$printoption           = $_POST['printoption'];
$designCharges         = $_POST['designCharges'];
$productVatStatus      = $_POST['vatStatus'];
$workingDays           = $_POST['workingDays'];




$productCatQuery = "select pc.catName, pc.pageDesc, p.productId, p.productSubCat, p.productPaperType, p.productPaperSize, p.productPrintType, p.productLaminationType, p.productNumSets, p.productFoldType, p.productPrintPageNum, p.productCoverType, p.productCutType, p.productQty, p.productPrice, p.profiteMargine from tbl_product as p  inner join tbl_product_cat as pc  on p.productSubCat=pc.productCatId where productId='$productId' ";
$productCatResult = mysqli_query($connection, $productCatQuery);

if($res=mysqli_fetch_array($productCatResult))
{
    $prodcutSubCatId       = $res['productSubCat'];
    $productName           = $res['catName'];    
    $quantity              = $res['productQty'];
    $productDesc           = substr($res['pageDesc'], 0, 300);
    $productPaperSize      = $res['productPaperSize'];
    $productPrintType      = $res['productPrintType'];
    $productPaperType      = $res['productPaperType'];
    $productLaminationType = $res['productLaminationType'];
    
    $productFoldType       = $res['productFoldType'];
    $productPrintPageNum   = $res['productPrintPageNum'];
    $productCoverType      = $res['productCoverType'];
    $productCutType        = $res['productCutType'];
    
    $productNumSets        = $res['productNumSets'];
    $proBuyPrice           = $res['productPrice'];
    $profitMargin          = $res['profiteMargine'];
}

//Add margin in buying price 
$margin                = ($proBuyPrice * $profitMargin)/100;
$finalPriceWithOutVat  =  $proBuyPrice + $margin;


                                                                    
if($productVatStatus=="Yes")
{
    $qryForVatDetail   = "SELECT rId, vatvalue  FROM tbl_vat ";
    $result2           = mysqli_query($connection, $qryForVatDetail);
    $rs2               = mysqli_fetch_assoc($result2);
    $vatRate           = $rs2['vatvalue'];
    $productVatPrice   = ($finalPriceWithOutVat*$vatRate)/100;
    $productVatPrice   = round($productVatPrice, 2);

    $finalPriceWithVat = $finalPriceWithOutVat + $productVatPrice;
    //echo "Product Price - ".$productPrice;
}
else
{
    $finalPriceWithVat = $finalPriceWithOutVat;
}

$totalPrice = $finalPriceWithVat + $designCharges;

echo   "<form name='productPricefrm' id='productPricefrm' action='shopping-cart.php' method='post' enctype='multipart/form-data'>
        <input type='hidden' name='proId'                   value='$productId'>
        <input type='hidden' name='qty'                     value='$quantity'>
        <input type='hidden' name='pCatId'                  value='$prodcutSubCatId'>    
        <input type='hidden' name='productName'             value='$productName'>
        <input type='hidden' name='productPaperSize'        value='$productPaperSize'>
        <input type='hidden' name='productPrintType'        value='$productPrintType'>
        <input type='hidden' name='productPaperType'        value='$productPaperType'>
        <input type='hidden' name='productLaminationType'   value='$productLaminationType'>
            
        <input type='hidden' name='productFoldType'         value='$productFoldType'>
        <input type='hidden' name='productPrintPageNum'     value='$productPrintPageNum'>
        <input type='hidden' name='productCoverType'        value='$productCoverType'>
        <input type='hidden' name='productCutType'          value='$productCutType'>

        <input type='hidden' name='productNumSets'          value='$productNumSets'>
        <input type='hidden' name='productPriceWOutVat'     value='$finalPriceWithVat'> 
        <input type='hidden' name='productPriceWithVat'     value='$finalPriceWithVat'>
            
        <!--
        <input type='hidden' name='vatFlag'                 value='$productVatStatus'>
        <input type='hidden' name='vateRate'                value='$vatRate'>
        <input type='hidden' name='vatAmount'               value='$productVatPrice'>
        -->
        <input type='hidden' name='vatFlag'                 value='No'>
        <input type='hidden' name='vateRate'                value='0'>
        <input type='hidden' name='vatAmount'               value='0'>

        <input type='hidden' name='designCharges'           value='$designCharges'>
        <input type='hidden' name='productDescription'      value='$productDesc'>        

<div class='price-total col-xs-12' style='margin-left: 175px; width: 230px; border: 0px solid red; margin-bottom: 5px;'>
<label>Price:</label>
<span class='price'>&pound; ".number_format($totalPrice, 2)."</span>
<p style='border: 0px solid red;width: 200px;text-align: center; font-size: 15px;'>All Inclusive</p> 
</div>
<div class='add-cart-btn-w col-xs-12' style='padding:0px;'>
<input type='submit' name='submit' value='ADD TO BASKET' class='add-cart-btn btn'>
<h3 style='font-size: 18px; margin: 15px;'>FREE UK MAINLAND DELIVERY!</h3>
<div style='clear: both; border-bottom: 1px solid #CCC; height: 30px;margin: 12px 18px;'></div>
<h2 style='font-size: 24px; color:#EF7F1B; '>Can&rsquo;t find what you&rsquo;re looking for?</h2>
<div  style='width: 300px; margin-top: 10px;margin-left: 150px; center; border: 0px solid red;' ><a href='#'><img src='images/request-quote.png'  /></a></div>
</div>
</form>";

echo "--------------------";

//echo "SELECT DISTINCT(productPaper) FROM tbl_product WHERE productSize='$psizeId' AND productStatus='1' ";die();
        $qury  = "select DISTINCT productQty, productId, productPrice, profiteMargine  from tbl_product where productSubCat='$prodcutSubCatId' and productPaperSize='$productPaperSize'  and productPrintType='$productPrintType'  and productPaperType='$productPaperType'  and productLaminationType='$productLaminationType' and productNumSets='$productNumSets' and  productTurnAround='$workingDays' order by productQty asc";
        $rs    = mysqli_query($connection, $qury);
        $ddstr = "<img src='images/arrow-left.jpg' style='float: left; padding: 0px; border: 0px;' class='btn prev'  />
                  <div class='frame' id='basic' style='width='100%;'><ul>";
        
        $count = 0;
        while($rows=mysqli_fetch_assoc($rs))
        {             
                $productId      = $rows['productId'];
                $qty            = $rows['productQty'];
                $proBuyPrice    = $rows['productPrice'];
                $profitMargin   = $rows['profiteMargine'];
                
                //Add margin in buying price 
                $margin                = ($proBuyPrice * $profitMargin)/100;
                $finalPriceWithOutVat  =  $proBuyPrice + $margin;
                
                if($productVatStatus=="Yes")
                {
                    $qryForVatDetail   = "SELECT rId, vatvalue  FROM tbl_vat ";
                    $result2           = mysqli_query($connection, $qryForVatDetail);
                    $rs2               = mysqli_fetch_assoc($result2);
                    $vatRate           = $rs2['vatvalue'];
                    $productVatPrice   = ($finalPriceWithOutVat*$vatRate)/100;
                    $productVatPrice   = round($productVatPrice, 2);

                    $finalPriceWithVat = $finalPriceWithOutVat + $productVatPrice;
                    //echo "Product Price - ".$productPrice;
                }
                else
                {
                    $finalPriceWithVat = $finalPriceWithOutVat;
                }
                
                $finalPrice = number_format($finalPriceWithVat, 2);                
                
                if($quantity==$qty)
                {
                    $startAt   = $count;
                    $defaultProductId = $productId;
                    $ddstr    .="<li class='selctQty'> 
                                <a style='cursor: pointer;' onclick='javascript: submitPriceForm($productId);'><div style='height: 48px; clear: both;padding-top: 15px; color: #FFF;'>$qty</div></a>
                                <a style='cursor: pointer;' onclick='javascript: submitPriceForm($productId);'><div style='height: 48px;clear: both;padding-top: 15px; color: #000;'>$finalPrice</div></a>
                                </li>";
                }
                else
                {
                     $ddstr   .="<li class='nonactive'> 
                                <a style='cursor: pointer;' onclick='javascript: submitPriceForm($productId);'><div style='height: 48px; clear: both;padding-top: 15px; color: #FFF;'>$qty</div></a>
                                <a style='cursor: pointer;' onclick='javascript: submitPriceForm($productId);'><div style='height: 48px;clear: both;padding-top: 15px; color: #000;'>$finalPrice</div></a>
                                </li>";
                }
                $count = $count + 1;
        }
        $ddstr   .= "</ul></div> <img src='images/arrow-right.jpg' border='0' style='float: left; padding: 0px; border: 0px;' class='btn next'  />";
        
echo $ddstr;
echo "--------------------";
?>
<input type="hidden" name="defaultQty" id="defaultQty" value="<?php echo $quantity; ?>" />
<?php
echo "--------------------";
//echo Dropdown::getAjaxProductTurnAroundList($prodcutSubCatId, $productPaperSize, $productPrintType, $productPaperType, $productLaminationType, $productNumSets, $quantity, $workingDays, $productFoldType, $productPrintPageNum, $productCoverType, $productCutType);


$productTurnArndQuery  = "select DISTINCT productTurnAround, productPrice from tbl_product where productSubCat='$prodcutSubCatId' and productPaperSize='$productPaperSize'  and productPrintType='$productPrintType'  and productPaperType='$productPaperType'  and productLaminationType='$productLaminationType' and productNumSets='$productNumSets' and productFoldType='$productFoldType' and productPrintPageNum='$productPrintPageNum' and productCoverType='$productCoverType' and productCutType='$productCutType' and productQty='$quantity'   order by productTurnAround asc";
$productTurnArndResult = mysqli_query($connection, $productTurnArndQuery);
$dropDown = "";
        while($row1=mysqli_fetch_assoc($productTurnArndResult))
        { 
    
                 $proTurnAround = $row1['productTurnAround'];
                 $price         = $row1['productPrice'];
                 
                 $dropDown     .='<div class="turnAround">
                                 <a style="cursor: pointer;"  onclick="javascript: submitForm('."'".$proTurnAround."'".')">';   
                        if($workingDays==$proTurnAround)
                        {
                               $dropDown   .="<p style='width: 135px; height: 35px; background-color: #EF7F1B; color: #fff; padding-top:8px;'>$proTurnAround</p>";
                        }
                        else
                        {
                               $dropDown   .="<p style='width: 135px; height: 35px; background-color: #D9DBDA;padding-top:8px;'>$proTurnAround</p>";
                        }
                 $dropDown     .='</a>
                               </div>';
        }
echo $dropDown;




?>

<script type="text/javascript">
jQuery(function($) {
 

  
  (function() {
    var $frame = $('#basic');
    var $slidee = $frame.children('ul').eq(0);
    var $wrap = $frame.parent();

    // Call Sly on frame
    $frame.sly({
      horizontal: 1,
      itemNav: 'basic',
      smart: 1,
      activateOn: 'click',
      mouseDragging: 1,
      touchDragging: 1,
      releaseSwing: 1,
      startAt: <?php echo $startAt; ?>,
      scrollBar: $wrap.find('.scrollbar'),
      scrollBy: 1,
      pagesBar: $wrap.find('.pages'),
      activatePageOn: 'click',
      speed: 300,
      elasticBounds: 1,
      easing: 'easeOutExpo',
      dragHandle: 1,
      dynamicHandle: 1,
      clickBar: 1,

      // Buttons
      forward: $wrap.find('.forward'),
      backward: $wrap.find('.backward'),
      prev: $wrap.find('.prev'),
      next: $wrap.find('.next'),
      prevPage: $wrap.find('.prevPage'),
      nextPage: $wrap.find('.nextPage')
    });

    // To Start button
    $wrap.find('.toStart').on('click', function() {
      var item = $(this).data('item');
      // Animate a particular item to the start of the frame.
      // If no item is provided, the whole content will be animated.
      $frame.sly('toStart', item);
    });

    // To Center button
    $wrap.find('.toCenter').on('click', function() {
      var item = $(this).data('item');
      // Animate a particular item to the center of the frame.
      // If no item is provided, the whole content will be animated.
      $frame.sly('toCenter', item);
    });

    // To End button
    $wrap.find('.toEnd').on('click', function() {
      var item = $(this).data('item');
      // Animate a particular item to the end of the frame.
      // If no item is provided, the whole content will be animated.
      $frame.sly('toEnd', item);
    });

    // Add item
    $wrap.find('.add').on('click', function() {
      $frame.sly('add', '<li>' + $slidee.children().length + '</li>');
    });

    // Remove item
    $wrap.find('.remove').on('click', function() {
      $frame.sly('remove', -1);
    });
  }());

 
  (function() {
    var $frame = $('#centered');
    var $wrap = $frame.parent();

    // Call Sly on frame
    $frame.sly({
      horizontal: 1,
      itemNav: 'centered',
      smart: 1,
      activateOn: 'click',
      mouseDragging: 1,
      touchDragging: 1,
      releaseSwing: 1,
      startAt: 4,
      scrollBar: $wrap.find('.scrollbar'),
      scrollBy: 1,
      speed: 300,
      elasticBounds: 1,
      easing: 'easeOutExpo',
      dragHandle: 1,
      dynamicHandle: 1,
      clickBar: 1,

      // Buttons
      prev: $wrap.find('.prev'),
      next: $wrap.find('.next')
    });
  }());

  
  (function() {
    var $frame = $('#forcecentered');
    var $wrap = $frame.parent();

    // Call Sly on frame
    $frame.sly({
      horizontal: 1,
      itemNav: 'forceCentered',
      smart: 1,
      activateMiddle: 1,
      activateOn: 'click',
      mouseDragging: 1,
      touchDragging: 1,
      releaseSwing: 1,
      startAt: 0,
      scrollBar: $wrap.find('.scrollbar'),
      scrollBy: 1,
      speed: 300,
      elasticBounds: 1,
      easing: 'easeOutExpo',
      dragHandle: 1,
      dynamicHandle: 1,
      clickBar: 1,

      // Buttons
      prev: $wrap.find('.prev'),
      next: $wrap.find('.next')
    });
  }());

 
  (function() {
    var $frame = $('#cycleitems');
    var $wrap = $frame.parent();

    // Call Sly on frame
    $frame.sly({
      horizontal: 1,
      itemNav: 'basic',
      smart: 1,
      activateOn: 'click',
      mouseDragging: 1,
      touchDragging: 1,
      releaseSwing: 1,
      startAt: 0,
      scrollBar: $wrap.find('.scrollbar'),
      scrollBy: 1,
      speed: 300,
      elasticBounds: 1,
      easing: 'easeOutExpo',
      dragHandle: 1,
      dynamicHandle: 1,
      clickBar: 1,

      // Cycling
      cycleBy: 'items',
      cycleInterval: 1000,
      pauseOnHover: 1,

      // Buttons
      prev: $wrap.find('.prev'),
      next: $wrap.find('.next')
    });

    // Pause button
    $wrap.find('.pause').on('click', function() {
      $frame.sly('pause');
    });

    // Resume button
    $wrap.find('.resume').on('click', function() {
      $frame.sly('resume');
    });

    // Toggle button
    $wrap.find('.toggle').on('click', function() {
      $frame.sly('toggle');
    });
  }());

  
  (function() {
    var $frame = $('#cyclepages');
    var $wrap = $frame.parent();

    // Call Sly on frame
    $frame.sly({
      horizontal: 1,
      itemNav: 'basic',
      smart: 1,
      activateOn: 'click',
      mouseDragging: 1,
      touchDragging: 1,
      releaseSwing: 1,
      startAt: 0,
      scrollBar: $wrap.find('.scrollbar'),
      scrollBy: 1,
      pagesBar: $wrap.find('.pages'),
      activatePageOn: 'click',
      speed: 300,
      elasticBounds: 1,
      easing: 'easeOutExpo',
      dragHandle: 1,
      dynamicHandle: 1,
      clickBar: 1,

      // Cycling
      cycleBy: 'pages',
      cycleInterval: 1000,
      pauseOnHover: 1,
      startPaused: 1,

      // Buttons
      prevPage: $wrap.find('.prevPage'),
      nextPage: $wrap.find('.nextPage')
    });

    // Pause button
    $wrap.find('.pause').on('click', function() {
      $frame.sly('pause');
    });

    // Resume button
    $wrap.find('.resume').on('click', function() {
      $frame.sly('resume');
    });

    // Toggle button
    $wrap.find('.toggle').on('click', function() {
      $frame.sly('toggle');
    });
  }());

  
  (function() {
    var $frame = $('#oneperframe');
    var $wrap = $frame.parent();

    // Call Sly on frame
    $frame.sly({
      horizontal: 1,
      itemNav: 'forceCentered',
      smart: 1,
      activateMiddle: 1,
      mouseDragging: 1,
      touchDragging: 1,
      releaseSwing: 1,
      startAt: 0,
      scrollBar: $wrap.find('.scrollbar'),
      scrollBy: 1,
      speed: 300,
      elasticBounds: 1,
      easing: 'easeOutExpo',
      dragHandle: 1,
      dynamicHandle: 1,
      clickBar: 1,

      // Buttons
      prev: $wrap.find('.prev'),
      next: $wrap.find('.next')
    });
  }());

  
  (function() {
    var $frame = $('#crazy');
    var $slidee = $frame.children('ul').eq(0);
    var $wrap = $frame.parent();

    // Call Sly on frame
    $frame.sly({
      horizontal: 1,
      itemNav: 'basic',
      smart: 1,
      activateOn: 'click',
      mouseDragging: 1,
      touchDragging: 1,
      releaseSwing: 1,
      startAt: 3,
      scrollBar: $wrap.find('.scrollbar'),
      scrollBy: 1,
      pagesBar: $wrap.find('.pages'),
      activatePageOn: 'click',
      speed: 300,
      elasticBounds: 1,
      easing: 'easeOutExpo',
      dragHandle: 1,
      dynamicHandle: 1,
      clickBar: 1,

      // Buttons
      forward: $wrap.find('.forward'),
      backward: $wrap.find('.backward'),
      prev: $wrap.find('.prev'),
      next: $wrap.find('.next'),
      prevPage: $wrap.find('.prevPage'),
      nextPage: $wrap.find('.nextPage')
    });

    // To Start button
    $wrap.find('.toStart').on('click', function() {
      var item = $(this).data('item');
      // Animate a particular item to the start of the frame.
      // If no item is provided, the whole content will be animated.
      $frame.sly('toStart', item);
    });

    // To Center button
    $wrap.find('.toCenter').on('click', function() {
      var item = $(this).data('item');
      // Animate a particular item to the center of the frame.
      // If no item is provided, the whole content will be animated.
      $frame.sly('toCenter', item);
    });

    // To End button
    $wrap.find('.toEnd').on('click', function() {
      var item = $(this).data('item');
      // Animate a particular item to the end of the frame.
      // If no item is provided, the whole content will be animated.
      $frame.sly('toEnd', item);
    });

    // Add item
    $wrap.find('.add').on('click', function() {
      $frame.sly('add', '<li>' + $slidee.children().length + '</li>');
    });

    // Remove item
    $wrap.find('.remove').on('click', function() {
      $frame.sly('remove', -1);
    });
  }());
});
</script>

