<?php
//Get Product Paper List Based on Product Size
include "../include/config.php";
require_once("../include/functions.php");
require_once("../include/functions_db.php");
$psize = $_GET['subCatId'];

$qryForProductPaper = "SELECT DISTINCT(productPaper) FROM ".prefix("product")." WHERE productSize='$psize' AND productStatus='1' ";
$rs = mysql_query($qryForProductPaper);
echo "<div id='productPaper'>";
			echo '<select name="productPaper" id="productPaper" style="width:171px;">';
			echo "<option value='-1'> -- Please Select -- </option>";
			while($rows=mysql_fetch_assoc($rs))
			{
				echo "<option value='".$rows['productPaper']."'>".$rows['productPaper']."</option>";
			}
			echo "</option>";
			echo "</select>";
echo "</div>";

?>