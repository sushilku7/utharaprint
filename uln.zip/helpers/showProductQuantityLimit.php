<?php
//Get Product Quantity List Based on Product Pages
include "../include/config.php";
require_once("../include/functions.php");
require_once("../include/functions_db.php");
$pdctCatId = $_GET['pCatId'];
$qryForProductCat = "SELECT DISTINCT(productQty) FROM ".prefix("product")." WHERE productCatId='$pdctCatId' AND productStatus='1' ";
$rs = mysql_query($qryForProductCat);
echo "<div id='productPages'>";
			echo "<select name='qty_limit' id='qty_limit' style='width:171px;'>";
			echo "<option value=''> -- Please Select -- </option>";
			while($rows=mysql_fetch_assoc($rs))
			{
				echo "<option value='".$rows['productQty']."'>".$rows['productQty']."</option>";
			}
			echo "</option>";
			echo "</select>";
echo "</div>";

?>