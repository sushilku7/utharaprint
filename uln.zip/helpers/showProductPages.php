<?php
//Get Product Paper List Based on Product Size
include "../include/config.php";
require_once("../include/functions.php");
require_once("../include/functions_db.php");
$ppaper = $_GET['ppaper'];
$qryForProductPages = "SELECT DISTINCT(productPages) FROM ".prefix("product")." WHERE productPaper='$ppaper' AND productStatus='1' ";
$rs = mysql_query($qryForProductPages);
echo "<div id='productPages'>";
			echo "<select name='pro_pages' id='pro_pages' style='width:171px;' onchange='javascript: showProductQuantity(this.value);'>";
			echo "<option value=''> -- Please Select -- </option>";
			while($rows=mysql_fetch_assoc($rs))
			{
				echo "<option value='".$rows['productPages']."'>".$rows['productPages']."</option>";
			}
			echo "</option>";
			echo "</select>";
echo "</div>";

?>