<?php
session_start();
$psizeId = $_POST['sizeId'];
//die();
//Get Product Paper List Based on Product Size
include('../DAO/DbConnection.php');
include('../DAO/VatDAO.php');
include('../valueobjects/VatVO.php');
$tempVatDAO   = new VatDAO();

DbConnection::CreateConnection();

        //echo "SELECT DISTINCT(productPaper) FROM tbl_product WHERE productSize='$psizeId' AND productStatus='1' ";die();
        $qryForProductPages = "SELECT DISTINCT(productPaper), productCatId FROM tbl_product WHERE productSize='$psizeId' AND productStatus='1' ";
        $rs = mysql_query($qryForProductPages);
        echo "<select name='productPaper' id='productPaper' style='border: 1px solid #000000;width: 100%; color:#000000; cursor: pointer; display: block;height: 40px;line-height: 40px; margin-bottom: 10px;padding-left: 15px;' onchange='javascript: showProductPriceBasedOnPaper(this.value);'>";
        //echo "<option value=''>Please Select</option>";
        $count = 0;
        while($rows=mysql_fetch_assoc($rs))
        {
                $proCatId = $rows['productCatId'];
                if($count==0)
                    $default_paper_for_calc = $rows['productPaper'];
                $product_paper = $rows['productPaper'];
                $cstPaper      = $product_paper.":".$psizeId;
                echo "<option value='".$cstPaper."'>".$rows['productPaper']."</option>";
                $count = $count + 1;
        }
        echo "</option>";
        echo "</select>";
//echo "</div>";
echo "--------------------";

$psize = $psizeId;
$paper = $default_paper_for_calc;


$qryForProductPages = "SELECT productId, productQty, productPages, productPrice, profiteMargine  FROM tbl_product WHERE productSize='$psize' AND productPaper='$paper' AND productStatus='1' order by  productQty";
$rs  = mysql_query($qryForProductPages);
//$rs1 = mysql_query($qryForProductPages);

$productDetailsQuery = "select * from tbl_product_cat where productCatId='$proCatId'  AND catStatus='1' ";
$productDetailsResult = mysql_query($productDetailsQuery);
if($rows3=mysql_fetch_assoc($productDetailsResult))
{
    $vatOption = $rows3['vat'];
}


$pagesPriceArr = array();
$qtyPriceArr = array();
$count = 0;
$tempArr = array();
$vatFlag = "";


if($vatOption=="Yes")
{                                                                            
    $tempVatVO = $tempVatDAO->vatDetails();
    $vatRate   = $tempVatVO->getVatValue();
    $vatFlag   = "yes";
}
else
{
    $tempVatVO = $tempVatDAO->customVatDetails($proCatId, $psize, $paper);
    $vatRate   = $tempVatVO->getVatValue();
    if($vatRate!="")
    {
        $vatFlag   = "yes";
    }
}

     while($rows=mysql_fetch_assoc($rs))
     {
        $pages      = $rows['productPages'];    
        $quantity   = $rows['productQty'];
        $qty        = $rows['productQty'];                
        $price      = $rows['productPrice'];
		
        $margin     = ($rows['productPrice'] * $rows['profiteMargine'])/100;
        $finlPrice  = $price + $margin;
        
        if($vatFlag=="yes")
        {                                                                               
            $vatPrice   = $finlPrice*$vatRate/100;
            $finalPrice = $finlPrice + $vatPrice;  
        }
        else
        {    
              $finalPrice = $finlPrice;
        }
        		
        $productId  = $rows['productId'];
        $idNPrice   = $productId."_".$finalPrice."_".$quantity."_".$pages;
        
        $pagesPriceArr[$pages] = $idNPrice;
        
        if(count($pagesPriceArr)>0)
        {
            foreach($pagesPriceArr as $kval)
            {                                                                                    
                $tempQtyArr = explode("_", $kval);
                $tempQty    = $tempQtyArr[2];
                $tempPages = $tempQtyArr[3];
                if($tempQty!=$quantity)
                {                 
                    unset($pagesPriceArr[$tempPages]);
                    //$pagesPriceArr[$tempPages] = "NIL";
                }
            }
        }        
        $tempArr[$qty] = $pagesPriceArr;          
     }    
          
     $count = 0;
     echo "<table style='background-color:#e7e7e7' class='table table-striped'>";
     foreach($tempArr as $key => $val)
     {
            if($count==0)
            {            
               echo "<tr><th>Quantity</th>";
               foreach($val as $ky => $value)
               {
                   echo "<th>$ky</th>";
               }
               echo "</tr>";
            }           
            $count = $count + 1;
     }
    
    
     foreach($tempArr as $key1 => $val1)
     {
           echo "<tr><td>$key1</td>";
           foreach($val1 as $k1 => $v1)
           {
                 $samArr = explode("_", $v1);
                 $productId = $samArr[0];
                 $price = $samArr[1];
                 if(isset($_SESSION['printoption']) && $_SESSION['printoption']=="paid")
                 {
                          //$price =  $price + $_SESSION['designCharges'];
                 }
                 echo "<td onclick='javascript: sumbitPriceForm($productId);' style='cursor: pointer;'>&pound; ".number_format($price, 2)."</td>";
           }
           echo "</tr>";
    }
    echo "</table>";
    
  echo "--------------------";  
  
                                $productDetailsQuery = "select * from tbl_product_cat where productCatId='$psizeId'  AND catStatus='1' ";
                                $result = mysql_query($productDetailsQuery);
                                if($rows2 = mysql_fetch_assoc($result))
                                {   
                                                $filePath           = "upload/productcategory/".$rows2['imagePath'];
                                                $productDescription = $rows2['pageDesc'];      
                                                
                                                $productName        = $rows2['catName'];
                                                $productNameWOsize  = explode("_", $productName);
                                                $productName = $productNameWOsize[0];
                                                if(isset($productNameWOsize[1]) && $productNameWOsize[1]!="")
                                                {
                                                         $productSize = $productNameWOsize[1];
                                                }
                                                else
                                                {
                                                                        if(strstr($productName, "("))
                                                                        {
                                                                            $ftbkt       = strpos($productName, "(");                                                    
                                                                            $ltbkt       = strpos($productName, ")");
                                                                            $ltbkt       = $ltbkt - $ftbkt;
                                                                            $productSize = substr($productName,$ftbkt+1,$ltbkt-1);                                                    
                                                                            $hidProductSize = substr($productName,$ftbkt,$ltbkt+1);
                                                                            $productName = str_replace($hidProductSize, " ", $productName);
                                                                        }
                                                                        else
                                                                        {
                                                                            $productSize = $productName;
                                                                        }

                                               }
                                                
                                                
                                                echo   "<div role='tabpanel' class='tab-pane active' id='features'>
                                                            <div class='product-image v-middle'>
                                                                <div class='col-sm-12 col-xs-12'>
                                                                        <img src='$filePath' alt='ideal 1'>
                                                                </div>
                                                            </div>
                                                            <div class='product-shortdescript v-middle'>
                                                                <div class='col-sm-12 col-xs-12'>
                                                                   <div class='v-middle'>
                                                                       <h3>$productName</h3>
                                                                       <div class='mainprd-discp-frame'>
                                                                            <p>$productDescription</p>
                                                                       </div>
                                                                   </div>
                                                               </div>
                                                            </div>
					                </div>";
                                                
     }

?>