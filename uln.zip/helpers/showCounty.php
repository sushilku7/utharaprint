<?php
//Get County List Based on Country
include "../include/config.php";
require_once("../include/functions.php");
require_once("../include/functions_db.php");
$countryId = $_GET['country'];
$qryForProductPages = "SELECT * FROM ".prefix("county")." WHERE countryId='$countryId' ";
$rs = mysql_query($qryForProductPages);
			echo "<select name='memberCounty' id='memberCounty' style='width:212px;'>";
			while($rows=mysql_fetch_assoc($rs))
			{
				echo "<option value='".$rows['countyId']."'>".$rows['countyName']."</option>";
			}
			echo "</option>";
			echo "</select>";

?>