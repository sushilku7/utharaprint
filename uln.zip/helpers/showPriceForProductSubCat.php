<!-- <script type="text/javascript" src="http://cdnjs.cloudflare.com/ajax/libs/Sly/1.6.1/sly.min.js"></script>
-->
<style>
    .frame {
  height: 95px;
  overflow: hidden;
  width: 84%;
  float: left;
}
.frame ul {
  list-style: none;
  margin: 0;
  padding: 0;
  font-size: 15px;
}
.frame ul li {
  float: left;
  width: 80px;
  height: 95px;
  margin-right: 5px;
  color: #000;
  text-align: center;
  background-color: red;
  background:url(images/bg.png); 
}

.frame ul li.active {
   background:url(images/active.png); 
   height: 95px;
}

.frame ul li.selctQty {
   background:url(images/hover.png); 
   height: 95px;
}

.frame ul li.nonactive {
   background:url(images/bg.png); 
   height: 95px;
}
</style>
<?php
//session_start();
//Get Product Paper List Based on Product Size
include('../DAO/DbConnection.php');
include('../DAO/VatDAO.php');
include('../valueobjects/VatVO.php');
include('../library/Dropdown.php');
include('../DAO/ProductDAO.php');

$tempVatDAO   = new VatDAO();
$tempProductDAO = new ProductDAO();

$prodcutSubCatId       = $_POST['prodcutSubCatId'];
$productPaperSize      = $_POST['productPaperSize'];
$productPrintType      = $_POST['productPrintType'];
$productPaperType      = $_POST['productPaperType'];
$productLaminationType = $_POST['productLaminationType'];

$productNumSets        = @$_POST['productNumSets'];
$productFoldType       = @$_POST['productFoldType'];
$productPrintPageNum   = @$_POST['productPrintPageNum'];
$productCoverType      = @$_POST['productCoverType'];
$productCutType        = @$_POST['productCutType'];

$workingDays           = $_POST['workingDays'];
$productQty            = $_POST['defaultQty'];
$productVatStatus      = $_POST['vatStatus'];
$printoption           = $_POST['printoption'];
$prodCatId             = $_POST['prodCatId'];



if($printoption=="free") 
{
    $designCharges  = 0;
}
if($printoption=="paid")
{
    $designCharges  = $tempProductDAO->getDesignCharges($prodCatId);
}

DbConnection::CreateConnection();

        //echo "SELECT DISTINCT(productPaper) FROM tbl_product WHERE productSize='$psizeId' AND productStatus='1' ";die();
        $qury  = "select DISTINCT productQty, productId, productPrice, profiteMargine  from tbl_product where productSubCat='$prodcutSubCatId' and productPaperSize='$productPaperSize'  and productPrintType='$productPrintType'  and productPaperType='$productPaperType'  and productLaminationType='$productLaminationType' and productNumSets='$productNumSets' and productFoldType='$productFoldType' and productPrintPageNum='$productPrintPageNum' and productCoverType='$productCoverType' and productCutType='$productCutType' and  productTurnAround='$workingDays' order by productQty asc";
        $rs    = mysql_query($qury);
       
        $ddstr = "<img src='images/arrow-left.jpg' style='float: left; padding: 0px; border: 0px;' class='btn prev'  />
                  <div class='frame' id='basic'><ul>";
        $count = 0;
        while($rows=mysql_fetch_assoc($rs))
        {             
                $productId      = $rows['productId'];
                $qty            = $rows['productQty'];
                $proBuyPrice    = $rows['productPrice'];
                $profitMargin   = $rows['profiteMargine'];
                
                //Add margin in buying price 
                $margin                = ($proBuyPrice * $profitMargin)/100;
                $finalPriceWithOutVat  =  $proBuyPrice + $margin;
                
                if($productVatStatus=="Yes")
                {
                    $qryForVatDetail   = "SELECT rId, vatvalue  FROM tbl_vat ";
                    $result2           = mysql_query($qryForVatDetail);
                    $rs2               = mysql_fetch_assoc($result2);
                    $vatRate           = $rs2['vatvalue'];
                    $productVatPrice   = ($finalPriceWithOutVat*$vatRate)/100;
                    $productVatPrice   = round($productVatPrice, 2);

                    $finalPriceWithVat = $finalPriceWithOutVat + $productVatPrice;
                    //echo "Product Price - ".$productPrice;
                }
                else
                {
                    $finalPriceWithVat = $finalPriceWithOutVat;
                }
                
                $finalPrice = number_format($finalPriceWithVat, 2);                
                //echo "<br />Quantiy - ".$productQty;
                if($productQty==$qty)
                {
                    $startAt = $count;
                    $defaultProductId = $productId;
                    $ddstr    .="<li class='selctQty'>
                                <a style='cursor: pointer;' onclick='javascript: submitPriceForm($productId);'><div style='height: 48px; clear: both;padding-top: 15px; color: #FFF;'>$qty</div></a>
                                <a style='cursor: pointer;' onclick='javascript: submitPriceForm($productId);'><div style='height: 48px;clear: both;padding-top: 15px; color: #000;'>$finalPrice</div></a>
                                </li>";
                }
                else
                {
                     $ddstr   .="<li> 
                                <a style='cursor: pointer;' onclick='javascript: submitPriceForm($productId);'><div style='height: 48px; clear: both;padding-top: 15px; color: #FFF;'>$qty</div></a>
                                <a style='cursor: pointer;' onclick='javascript: submitPriceForm($productId);'><div style='height: 48px;clear: both;padding-top: 15px; color: #000;'>$finalPrice</div></a>
                                </li>";
                }
                $count = $count + 1;
        }
        $ddstr   .= "</ul></div> <img src='images/arrow-right.jpg' border='0' style='float: left; padding: 0px; border: 0px;' class='btn next'  />";
        
echo $ddstr;
?>


<style>
 .frame {
  height: 95px;
  overflow: hidden;
  width: 84%;
  border: 0px solid red;
  float: left;
}
.frame ul {
  list-style: none;
  margin: 0;
  padding: 0;
  font-size: 15px;
}
.frame ul li {
  float: left;
  width: 80px;
  height: 95px;
  margin-right: 5px;
  color: #000;
  text-align: center;
  background:url(images/bg.png); 
}

.frame ul li.active {
   background:url(images/active.png); 
   height: 95px;
}

.frame ul li.selctQty {
   background:url(images/hover.png); 
   height: 95px;
}

.frame ul li.nonactive {
   background:url(images/bg.png); 
   height: 95px;
}

</style>
<script type="text/javascript">    
jQuery(function($) {  
  (function() {
    var $frame = $('#basic');
    var $slidee = $frame.children('ul').eq(0);
    var $wrap = $frame.parent();

    // Call Sly on frame
    $frame.sly({
      horizontal: 1,
      itemNav: 'basic',
      smart: 1,
      activateOn: 'click',
      mouseDragging: 1,
      touchDragging: 1,
      releaseSwing: 1,
      startAt: <?php echo $startAt; ?>,
      scrollBar: $wrap.find('.scrollbar'),
      scrollBy: 1,
      pagesBar: $wrap.find('.pages'),
      activatePageOn: 'click',
      speed: 300,
      elasticBounds: 1,
      easing: 'easeOutExpo',
      dragHandle: 1,
      dynamicHandle: 1,
      clickBar: 1,

      // Buttons
      forward: $wrap.find('.forward'),
      backward: $wrap.find('.backward'),
      prev: $wrap.find('.prev'),
      next: $wrap.find('.next'),
      prevPage: $wrap.find('.prevPage'),
      nextPage: $wrap.find('.nextPage')
    });

    // To Start button
    $wrap.find('.toStart').on('click', function() {
      var item = $(this).data('item');
      // Animate a particular item to the start of the frame.
      // If no item is provided, the whole content will be animated.
      $frame.sly('toStart', item);
    });

    // To Center button
    $wrap.find('.toCenter').on('click', function() {
      var item = $(this).data('item');
      // Animate a particular item to the center of the frame.
      // If no item is provided, the whole content will be animated.
      $frame.sly('toCenter', item);
    });

    // To End button
    $wrap.find('.toEnd').on('click', function() {
      var item = $(this).data('item');
      // Animate a particular item to the end of the frame.
      // If no item is provided, the whole content will be animated.
      $frame.sly('toEnd', item);
    });

    // Add item
    $wrap.find('.add').on('click', function() {
      $frame.sly('add', '<li>' + $slidee.children().length + '</li>');
    });

    // Remove item
    $wrap.find('.remove').on('click', function() {
      $frame.sly('remove', -1);
    });
  }());
});
</script>

<?php
echo "--------------------";
?>
<?php
$productId             = $defaultProductId;
$pCatId                = $prodcutSubCatId;

$productCatQuery = "select pc.catName, pc.pageDesc, p.productId, p.productSubCat, p.productPaperType, p.productPaperSize, p.productPrintType, p.productLaminationType, p.productNumSets, p.productFoldType, p.productPrintPageNum, p.productCoverType, p.productCutType, p.productQty, p.productPrice, p.profiteMargine from tbl_product as p  inner join tbl_product_cat as pc  on p.productSubCat=pc.productCatId where productId='$productId' ";
$productCatResult = mysql_query($productCatQuery);

if($res=mysql_fetch_array($productCatResult))
{
    $productName           = $res['catName'];
    $quantity              = $res['productQty'];
    $productDesc           = substr($res['pageDesc'], 0, 300);
    $productPaperSize      = $res['productPaperSize'];
    $productPrintType      = $res['productPrintType'];
    $productPaperType      = $res['productPaperType'];
    $productLaminationType = $res['productLaminationType'];
    $productNumSets        = $res['productNumSets'];
    
    $productFoldType        = $res['productFoldType'];
    $productPrintPageNum    = $res['productPrintPageNum'];
    $productCoverType       = $res['productCoverType'];
    $productCutType         = $res['productCutType'];
    
    
    $proBuyPrice           = $res['productPrice'];
    $profitMargin          = $res['profiteMargine'];
}

//Add margin in buying price 
$margin                = ($proBuyPrice * $profitMargin)/100;
$finalPriceWithOutVat  =  $proBuyPrice + $margin;


                                                                    
if($productVatStatus=="Yes")
{
    $qryForVatDetail   = "SELECT rId, vatvalue  FROM tbl_vat ";
    $result2           = mysql_query($qryForVatDetail);
    $rs2               = mysql_fetch_assoc($result2);
    $vatRate           = $rs2['vatvalue'];
    $productVatPrice   = ($finalPriceWithOutVat*$vatRate)/100;
    $productVatPrice   = round($productVatPrice, 2);

    $finalPriceWithVat = $finalPriceWithOutVat + $productVatPrice;
    //echo "Product Price - ".$productPrice;
}
else
{
    $finalPriceWithVat = $finalPriceWithOutVat;
}

$totalPrice = $finalPriceWithVat + $designCharges;

echo   "<form name='productPricefrm' id='productPricefrm' action='shopping-cart.php' method='post' enctype='multipart/form-data'>
        <input type='hidden' name='proId'                   value='$productId'>
        <input type='hidden' name='qty'                     value='$quantity'>
        <input type='hidden' name='pCatId'                  value='$pCatId'>    
        <input type='hidden' name='productName'             value='$productName'>
        <input type='hidden' name='productPaperSize'        value='$productPaperSize'>
        <input type='hidden' name='productPrintType'        value='$productPrintType'>
        <input type='hidden' name='productPaperType'        value='$productPaperType'>
        <input type='hidden' name='productLaminationType'   value='$productLaminationType'>
            
        <input type='hidden' name='productFoldType'         value='$productFoldType'>
        <input type='hidden' name='productPrintPageNum'     value='$productPrintPageNum'>
        <input type='hidden' name='productCoverType'        value='$productCoverType'>
        <input type='hidden' name='productCutType'          value='$productCutType'>
            
        <input type='hidden' name='productNumSets'          value='$productNumSets'>
        <input type='hidden' name='productPriceWOutVat'     value='$finalPriceWithVat'>
        <input type='hidden' name='productPriceWithVat'     value='$finalPriceWithVat'>
            
        <!--
        <input type='hidden' name='vatFlag'                 value='$productVatStatus'>
        <input type='hidden' name='vateRate'                value='$vatRate'>
        <input type='hidden' name='vatAmount'               value='$productVatPrice'>
        -->
        <input type='hidden' name='vatFlag'                 value='No'>
        <input type='hidden' name='vateRate'                value='0'>
        <input type='hidden' name='vatAmount'               value='0'>

        <input type='hidden' name='designCharges'           value='$designCharges'>
        <input type='hidden' name='productDescription'      value='$productDesc'>        

<div class='price-total col-xs-12' style='margin-left: 175px; width: 230px; border: 0px solid red; margin-bottom: 5px;'>
<label>Price:</label>
<span class='price'>&pound; ".number_format($totalPrice, 2)."</span>
<p style='border: 0px solid red;width: 200px;text-align: center; font-size: 15px;'>All Inclusive</p> 
</div>
<div class='add-cart-btn-w col-xs-12' style='padding:0px;'>
<input type='submit' name='submit' value='ADD TO BASKET' class='add-cart-btn btn'>
<h3 style='font-size: 18px; margin: 15px;'>FREE UK MAINLAND DELIVERY!</h3>
<div style='clear: both; border-bottom: 1px solid #CCC; height: 30px;margin: 12px 18px;'></div>
<h2 style='font-size: 24px; color:#EF7F1B; '>Can&rsquo;t find what you&rsquo;re looking for?</h2>
<div  style='width: 300px; margin-top: 10px;margin-left: 150px; border: 0px solid red;' ><a href='#'><img src='images/request-quote.png'  /></a></div>
</div>
</form>";


echo "--------------------";
$workingDays           = $_POST['workingDays'];
//echo Dropdown::getAjaxProductTurnAroundList($prodcutSubCatId, $productPaperSize, $productPrintType, $productPaperType, $productLaminationType, $productNumSets, $productQty, $workingDays, $productFoldType, $productPrintPageNum, $productCoverType, $productCutType);
$productTurnArndQuery  = "select DISTINCT productTurnAround, productPrice from tbl_product where productSubCat='$prodcutSubCatId' and productPaperSize='$productPaperSize'  and productPrintType='$productPrintType'  and productPaperType='$productPaperType'  and productLaminationType='$productLaminationType' and productNumSets='$productNumSets' and productFoldType='$productFoldType' and productPrintPageNum='$productPrintPageNum' and productCoverType='$productCoverType' and productCutType='$productCutType' and productQty='$quantity'   order by productTurnAround asc";
$productTurnArndResult = mysql_query($productTurnArndQuery);
$dropDown = "";
        while($row1=mysql_fetch_assoc($productTurnArndResult))
        { 
    
                 $proTurnAround = $row1['productTurnAround'];
                 $price         = $row1['productPrice'];
                 
                 $dropDown     .='<div class="turnAround">
                                 <a style="cursor: pointer;"  onclick="javascript: submitForm('."'".$proTurnAround."'".')">';   
                        if($workingDays==$proTurnAround)
                        {
                               $dropDown   .="<p style='width: 135px; height: 35px; background-color: #EF7F1B; color: #fff; padding-top:8px;'>$proTurnAround</p>";
                        }
                        else
                        {
                               $dropDown   .="<p style='width: 135px; height: 35px; background-color: #D9DBDA;padding-top:8px;'>$proTurnAround</p>";
                        }
                 $dropDown     .='</a>
                               </div>';
        }
echo $dropDown;

echo "--------------------";

//echo "<br />Test - $dsgnCharges";
?>
<input type="hidden" id='prodCatId' name="prodCatId" value='<?php echo $prodCatId;  ?>'  />  
<input type="hidden" id='printoption' name="printoption" value="<?php echo $printoption; ?>"  />
<input type="hidden" id='designCharges' name="designCharges" value="<?php echo $designCharges; ?>"  />
    <label>
        <?php 
             $printOptionFree =  "class='btn btn-default' style='width:274px;'";
             if($printoption=="free") 
             {
                 $printOptionFree =  "class='btn btn-primary' style='width:274px;'";
             }
             
             $printOptionPaid =  "class='btn btn-default' style='width:274px;'";
             if($printoption=="paid") 
             {
                 $printOptionPaid =  "class='btn btn-primary' style='width:274px;'";
             }
            
        ?>
        <button type="button" <?php  echo $printOptionFree; ?>     name="printoption1" id="printoption1" value="free" onclick="javascript: submitProductDesignForm(1);">I will upload my Artwork</button> 
    </label>
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    <label>
        <button type="button" <?php  echo $printOptionPaid; ?>     name="printoption2" id="printoption2" value="paid" onclick="javascript: submitProductDesignForm(2);">Please create Artwork for me</button> 
    </label>