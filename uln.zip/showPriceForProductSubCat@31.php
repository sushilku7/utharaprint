<?php
//session_start();
//Get Product Paper List Based on Product Size
include('DAO/DbConnection.php');
include('DAO/VatDAO.php');
include('valueobjects/VatVO.php');
include('library/Dropdown.php');
include('DAO/ProductDAO.php');
$tempVatDAO   = new VatDAO();
$tempProductDAO = new ProductDAO();

DbConnection::CreateConnection();
//echo "haaaa";die();
$prodcutSubCatId       = $_POST['prodcutSubCatId'];
$productPaperSize      = $_POST['productPaperSize'];
$productPrintType      = $_POST['productPrintType'];
$productPaperType       = $_POST['productPaperType'];
$printoption           = $_POST['printoption'];
$workingDays           = "7-10 Working Days";

$prodCatId           = $_POST['prodCatId'];
?>

<?php


$prodcutSubCatId       = $_POST['prodcutSubCatId'];
$productPaperSize      = $_POST['productPaperSize'];
$proPaperType          = $_POST['productPaperType'];
//echo "select distinct(productPaperType) from tbl_product where productSubCat='$prodcutSubCatId'";
//echo "select distinct(productPaperType) from tbl_product where productSubCat='$prodcutSubCatId'";

$productPaperTypeQuery  = "select distinct(productPaperType) from tbl_product where productSubCat='$prodcutSubCatId'";
$productPaperTypeResult = mysql_query($productPaperTypeQuery);
$dropDown = "";
$ddstr="";
        while($row1=mysql_fetch_assoc($productPaperTypeResult))
        { 
    
                $productPaperType = $row1['productPaperType'];
                 //$price         = $row1['productPrice'];
                 //$productId = $row1['productId'];
                // $dropDown     .='<div class="turnAround" style="float: left;">
                    //             <a style="cursor: pointer;"  onclick="javascript: submitForm('."'".$productPaperType."'".')">';   
                if($proPaperType==$productPaperType)
                {
                    $ddstr         .='<label class="pressed"><a onclick="javascript: submitForm('."'".$productPaperType."'".')">';
                    $ddstr         .="$productPaperType</a></label>";
                }
                else
                {
                     $ddstr         .='<label class="radio1"><a onclick="javascript: submitForm('."'".$productPaperType."'".')">';
                     $ddstr         .="$productPaperType</a></label>";
                }
                              
        }
       //echo $productPaperType;
echo $ddstr;
 
echo "--------------------";

//echo "<br />Test - $dsgnCharges";
?>

<?php
$proPaperType      = $_POST['productPaperType'];
$proPrintType      = $_POST['productPrintType'];
$productPrintTypeQuery  = "select distinct(productPrintType) from tbl_product where productSubCat='$prodcutSubCatId'";
$productPrintTypeResult = mysql_query($productPrintTypeQuery);
$dropDown = "";
$ddstr ="";
        while($row1=mysql_fetch_assoc($productPrintTypeResult))
        { 
    
                $productPrintType = $row1['productPrintType'];
                 //$price         = $row1['productPrice'];
                
                // $dropDown     .='<div class="turnAround" style="float: left;">
                    //             <a style="cursor: pointer;"  onclick="javascript: submitForm('."'".$productPaperType."'".')">';   
                        if($proPrintType==$productPrintType)
                        {
                            $ddstr         .='<label class="pressed"><a onclick="javascript: submitProductPrintTypeForm('."'".$productPrintType."'".')">';
                            $ddstr         .="$productPrintType</a></label>";
                        }
                        else
                        {
                            $ddstr         .='<label class="radio1"><a onclick="javascript: submitProductPrintTypeForm('."'".$productPrintType."'".')">';
                            $ddstr         .="$productPrintType</a></label>";
                        }
                              
        }
       //echo $productPaperType;
echo $ddstr;


echo "--------------------";
?>


 <?php	
$prodcutSubCatId       = $_POST['prodcutSubCatId'];
$productPaperSize      = $_POST['productPaperSize'];
$productPrintType      = $_POST['productPrintType'];
$productPaperType          = $_POST['productPaperType'];
$productCatName          = $_POST['productCatName'];
$printoption           = $_POST['printoption'];
$workingDays           = "7-10 Working Days";      
echo "<label>$productPaperType</label>";
                                                
           
    echo "--------------------";       
        ?>
<?php


$prodcutSubCatId       = $_POST['prodcutSubCatId'];
$productPaperSize      = $_POST['productPaperSize'];
$productPrintType      = $_POST['productPrintType'];
$productPaperType          = $_POST['productPaperType'];
$printoption           = $_POST['printoption'];
$workingDays           = "7-10 Working Days";

//echo "select DISTINCT productQty, productId, productPrice, profiteMargine  from tbl_product where productSubCat='$prodcutSubCatId' and productPaperSize='$productPaperSize' and productPrintType='$productPrintType' and productPaperType='$productPaperType' order by productQty asc";
//die();
$productVatStatus="No";
$qury  = "select DISTINCT productQty, productId, productPrice, profiteMargine  from tbl_product where productSubCat='$prodcutSubCatId' and productPrintType='$productPrintType' and productPaperType='$productPaperType' order by productQty asc";
$rs    = mysql_query($qury);
$ddstr = "<select class='put1' name='productPrice' id='productPrice' onchange='javascript: submitPriceForm();'>";
        $count = 0;
        while($rows=mysql_fetch_assoc($rs))
        {             
                //$product_id       = $rows['productId'];
                $productId        = $rows['productId'];
                $qty              = $rows['productQty'];
                $proBuyPrice      = $rows['productPrice'];
                $profitMargin     = $rows['profiteMargine'];
                $margin                = ($proBuyPrice * $profitMargin)/100;
                $finalPriceWithOutVat  =  $proBuyPrice + $margin;                
                if($productVatStatus=="Yes")
                {
                    $qryForVatDetail   = "SELECT rId, vatvalue  FROM tbl_vat ";
                    $result2           = mysql_query($qryForVatDetail);
                    $rs2               = mysql_fetch_assoc($result2);
                    $vatRate           = $rs2['vatvalue'];
                    $productVatPrice   = ($finalPriceWithOutVat*$vatRate)/100;
                    $productVatPrice   = round($productVatPrice, 2);

                    $finalPriceWithVat = $finalPriceWithOutVat + $productVatPrice;
                    //echo "Product Price - ".$productPrice;
                }
                else
                {
                    $finalPriceWithVat = $finalPriceWithOutVat;
                }
                
                $finalPrice = number_format($finalPriceWithVat, 2);                                
                
                $ddstr.="<option value='$productId'>$qty</option>";
                $count = $count + 1;
        }
        $ddstr   .= "</select>";
        
echo $ddstr;

echo "--------------------"; 
?>
<?php
$tempProductDAO = new ProductDAO();
$prodcutSubCatId       = $_POST['prodcutSubCatId'];
$productPaperSize      = $_POST['productPaperSize'];
$productPrintType      = $_POST['productPrintType'];
$productPaperType          = $_POST['productPaperType'];
$productLaminationType = $_POST['productLaminationType'];
//$productId             = $_POST['productId'];
$productNumSets        = @$_POST['productNumSets'];
$productFoldType       = @$_POST['productFoldType'];
$productPrintPageNum   = @$_POST['productPrintPageNum'];
$productCoverType      = @$_POST['productCoverType'];
$productCutType        = @$_POST['productCutType'];
$printoption           = $_POST['printoption'];
$workingDays           = "7-10 Working Days";

//echo "select DISTINCT productQty, productId, productPrice, profiteMargine  from tbl_product where productSubCat='$prodcutSubCatId' and productPaperSize='$productPaperSize'  and productPrintType='$productPrintType'  and productPaperType='$productPaperType'  and productLaminationType='$productLaminationType' and productNumSets='$productNumSets' and  productTurnAround='$workingDays' and productPrintPageNum='$productPrintPageNum' and productCutType='$productCutType' and productFoldType='$productFoldType' and productCoverType='$productCoverType' order by productQty asc";

$productVatStatus="Yes";
$qury  = "select DISTINCT productQty, productId, productCatId, productPrice, profiteMargine  from tbl_product where productSubCat='$prodcutSubCatId' and productPrintType='$productPrintType'  and productPaperType='$productPaperType' order by productQty asc limit 0, 1";
$rs    = mysql_query($qury);
     $count = 0;
        while($rows=mysql_fetch_assoc($rs))
        {             
                //$product_id       = $rows['productId'];
                $productId        = $rows['productId'];
                $productCatId        = $rows['productCatId'];
                $qty              = $rows['productQty'];
                $proBuyPrice      = $rows['productPrice'];
                $profitMargin     = $rows['profiteMargine'];
                
                //Add margin in buying price 
                $margin                = ($proBuyPrice * $profitMargin)/100;
                $finalPriceWithOutVat  =  $proBuyPrice + $margin;
                
                if($productVatStatus=="Yes")
                {
                    $qryForVatDetail   = "SELECT rId, vatvalue  FROM tbl_vat ";
                    $result2           = mysql_query($qryForVatDetail);
                    $rs2               = mysql_fetch_assoc($result2);
                    $vatRate           = $rs2['vatvalue'];
                    $productVatPrice   = ($finalPriceWithOutVat*$vatRate)/100;
                    $productVatPrice   = round($productVatPrice, 2);

                    $finalPriceWithVat = $finalPriceWithOutVat + $productVatPrice;
                    //echo "Product Price - ".$productPrice;
                }
                else
                {
                    $finalPriceWithVat = $finalPriceWithOutVat;
                }
                
                              
                
                /*              
                if($quantity==$qty)
                {
                 $select="selected";
                }
                else
                {
                 $select="";
                }
               */
               // echo $printoption;
                
                if($printoption=="free") 
                    {
                        $designCharges  = 0;
                    }
                    if($printoption=="paid")
                    {
                    $designCharges  = $tempProductDAO->getDesignCharges($productCatId);
                    }
                 
                $totalPriceWithDesignCharge= $finalPriceWithOutVat + $designCharges;   
                $finalPrice = number_format($totalPriceWithDesignCharge, 2);
                $totalPrice = $totalPriceWithDesignCharge+$productVatPrice;
				
				echo "<input type='hidden' id='sushil' name='sushil' value='$finalPriceWithOutVat'  />
					<input type='hidden' id='vatAmt' name='vatAmt' value='$productVatPrice'  />
					<input type='hidden' name='productPriceWOutVat'  value='$totalPriceWithDesignCharge'>
					<input type='hidden' id='designCharges' name='designCharges' value='$designCharges'>";
                echo "<center>
                            <div class='productInfo'>
                                <a href class='productLink'> Design Fee + Price  = Net Amount</a>
                                <div class='productshortInfo'>&pound;".number_format($designCharges, 2)."+&pound;".number_format($finalPriceWithOutVat, 2)." = <strong>&pound;".number_format($totalPriceWithDesignCharge, 2)."</strong></div>
                            </div>
			    <br/>
			   <div class='productInfo'>
                                <a href class='productLink'> Net Amount + VAT = Total Amount</a>
                                <div class='productshortInfo'>&pound;".number_format($totalPriceWithDesignCharge, 2)."+&pound;".number_format($productVatPrice, 2)." = <strong>&pound;".number_format($totalPrice, 2)."</strong></div>
                            </div>
				<br/>
				<table class='tabl' ><tr class='tri'>
				<td class='in'><a href='quote.php'><div class='productPrice' style='text-align: center'>Quotation </div></a></td><td class='in'><a href='#'><div class='productPrice'  style='text-align: center'><button type='submit' class='productPrice' name='cart' value='addtocart' class='formbutton'>Add to Cart</button></div></a></td>
				</tr>
				</table>
			</center>";
               
        }
       
    echo "--------------------";
?>


 <?php	
$prodcutSubCatId       = $_POST['prodcutSubCatId'];
$productPaperSize      = $_POST['productPaperSize'];
$productPrintType      = $_POST['productPrintType'];
$productPaperType          = $_POST['productPaperType'];
$productCatName          = $_POST['productCatName'];
$printoption           = $_POST['printoption'];
$workingDays           = "7-10 Working Days";      
echo "<label>$productPrintType</label>";
?>