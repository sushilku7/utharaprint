<?php
ob_start();
session_start();
error_reporting (E_ALL ^ E_NOTICE);
include('includes/top_header.php');
$tempProductDAO    = new ProductDAO();
$tempProductMainCatDAO = new ProductMainCategoryDAO();
$tempProductCatDAO = new ProductCatDAO();
?> 
<!DOCTYPE html>
<html lang="en">

<head>
    <title>Uthara Print London Testimonals</title>
    <meta charset="utf-8">
    <meta name="robots" content="noodp, noydir" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width; initial-scale=1.0; maximum-scale=1.0">
    <!--css-->
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/responsive.css">
    
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
   
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
    <!--css-->
   
	<style>
		
	* { -webkit-box-sizing: border-box; -moz-box-sizing: border-box; box-sizing: border-box; }
*:before, *:after { -webkit-box-sizing: inherit; -moz-box-sizing: inherit; box-sizing: inherit; }



#video-viewport{ position: relative; top:30px; left: 0; width: 100%; height: auto; overflow: hidden; z-index: -1;  }


.fullsize-video-bg { height: auto; }

.fullsize-video-bg:before { content: "";  position: absolute; top:30px; left: 0; width: 100%; height: auto; z-index: 0; }
.fullsize-video-bg:after { content: "";  background-size: 3px 3px; position: absolute; top:30px; left: 0; width: 100%; height: auto; z-index: 1; }


	</style>
	
  
	
</head>

<body>
    <!--Start mainContainer-->
    <div class="mainCon">
        <?php
        include 'header.php';
        ?>
		
        <div class="content">
            <div class="lineh"></div>
			<div class="lineh"></div>
			<div class="lineh"></div>
			<div class="lineh"></div>
		<section class="fullsize-video-bg">
			<div id="video-viewport">
				<img src="images/trustpilot banner.jpg" alt=""/>
			</div> 
			</section>		
			
           <!-- <div class="bannerBox">
                
            </div>-->
			<div class="lineh"></div>
			<div class="lineh"></div>
			<div class="lineh"></div>
			<div class="lineh"></div>
			
           <div class="container-sm productOffers">
              <h2 style="color: #294b8a;text-align: center">We are Super Thrilled to tell you all about our Excellent rating on Trustpilot.</h2>
		
                <div class="productContainet">
                    <div class="productBox shopwidth">
                       <div class="box1">
							<img src="images/73x73.png" alt="" style="border-radius: 50%;float: left;margin-left: 20px;margin-top: 15px;margin-bottom:  " class="productImage1"/>
							<h4 style="font-size: 20px; ;text-align: left;float: left;display: block;justify-content: space-around;padding: 24px;padding-left: 30px">Robert Barney  <br/>
						   <small style="font-size: 12px">London | United Kingdom &nbsp; &nbsp;&nbsp;&nbsp; | &nbsp; &nbsp;&nbsp;&nbsp; Jul 13 , 2016</small></h4>
						<h4 style="display: flex;justify-content: center;float: left;padding-left: 30px">Great service and the shutters are fabulous</h4>
							<p style="padding: 10px;float: left">	" <i>Really professional service. Excellent customer services that really went above and beyond to make sure the measurements were all accurate. The shutters themselves are beautiful.</i>"
						   <br/><br/>
						   <img src="images/rating.jpg" alt="" style="float: right;display: flex-end;border: 2px solid #04b679;border-radius: 10px"/></p>
						   <br/>
						   
						</div>
                    </div>
                   
               
                   
	                  <div class="productBox shopwidth">
                        <div class="box1" style="height: auto;">
							<img src="images/73x731.jpg" alt="" style="border-radius: 50%;float: left;margin-left: 20px;margin-top: 15px;margin-bottom:  " class="productImage1"/>
							<h4 style="font-size: 20px; ;text-align: left;float: left;display: block;justify-content: space-around;padding: 24px;padding-left: 30px">
Phillip Morgan<br/>
						   <small style="font-size: 12px"> United Kingdom &nbsp;&nbsp;&nbsp; &nbsp; | &nbsp; &nbsp; &nbsp;&nbsp;Mar 2 , 2019</small></h4>
							
							<h4 style="display: flex;justify-content: center;float: left;padding-left: 30px">
								Great quality and service. Terrific value!</h4><p style="padding: 10px;float: left">" <i>I used Utharaprint for the first time recently for my business card printing.
Anna was very helpful throughout the ordering process. 
Very pleased with the quality of the business cards provided and at an excellent price.
I would certainly use Utharaprint again for future printing requirements.</i>"
							<br/>
						   <img src="images/rating.jpg" alt="" style="float: right;display: flex-end;border: 2px solid #04b679;border-radius: 10px"/>

</p>
<br/>
						  </div>   
                     </div>
				
                </div> 
			   	<div class="lineh"></div>
			   	<div class="lineh"></div>
			           <div class="productContainet">
                    <div class="productBox shopwidth">
                       <div class="box1">
							<img src="images/73x732.jpg" alt="" style="border-radius: 50%;float: left;margin-left: 20px;margin-top: 15px;margin-bottom:  " class="productImage1"/>
							<h4 style="font-size: 20px; ;text-align: left;float: left;display: block;justify-content: space-around;padding: 24px;padding-left: 30px">
Andrew Gardiner<br/>
						   <small style="font-size: 12px"> United Kingdom  &nbsp; &nbsp;&nbsp;&nbsp; | &nbsp; &nbsp; &nbsp;&nbsp;Mar 11, 2019</small></h4>
						<h4 style="display: flex;justify-content: center;padding-left: 30px;width: 100%;text-align: left;">Excellent</h4>
							<p style="padding: 10px;float: left">	" <i>excellent - great prices, great customer service [ Anna jones especially ], gave me an estimation of a week delivery but the order arrived the next day! will certainly use again. cat at TEN.</i>"<br/><br/>
						   <img src="images/rating.jpg" alt="" style="float: right;display: flex-end;border: 2px solid #04b679;border-radius: 10px"/></p>
						   <br/>
						</div>
                    </div>
                   
                 
                   
	                  <div class="productBox shopwidth">
                        <div class="box1" style="height: auto;">
							<img src="images/73x733.jpg" alt="" style="border-radius: 50%;float: left;margin-left: 20px;margin-top: 15px;margin-bottom:  " class="productImage1"/>
							<h4 style="font-size: 20px; ;text-align: left;float: left;display: block;justify-content: space-around;padding: 24px;padding-left: 30px">Danielle<br/>
						   <small style="font-size: 12px"> United Kingdom &nbsp; &nbsp;&nbsp; &nbsp; | &nbsp; &nbsp;&nbsp;&nbsp; Mar 1 , 2019 </small><br/>
								
							</h4>
							
							<h4 style="display: flex;justify-content: center;padding-left: 30px;width: 100%;text-align: left;">
								The service was great</h4><p style="padding: 10px;float: left">" <i>The service was great, fast and efficient. Rebecca in particular was amazing, she went out of her way in order to help us get our work completed as we needed some amendments to be done before hand.</i>"<br/><br/>
						   <img src="images/rating.jpg" alt="" style="float: right;display: flex-end;border: 2px solid #04b679;border-radius: 10px"/>

</p><br/>

						  </div>   
                     </div>
				
                </div> 
			    	<div class="lineheight"></div>
			   <center>
			   
			   <a href="https://www.trustpilot.com/review/utharaprint.co.uk" class="reviewbutton" target="_blank"> View all Reviews</a>
			   </center>
			  
		    </div>
				
			
		<!--------------------------------->
           
        </div>
	
        <?php
        include 'footer.php';
        ?>
    </div>
    <!--End mainContainer-->
    <!--script-->
    
    <script type="text/javascript" src="js/jquery.min.js"></script>
    <script type="text/javascript" src="js/function.js"></script>

</body>

</html>