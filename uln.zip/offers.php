<?php
ob_start();
session_start();
error_reporting (E_ALL ^ E_NOTICE);
include('includes/top_header.php');
$tempProductDAO = new ProductDAO();
$tempProductMainCatDAO = new ProductMainCategoryDAO();
$tempProductCatDAO = new ProductCatDAO();
$tempFeaturesDAO = new FeaturesDAO();
$tempOurbrandDAO = new OurbrandDAO();
$tempBannerDAO = new BannerDAO();
$tempSpecialofferDAO = new SpecialofferDAO();
$tempSettingDAO= new SettingDAO();
$configID=1;
$tempSettingVO=$tempSettingDAO->getSiteSettingDetails($configID);
$logo		=$tempSettingVO->getSite_logo(); 
$siteTitle	=$tempSettingVO->getSite_title();  
$emailID	=$tempSettingVO->getAdmin_email(); 
$contactNumber=$tempSettingVO->getAdmin_name(); 
//echo count($tempProductCatResult);die();
$tempBestsellingProductCatResult = $tempProductCatDAO->BestsellingProductCatList();
//print_r($tempBestsellingProductCatResult);
$tempTopSellerProductCatResult = $tempProductCatDAO->TopSellerProductCatList();
$tempMusthavesProductCatResult = $tempProductCatDAO->MusthavesProductCatList();
$tempProductCatResult = $tempProductCatDAO->mainProductCatList();
//$tempOurserviceResult = $tempOurserviceDAO->OurServiceList();
$tempOurbrandResult = $tempOurbrandDAO->OurbrandList();
$tempSpecialofferResult = $tempSpecialofferDAO->specialOfferProductListing();
$topBanner1=12;
$personalizeBanner1=2;
$personalizeBanner2=3;
$samplePackBanner1=4;
$samplePackBanner2=5;

$tempFeaturesResult = $tempFeaturesDAO->FeaturesList();
$tempBannerVO=$tempBannerDAO->getBannerDetails($topBanner1);
$topBanner1=$tempBannerVO->getImage();
$topBannerDesc=$tempBannerVO->getBannerDesc();
$topBannerUrl=$tempBannerVO->getBannerUrl();
if(isset($_POST['submit']) && $_POST['submit']='Submit')
{
$name = $_POST['memberName'];
$memberEmail = $_POST['memberEmail'];
$msg = $_POST['requirement'];
$message ="<table width='560' border='0' cellspacing='1' cellpadding='4' align='center' style='font-family:Verdana, Arial, Helvetica, sans-serif; font-size:12px;' bgcolor='#DBDBDB'>

						<tr>

						<td width='700px' colspan='2' align='left' bgcolor='#FFFFFF'>Dear $name,

						<br/><br/>

						Your Quotation Details :</td>

						</tr>



						<tr>

						<td colspan='2' align='left' bgcolor='#FFFFFF'><b> Name: $name</b></td>

						</tr>

						<tr>

						<td colspan='2' align='left' bgcolor='#FFFFFF'><b>Email Id: $memberEmail</b></td>

						</tr>

						<tr>

						<td colspan='2' align='left' bgcolor='#FFFFFF'><b>Message: $msg</b></td>

						</tr>

						

						<tr>

						<td colspan='2'  align='left' bgcolor='#FFFFFF'>

						 Uthara Print Team <br /> 



						</td>

						</tr>





						<tr>

						<td  style='background-color:#FFFFFF; padding-top:10px; padding-bottom:10px;'><b>Thanks,</b></td>

						</tr>

						

                                </table>";

                   //echo $message;die();                                     

                                  $email_to     = $memberEmail;

                                  $email_from 	= "sales@utharaprint-london.co.uk";						

				  $email_subject= "Utharaprint London - Special Offers";

				  $headers  = "From: Uthara Print <".$email_from.">\r\n";

				  $headers .= "Reply-To: " . $email_from . "\r\n";

				  $headers .= "Content-type: text/html";

				  

		  $sent = mail($email_to, $email_subject, $message, $headers);
}
		  
?>
<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="content-type" content="text/html;charset=utf-8"/>
    <title>Offers | Uthara Print London </title>
    <meta charset="utf-8">
    <meta name="robots" content="noodp, noydir" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width; initial-scale=1.0; maximum-scale=1.0">
    <!--css-->
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/responsive.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
    <script type="text/javascript" src="https://code.jquery.com/jquery-1.8.2.js"></script>
    <!--css-->
	<link rel="stylesheet" href="css/offercss.css">
    <!-- Insert to your webpage before the </head> -->
    <script src="sliderengine/jquery.js"></script>
    <script src="sliderengine/amazingslider.js"></script>
    <link rel="stylesheet" type="text/css" href="sliderengine/amazingslider-1.css">
    <script src="sliderengine/initslider-1.js"></script>
    <!-- End of head section HTML codes -->
    
</head>
<body>
     <div class="content">
			<?php
        include 'header.php';
        ?>
				<div class="lineheight"></div>
				
			
    <!-- Insert to your webpage where you want to display the slider -->
    <div id="amazingslider-wrapper-1" style="display:block;position:relative;max-width:100%;margin-bottom: 56px;">
        <div id="amazingslider-1" style="display:block;position:relative;margin:0 auto;">
            <ul class="amazingslider-slides" style="display:none;">
                <?php
                if(count($tempFeaturesResult)>0)
                {
                    for($i=0;$i<count($tempFeaturesResult);$i++)
                    {
                        $tempFeaturesVO=$tempFeaturesResult[$i];
                        $images=$tempFeaturesVO->getImage();
                        echo "<li><a href='upload/features/$images' class='html5lightbox'><img src='upload/features/$images' alt='Banner'  title='Banner' /></a>";
                    }
                }
                
                ?>
               
            </ul>
            <ul class="amazingslider-thumbnails" style="display:none;">
                <?php
                if(count($tempFeaturesResult)>0)
                {
                    for($i=0;$i<count($tempFeaturesResult);$i++)
                    {
                        $tempFeaturesVO=$tempFeaturesResult[$i];
                        $images=$tempFeaturesVO->getImage();
                        echo "<li><img src='slider-images/Banner-tn.jpg' alt='Banner' title='Banner' /></li>";
                    }
                }?>
              
            </ul>
        </div>
    </div>
    <!-- End of body section HTML codes -->
		 		<div class="container-sm productOffers">
				
            <div class="mainHd">Products On Offer </div>
            <div class="productContainet flex">
            <?php
                            
                              if(count($tempSpecialofferResult)>0)
                                                         {
                                                               $count = 1;
                                                               for($i=0;$i<count($tempSpecialofferResult);$i++)
                                                                {
                                                                   $tempSpecialofferVO = $tempSpecialofferResult[$i];
                                                                   $productName      = $tempSpecialofferVO->getOfferHeadline();
                                                                   $productCatId     = $tempSpecialofferVO->getOfferId();
                                                                   $productImg       = $tempSpecialofferVO->getImagePath();
                                                                   $dirName          = $tempSpecialofferVO->getAlias();
                                                                   $aliasName        = $tempSpecialofferVO->getAlias();
                                                                   $shortCatDesc     = $tempSpecialofferVO->getOfferText();

                                                                   if($productImg=="" || $productImg==NULL)
                                                                   {
                                                                       $productImg = "no-preview.jpg";
                                                                   }
                                                                   echo "<div class='productBox transition width'>
            <div class='productImage'><a href='$dirName.html'><img src='upload/specialoffer/$productImg' alt=''></a></div>
            
             <div class='productContent'>
                            <div class='productInfo' style='padding-bottom:10px'>
                                <a href='$dirName.html' class='first'>$productName</a>
                             
                            </div>
                          </div>
             <a href='$dirName.html'><div class='productPrice' >Order Now</div></a>
</div>";
                                     if($count%5==0 & $count!=0)
                                        {
                                     echo "</div><div class='lineheight'> </div>
                                        <div class='productContainet flex'>";
                                        }
                                        $count=$count+1;
                                         }
                                        }
                    ?>
            
		  
            </div>		  		
          </div>
			
   <?php
            include 'footer.php';
        ?>
	</div>
	<!--<script type="text/javascript" src="js/function.js"></script>
<script type="text/javascript">! function(t, e) {"use strict";var r = function(t) {try {var r = e.head || e.getElementsByTagName("head")[0],a = e.createElement("script");a.setAttribute("type", "text/javascript"), a.setAttribute("src", t), r.appendChild(a)} catch (t) {}};t.chatbot_id =369, r("https://s3.amazonaws.com/smatbot/files/smatbot_plugin.js.gz")}(window, document);</script><script src="https://cdnjs.cloudflare.com/ajax/libs/fingerprintjs2/1.5.1/fingerprint2.min.js"></script>
 -->
</body>
</html>