<?php
ob_start();
session_start();
error_reporting (E_ALL ^ E_NOTICE);
include('includes/top_header.php');
$tempProductDAO    = new ProductDAO();
$tempProductMainCatDAO = new ProductMainCategoryDAO();
$tempProductCatDAO = new ProductCatDAO();
$tempFinalorderDAO = new FinalorderDAO();
$tempMemberDAO     = new MemberDAO();
$tempBannerDAO      = new BannerDAO();
$tempArr           = array();
$productCart       = array();
$productId         = $_POST['proId'];
$productDeliveTime = $_POST['productDeliveTime'];
$memberId=$_SESSION['memberId'];
$tempOurbrandDAO = new OurbrandDAO();
$tempOurbrandResult = $tempOurbrandDAO->OurbrandList();
$tempMemberVO = $tempMemberDAO->getMemberDetails($memberId);
//print_r($tempMemberVO);
$memberName=$tempMemberVO->getFirstName();
$memberEmail=$tempMemberVO->getMemberEmail();
$memberAddress=$tempMemberVO->getMemberAddress1();
$memberPostalCode=$tempMemberVO->getMemberPostalCode();
$memberCity=$tempMemberVO->getMemberCounty();
$memberCountry=$tempMemberVO->getMemberCountry();
$totalProductAmt=$_POST['productAmount'];
$productName=$_POST['productName'];
$productAmount=$_POST['productAmount'];
$paymentMethod = $_POST['payment'];
if(isset($_SESSION['specailofferCart'])  && count($_SESSION['specailofferCart'])>0)
                                                 {
                                                         $shoppingCart     = $_SESSION['specailofferCart'];
                                                         $totalNetAmount   = 0.00;
                                                         $totalVatPrice    = 0.00;
                                                         $designCharges    = 0.00;
                                                         $ttllDsgnChrges   = 0.00;
                                                         //$productNumSets = "NA";
                                                         for($j=0;$j<count($shoppingCart);$j++)
                                                         {
                                                                 $productId                  = $shoppingCart[$j]['PID'];
                                                                 $productName                = $shoppingCart[$j]['PNAME'];
                                                                 $productImage                = $shoppingCart[$j]['PIMAGE'];
                                                                 $productFinish              = $shoppingCart[$j]['PFINISH'];
                                                                 $productPrintType           = $shoppingCart[$j]['PPRINTTYPE'];
                                                                 $productPaperType           = $shoppingCart[$j]['PPAPERTYPE'];
                                                                 $productDeliveryTime      = $shoppingCart[$j]['PDTIME'];
                                                                 $productNumSets             = $shoppingCart[$j]['PNOFSETS'];

                                                                 $productQty        = $shoppingCart[$j]['PQTY'];

                                                                 $productDesc       = $shoppingCart[$j]['PRODUCTDESCRIPTION'];

                                                                 $designCharges     = $shoppingCart[$j]['DESIGNCHARGES'];
                                                                 $ttllDsgnChrges   += $shoppingCart[$j]['DESIGNCHARGES'];

                                                                 $productPrice      = $shoppingCart[$j]['PPRICEWOUTVAT'];
                                                                 $totalNetAmount   += $shoppingCart[$j]['PPRICEWOUTVAT'];

                                                                 $prdcttprcewthvt   = $shoppingCart[$j]['PPRICEWITHVAT'];
                                                                 $totalAmount      += $shoppingCart[$j]['PPRICEWITHVAT'];
                                                                 $vatflag           = $shoppingCart[$j]['VATFLAG'];
                                                                 $totalVatAmt      += $shoppingCart[$j]['VATAMT'];

                                                                 $ttlPrice         =  $productPrice;
                                                                 $netTotal        += $ttlPrice;
                                                                 $ttlPrice         = number_format($ttlPrice, 2);

                                                                 if($vatflag=="Yes")
                                                                     $vatRate        = $shoppingCart[$j]['VATRATE'];

                                                                 //$vatAmount          = $totalAmount - $totalNetAmount;



                                                                 $totalPriceWithVat  = $netTotal+$totalVatAmt;

                                                                 $productNameWOsize  = explode("_", $productName);
                                                                 $productName = $productNameWOsize[0];
                                                                 $item_name = $productName;
                                                                 if(isset($productNameWOsize[1]) && $productNameWOsize[1]!="")
                                                                 {
                                                                              $productSize = $productNameWOsize[1];
                                                                 }
                                                                 else
                                                                 {
                                                                                             if(strstr($productName, "("))
                                                                                             {
                                                                                                 $ftbkt       = strpos($productName, "(");                                                    
                                                                                                 $ltbkt       = strpos($productName, ")");
                                                                                                 $ltbkt       = $ltbkt - $ftbkt;
                                                                                                 $productSize = substr($productName,$ftbkt+1,$ltbkt-1);                                                    
                                                                                                 $hidProductSize = substr($productName,$ftbkt,$ltbkt+1);
                                                                                                 $productName = str_replace($hidProductSize, " ", $productName);
                                                                                             }
                                                                                             else
                                                                                             {
                                                                                                 $productSize = $productName;
                                                                                             }

                                                                 }

                                                                        
                                                             $netTotal    = number_format($totalNetAmount, 2);
                                                            $totalVatAmt = number_format($totalVatAmt, 2);
                                                            $totalPriceWithVat = number_format($totalPriceWithVat, 2);
                                                         }
                                                 }


if(isset($_POST['PayNow']) && $_POST['PayNow']=='Proceed to pay') 
{
   $paymentMethod = $_POST['payment'];
         if($paymentMethod=="Card Payment")
                {
                
                //header('location: paynow.php');
                //exit();
                        $totalAmountWithVat=$product_amount;
                        $finalPrice = $totalAmountWithVat+($totalAmountWithVat*3)/100;
                        $item_amount = number_format($finalPrice, 2, '.', '');
                        $orderId =  $tempFinalorderDAO->addFinalOrder($memberId, $memberName, $memberEmail, $shoppingCart, $paymentMethod, $cartInsertId, $item_name);
                        $custom = $orderId;
                        $paypal_email = "sales@utharaprint.com";
                        $return_url   = "https://utharaprint-london.co.uk/payment-success.php?cusId=".$orderId;
                        $cancel_url   = "https://utharaprint-london.co.uk/payment-unsuccess.php?cusId=".$orderId;
                        $notify_url   = "https://utharaprint-london.co.uk/payment-process.php";
                        // Check if paypal request or response
                   
				$instId="1255565";
                                $cartId="10";
                                $accId1="10";
                                $amount=$item_amount;
                                $currency="GBP";
                                $authMode="A";
                                $testMode="0";
                                $desc=$item_name;
                                $name=$memberName;
                                $address1=$memberAddress;
                                $town    =$memberCity;
                                $postcode=$memberPostalCode;
                                $country ="UK";
                        //$url = "https://secure-test.worldpay.com/wcc/purchase?instId=123456&cartId=WorldPay+Test
//&amount=40.00&currency=GBP&desc=WorldPay+Test&testMode=100";
                        if(!isset($_POST["txn_id"]) && !isset($_POST["txn_type"]))
                        {	
                                $querystring .= "?instId=".$instId."&";								
                                $querystring .= "cartId=".$cartId."&";
                                $querystring .= "accId1=".$accId1."&";
                                $querystring .= "Amount=".$amount."&";
                                $querystring .= "currency=".$currency."&";
                                $querystring .= "authMode=".$authMode."&";
                                $querystring .= "testMode=".$testMode."&";
                                $querystring .= "desc=".$desc."&";
                                $querystring .= "name=".$name."&";
                                $querystring .= "address1=".$address1."&";
                                $querystring .= "town=".$town."&";
                                $querystring .= "postcode=".$postcode."&";
                                $querystring .= "country=".$country;
                                //echo $querystring;die();
                                header('location: https://secure.worldpay.com/wcc/purchase'.$querystring);
                                exit();		
                         
                         }		
                        }  
                        
        if($paymentMethod=="Paypal")
        {
                $totalAmountWithVat=$product_amount;
                $finalPrice = $totalAmountWithVat+($totalAmountWithVat*3.5)/100;
		$item_amount = number_format($finalPrice, 2, '.', '');
                $orderId =  $tempFinalorderDAO->addFinalOrder($memberId, $memberName, $memberEmail, $shoppingCart, $paymentMethod, $cartInsertId, $item_name);
                $custom = $orderId;
                $paypal_email = "sales@utharaprint.com";
                $return_url   = "https://utharaprint-london.co.uk/payment-success.php?cusId=".$orderId;
                $cancel_url   = "https://utharaprint-london.co.uk/payment-unsuccess.php?cusId=".$orderId;
                $notify_url   = "https://utharaprint-london.co.uk/payment-process.php";
                // Check if paypal request or response
                if(!isset($_POST["txn_id"]) && !isset($_POST["txn_type"]))
                {	
                        $querystring .= "?business=".urlencode($paypal_email)."&";								
                        $querystring .= "item_name=".urlencode($item_name)."&";
                        $querystring .= "amount=".urlencode($item_amount)."&";
                        $querystring .= "cmd=_xclick&lc=UK&currency_code=GBP&first_name=".$firstName."&last_name=".$lastName."&payer_email=".$memberEmail."&item_number=".$orderId."&";
                        $querystring .= "notify_url=".urlencode($notify_url)."&";
                        $querystring .= "cancel_return=".urlencode($cancel_url)."&";
                        $querystring .= "custom=".urlencode($custom)."&";
                        $querystring .= "return=".urlencode($return_url);
                        header('location: https://www.paypal.com/cgi-bin/webscr'.$querystring);
                        exit();					
                }
       }
       if($paymentMethod=="Bank Transfer")
       {
          // echo "hi";die();
           $orderId =  $tempFinalorderDAO->addFinalOrder($memberId, $memberName, $memberEmail, $shoppingCart, $paymentMethod, $cartInsertId, $item_name);
           $custom = $orderId;
           //die();
           header("Location:bank-transfer.php?ordId=$orderId");
           exit();
       }
       if($paymentMethod=="paybyphone")
       {
          // echo "hi";die();
           $orderId =  $tempFinalorderDAO->addFinalOrder($memberId, $memberName, $memberEmail, $shoppingCart, $paymentMethod, $cartInsertId, $item_name);
           $custom = $orderId;
           //die();
           header("Location:paybyphone.php?ordId=$orderId");
           exit();
       }
   }
   
        
   
   
   
  
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width; initial-scale=1.0; maximum-scale=1.0">
    <!--css-->
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/responsive.css">
    
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
   	<script type="text/javascript" src="js/jquery.min.js"></script>
    <script type="text/javascript" src="js/function.js"></script>

    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <script lang="javascript">
    function submitPaymentForm()
    {
        //alert('hiii');
        document.getElementById('paypalform').submit();
    }
    </script>
  <!-- <script lang="javascript">
       function validatePayment()
        {
           
           if(document.getElementById('terms').checked == true){
               
            }
            else
            {
            alert('Please select Terms & conditions');
            return false;
            }

          var category = document.getElementsByName("payment");
          var check1 = 0;
          var a=(category.length);
          if(category[0].checked){
        
          return true;
          }
          if(category[1].checked){
           
          return true;
          }
          if(category[2].checked){
             
          return true;
          }
           var i;
          for(i=0;i<a;i++){
            if(category[i].checked){
              check1++;
              break;
            }
            
          if(check1)
          {
              return true;
          }
          else
          {
              alert('Please select payment Method!');
              return false;
          }
         
           
        }
        }
        
  </script>-->
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css" >
	<link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
   
	<style>
	
		* { -webkit-box-sizing: border-box; -moz-box-sizing: border-box; box-sizing: border-box; }
*:before, *:after { -webkit-box-sizing: inherit; -moz-box-sizing: inherit; box-sizing: inherit; }


	</style>
         <title>Uthara Print - London</title>
</head>

<body>

    <body><div class="mainCon">
         <?php include 'header.php'; ?>
                
    <div class="lineheight" ></div><div class="lineheight" ></div>
			
			<p style="margin-left:80px;font-family: Montserrat;">Payment Option</p>                    
            <p style="font-weight: 600; color: #294b8a; font-size: 22px; font-family: Montserrat; margin-left:80px;">Select Your Payment Mode</p>
			
   		  	<div class="content">
				
				<div class="container-sm ">
			
			<!--	<div class="productContainet">
               
                  <div class="productBox transition">
					
							
			<div class="productContainet">
				
				<?php
                                $bid = 16;
                                $tempBannerVO = $tempBannerDAO->getBannerDetails($bid);
                                $bannerName16=$tempBannerVO->getBannerName();
                                $bannerImage16=$tempBannerVO->getImage();
                                echo "<div class='disable'>
                                        <div class='productBox transition'>
                                        <div class='productImage' style='height: auto; margin-top: -16px'>
                                         <img src='upload/banner/$bannerImage16' alt='$bannerName16' />
                                        </div>
                                        </div>
                                        </div>";
                                ?>
				<?php
                                $bid = 17;
                                $tempBannerVO = $tempBannerDAO->getBannerDetails($bid);
                                $bannerName17=$tempBannerVO->getBannerName();
                                $bannerImage17=$tempBannerVO->getImage();
                                echo "<div class='productBox transition'>
                                        <div class='productImage' style='height: auto;'>
                                         <img src='upload/banner/$bannerImage17' alt='$bannerName17' />
                                        </div>
                                        </div>";
                                ?>
                            <?php
                                $bid = 18;
                                $tempBannerVO = $tempBannerDAO->getBannerDetails($bid);
                                $bannerName18=$tempBannerVO->getBannerName();
                                $bannerImage18=$tempBannerVO->getImage();
                                echo "<div class='disable'>
                                        <div class='productBox transition'>
                                        <div class='productImage' style='height: auto; margin-top: -16px'>
                                         <img src='upload/banner/$bannerImage18' alt='$bannerName18' />
                                        </div>
                                        </div>
                                        </div>";
                                ?>
				
			</div>
                  </div>
					
                </div>-->
		
			<br/>
			<div class="row" style="  border: 1px solid #999; border-radius:10px; padding:1%; margin-bottom:1em;" id="#">
					<div id="PaymentOrderNo">
					    <h4>Order No.</h4>
					    <p><?php echo "UPLND#".$orderId;?></p>
					</div>
					<div id="PaymentProduct">
					    <h4>Product:</h4>
						<?php 
					if(isset($_SESSION['specailofferCart'])  && count($_SESSION['specailofferCart'])>0)
                                                 {
                                                         $shoppingCart     = $_SESSION['specailofferCart'];
                                                         $totalNetAmount   = 0.00;
                                                         $totalVatPrice    = 0.00;
                                                         $designCharges    = 0.00;
                                                         $ttllDsgnChrges   = 0.00;
                                                         //$productNumSets = "NA";
                                                         for($j=0;$j<count($shoppingCart);$j++)
                                                         {
                                                                 $productId                  = $shoppingCart[$j]['PID'];
                                                                 $productName                = $shoppingCart[$j]['PNAME'];
                                                                 $productImage                = $shoppingCart[$j]['PIMAGE'];
                                                                 $productFinish              = $shoppingCart[$j]['PFINISH'];
                                                                 $productPrintType           = $shoppingCart[$j]['PPRINTTYPE'];
                                                                 $productPaperType           = $shoppingCart[$j]['PPAPERTYPE'];
                                                                 $productDeliveryTime      = $shoppingCart[$j]['PDTIME'];
                                                                 $productNumSets             = $shoppingCart[$j]['PNOFSETS'];

                                                                 $productQty        = $shoppingCart[$j]['PQTY'];

                                                                 $productDesc       = $shoppingCart[$j]['PRODUCTDESCRIPTION'];

                                                                 $designCharges     = $shoppingCart[$j]['DESIGNCHARGES'];
                                                                 $ttllDsgnChrges   += $shoppingCart[$j]['DESIGNCHARGES'];

                                                                 $productPrice      = $shoppingCart[$j]['PPRICEWOUTVAT'];
                                                                 $totalNetAmount   += $shoppingCart[$j]['PPRICEWOUTVAT'];

                                                                 $prdcttprcewthvt   = $shoppingCart[$j]['PPRICEWITHVAT'];
                                                                 $totalAmount      += $shoppingCart[$j]['PPRICEWITHVAT'];
                                                                 $vatflag           = $shoppingCart[$j]['VATFLAG'];
                                                                 $totalVatAmt      += $shoppingCart[$j]['VATAMT'];

                                                                 $ttlPrice         =  $productPrice;
                                                                 $netTotal        += $ttlPrice;
                                                                 $ttlPrice         = number_format($ttlPrice, 2);

                                                                 if($vatflag=="Yes")
                                                                     $vatRate        = $shoppingCart[$j]['VATRATE'];

                                                                 //$vatAmount          = $totalAmount - $totalNetAmount;



                                                                 //$totalPriceWithVat  = $netTotal+$totalVatAmt;

                                                                 $productNameWOsize  = explode("_", $productName);
                                                                 $productName = $productNameWOsize[0];
                                                                 $item_name = $productName;
                                                                 if(isset($productNameWOsize[1]) && $productNameWOsize[1]!="")
                                                                 {
                                                                              $productSize = $productNameWOsize[1];
                                                                 }
                                                                 else
                                                                 {
                                                                                             if(strstr($productName, "("))
                                                                                             {
                                                                                                 $ftbkt       = strpos($productName, "(");                                                    
                                                                                                 $ltbkt       = strpos($productName, ")");
                                                                                                 $ltbkt       = $ltbkt - $ftbkt;
                                                                                                 $productSize = substr($productName,$ftbkt+1,$ltbkt-1);                                                    
                                                                                                 $hidProductSize = substr($productName,$ftbkt,$ltbkt+1);
                                                                                                 $productName = str_replace($hidProductSize, " ", $productName);
                                                                                             }
                                                                                             else
                                                                                             {
                                                                                                 $productSize = $productName;
                                                                                             }

                                                                 }
																 echo "<p>$productName</p>";
														 }
												 }
						?>
					    
					</div>
					<div id="PaymentTotel">
					    <h4>Total Amount:</h4>
					    <p>&pound;<?php echo $totalPriceWithVat; ?></p>
					</div>
					<div style="clear:both"></div>    
					</div>    
					
					<div class="row" style="  border: 1px solid #999; border-radius:10px;" id="paymentproceed">
					    
			<div style="width: 100%"><h3 style="float: left;padding-left: 20px;padding-top: 0px;width: 30%;"><strong><font style="font-family: 'Montserrat'"></font></strong></h3></div>
						
<div class="tab1">
  <button class="tablinks active" onclick="openCity(event, 'London')" ><img src="images/pay-by-phone.png" alt="" style="margin-left:7px"/></button>
 <button class="tablinks" onclick="openCity(event, 'Paris')"> <img src="images/pay-pal.png" alt="" style="margin-left:16px"/></button>
  <button class="tablinks" onclick="openCity(event, 'Tokyo')" ><img src="images/Bank-transfer.png" alt=""/></button>
<p style="color: #336699; font-family: Montserrat; font-size:26px; float:right; padding-right:10px; font-weight:600;"><span style="font-size:20px"> Total Amount </span>
&pound;<?php echo $totalPriceWithVat; ?></p>
		
	
</div>
	

<div id="London" class="tabcontents"  style="font-family: 'Montserrat', sans-serif;padding-left:20px;padding-right:20px">

				

	<br/><br/>
<img src="images/pay-by-phone.png" alt="">
 
<p style="padding-left:20px; text-align:justify; font-family: Montserrat;">At Uthara Print, we accept card payments over the phone using the latest technology. A member of our accounts team will call you. Should you wish to make a call then the phone 
number to call and make a payment is</p>

<h2 align="center"><strong><span style="color:#253b80"><font style="font-family: 'Montserrat'"  font-weight="600"> 020 3239 9280 </font> </span>  <span style="color:#169bd7"> 
<font style="font-family: 'Montserrat'">  </font></span></strong></h2>

<p style="padding-left:20px; text-align:justify; font-family: Montserrat;">
We accept the latest Visa, Mastercard debit and credit card, American express card payments, safe in the knowledge all our phone payment solutions are secured to the highest PCI DSS Level 1 standards.</p>

<p style="font-family: 'Montserrat'; font-size:14px; padding-left:20px;"> 
<span class="shophead" style="color: #333;display: flex; ">
    
<form method="post" action="specialoffers-payment-process.php">    
<input type="checkbox" value="terms" style="margin-right: 00px" name="terms" id="terms" checked/> 
<a href="https://utharaprint-london.co.uk/privacy-policy.php" target="blanck" style="">
Click here to accept terms and conditions</a> </span>
<input type="submit" name="paybyphone" value="Proceed to Next" class="btn btn-primary btn-lg" style="font-family: 'Roboto' sans-serif;margin: 20px;float: right;display: flex-end;"/>
</form>		
		
	
</div>

<form name='paypalform' id='paypalform' action="specialoffers-payment-process.php" method="post" > 
<div id="Paris" class="tabcontents" style="display:none;width:100%;padding-left:20px;">
    	
	<br/><br/>
  <img src="images/pay-pal.png" alt=""><br/>
 <p style="color: #336699; font-family: Montserrat; font-size:18px;padding:10px; font-weight:600;"> 3.5% Extra</p>
 <span class="shophead" style="color: #333;display: flex; "> <input type="checkbox" value="terms" style="margin-right: 10px" name="terms" id="terms" checked/> <a href="https://utharaprint-london.co.uk/privacy-policy.php" target="blanck" style="">Click here to accept terms and conditions</a> </span>
<br/><br/>
  
 <button class="btn btn-primary btn-lg" name='paypal' target="_blank" onclick='submitPaymentForm()' style="font-family: 'Roboto', sans-serif;">Pay Through Paypal</button>
  
  </form>
  

<div style="margin-left:600px;">
<p align="right">
<form method="post" action="specialoffers-payment-process.php">
<input type="submit" value="Proceed to Next" class="btn btn-primary btn-lg" style="font-family: 'Roboto' sans-serif;margin: 20px;"/>
</form></p>
</div>

</div>


<div id="Tokyo" class="tabcontents" style="display: none;font-family: 'Lato', sans-serif;">
    	

 	<label style="width: 100%"><img src="images/Bank-transfer.png" ></label>
 	 <table class="table-striped table-hover" style="width:100%">
						<tr class="" style="height: 35px;line-height: 30px; ">
							<td scope="row" style="padding-left: 20px;font-family: 'Montserrat', sans-serif; font-weight:600;">Name</td><td class="Product1">Bumboom Ltd trading as Uthara Print</td>
						</tr>
								
						<tr style="height: 35px;line-height: 30px; ">
							<td scope="row" style="padding-left: 20px;font-family: 'Montserrat', sans-serif; font-weight:600;">Bank Name</td><td class="Product1"> Barclays</td>
						</tr>
						<tr style="height: 35px;line-height: 30px; ">
							<td scope="row" style="padding-left: 20px;font-family: 'Montserrat', sans-serif; font-weight:600;">Account no.</td><td class="Product1">5380 5638</td>
						</tr>
						<tr style="height: 35px;line-height: 30px; ">
							<td scope="row" style="padding-left: 20px;font-family: 'Montserrat', sans-serif; font-weight:600;">Sort Code</td><td class="Product1">20-11-43</td>
						</tr>		
						<br/>
							</table>


<p style="font-family: 'Montserrat', sans-serif;">You have choosen "bank transfer/prepayment" as the payment method for your order.Please transfer the invoice amount to our bank account (bank details given above). The job will be printed and despatched as soon as the payment is received. Please choose immediate bank transfer and always use your order number as reference while making the payment. Do inform us by email when you have made the payment by the bank transfer to expedite the process. Please be aware that bank transfers can sometimes take up to a couple of working days to be registered within our bank account if you have not choosen to transfer the payment immediately.</p>
<br/>


<form method="post" action="specialoffers-payment-process.php">
<span class="shophead" style="color: #333;display: flex;"> <input type="checkbox" value="terms" style="margin-left: 00px;" name="terms" id="terms" checked/> <a href="https://utharaprint-london.co.uk/privacy-policy.php" target="blanck" style="">Click here to accept terms and conditions</a> </span>
<input type="submit" name="bankpayment" value="Proceed to Next" class="btn btn-primary btn-lg" style="font-family: 'Roboto' sans-serif;margin: 20px;float: right;display: flex-end;"/>
 

</form>
 
	
</div>

<p style="font-family: 'Montserrat'; padding: 25px;padding-bottom: 10px; background-color:#fff; font-size:11px;" align="left">
   <i class="fa fa-thumbs-up" aria-hidden="true"></i> <b> Thank you very much for your order!
   We will contact you within the next working day and confirm a delivery time for your order. 
    A confirmation email has been sent to  <i class="fa fa-envelope" aria-hidden="true"></i> <a href="mailto:sales@utharaprint-london.co.uk">sales@utharaprint-london.co.uk</a><br/>
   <i class="fa fa-refresh" aria-hidden="true"></i> Please keep a regular check on your email to view the progress of your order and any order updates. All contact will be made via your online account.</b>
    </p>


	
<script>
		
		
function openCity(evt, cityName) {
  // Declare all variables
  var i, tabcontent, tablinks;

  // Get all elements with class="tabcontent" and hide them
  tabcontent = document.getElementsByClassName("tabcontents");
  for (i = 0; i < tabcontent.length; i++) {
    tabcontent[i].style.display = "none";
  }

  // Get all elements with class="tablinks" and remove the class "active"
  tablinks = document.getElementsByClassName("tablinks");
  for (i = 0; i < tablinks.length; i++) {
    tablinks[i].className = tablinks[i].className.replace(" active", "");
  }

  // Show the current tab, and add an "active" class to the link that opened the tab
  document.getElementById(cityName).style.display = "block";
  evt.currentTarget.className += " active";
}
		
		
		
		</script>
				
		</div>
	<div class="lineh"></div>
			<div class="lineh"></div>
	<!--	<div class="row" >
		
		<div class="col-lg-6" style=" border-image: linear-gradient(30deg, rgb(255,255,255), rgb(41,75,138) , rgb(255,255,255)) 1;border-left: 2px solid;border-bottom: 2px solid;padding: 20px;border-top: 2px solid;border-radius: 20px">
		<div class="col-lg-6"> <img src="images/img44.jpg" style="box-shadow: 0 2px 14px rgba(0, 0, 0, 0.18);padding: 10px"></div>	
		<div class="col-lg-6"> <p style="font-family: 'Roboto', sans-serif;text-align: center;padding-top: 15px;font-size: 14px;">
			
Action fraud is the UK's national fraud and cyber crime reporting center. We provide a central point of contact for information about fraud and cyber crime. The easiest way to report fraud and cyber crime is by using online reporting tool .</p></div>	
			
		</div>
		<div class="col-lg-6" style=" border-image: linear-gradient(330deg, rgb(255,255,255), rgb(41,75,138) , rgb(255,255,255)) 1;border-left: 2px solid;border-bottom: 2px solid;border-top: 2px solid;padding: 20px;border-radius: 20px">
		<div class="col-lg-6"> <img src="images/img4.jpg" style="box-shadow: 0 2px 14px rgba(0, 0, 0, 0.18);padding: 10px"></div>	
		<div class="col-lg-6"> <p style="font-family: 'Roboto', sans-serif;text-align: center;padding-top: 15px;font-size: 14px">
			
With the UK's largest cross-sector fraud sharing databases, Cifas is a not-for profit organisation working to reduce and prevent fraud financial crime in the UK. Identity protection. Individuals Nation Fraud Dtabse. Internal Fraud Database.</p></div>	
			
		</div>-->
	
			
			
	    </div>
					
			</div>
			</div>
		
        </div>
	
         <?php include 'footer.php'; ?>
		</div>
	
		</body>

</html>