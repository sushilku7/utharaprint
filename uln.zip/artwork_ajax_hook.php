<?php
//error_reporting (E_ALL ^ E_NOTICE);
include('includes/top_header.php');

$tempFinalorderDAO = new FinalorderDAO();
$valid_extensions = array('jpg','jpeg','gif','png','bmp','tiff','pdf','cdr','psd','ai'); // valid extensions
$path = 'upload/client-artworks/';
$artworkNum= $_POST['artworkNum'];
//print_r($_FILES['artworks1']['name']);
//print_r($_FILES['artworks']['tmp_name']);
$artworks="artworks".$artworkNum;
$total = count($_FILES[$artworks]["tmp_name"]);
$orderId= base64_decode($_POST['orderId']);
$memberId= $_POST['memberId'];

for($i = 0; $i<$total; $i++){
	
	$img = $_FILES[$artworks]["name"][$i];
	$tmp = $_FILES[$artworks]["tmp_name"][$i];
	$errorimg = $_FILES[$artworks]["error"][$i];
	$size = $_FILES[$artworks]["size"][$i];
	$bUnit = "Bytes";
	if($size>1024){
		$size = $size/1024;
		$bUnit = "KB";
	}
	//extract($POST);
	$artwokHead="artwokHead".$artworkNum;
	$artwokSubHead="artwokSubHead".$artworkNum;
	$companyName="companyName".$artworkNum;
	$addressOnArt1="addressOnArt1".$artworkNum;
	$addressOnArt2="addressOnArt2".$artworkNum;
	$webSocialMed="webSocialMed".$artworkNum;
	$contactNumber1="contactNumber1".$artworkNum;
	$contactNumber2="contactNumber2".$artworkNum;
	$emailId="emailId".$artworkNum;
	$otherInfo="otherInfo".$artworkNum;
	
	$artwokHead = $_POST[$artwokHead];
	$artwokSubHead = $_POST[$artwokSubHead];
	$companyName = $_POST[$companyName];
	$addressOnArt1 = $_POST[$addressOnArt1];
	$addressOnArt2 = $_POST[$addressOnArt2];
	$webSocialMed = $_POST[$webSocialMed];
	$contactNumber1 = $_POST[$contactNumber1];
	$contactNumber2 = $_POST[$contactNumber2];
	$emailId = $_POST[$emailId];
	$otherInfo = $_POST[$otherInfo];
	
	$ext = strtolower(pathinfo($img, PATHINFO_EXTENSION));
	// can upload same image using rand function
	$final_image = date("d-m-y_H-i-s").$img;
	// check's valid format
	if(in_array($ext, $valid_extensions)) 
	{
		$rowId = $tempFinalorderDAO->addArtwork($artwokHead,$artwokSubHead ,$companyName,$addressOnArt1,$addressOnArt2,$webSocialMed,$contactNumber1,$contactNumber2,$emailId,$otherInfo,$orderId,$memberId);
        // echo $rowId;die();
		$userFile_name = $img;
		$userFile_extn = substr($userFile_name, strpos($userFile_name, '.')+1);
		
		    //echo "hello";die();
			$currentDate= date('d-m-Y H:s:i');
			$alias=strtotime($currentDate);
			$final_image = $img;
			$destinawtion = "upload/client-artworks/".$final_image;
			if(move_uploaded_file($tmp,$destinawtion))
			{
				//update database;
				$colName="artworkDesign1";
	            $updateId=$tempFinalorderDAO->updateArtwork($rowId, $colName, $final_image);
			
		?>
        <div id="art-uploaded">
        <div id="art-uploaded-left">
               
               
               <ul id="afteruploadartwork" align="left">
               <!--<li>01</li>--> 
               <li><div style="display:inline"><?php echo $final_image; ?></div></li> 
               <br/>
               <li><div style="display:inline;">
            <img src="<?php echo $destinawtion; ?>" width="100%" height="auto" style="margin-top:3%; box-shadow: 0 2px 8px rgba(0, 0, 0, 0.6); border:2px solid #fff;"/></div></li> 
                <br/>
               
               
               </ul>
               <div style="clear:both"></div>
            </div>
           <!-- <div id="art-uploaded-right">
            <ul>       
            <li id="closeartwork"><i class="fa fa-times" aria-hidden="true" style="font-size:35px"></i></li>
            </ul>
            
            </div>-->
		<?php
	}
	} 
	else 
	{
		?>
        <div id="#">
        	<?php echo '<center><strong>Invalid: Please Select File From "Add Your Artwork Files" then Click On Upload Artwork</strong></center>'; ?>
    	</div>
    	<?php
	}	
}

?>