<?php
ob_start();
session_start();
error_reporting (E_ALL ^ E_NOTICE);
include('includes/top_header.php');
$tempProductDAO     = new ProductDAO();
$tempProductCatDAO  = new ProductCatDAO();
$tempVatDAO         = new VatDAO();
$tempBannerDAO      = new BannerDAO();
$tempProductMainCatDAO = new ProductMainCategoryDAO();
$tempOurbrandDAO = new OurbrandDAO();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width; initial-scale=1.0; maximum-scale=1.0">
    <!--css-->
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/responsive.css">
    
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
   
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
    <!--css-->
	<style>
	
		* { -webkit-box-sizing: border-box; -moz-box-sizing: border-box; box-sizing: border-box; }
*:before, *:after { -webkit-box-sizing: inherit; -moz-box-sizing: inherit; box-sizing: inherit; }



#video-viewport{ position: relative; top:30px; left: 0; width: 100%; height: auto; overflow: hidden; z-index: -1; background-color: #000; }


.fullsize-video-bg { height: auto; }

.fullsize-video-bg:before { content: "";  position: absolute; top:30px; left: 0; width: 100%; height: auto; z-index: 0; }
.fullsize-video-bg:after { content: "";  background-size: 3px 3px; position: absolute; top:30px; left: 0; width: 100%; height: auto; z-index: 1; }

.center1{
	
			position:absolute;
	content:Became a Uthara Print Partner;
			top: 75%;left:47%;
			transform: translate(-50%, -50%);
		}
		
		input[type="button"]{
			position: relative;width: 300px;height: 60px;
			-webkit-appearance:none;
		background: linear-gradient(0deg, #333 , #000);
			outline: none;border-radius: 20px;
			box-shadow: 0 0 0 4px #353535, 0 0 0 5px #3e3e3e, inset 0 0 10px rgba(0,0,0,1), 0 5px 15px rgba(0,0,0,.5), inset 0 0 15px rgba(0,0,0,.2);
			content:'Became a Uthara Print Partner';color: #eee;
  text-shadow: 1px 1px 3px #fff;
	}
		.midiv{
			position:relative; top:40%;z-index: 1;color: #333;
		}
		
		
	</style>
</head>

<body>

    <body><div class="mainCon">
        <?php include 'header.php'; ?>
			
             <section class="fullsize-video-bg">
			<div id="video-viewport">
				<img src="images/Banner.jpg" alt=""/>
				<div class="center1">
	<a href="#"><input type="button" name="yes" value="Became a Uthara Print Partner"/></a>
	</div>
			
			</div> 
			</section>		   
			
		  	<div class="content">
				<div class="lineheight"></div>
			
			<div class="container-sm productOffers">
			<!--<h2 style="margin-bottom: 30px; font-family:Impact, Haettenschweiler, 'Franklin Gothic Bold', 'Arial Black', 'sans-serif' "><center> Login if you have an account or simply register to proceed</center></h2>-->
				<div class="productContainet">
               
                  
                    
                    <div class="productBox transition">
						<div class="productPrice"> <h4>Already having an existing design and print business? </h4></div>
                        <div class="productImage" style="height: auto; margin-top: 10px;">
					<p style="font-family: Baskerville, 'Palatino Linotype', Palatino, 'Century Schoolbook L', 'Times New Roman', 'serif'; color: #630103; font-size: 16px;padding: 10px;">
							
							It costs nothing to be our re-seller. Simply start trading with us now. It lets you get on with running your existing design, print or marketing business, whilst adding a great new concept of one stop solution for your existing business. Use our knowledge, information technology and production capabilities to sell full colour printing at much lower prices than all high street printers do. It’s a profitable proposition with the <strong>following benefits:</strong></p>
							
							<!--<div class="productPrice"> <h4>Special Offers for Partners </h4></div>-->
							<!--------------------------------->
				<div class="productContainet">
								<div class="productBox transition">
                        <div class="productImage" style="height: auto; margin-top: 10px;">
							<h4 style="color: #630103;">Special Offers for Partners </h4>
						<p style="font-family: Baskerville, 'Palatino Linotype', Palatino, 'Century Schoolbook L', 'Times New Roman', 'serif'; color: #630103; font-size: 16px;">
							Become our print business partner at Uthara Print Ltd and you can save even more money!. We will give you discount for every job booked and additional offer of stationery printed FREE once every quarter.
							
							<ul class="shophead" style="text-align: left">
							<li><strong> <i class="fa fa-handshake-o fa-lg" aria-hidden="true"></i> &nbsp;Bronze Business Partners</strong> trade &pound;5,000 a month and save £1200 per annum</li>
							<li><strong><i class="fa fa-handshake-o fa-lg" aria-hidden="true"></i> &nbsp;Silver Business Partners</strong>  trade &pound;10,000 a month and save £1800 per annum</li>
							<li><strong><i class="fa fa-handshake-o fa-lg" aria-hidden="true"></i> &nbsp;Gold Business Partners </strong>trade &pound;15,000 a month and save £2000 per annum</li>
							<li><strong><i class="fa fa-handshake-o fa-lg" aria-hidden="true"></i> &nbsp;Platinum Business Partners </strong>trade &pound;25,000 a month and save £2500 per annum</li>
							<br/>
							</ul></p>
									
							</div>
							</div>
							
						<div class="productBox transition">
						
							<div  style="height: auto; margin-top: 10px;">
							<img src="images/partner2.jpg" alt=""/>

							</div>

						</div>
							
				</div>
						<!--------------------------------------------->
						</div>
                       
                    </div>
					
                </div>
				<!----------------------->
				<div class="lineheight"></div>
				
				<div class="productContainet">
					<div class="productBox transition">
						<div class="productImage" style="padding-bottom: 15px;" >

                    <div  style="height: auto;">
					<img src="images/partner 1.jpg" alt=""/>
						 
							</div></div>
                       
                    </div>
					
               
                    <div class="productBox transition">
						 
                        
<div class="productImage" style="height: auto;">
	<h4 style="color: #292828">Dreaming to be an entrepreneur?</h4>
						<p style="font-family: Baskerville, 'Palatino Linotype', Palatino, 'Century Schoolbook L', 'Times New Roman', 'serif';  font-size: 15px;line-height: 20px;text-align: left;color: #292828">
							Start your own joint venture Uthara Print Ltd Territory Agency. It’s one of the most popular, highly rewarding business opportunities available in the industry. Start a joint venture Uthara Print Ltd agency and build a territory of your own. This is ideal for sales or marketing professionals, a joint venture Territory Agency will test your entrepreneurial skills. Find out more with us. Simply email us to sales@utharaprint.co.uk<br/>

<br/>
<i class="fa fa-check-circle" aria-hidden="true"></i> &nbsp;Initial Investment of £15000 to £25000.<br/>
<i class="fa fa-check-circle" aria-hidden="true"></i> &nbsp;Free full fledge ecommerce print website.<br/>
<i class="fa fa-check-circle" aria-hidden="true"></i> &nbsp;Free Business networking membership for one year.<br/>
<i class="fa fa-check-circle" aria-hidden="true"></i> &nbsp;Free laptop<br/>
<i class="fa fa-check-circle" aria-hidden="true"></i> &nbsp;Free business starter kit includes business cards, flyers and stationeries.<br/>
<i class="fa fa-check-circle" aria-hidden="true"></i> &nbsp;Full training and support for 3 months.<br/>
<i class="fa fa-check-circle" aria-hidden="true"></i> &nbsp;Prompt weekly or monthly credits.
							</p>
							<h4 style="color: #292828">Terms and Conditons within Pertnership </h4>
						<p style="font-family: Baskerville, 'Palatino Linotype', Palatino, 'Century Schoolbook L', 'Times New Roman', 'serif'; font-size: 15px;line-height: 20px;text-align: left;color: #292828">
							<i class="fa fa-check-circle" aria-hidden="true"></i> &nbsp;Discounted pricing<br/>
<i class="fa fa-check-circle" aria-hidden="true"></i> &nbsp;Dedicated account manager<br/>
<i class="fa fa-check-circle" aria-hidden="true"></i> &nbsp;Additional partner offers at specific times<br/>
<i class="fa fa-check-circle" aria-hidden="true"></i> &nbsp;Signed Agreement based over 12 fiscal months
							</p>
						</div>
                    </div>
					
					
                </div>
		<!------------------------------->
				
		<!----------------------------------->
			</div>
			
			
			<div class="visaCard">
            <img src="images/worldpay.jpg"/>
            <div style="display:flex-start;">
                <img src="images/visa.png">
                </div>
            </div>
        </div>
	
        <?php include 'footer.php'; ?>
		</div>
		<script type="text/javascript" src="js/jquery.min.js"></script>
    <script type="text/javascript" src="js/function.js"></script>

		</body>

</html>