<?php include "../include/config.php";
include $_conf_vars['BASEPATH']."include/functions.php";
include $_conf_vars['BASEPATH']."include/functions_db.php";

###############################################################
# Thumbnail Image Generator 1.24
###############################################################
# Visit http://www.zubrag.com/scripts/ for updates
############################################################### 

// REQUIREMENTS:
// PHP 4.0.6 and GD 2.0.1 or later
// May not work with GIFs if GD2 library installed on your server 
// does not support GIF functions in full

// Parameters:
// src - path to source image
// dest - path to thumb (where to save it)
// x - max width
// y - max height
// q - quality (applicable only to JPG, 1 to 100, 100 - best)
// t - thumb type. "-1" - same as source, 1 = GIF, 2 = JPG, 3 = PNG
// f - save to file (1) or output to browser (0).

// Sample usage: 
// 1. save thumb on server
// http://www.zubrag.com/thumb.php?src=test.jpg&dest=thumb.jpg&x=100&y=50
// 2. output thumb to browser
// http://www.zubrag.com/thumb.php?src=test.jpg&x=50&y=50&f=0


// Below are default values (if parameter is not passed)

// save to file (true) or output to browser (false)
$saveToFile = false;

// Quality for JPEG and PNG.
// 0 (worst quality, smaller file) to 100 (best quality, bigger file)
// Note: PNG quality is only supported starting PHP 5.1.2
$imageQuality = 100;

// resulting image type (1 = GIF, 2 = JPG, 3 = PNG)
// enter code of the image type if you want override it
// or set it to -1 to determine automatically
$imageType = -1;

// maximum thumb side size
//$max_x = 234;
//$max_y = 120;

// Folder where source images are stored (thumbnails will be generated from these images).
// MUST end with slash.
//$imagesFolder = '../uploadeImage/';

$imagesFolder = '../';
// Folder to save thumbnails, full path from the root folder, MUST end with slash.
// Only needed if you save generated thumbnails on the server.
// Sample for windows:     c:/wwwroot/thumbs/
// Sample for unix/linux:  /home/site.com/htdocs/thumbs/
//$thumbsFolder = '../uploadeImage/';

$thumbsFolder = '../';



///////////////////////////////////////////////////
/////////////// DO NOT EDIT BELOW
///////////////////////////////////////////////////

$toName = '';

if (isset($_REQUEST['f'])) {
  $saveToFile = intval($_REQUEST['f']) == 1;
}

if (isset($_REQUEST['src'])) {
  $fromName = "../".urldecode($_REQUEST['src']);
}
else
{
	$noImage = 0;
	$q = Requested_Var('q');
	if(!isEmpty($q))
	{
		$qstrArr  = explode("/", $q); #--100/100/press/imgName---
		list($width, $height, $fname) = $qstrArr;
		
		unset($qstrArr[0]); #Unset width
		unset($qstrArr[1]); #Unset Height
		$fname = implode("/", $qstrArr);
		
		$fromName = $_conf_vars['BASEPATH'].$_conf_vars['UPLOADS_DIR'].$fname;
		if(!is_file($fromName)) $noImage = 1;
	}
	else
	{
		$noImage = 1;
	}
	
	if($noImage == 1)
	{
		$fromName = $_conf_vars['BASEPATH'].$_conf_vars['IMAGES_DIR']."noimg.gif";
	}
	
}

$imageQuality = 100;

if (isset($_REQUEST['t'])) {
  $imageType = intval($_REQUEST['t']);
}

$max_x = isset($width) && !empty($width) ? $width : 100;

$max_y = isset($height) && !empty($height) ? $height : 100;

if (!file_exists($imagesFolder)) die('Images folder does not exist (update $imagesFolder in the script)');
if ($saveToFile && !file_exists($thumbsFolder)) die('Thumbnails folder does not exist (update $thumbsFolder in the script)');

// Allocate all necessary memory for the image.
// Special thanks to Alecos for providing the code.
ini_set('memory_limit', '-1');

function SaveImage($type, $im, $filename, $quality, $to_file = true) {

  $res = null;

  // ImageGIF is not included into some GD2 releases, so it might not work
  // output png if gifs are not supported
  if(!function_exists('imagegif')) $type = 3;

  switch ($type) {
    case 1:
      if ($to_file) {
        $res = ImageGIF($im,$filename);
      }
      else {
        header("Content-type: image/gif");
        $res = ImageGIF($im);
      }
      break;
    case 2:
      if ($to_file) {
        $res = ImageJPEG($im,$filename,$quality);
      }
      else {
        header("Content-type: image/jpeg");
        $res = ImageJPEG($im, NULL, $quality);
      }
      break;
    case 3:
      if (PHP_VERSION >= '5.1.2') {
        // Convert to PNG quality.
        // PNG quality: 0 (best quality, bigger file) to 9 (worst quality, smaller file)
        $quality = 9 - min( round($quality / 10), 9 );
        if ($to_file) {
          $res = ImagePNG($im, $filename, $quality);
        }
        else {
          header("Content-type: image/png");
          $res = ImagePNG($im, NULL, $quality);
        }
      }
      else {
        if ($to_file) {
          $res = ImagePNG($im, $filename);
        }
        else {
          header("Content-type: image/png");
          $res = ImagePNG($im);
        }
      }
      break;
  }

  return $res;

}

function ImageCreateFromType($type,$filename) {
 $im = null;
 switch ($type) {
   case 1:
     $im = ImageCreateFromGif($filename);
     break;
   case 2:
     $im = ImageCreateFromJpeg($filename);
     break;
   case 3:
     $im = ImageCreateFromPNG($filename);
     break;
  }
  return $im;
}

// generate thumb from image and save it
function GenerateThumbFile($fromName, $toName, $max_x, $max_y) {

  global $saveToFile, $imageType, $imageQuality;

  // if src is URL then download file first
  $temp = false;
  if (substr($fromName,0,7) == 'http://') {
    $tmpfname = tempnam("tmp/", "TmP-");
    $temp = @fopen($tmpfname, "w");
    if ($temp) {
      @fwrite($temp, @file_get_contents($fromName)) or die("Cannot download image");
      @fclose($temp);
      $fromName = $tmpfname;
    }
    else {
      die("Cannot create temp file");
    }
  }

  // get source image size (width/height/type)
  // orig_img_type 1 = GIF, 2 = JPG, 3 = PNG
  list($orig_x, $orig_y, $orig_img_type, $img_sizes) = @GetImageSize($fromName);

  // should we override thumb image type?
  $imageType = ($imageType != -1 ? $imageType : $orig_img_type);

  // check for allowed image types
  if ($orig_img_type < 1 or $orig_img_type > 3) die("Image type not supported");

  if ($orig_x > $max_x or $orig_y > $max_y) {

    // resize
    $per_x = $orig_x / $max_x;
    $per_y = $orig_y / $max_y;
    if ($per_y > $per_x) {
      $max_x = $orig_x / $per_y;
    }
    else {
      $max_y = $orig_y / $per_x;
    }

  }
  else {
    // keep original sizes, i.e. just copy
    if ($saveToFile) {
      @copy($fromName, $toName);
    }
    else {
      switch ($imageType) {
        case 1:
            header("Content-type: image/gif");
            readfile($fromName);
          break;
        case 2:
            header("Content-type: image/jpeg");
            readfile($fromName);
          break;
        case 3:
            header("Content-type: image/png");
            readfile($fromName);
          break;
      }
    }
    return;
  }

  if ($imageType == 1) {
    // should use this function for gifs (gifs are palette images)
    $ni = imagecreate($max_x, $max_y);
  }
  else {
    // Create a new true color image
    $ni = ImageCreateTrueColor($max_x,$max_y);
  }

  // Fill image with white background (255,255,255)
  $white = imagecolorallocate($ni, 255, 255, 255);
  imagefilledrectangle( $ni, 0, 0, $max_x, $max_y, $white);
  // Create a new image from source file
  $im = ImageCreateFromType($orig_img_type,$fromName); 
  // Copy the palette from one image to another
  imagepalettecopy($ni,$im);
  // Copy and resize part of an image with resampling
  imagecopyresampled(
    $ni, $im,             // destination, source
    0, 0, 0, 0,           // dstX, dstY, srcX, srcY
    $max_x, $max_y,       // dstW, dstH
    $orig_x, $orig_y);    // srcW, srcH

  // save thumb file
  SaveImage($imageType, $ni, $toName, $imageQuality, $saveToFile);

  if($temp) {
    unlink($tmpfname); // this removes the file
  }
}

// generate
GenerateThumbFile($fromName, $thumbsFolder. $toName, $max_x, $max_y);

?>