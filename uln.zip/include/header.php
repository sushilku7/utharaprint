<?php

$table	= prefix("mainpage_meta");
$slt	= "*";
$where	= "main_name='".$opt_main."'";
$record = Get_Records($table,$slt,$where);
$meta_title	= '';
$meta_keywords = '';
$meta_desc	= '';
if(count($record)>0)
{
		$meta_title  	= stripslashes($record[0]['main_title']);
		$meta_keywords  = stripslashes($record[0]['main_key']);
		$meta_desc  	= stripslashes($record[0]['main_disc']);
}
$smarty->assign('meta_title',$meta_title);
$smarty->assign('meta_keywords',$meta_keywords);
$smarty->assign('meta_desc',$meta_desc);
$smarty->assign('sitetitleStatic',getSingleValue("config","site_title","configID='1'"));

/*
//--ASSIGN ADDRESS VARIABLE
$address = Requested_Var("address");

$smarty->assign('address',$address);
//-------
//---Declaration of all variables of cat details----
$cat_arr = Declare_Variable(prefix("category"));
//-----
//--Fetach Parent Category and assign smarty variable
$cat_arr = Get_Records(prefix("category")." ca INNER JOIN ".prefix("alias")." al ON al.rec_id=ca.catID"," ca.catName,ca.catImage,al.alias,catID ","catStatus='1'  AND alias_table='category' order by ordering ");
if(count($cat_arr) > 0)
{
	$tt=0;
	foreach($cat_arr as $cat_key=>$cat_al)
	{
		if(file_exists($_conf_vars['BASEPATH']."upload/category/".$cat_al['catImage']))
		{
			$cat_arr[$tt]['catImage'] = $cat_al['catImage'];
		}
		$tt++;
	}
}

$smarty->assign('cat_arr',$cat_arr);
//--------------
*/


$pageArr = array("aboutus"=>"29","termscondition"=>"30","privacy"=>"31","boardadvisors"=>"32","thefilms"=>"33");
$table	= prefix("page");
$table2 = prefix("alias");
$slt	= "*";
$where	= " page.page_status='1' and alias.alias_table='page'";
$rsPage = Get_Records($table." as page INNER JOIN ".$table2." as alias ON page.page_id=alias.rec_id",$slt,$where);
if(count($rsPage)>0)
{
	foreach($rsPage as $key=>$val)
	{
		$page_title  	= stripslashes($val['page_title']);
		$page_alias		= $val['alias'];
		$page_id		= $val['page_id'];
		if(in_array($page_id,$pageArr))
		{
			$keyArr = array_search($page_id, $pageArr); 
			$smarty->assign($keyArr,'<a href="'.$_conf_vars['ROOT_URL'].$page_alias.$_conf_vars['FILE_EXTN'].'">'.$page_title.'</a>');
		}
	}
}


?>
