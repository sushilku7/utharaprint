<?php
$footerlink = '';
$pageArr	= Get_Records(prefix('page')." AS pg INNER JOIN ".prefix("alias")." AS al ON pg.page_id=al.rec_id ","al.alias AS page_alias, pg.page_title AS page_title","pg.menu_id= '2' and pg.page_status='1' and al.alias_table='page' ORDER BY pg.page_order ASC");
  if(count($pageArr) > 0)
  {
     foreach($pageArr as $memKey=>$memVal)
	 {
	   $footerlink .= '<li><a href="'.$_conf_vars['ROOT_URL'].$memVal['page_alias'].$_conf_vars['FILE_EXTN'].'">'.$memVal['page_title'].'</a></li>';
	   
	 }
  }
  $smarty -> assign("footerlink", $footerlink);
?>