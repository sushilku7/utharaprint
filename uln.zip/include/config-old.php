<?php // CONFIG FILE



if (isset($session_save_path)) session_save_path($session_save_path);

error_reporting(E_ERROR | E_WARNING | E_PARSE | E_NOTICE);

//ini_set('magic_quotes_gpc', 1);

//ini_set('session.use_trans_sid', 0);

//ini_set('memory_limit', '320M');





//echo "session_save_path - ".$session_save_path;

/*define("DB_HOST","localhost");

define("DB_USER","shobhan_nishant");

define("DB_PASSWORD","nishant");

define("DB_DATABASE","shobhan_waterfall");*/



if($_SERVER['HTTP_HOST'] == "localhost")
{
	//echo "";
	define("DB_HOST","212.67.215.82");
	define("DB_USER","utharauser");
	define("DB_PASSWORD","upuser@123#");
	define("DB_DATABASE","admin_utharaprint");
}

else
{
	define("DB_HOST","212.67.215.82");
	//define("DB_HOST","50.62.209.3:3306");
	define("DB_USER","utharauser");
	define("DB_PASSWORD","upuser@123#");
	define("DB_DATABASE","admin_utharaprint");
}





ob_start();

session_start();

// DB VARIABLES

$conf["PREFIX"]="tbl_";

class DB{

	var $cn;

	var $result;

	function DB(){

		$DbHost=DB_HOST;

		$DbUserName=DB_USER;

		$DbPassword=DB_PASSWORD;

		$DbName=DB_DATABASE;

		$this->cn=mysql_connect($DbHost,$DbUserName,$DbPassword);

		mysql_select_db($DbName,$this->cn) or Site_Error("Configuration");

	}

	function Limit($offset){mysql_data_seek($this->result,$offset) or die(display_error(mysql_error(), mysql_errno(), $sql));}

	function InsertId(){return mysql_insert_id($this->cn);}

	function Query($sql)

	{

		//\echo $sql."<br /><br />";

		$this->result=mysql_query($sql,$this->cn);

		//die();

	}

	function NumRow()

	{



		if(isset($this->result) && $this->result!="")

		return mysql_num_rows($this->result);

	}

	function getData(){ if($rs=mysql_fetch_array($this->result)) return($rs); else return(false); }

	function getObject(){ if($rs=mysql_fetch_object($this->result)) return($rs); else  return(false); }

	function getAssoc(){ if($rs=mysql_fetch_assoc($this->result)) return($rs); else  return(false); }

	function getResult($pos, $field){return mysql_result($this->result,$pos,$field);}

	function loadObjectList( $key='' ) {

		if(!($cur = $this->result)) return null;

		$array = array();

		while($row = mysql_fetch_object($cur)){

			if($key) $array[$row->$key] = $row;

			else $array[] = $row;

		}

		mysql_free_result( $cur );

		return $array;

	}

	function FreeResult(){if(isset($this->result) && $this->result!="") mysql_free_result($this->result);}

	function Close(){

		if($this->cn) mysql_close($this->cn);

	}

	function __destruct(){

		if($this->cn) mysql_close($this->cn);

	}

	function GetField($p){return mysql_fetch_field($this->result, $p);}

	function NumField(){return mysql_num_fields($this->result);}

}



function display_error($error, $error_num, $query){

	$query='';

	if($query) {// Safify query

		$query = preg_replace("/([0-9a-f]){32}/", "********************************", $query); // Hides all hashes

		$query_str = "$query";

	}

	echo '<font style="font-size: 11px; font-family: tahoma"><hr noshade color="#ECECEC"/>

		&nbsp;&nbsp;<font color="#FF0000"><strong>ERROR OCCURED: </strong></font> <strong>'.$error.'</strong></font>

		<hr noshade color="#ECECEC"/>';

	exit();

}



class XMLParser{

	private $xml;

	public function __construct($xmlString='default_xml_string'){

		if(!is_string($xmlString)){

			throw new Exception('Invalid XML string.');

		}

		// read XML string

		if(!$this->xml=simplexml_load_string($xmlString)){

			throw new Exception('Error reading XML string.');

		}

	}

	// fetch specific nodes according to node name

	public function fetchNodes($nodeName){

		if(!$nodeName){

			throw new Exception('Invalid node name.');

		}

		$nodes=array();

		foreach($this->xml as $node){

			$nodes[]=$node->$nodeName;

		}

		return $nodes;

	}

	// fetch all nodes as array of objects

	public function fetchNodesAsObjects(){

		$nodes=array();

		foreach($this->xml as $node){

			$nodes[]=$node;

		}

		return $nodes;

	}

	// count nodes of type $nodeName

	public function countNodes($nodeName){

		if(!$nodeName){

			throw new Exception('Invalid node name.');

		}

		$nodeCounter=0;

		foreach($this->xml as $node){

			$nodeCounter++;

		}

		return $nodeCounter;

	}

}



// DEFINE VARIABLES

$db=new DB();

global $db;



$sql="select * from ".$conf["PREFIX"]."config";

$result=$db->Query($sql);

$numrow=$db->NumRow($result);

if($numrow > 0){

	while($rs=$db->getData()){

		$conf["SITE_ROOT_DIR"]=$rs["root_dir"];

		$conf["ADMIN_ROOT_DIR"]="siteadmin/";

		$conf["SITE_URL"]=$rs["siteURL"];

		$conf["SITE_NAME"]=$rs["site_name"];

		$conf["SITE_TITLE"]=$rs["site_title"];

		$conf["META_KEYWORDS"]=$rs["meta_keywords"];

		$conf["META_DESC"]=$rs["meta_desc"];

		$conf["FORMAT_DATE"]=$rs["format_date"];

		$conf["FORMAT_TIME"]=$rs["format_time"];

		$conf["CURRENCY"]=$rs["currency"];

		$conf["ADMIN_NAME"]=$rs["admin_name"];

		$conf["ADMIN_EMAIL"]=$rs["admin_email"];

		$conf["MAIL_OPTION"]=$rs["mail_option"];

		$conf["API_KEY"]=$rs["google_api_key"];

		$conf["FILE_EXTN"]=$rs["file_extn"];

		$_SESSION["VAR_LOADED"]=1;

	}

}





$conf['PER_PAGE_RECORD'] = "20";

$conf['ROOT_URL'] = $conf["SITE_URL"].$conf["SITE_ROOT_DIR"];



$conf['ADMIN_URL'] = $conf["SITE_ROOT_DIR"].$conf["ADMIN_ROOT_DIR"];

$conf['INCLUDE_DIR'] = "include/";

$conf['BASEPATH'] = $_SERVER['DOCUMENT_ROOT'].$conf['SITE_ROOT_DIR'];

//$conf['BASEPATH'] = 'D:'.$conf['SITE_ROOT_DIR'];

$conf['TEMPLATES'] = "templates/";

$conf['UPLOADS_DIR'] = "upload/";

$conf['PICTURES'] = "pictures/";



$conf['IMAGES_DIR'] = "images/";

$conf['IMAGES_URL'] = $conf["SITE_ROOT_DIR"].$conf["IMAGES_DIR"];

$conf['NO_IMAGE'] = $conf['IMAGES_URL']."no-image.gif";



$conf['ADMIN_TEMPLATES'] = $conf['TEMPLATES'].$conf['ADMIN_ROOT_DIR'];



$conf['COUNTRY_CODE'] = 'US';



$conf['SIGN_UP'] = 'sign-up';

$conf['PROFILE'] = 'profile';

$conf['FILE_EXTN'] = '.html';

$conf['LOGIN'] = 'login';



$conf["PERPAGEITEM"] =3;

$conf["HOMEPERPAGEITEM"] =2;







//$conf["ADMINEMAIL"] ="rameshkumar@eyeforweb.com";

$conf["ADMINEMAIL"] ="anshu.porwal@ukdatahouse.com";





$conf['USERS_TYPE'] = array('ADMIN' => 'Admin', 'GENERAL'=>'General');

$conf['STATUS'] = array('1' => 'Active', '2' => 'Inactive');

$conf['CONTACTUS_SUBJECT'] = array('Business Development' => 'Business Development', 'General' => 'General','Site Feedback'=>'Site Feedback',

																	'Legal'=>'Legal','Report an Issue'=>'Report an Issue','Subscriptions'=>'Subscriptions');

$conf['GENDER'] = array('Male' => 'Male', 'Female' => 'Female');

$conf['POSTS_TYPE'] = array('Daily' => 'Daily', 'Weekly' => 'Weekly', 'Monthly' => 'Monthly');

$conf['MONTH_ARRAY'] = array (

1 => 'January',

2 => 'February',

3 => 'March',

4 => 'April',

5 => 'May',

6 => 'June',

7 => 'July',

8 => 'August',

9 => 'September',

10 => 'October',

11 => 'November',

12 => 'December'

);



$conf['ORDER_STATUS'] = array (

         'Active' => 'Active',

         'Cancelled' => 'Cancelled',

         'Delivered' => 'Delivered',

         'In Design' => 'In Design',

         'Not Active' => 'Not Active',

         'Printing' => 'Printing',

         'Artwork under quality check with Studio' => 'Artwork under quality check with Studio',

         'Artwork issue - no bleed and no crop mark' => 'Artwork issue - no bleed and no crop mark',

         'Artwork issue - Low resolution file' => 'Artwork issue - Low resolution file',

         'Artwork issue - Not correct size' => 'Artwork issue - Not correct size',

         'Artwork issue - completely incorrect' => 'Artwork issue - completely incorrect',

         'Artwork issue - reported to customer' => 'Artwork issue - reported to customer',

         'Artwork issue- sorted and waiting for customer approval' => 'Artwork issue- sorted and waiting for customer approval',

         'Artwork approved-waiting for payment confirmation' => 'Artwork approved-waiting for payment confirmation',

         'Artwork approved- Payment confirmed for artwork charge' => 'Artwork approved- Payment confirmed for artwork charge',

         'Despatched through courier' => 'Despatched through courier',

         'Delivered to customer' => 'Delivered to customer',

         'Customer did not recieve' => 'Customer did not recieve',

         'Refund request' => 'Refund request'

         );



         $conf['PAYMENT_STATUS'] = array (

         'Not Received' => 'Not Received',

     	 'Received' => 'Received'

        

     	 );     	      	 $conf['SPEAK_DESIGNER'] = array (         '1' => 'Yes',     	 '2' => 'No'     	 );     	      	 







     	 $conf['ADMIN_MODULES'] = $conf['BASEPATH'].$conf["ADMIN_ROOT_DIR"]."modules/";

     	 $conf['SITE_MODULE_DIR'] = $conf['BASEPATH']."modules/";

     	 $conf['CALENDAR_PATH']  		=  $conf["SITE_ROOT_DIR"]."calendar/";

     	 $_conf_vars = $conf;

     	 global $_conf_vars;



     	 $GENDDER =array();

     	 $GENDDER[0]="Male";

     	 $GENDDER[1]="Female";





