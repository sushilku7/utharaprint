<?php

$cur_page=1;
$rowpos=0;
$show = 10;//$_conf_vars['PERPAGERECORD_FRONTEND'];
//$show = 1;
if(isset($_REQUEST['p']) && trim($_REQUEST['p'])!="") $cur_page=trim($_REQUEST['p']);
$rowpos=$show*($cur_page-1);
	
class clsPaging{
	var $size, $cur_page, $rowpos, $show, $filename, $qstr,$productCatId;
	function clsPaging($size, $cur_page, $show, $filename, $querystring,$productCatId='')
	{
		$this->size=$size;
		$this->cur_page=$cur_page;
		$this->show=$show;
		$this->filename=$filename;
		$this->qstr=$querystring;
                if($productCatId!="")
                {
                $this->productCatId=$productCatId;
                }
	}
	
	function Navigator(){
		$k=0;
		$tot_page=0;
		$curpage=$this->cur_page;
		$show=$this->show;
		$size=$this->size;
                $productCatId=$this->productCatId;
		if($this -> qstr == "1")
			$this->filename .= "&amp;";
		else
			$this->filename .= "?";
		$page=1;
		$tot_rowpos=0;
		$page_show=10;
		$navigation="";
		$rowpos=0;
		$tot_page=ceil($size/$show);
		if($size>0 && $tot_page >= 1){//IF OF $total_records>0--------
			$rowpos=$show*($curpage-1);
			if(($curpage%$page_show)==1) $page=$curpage;
			elseif(($curpage%$page_show)>1) $page=($curpage-($curpage%$page_show))+1;
			elseif(($curpage%$page_show)==0) $page=$curpage-($page_show-1);
			$tot_rowpos=$rowpos+$show;
			if($tot_rowpos>$size) $tot_rowpos=$size;
			//if($tot_page > 1) $navigation.= "<strong>Page &nbsp;&nbsp;</strong>";
			if($tot_page >= $curpage && $curpage > 1){
				$prev=$curpage-1;
				$navigation.="<a href=\"".$this->filename."p=$prev\">Previous</a>";
			}
			$tot_page=($size-($size%$show))/$show;
			if(($size%$show)>0) $tot_page=$tot_page+1;
			$ctr=$page;
			for($pgno=$page; $pgno<=$tot_page; $pgno++)	{
				if($pgno==$curpage && $tot_page > 1) $navigation.= "<a href='#' class='selected'>".$pgno."</a>";
				elseif($tot_page > 1) $navigation.="<a href=\"".$this->filename."p=$pgno&productCatId=$productCatId\">$pgno</a>";
				$ctr++;
				if($ctr>=($page_show+$page)) break;
			}
			if($tot_page > $curpage){
				$next = $curpage + 1;
				 $navigation.="<a href=\"".$this->filename."p=".$next."\">Next</a>";
			}
		}//----END IF OF $total_records>0--------
		$arr=array();
		$arr['navigation']=$navigation;
		$arr['rowpos']=$rowpos;
		return $arr;
	}
}

class clsPaging_Site{
	var $size, $cur_page, $rowpos, $show, $filename, $qstr;
	function clsPaging_Site($size, $cur_page, $show, $filename, $querystring){
		$this->size=$size;
		$this->cur_page=$cur_page;
		$this->show=$show;
		$this->filename=$filename;
		$this->qstr=$querystring;
	}
	
	function Navigator(){
		$k = 0;
		$tot_page = 0;
		$curpage = $this -> cur_page;
		$show = $this -> show;
		$size = $this -> size;
		if(strpos($this -> filename, "?")) $this -> filename .= "&amp;";
		else $this->filename .= "?";
		$page = 1;
		$tot_rowpos = 0;
		$page_show = 5;
		$navigation = "";
		$rowpos = 0;
		$tot_page = ceil($size/$show);
		
		if($size > 0 && $tot_page > 1){//IF OF $total_records>0--------
			$rowpos=$show * ($curpage-1);
			if(($curpage%$page_show)==1) $page=$curpage;
			elseif(($curpage%$page_show)>1) $page=($curpage-($curpage%$page_show))+1;
			elseif(($curpage%$page_show)==0) $page=$curpage-($page_show-1);
			$tot_rowpos=$rowpos+$show;
			if($tot_rowpos>$size) $tot_rowpos=$size;
			if($tot_page > 1) $navigation.= '<div class="pagination"><ul>';
			if($tot_page >= $curpage && $curpage > 1){
				$prev=$curpage-1;
				$navigation.="<li><a class='prev' href=\"".$this->filename."p=$prev\">&laquo; Previous</a></li>";
			}
			$tot_page=($size-($size%$show))/$show;
			if(($size%$show)>0) $tot_page=$tot_page+1;
			$ctr=$page;
			for($pgno=$page; $pgno<=$tot_page; $pgno++)	{
				if($pgno==$curpage && $tot_page > 1) $navigation.= '<li><span ><a href="#" class="visited">'.$pgno.'</a></span></li>';
				elseif($tot_page > 1) $navigation.="<li><a href=\"".$this->filename."p=$pgno\">$pgno</a></li>";
				$ctr++;
				if($ctr>=($page_show+$page)) break;
			}
			if($tot_page > $curpage){
				$next = $curpage + 1;
				 $navigation.="<li><a  class='next' href=\"".$this->filename."p=".$next."\">Next &raquo;</a></li>";
			}
			$navigation .= "</ul></div>";
		}//----END IF OF $total_records>0--------
		$arr=array();
		$arr['navigation']=$navigation;
		$arr['rowpos']=$rowpos;
		return $arr;
	}
}

class clsPaging_New{
	var $size, $cur_page, $rowpos, $show, $filename, $qstr;
	function clsPaging_New($size, $cur_page, $show, $filename, $querystring){
		$this->size=$size;
		$this->cur_page=$cur_page;
		$this->show=$show;
		$this->filename=$filename;
		$this->qstr=$querystring;
	}
	
	function Navigator(){
		$k = 0;
		$tot_page = 0;
		$curpage = $this -> cur_page;
		$show = $this -> show;
		$size = $this -> size;
		//if($this -> qstr == "1") $this->filename .= "&amp;";
		//else $this->filename .= "?";
		$page = 1;
		$tot_rowpos = 0;
		$page_show = 5;
		$navigation = "";
		$rowpos = 0;
		$tot_page = ceil($size/$show);
		if($size > 0 && $tot_page > 1){//IF OF $total_records>0--------
			$rowpos=$show*($curpage-1);
			if(($curpage%$page_show)==1) $page=$curpage;
			elseif(($curpage%$page_show)>1) $page=($curpage-($curpage%$page_show))+1;
			elseif(($curpage%$page_show)==0) $page=$curpage-($page_show-1);
			$tot_rowpos=$rowpos+$show;
			if($tot_rowpos>$size) $tot_rowpos=$size;
			if($tot_page > 1) $navigation.= '<div class="pagination"><strong>';
			if($tot_page >= $curpage && $curpage > 1){
				$prev=$curpage-1;
				$navigation.="<a href=\"".$this->filename."\" onclick=\"document.frm.p.value = '".$prev."'; document.frm.submit(); return false;\" style=\"padding:0px 0px 0px 0px;\">&lt;&lt; Previous</a><span>|</span>";
			}
			$tot_page=($size-($size%$show))/$show;
			if(($size%$show)>0) $tot_page=$tot_page+1;
			$ctr=$page;
			$page_nos = '';
			for($pgno=$page; $pgno<=$tot_page; $pgno++)	{
				if(!isEmpty($page_nos))$page_nos .= '<span>|</span>';
				if($pgno==$curpage && $tot_page > 1) $page_nos .= $pgno;
				elseif($tot_page > 1) $page_nos .= "<a href=\"".$this->filename."\" onclick=\"document.frm.p.value = '".$pgno."'; document.frm.submit(); return false;\">$pgno</a>";
				$ctr++;
				if($ctr>=($page_show + $page)) break;
			}
			$navigation .= $page_nos;
			if($tot_page > $curpage){
				$next = $curpage + 1;
				 $navigation.="<span>|</span><a href=\"".$this->filename."\" onclick=\"document.frm.p.value = '".$next."'; document.frm.submit(); return false;\">Next &gt;&gt;</a>";
			}
			$navigation .= "</strong></div>";
		}//----END IF OF $total_records>0--------
		$arr=array();
		$arr['navigation']=$navigation;
		$arr['rowpos']=$rowpos;
		return $arr;
	}
}

class clsPaging_Hotel_Review{
	var $size, $cur_page, $rowpos, $show, $filename, $qstr;
	function clsPaging_Hotel_Review($size, $cur_page, $show, $filename, $querystring){
		$this->size=$size;
		$this->cur_page=$cur_page;
		$this->show=$show;
		$this->filename=$filename;
		$this->qstr=$querystring;
	}
	
	function Navigator(){
		$k = 0;
		$tot_page = 0;
		$curpage = $this -> cur_page;
		$show = $this -> show;
		$size = $this -> size;
		if($this -> qstr == "1") $this->filename .= "&amp;";
		else $this->filename .= "?";
		$page = 1;
		$tot_rowpos = 0;
		$page_show = 5;
		$navigation = "";
		$rowpos = 0;
		$tot_page = ceil($size/$show);
		if($size > 0 && $tot_page > 1){//IF OF $total_records>0--------
			$rowpos=$show*($curpage-1);
			if(($curpage%$page_show)==1) $page=$curpage;
			elseif(($curpage%$page_show)>1) $page=($curpage-($curpage%$page_show))+1;
			elseif(($curpage%$page_show)==0) $page=$curpage-($page_show-1);
			$tot_rowpos=$rowpos+$show;
			if($tot_rowpos>$size) $tot_rowpos=$size;
			if($tot_page > 1) $navigation.= '<div class="pagination"><strong>';
			if($tot_page >= $curpage && $curpage > 1){
				$prev=$curpage-1;
				$navigation.='<a href="'.$this->filename.'p='.$prev.'" style="padding:0px 0px 0px 0px;">&lt;&lt; Previous</a><span>|</span>';
			}
			$tot_page=($size-($size%$show))/$show;
			if(($size%$show)>0) $tot_page=$tot_page+1;
			$ctr=$page;
			$page_nos = '';
			for($pgno=$page; $pgno<=$tot_page; $pgno++)	{
				if(!isEmpty($page_nos))$page_nos .= '<span>|</span>';
				if($pgno==$curpage && $tot_page > 1) $page_nos .= $pgno;
				elseif($tot_page > 1) $page_nos .= "<a href=\"".$this->filename."p=".$pgno."\">$pgno</a>";
				$ctr++;
				if($ctr>=($page_show + $page)) break;
			}
			$navigation .= $page_nos;
			if($tot_page > $curpage){
				$next = $curpage + 1;
				 $navigation.="<span>|</span><a href=\"".$this->filename."p=".$next."\">Next &gt;&gt;</a>";
			}
			$navigation .= "</strong></div>";
		}//----END IF OF $total_records>0--------
		$arr=array();
		$arr['navigation']=$navigation;
		$arr['rowpos']=$rowpos;
		return $arr;
	}
}



	//		$paging = new clsPaging($tot_clt, $cur_page,$show, $_conf_vars['ADMIN_URL']."index.php?opt=client", 1);
	//		$navigator = $paging -> Navigator();
?>