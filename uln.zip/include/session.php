<?php
global $sess_member_id, $sess_reg_type, $sess_email, $sess_name, $sess_alias, $opt_main;

$sess_member_id	= "";

if(isset($_COOKIE['userID']) && $_COOKIE['userID'] !="" && !isset($_SESSION['memberId']))
{
	$totalRecod = Count_Record(prefix("member"),"memberId","memberId='".$_COOKIE['userID']."'");
	if(!isEmpty($totalRecod))
	{
		$_SESSION['memberId'] = $_COOKIE['userID'];
	}
}

if(isset($_SESSION['memberId']))
{
	$sess_member_id	= $_SESSION['memberId'];
}

$smarty->assign('sess_member_id',$sess_member_id);

?>