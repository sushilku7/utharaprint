<?php
$which_module = '';
//echo "opt_main - ".$opt_main;
if(!isEmpty($opt_main)) $which_module = Retrieve_Field(prefix("alias"), "alias_table", "alias = '".$opt_main."'"); //---IF MAIN-OPTION IS NOT EMPTY---
elseif(!isEmpty($opt_sub)) $which_module = Retrieve_Field(prefix("alias"), "alias_table", "alias = '".$opt_sub."'"); //---IF SUB-OPTION IS NOT EMPTY---

//echo "which_module - ".$which_module;
//echo "pp=".$which_module;
$smarty -> assign('which_module', $which_module);
if(is_file($_conf_vars['SITE_MODULE_DIR'].$which_module.".php")){
	if(sizeof($qstr_arr) > 2){
		$sub_option = StripSlash($qstr_arr[1]);
		$smarty -> assign('sub_option', $sub_option);
		$sub_action = StripSlash($qstr_arr[2]);
	}
	elseif(sizeof($qstr_arr) > 1) $sub_option = StripSlash($qstr_arr[1]);
	if(!isEmpty($which_module)) {
		include $_conf_vars['SITE_MODULE_DIR'].$which_module.".php";
		}
}
elseif(is_file($_conf_vars['BASEPATH']."templates/".$which_module.".tpl")){

	$smarty -> display($which_module.".tpl");
}
else{ 	
	$smarty -> display("no-files.tpl"); 
}
//echo "Module Name - ".$which_module;
?>
