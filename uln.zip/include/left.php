<?php

$mainCatOrder = "ORDER BY pMainCatId";
$mainCatCond = "pmc.productStatus='1' and  als.alias_table='tbl_productmaincategory'";
$tot_main_product_category = Count_Record(prefix("productmaincategory")." pmc INNER JOIN ".prefix("alias")." als ON als.rec_id=pmc.pMainCatId","pmc.pMainCatId",$mainCatCond );	
$leftProductMenu 	= "";
$bottomProductMenu      = "";

$sort_text = "ORDER BY mainIndex";
$cond=" parent='0' and flag='mainproduct' and catStatus='1' and alias_table='product_cat'";
$condForFeatureProduct=" flag!='freeproduct' and featureStatus='Yes' order by mainIndex";
//---- Start Product Category Listing In Left Bar -----
//$tot_product_category = Count_Record(prefix("product_cat")." pc INNER JOIN ".prefix("alias")." al ON al.rec_id=pc.productCatId","productCatId",$cond ); //----Total Product Category--		

if($tot_main_product_category > 0)
{			
			//----Retrieve The Records of Product Category-----
                        ///////////////////////////////////////////////////////
                        $product_cat_arr = Get_Records(prefix("productmaincategory")." pmc INNER JOIN ".prefix("alias")." als ON als.rec_id=pmc.pMainCatId"," pmc.*,als.alias ","$mainCatCond".$mainCatOrder." ");
		 	if(!empty($product_cat_arr))
		 	{				
				for($tt=0; $tt < sizeof($product_cat_arr); $tt++)
				{
					extract($product_cat_arr[$tt]);					
					$pmcid = $product_cat_arr[$tt]['pMainCatId'];
					$condForMainChild=" parentCat='$pmcid' and catStatus='1' and alias_table='product_cat'";
					$tot_sub_main_product_category = Count_Record(prefix("product_cat")." pc INNER JOIN ".prefix("alias")." al ON al.rec_id=pc.productCatId","productCatId",$condForMainChild ); //----Total Main Child Category--
					if(count($tot_sub_main_product_category)>0)
					{
						for($i=0;$i<count($tot_sub_main_product_category);$i++)
						{
							$sub_main_product_cat_arr = Get_Records(prefix("product_cat")." pc INNER JOIN ".prefix("alias")." al ON al.rec_id=pc.productCatId"," pc.catName, pc.productCatId, al.alias ","$condForMainChild".$sort_text." ");						
						
                                                }
						$product_cat_arr[$tt]['mainchild'] = $sub_main_product_cat_arr;
                                                
                                                for($c=0;$c<count($sub_main_product_cat_arr);$c++)
                                                {  
                                                    $pcid = $sub_main_product_cat_arr[$c]['productCatId'];
                                                    $condForSubChild = " parent='$pcid' and catStatus='1' and alias_table='product_cat'";
                                                    $tot_sub_product_category = Count_Record(prefix("product_cat")." pc INNER JOIN ".prefix("alias")." al ON al.rec_id=pc.productCatId","productCatId",$condForSubChild); //----Total Sub Child Category--
                                                    if(count($tot_sub_product_category)>0)
                                                    {
                                                        $sub_cat_product_cat_arr = Get_Records(prefix("product_cat")." pc INNER JOIN ".prefix("alias")." al ON al.rec_id=pc.productCatId"," pc.catName, pc.productCatId,al.alias ","$condForSubChild".$sort_text." ");
                                                    }
                                                    $product_cat_arr[$tt]['mainchild'][$c]['child'] = $sub_cat_product_cat_arr;
				                }
					        
                                                
                                                
                                       }					
				}
			}
                        
                        
                        
                        ///////////////////////////////////////////////////////////////////////
                        $product_subcat_arr = Get_Records(prefix("product_cat")." pc INNER JOIN ".prefix("alias")." al ON al.rec_id=pc.productCatId"," pc.*,al.alias ","$cond".$sort_text." ");
		 	if(!empty($product_subcat_arr))
		 	{
				//$sno = $i + 1;
				for($g=0; $g < sizeof($product_subcat_arr); $g++)
				{
					extract($product_subcat_arr[$g]);
					//$product_cat_arr[$tt]['sno'] = $sno;			
					//$sno++;
					$pid = $product_subcat_arr[$g]['productCatId'];
					$condForChild=" parent='$pid' and flag='mainproduct' and catStatus='1' and alias_table='product_cat'";
					$tot_sub_product_category = Count_Record(prefix("product_cat")." pc INNER JOIN ".prefix("alias")." al ON al.rec_id=pc.productCatId","productCatId",$condForChild ); //----Total Child Category--
					if(count($tot_sub_product_category)>0)
					{
						for($i=0;$i<count($tot_sub_product_category);$i++)
						{
							$sub_product_cat_arr = Get_Records(prefix("product_cat")." pc INNER JOIN ".prefix("alias")." al ON al.rec_id=pc.productCatId"," pc.*,al.alias ","$condForChild".$sort_text." ");						
						}
						$product_subcat_arr[$g]['child'] = $sub_product_cat_arr;
					}					
				}
			}	
                        
                        ///////////////////////////////////////////////////////////////////////
    
    
                        	
			
			$leftProductMenu .="<div id='smoothmenu2' class='ddsmoothmenu-v'>";		
			$leftProductMenu .="<ul>";
			for($j=0;$j<count($product_cat_arr);$j++)
			{
				$aliasName = $product_cat_arr[$j]['alias'];
				$catName   = $product_cat_arr[$j]['catName'];
                                $pcid      = $product_cat_arr[$j]['pMainCatId'];
                                
                                //Removing the last printing word from category name
                                $tempCatNameArr = explode(" ", $catName);                               
                                $lastWordPositionInCatName = count($tempCatNameArr)-1;
                                if($tempCatNameArr[$lastWordPositionInCatName]=="Printing")
                                    unset($tempCatNameArr[$lastWordPositionInCatName]);
                                $catName = implode(" ", $tempCatNameArr);
                                //End    
                                
				if($j%2==0)
					$leftProductMenu .="<li class='left-menu-first'>";
				else
					$leftProductMenu .="<li class='left-menu-second'>";
				
				$mainChildArr = $product_cat_arr[$j]['mainchild'];
                                
				$leftProductMenu .="<a href='#'>$catName</a>";
                                $leftProductMenu .="<ul>";
                                for($k=0;$k<count($mainChildArr);$k++)
                                {  
                                    $subAliasName = $mainChildArr[$k]['alias'];
		       		    $subMainCatName = $mainChildArr[$k]['catName'];
                                    $childMainProductId = $mainChildArr[$k]['productCatId'];
                                    
                                    $tempSubCatNameArr = explode(" ", $subMainCatName);                               
                                    $lastWordPositionInSubCatName = count($tempSubCatNameArr)-1;
                                    if($tempSubCatNameArr[$lastWordPositionInSubCatName]=="Printing")
                                            unset($tempSubCatNameArr[$lastWordPositionInSubCatName]);
                                    $subMainCatName = implode(" ", $tempSubCatNameArr);
                                               
                                    $tmpSubCatArr = explode("(", $subMainCatName);
                                    $tempSubCatName = $tmpSubCatArr[0];                                                
                                                //echo $subCatName;
                                    $tmpSSubCatArr = explode("_", $tempSubCatName);
                                    $tempSubCatName = $tmpSSubCatArr[0];
                                    
                                    if($k%2==0)
						$leftProductMenu .="<li class='left-menu-first'>";
                                    else
						$leftProductMenu .="<li class='left-menu-second'>";
                                    
                                    //$leftProductMenu .="<a href='$_conf_vars[SITE_ROOT_DIR]$subAliasName$_conf_vars[FILE_EXTN]'>$tempSubCatName</a></li>";
                                    
                                    $leftProductMenu .="<a href='$_conf_vars[SITE_ROOT_DIR]$subAliasName$_conf_vars[FILE_EXTN]'>$tempSubCatName</a>";
                                    $leftProductMenu .="<ul>";
                                    $subChildArr = $mainChildArr[$k]['child'];
                                    for($f=0;$f<count($subChildArr);$f++)
                                    {
                                                                $childSubAliasName = $subChildArr[$f]['alias'];
                                                                $childSubMainCatName = $subChildArr[$f]['catName'];
                                                                $childSubMainProductId = $subChildArr[$f]['productCatId'];
                                                                //Removing the last printing word from sub category name
                                                                $tempSubCatNameArr1 = explode(" ", $childSubMainCatName);                               
                                                                $lastWordPositionInSubCatName1 = count($tempSubCatNameArr1)-1;
                                                                if($tempSubCatNameArr1[$lastWordPositionInSubCatName1]=="Printing")
                                                                    unset($tempSubCatNameArr1[$lastWordPositionInSubCatName1]);
                                                                $childSubMainCatName = implode(" ", $tempSubCatNameArr1);
                                                                
                                                                $tmpSubCatArr1 = explode("(", $childSubMainCatName);
                                                                $childSubMainCatName = $tmpSubCatArr1[0];

                                                                
                                                                $tmpSubCatArr1 = explode("_", $childSubMainCatName);
                                                                $childSubMainCatName = $tmpSubCatArr1[0];

                                                                if($f%2==0)
                                                                           $leftProductMenu .="<li class='left-menu-first'>";
                                                                else
                                                                           $leftProductMenu .="<li class='left-menu-second'>";
                                                               $leftProductMenu .="<a href='$_conf_vars[SITE_ROOT_DIR]$childSubAliasName$_conf_vars[FILE_EXTN]'>$childSubMainCatName</a></li>";
                                    }
                                    $leftProductMenu .="</ul>";
                                    $leftProductMenu .="</li>";
                                    
                                }
                                $leftProductMenu .="</ul>";
                                $leftProductMenu .="</li>";
                        
                        }
                        
                       
			if($j%2==0)
					$leftProductMenu .="<li class='left-menu-first'>";
				else
					$leftProductMenu .="<li class='left-menu-second'>";
			$leftProductMenu .="<a href='http://utharaphotos.co.uk' target='_blank'>Photo Print</a></li>";	
			
			$leftProductMenu .="</ul>";				
			$leftProductMenu .="</div>";	
			
			
                        
                        
			//Display Product Category Listing
			$bottomProductMenu .="<ul>";
			for($j=0;$j<=27;$j++)
			{
				$aliasName = $product_subcat_arr[$j]['alias'];
				$catName = $product_subcat_arr[$j]['catName'];
                                
                                //Removing the last printing word from category name
                                $tempCatNameArr = explode(" ", $catName);                               
                                $lastWordPositionInCatName = count($tempCatNameArr)-1;
                                if($tempCatNameArr[$lastWordPositionInCatName]=="Printing")
                                    unset($tempCatNameArr[$lastWordPositionInCatName]);
                                $catName = implode(" ", $tempCatNameArr);
                                
				$bottomProductMenu .="<li>";							
				$bottomProductMenu .="<a href='$_conf_vars[SITE_ROOT_DIR]$aliasName$_conf_vars[FILE_EXTN]'>$catName</a>";
				$bottomProductMenu .="</li>";
				if($j%7==0 && $j!=0)
				{                                        
					$bottomProductMenu .="</ul><ul>";
                                        
				}                                
			}
			
			$bottomProductMenu .= "<li><a href='$_conf_vars[SITE_ROOT_DIR]unsubscribe-user$_conf_vars[FILE_EXTN]'>Unsubscribe</a></li>";
			$bottomProductMenu .= "<li><a href='$_conf_vars[SITE_ROOT_DIR]sitemap$_conf_vars[FILE_EXTN]'>Sitemap</a></li>";
			$bottomProductMenu .="</ul>";	 
			
			
			
			
}
else 
{
	$leftProductMenu ="<ul id='nav'><li>No Product Found</li></ul>";
}

$tot_feature_product = Count_Record(prefix("product_cat")." AS pc ","productCatId",$condForFeatureProduct ); //----Total Feature Product --		

$FeatureProductList  = "";
if($tot_feature_product > 0)
{			
			//----Retrieve The Records of Product Category-----
			$feature_product_arr = Get_Records("tbl_product_cat AS pc INNER JOIN tbl_alias AS al ON al.rec_id=pc.productCatId"," pc.catName, pc.anotherImagePath, pc.productCatDesc, al.alias  ", "$condForFeatureProduct");
			
		 	for($x=0;$x<count($feature_product_arr);$x++)
			{
				$aliasName1  = $feature_product_arr[$x]['alias'];
				$catName1    = $feature_product_arr[$x]['catName'];
				$imageName1  = $feature_product_arr[$x]['anotherImagePath'];
				$desc1       = $feature_product_arr[$x]['productCatDesc'];
				
				$FeatureProductList .="<div class='home-box'>";
				$FeatureProductList .="<a href='$_conf_vars[SITE_ROOT_DIR]$aliasName1$_conf_vars[FILE_EXTN]'><h1>$catName1</h1></a>";
				$FeatureProductList .="<div class='cat-image'>";
				$FeatureProductList .="<a href='$_conf_vars[SITE_ROOT_DIR]$aliasName1$_conf_vars[FILE_EXTN]'>";
				$FeatureProductList .="<img src='$_conf_vars[SITE_ROOT_DIR]upload/productcategoryfeatureimage/$imageName1' align='left' alt='$catName1' border='0' />";
				$FeatureProductList .="</a>";
				$FeatureProductList .="<p>$desc1</p>";
				$FeatureProductList .="</div></div>";
			}			
}
else 
{
	$FeatureProductList ="<ul id='nav'><li>Feature Product Not Exist</li></ul>";
}

$smarty ->assign('leftProductMenu',   $leftProductMenu);
$smarty ->assign('bottomProductMenu', $bottomProductMenu);
$smarty ->assign('FeatureProductList', $FeatureProductList);


?>