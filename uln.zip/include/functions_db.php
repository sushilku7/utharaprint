<?php
function Count_Record($table, $ctr_field, $condn = ''){
	global $db;
	if(!empty($condn)) $condn = " where ".$condn;
	$query = "Select count(".$ctr_field.") as tot_rec from ".$table." ".$condn; 
	//echo $query;die();
	$db -> Query($query);
	
	
	$tot_rec = $db -> getResult(0, 'tot_rec');
	$db -> FreeResult();
	return $tot_rec;
}
function create_thumb($target,$ext,$thumb_path,$w,$h){
        list($w_orig,$h_orig)=getimagesize($target);
        $scale_ratio=$w_orig/$h_orig;
		if(($w/$h)>$scale_ratio)
			$w=$h*$scale_ratio;
		else
			$h=$w/$scale_ratio;

	if($w_orig<=$w){
		$w=$w_orig;
		$h=$h_orig;
	}
	$img="";
	if($ext=="gif")
		$img=imagecreatefromgif($target);
	else if($ext=="png")
		$img=imagecreatefrompng($target);
	else if($ext=="jpg")
		$img=imagecreatefromjpeg($target);

	$tci=imagecreatetruecolor($w,$h);
	imagecopyresampled($tci,$img,0,0,0,0,$w,$h,$w_orig,$h_orig);
	imagejpeg($tci,$thumb_path,80);
    imagedestroy($tci);
}
function createThumbnail($imageDirectory, $imageName, $thumbDirectory, $thumbWidth, $quality)
                { 
            $details = getimagesize($imageDirectory."/".$imageName) or die('Please only upload images.'); 
            $type = preg_replace('@^.+(?<=/)(.+)$@', '$1', $details['mime']); 
            eval('$srcImg = imagecreatefrom'.$type.'("$imageDirectory/$imageName");'); 
            $thumbHeight = $details[1] * ($thumbWidth / $details[0]); 
            $thumbImg = imagecreatetruecolor($thumbWidth, $thumbHeight); 
            imagecopyresampled($thumbImg, $srcImg, 0, 0, 0, 0, $thumbWidth, $thumbHeight,  
            $details[0], $details[1]); 
            eval('image'.$type.'($thumbImg, "$thumbDirectory/$imageName"'. 
            (($type=='jpeg')?', $quality':'').');'); 
            imagedestroy($srcImg); 
            imagedestroy($thumbImg); 
        } 
function thumbimageResize($imageSrc,$imageWidth,$imageHeight) {

            $newImageWidth =99;
            $newImageHeight =66;

            $newImageLayer=imagecreatetruecolor($newImageWidth,$newImageHeight);
            imagecopyresampled($newImageLayer,$imageSrc,0,0,0,0,$newImageWidth,$newImageHeight,$imageWidth,$imageHeight);

            return $newImageLayer;
        }
function imageResize($imageSrc,$imageWidth,$imageHeight) {

            $newImageWidth =200;
            $newImageHeight =200;

            $newImageLayer=imagecreatetruecolor($newImageWidth,$newImageHeight);
            imagecopyresampled($newImageLayer,$imageSrc,0,0,0,0,$newImageWidth,$newImageHeight,$imageWidth,$imageHeight);

            return $newImageLayer;
        }
function Get_Images($table, $field, $condn){
	global $_conf_vars, $db;
	$img_arr = array();
	if(!empty($condn)) $condn = " where ".$condn;
	$db -> Query("Select ".$field." from ".prefix($table)." ".$condn);
	if($db -> NumRow() > 0){
		while($row = $db -> getAssoc()) $img_arr[] = $row;
	}
	$db -> FreeResult();
	return $img_arr;
}

function Retrieve_Field($table, $field, $condn = ''){
	global $db, $_conf_vars;
	$val = '';
	if(!empty($condn)) $condn = " where ".$condn;
	$query = "Select ".$field." from ".$table." ".$condn; //echo "<br /><br />".$query;
	//echo "<br/>Query - ".$query;
	$db -> Query($query);
	if($db -> NumRow() > 0){ $row = $db -> getData(); $val = StripSlash($row[0]); }
	$db -> FreeResult();
	return $val;
}


function Show_List($query, $name, $sel_val = '', $select = '', $attrib = ''){
	global $_conf_vars, $db;	
	//echo "$sel_val - ".$query."<br />";
        //echo $name;
	//die();
	$list = '<select name="'.$name.'" id="'.$name.'" '.$attrib.'><option value="-1"> --Please Select-- </option>';
	if(!empty($select)) $list .= chr(13).'<option value="">'.$select.'</option>'.chr(13);
	$db -> Query($query);
	if($db -> NumRow() > 0){
		while($row = $db -> getData()){
			if(!is_array($sel_val) && $row[0] == $sel_val) $selected = 'selected="selected"';
			elseif(is_array($sel_val) && in_array($row[0], $sel_val)) $selected = 'selected="selected"';
			else $selected = '';
                        
                        //Removing the last printing word from category name
                        $tempCatNameArr = explode(" ", $row[1]);                               
                        $lastWordPositionInCatName = count($tempCatNameArr)-1;
                        if($tempCatNameArr[$lastWordPositionInCatName]=="Printing")
                              unset($tempCatNameArr[$lastWordPositionInCatName]);
                        $catName = implode(" ", $tempCatNameArr);       
                        //End
                        
			$list .= '<option value="'.$row[0].'" '.$selected.'>'.StripSlash($catName).'</option>'.chr(13);
		}
	}
	$list .= '</select>';
	$db -> FreeResult();
	return $list;
}

function Show_List1($query, $name, $sel_val = '', $select = '', $attrib = ''){
	global $_conf_vars, $db;	
	echo "$sel_val - ".$query."<br />";
        //echo $name;
	die();
	$list = '<select name="'.$name.'" id="'.$name.'" '.$attrib.'><option value="-1"> --Please Select-- </option>';
	if(!empty($select)) $list .= chr(13).'<option value="">'.$select.'</option>'.chr(13);
	$db -> Query($query);
	if($db -> NumRow() > 0){
		while($row = $db -> getData()){
			if(!is_array($sel_val) && $row[0] == $sel_val) $selected = 'selected="selected"';
			elseif(is_array($sel_val) && in_array($row[0], $sel_val)) $selected = 'selected="selected"';
			else $selected = '';
                        
                        //Removing the last printing word from category name
                        $tempCatNameArr = explode(" ", $row[1]);                               
                        $lastWordPositionInCatName = count($tempCatNameArr)-1;
                        if($tempCatNameArr[$lastWordPositionInCatName]=="Printing")
                              unset($tempCatNameArr[$lastWordPositionInCatName]);
                        $catName = implode(" ", $tempCatNameArr);       
                        //End
                        
			$list .= '<option value="'.$row[0].'" '.$selected.'>'.StripSlash($catName).'</option>'.chr(13);
		}
	}
	$list .= '</select>';
	$db -> FreeResult();
	return $list;
}
function Show_RelevantProduct_List($query, $name, $sel_val = '', $select = '', $attrib = ''){
	global $_conf_vars, $db;	
	//echo "$sel_val - ".$query."<br />";
       // echo $name;
	//die();
	$list = '<select name="'.$name.'" id="'.$name.'" '.$attrib.'><option value="-1"> --Please Select-- </option>';
	if(!empty($select)) $list .= chr(13).'<option value="">'.$select.'</option>'.chr(13);
	$db -> Query($query);
	if($db -> NumRow() > 0){
		while($row = $db -> getData()){
			if(!is_array($sel_val) && $row[0] == $sel_val) $selected = 'selected="selected"';
			elseif(is_array($sel_val) && in_array($row[0], $sel_val)) $selected = 'selected="selected"';
			else $selected = '';
                        
                        //Removing the last printing word from category name
                        $tempCatNameArr = explode(" ", $row[1]);                               
                        $lastWordPositionInCatName = count($tempCatNameArr)-1;
                        if($tempCatNameArr[$lastWordPositionInCatName]=="Printing")
                              unset($tempCatNameArr[$lastWordPositionInCatName]);
                        $catName = implode(" ", $tempCatNameArr);       
                        //End
                        
			$list .= '<option value="'.$row[0].'" '.$selected.'>'.StripSlash($catName).'</option>'.chr(13);
		}
	}
	$list .= '</select>';
	$db -> FreeResult();
	return $list;
}
function Show_Size_Data($query, $name, $sel_val = '', $select = '', $attrib = ''){
	global $_conf_vars, $db;		
           $list = "<ul>";
           $db -> Query($query);
	   if($db -> NumRow() > 0) 
           {
               while($row = $db -> getData())
                {
                        //Removing the last printing word from category name
                          
                        //End
                        $sizeId = $row[0];
                        $sizeName = $row[1];
                        $tmpSubCatArr = explode("_", $sizeName);
                        $sizeName = $tmpSubCatArr[0];
                                                
                        if(!is_array($sel_val) && $row[0] == $sel_val) $selected = 'style="background-color:#d92822;"';
			elseif(is_array($sel_val) && in_array($row[0], $sel_val)) $selected = 'style="background-color:#d92822;"';
			else $selected = '';
                        //$test = "1234";
                        //$list .="<li><input type='submit' class='buttonLink' id='$name' name='$name' value='$dVName' onclick='javascript: submitProductForm(this.value);' $selected /> </li>";
                        $list .= "<li><a   onclick='javascript: submitProductSizeForm($sizeId);' title='$sizeName' $selected >$sizeName</a></li>";
                        
                }
           }           
           $list .="</ul>";
           $db -> FreeResult();
	   return $list;                
}

function Show_Paper_Data($query, $name, $sel_val = '', $select = '', $attrib = ''){
	global $_conf_vars, $db;		
           $list = "<ul>";
           $db -> Query($query);
	   if($db -> NumRow() > 0) 
           {
               while($row = $db -> getData())
                {
                        //Removing the last printing word from category name
                        $dataValueArr = explode(" ", $row[1]);                               
                        $lastWordPositionInName = count($dataValueArr)-1;
                        if($dataValueArr[$lastWordPositionInName]=="Printing")
                              unset($dataValueArr[$lastWordPositionInName]);
                        $dVName = implode(" ", $dataValueArr);       
                        //End
                        if(!is_array($sel_val) && $row[0] == $sel_val) $selected = 'style="background-color:#d92822;"';
			elseif(is_array($sel_val) && in_array($row[0], $sel_val)) $selected = 'style="background-color:#d92822;"';
			else $selected = '';
                        //$test = "1234";
                        $list .="<li><input type='submit' class='buttonLink' id='$name' name='$name' value='$dVName' onclick='javascript: submitProductPaperForm(this.value);' $selected /> </li>";
                        //$list .= "<li><a href=''  onclick='javascript: submitProductForm($test);' value='$dVName' title='$dVName' $selected >$dVName</a></li>";
                        
                }
           }           
           $list .="</ul>";
           $db -> FreeResult();
	   return $list;                
}

function Show_Pages_Data($query, $name, $sel_val = '', $select = '', $attrib = ''){
	global $_conf_vars, $db;		
           $list = "<ul>";
           $db -> Query($query);
	   if($db -> NumRow() > 0) 
           {
               while($row = $db -> getData())
                {
                        //Removing the last printing word from category name
                        $dataValueArr = explode(" ", $row[1]);                               
                        $lastWordPositionInName = count($dataValueArr)-1;
                        if($dataValueArr[$lastWordPositionInName]=="Printing")
                              unset($dataValueArr[$lastWordPositionInName]);
                        $dVName = implode(" ", $dataValueArr);       
                        //End
                        if(!is_array($sel_val) && $row[0] == $sel_val) $selected = 'style="background-color:#d92822;"';
			elseif(is_array($sel_val) && in_array($row[0], $sel_val)) $selected = 'style="background-color:#d92822;"';
			else $selected = '';
                        //$test = "1234";
                        $list .="<li><input type='submit' class='buttonLink' id='$name' name='$name' value='$dVName' onclick='javascript: submitProductpagesForm(this.value);' $selected /> </li>";
                        //$list .= "<li><a href=''  onclick='javascript: submitProductForm($test);' value='$dVName' title='$dVName' $selected >$dVName</a></li>";
                        
                }
            }           
           $list .="</ul>";
           $db -> FreeResult();
	   return $list;                
}

function Show_table_Data($query1, $name, $sel_val = '', $select = '', $attrib = '', $designCharges=''){
           global $_conf_vars, $db;
           $db -> Query($query1);
           
           $htmlData   = "<table border='1' align='center' cellpadding='0' cellspacing='0' bordercolor='#e1e1e1'>";            
           $htmlData  .="<tr>                       
                        <th align='center' valign='middle'>Quantity</th>
                        <th align='center' valign='middle'>Price</th>              
                        </tr>";
           if($db -> NumRow() > 0) 
           {
                $count = 1;
                while($rowsdata = $db -> getData())
                {
                    $productId      = $rowsdata[0];
                    $productQty     = $rowsdata[1];                    
                    $buyPrice       = $rowsdata[2]; 
                    $profitemargine = $rowsdata[3];
                    
                    
                // echo $profitemargine ;die;
                  
                     //echo "<br />Member Id - ".$_SESSION['memberId'];
                     if(isset($_SESSION['memberId']) && $_SESSION['memberId']!="")
                      {    
                                
                                $whereCond = " 1=1";
                                $memberId  = $_SESSION['memberId'];
                                //$whereCond = " memberId = '".$memberId."'";
                                $qery1 = "SELECT * FROM tbl_reseller WHERE memberId='$memberId'";
                                                        $rslt1 = mysql_query($qery1);
                                                        $rs = mysql_fetch_array($rslt1); 
                                                        $whereCond = " 1=1";
                                                        //$memberId  = $_SESSION['memberId'];
                                                        //$whereCond = " memberId = '".$memberId."'";
                                                        if(isset($rs['memberId']) && $rs['memberId']==$_SESSION['memberId'])
                                                        {                      
                                                                    if(isEmpty($rs['resellerDisc']))
                                                                    {
                                                                    $priceMrgnPrcntge   = $rs['resellerFlateMargine'];  
                                                                    $productPrice       = $buyPrice + $priceMrgnPrcntge;
                                                                    }
                                                                 else 
                                                                     { 
                                                                    $priceMrgnPrcntge   = $rs['resellerDisc'];
                                                                    $productMarginPrice = ($buyPrice * $priceMrgnPrcntge)/100;
                                                                    $productPrice       = $buyPrice + $productMarginPrice;
                                                                     }
                                                        }
                                                        else 
                                                        {
                                                                $productMarginPrice = ($buyPrice * $profitemargine)/100;
                                                                $productPrice = $buyPrice+$productMarginPrice;
                                                        }
                                                      
                         }
                    else 
                        {
                            $productMarginPrice = ($buyPrice * $profitemargine)/100;
                            $productPrice = $buyPrice+$productMarginPrice;
                        }
                    $productPrice = round($productPrice, 2);                 
                    $productPrice = number_format($productPrice, 2);
                    $htmlData     .="<tr>                                    
                                    <td align='center' valign='middle'>$productQty</td>
                                    <td align='center' valign='middle'><a  onclick='javascript: submitProductIdWithForm(".$productId.");'>&pound; $productPrice</a></td>              
                                    </tr>";
                    $count = $count + 1;
                }
           }
            $htmlData .="</table>";
            $db -> FreeResult();
            return  $htmlData;                         
}

function Show_table_Data_with_design_charges($query1, $name, $sel_val = '', $select = '', $attrib = '', $designCharges=''){
           global $_conf_vars, $db;
           $db -> Query($query1);
           
           $htmlData   = "<table border='1' align='center' cellpadding='0' cellspacing='0' bordercolor='#e1e1e1'>";            
           $htmlData  .="<tr>                       
                        <th align='center' valign='middle' width='30%'>Quantity</th>
                        <th align='left' valign='middle' width='70%'>&nbsp;&nbsp;&nbsp;Price (Design + Printing with proof for approval) </th>              
                        </tr>";
           if($db -> NumRow() > 0) 
           {
                $count = 1;
                while($rowsdata = $db -> getData())
                {
                    $productId      = $rowsdata[0];
                    $productQty     = $rowsdata[1];                    
                    $buyPrice       = $rowsdata[2]; 
                    $profitemargine = $rowsdata[3];
                    
                    
                // echo $profitemargine ;die;
                  
                     //echo "<br />Member Id - ".$_SESSION['memberId'];
                     if(isset($_SESSION['memberId']) && $_SESSION['memberId']!="")
                      {    
                                
                                $whereCond = " 1=1";
                                $memberId  = $_SESSION['memberId'];
                                //$whereCond = " memberId = '".$memberId."'";
                                $qery1 = "SELECT * FROM tbl_reseller WHERE memberId='$memberId'";
                                                        $rslt1 = mysql_query($qery1);
                                                        $rs = mysql_fetch_array($rslt1); 
                                                        $whereCond = " 1=1";
                                                        //$memberId  = $_SESSION['memberId'];
                                                        //$whereCond = " memberId = '".$memberId."'";
                                                        if(isset($rs['memberId']) && $rs['memberId']==$_SESSION['memberId'])
                                                        {                      
                                                                    if(isEmpty($rs['resellerDisc']))
                                                                    {
                                                                    $priceMrgnPrcntge   = $rs['resellerFlateMargine'];  
                                                                    $productPrice       = $buyPrice + $priceMrgnPrcntge;
                                                                    }
                                                                 else 
                                                                     { 
                                                                    $priceMrgnPrcntge   = $rs['resellerDisc'];
                                                                    $productMarginPrice = ($buyPrice * $priceMrgnPrcntge)/100;
                                                                    $productPrice       = $buyPrice + $productMarginPrice;
                                                                     }
                                                        }
                                                        else 
                                                        {
                                                                $productMarginPrice = ($buyPrice * $profitemargine)/100;
                                                                $productPrice = $buyPrice+$productMarginPrice;
                                                        }
                                                      
                         }
                    else 
                        {
                            $productMarginPrice = ($buyPrice * $profitemargine)/100;
                            $productPrice = $buyPrice+$productMarginPrice;
                        }
                    $productPrice = round($productPrice, 2);
                    //echo "<br />New Design Charges 1- ".$designCharges;
                    if($designCharges!="")
                    {
                        $productPrice = ($productPrice + $designCharges);
                    }
                    $productPrice = number_format($productPrice, 2);
                    $htmlData     .="<tr>                                    
                                    <td align='center' valign='middle'>$productQty</td>
                                    <td align='center' valign='middle'><a  onclick='javascript: submitProductIdWithForm(".$productId.");'>&pound; $productPrice</a></td>              
                                    </tr>";
                    $count = $count + 1;
                }
           }
            $htmlData .="</table>";
            $db -> FreeResult();
            return  $htmlData;                         
}

function Show_List_Without_Select($query, $name, $sel_val = '', $select = '', $attrib = ''){
	global $_conf_vars, $db;
	$list = '<select name="'.$name.'" id="'.$name.'" '.$attrib.'>';
	if(!empty($select)) $list .= chr(13).'<option value="">'.$select.'</option>'.chr(13);
	$db -> Query($query);
	if($db -> NumRow() > 0){
		while($row = $db -> getData()){
			if(!is_array($sel_val) && $row[0] == $sel_val) $selected = 'selected="selected"';
			elseif(is_array($sel_val) && in_array($row[0], $sel_val)) $selected = 'selected="selected"';
			else $selected = '';
			$list .= '<option value="'.$row[0].'" '.$selected.'>'.StripSlash($row[1]).'</option>'.chr(13);
		}
	}
	$list .= '</select>';
	$db -> FreeResult();
	return $list;
}
//Added By Anshu @ 22-Feb-2013
function Show_Blank_List($name, $attrib = '')
{
	$list = '<select name="'.$name.'" id="'.$name.'" '.$attrib.'>
			 <option value="-1"> --Please Select-- </option>
			 </select>';	
	return $list;
}

function Return_List_Value($query, $sel_val = '')
{
    global $_conf_vars, $db;
	$list = array();	
	$db -> Query($query);
	if($db -> NumRow() > 0){
		while($row = $db -> getData()){
			if(!is_array($sel_val) && $row[0] == $sel_val) 
                        {
                            $list[] = $row[1];
                        }
			elseif(is_array($sel_val) && in_array($row[0], $sel_val)) 
                        {
                             $list[] = $row[1];
                        }			
		}
	}	
	$db -> FreeResult();
	return $list;
}



function Get_Assoc($table, $fields, $condn = '')
{
	global $db, $_conf_vars;
	$row = array();
	if(!empty($condn)) $condn = " where ".$condn;
	$query = "Select ".$fields." from ".$table." ".$condn;
	//echo $query;
	//echo "<br /><br />";
	$db -> Query($query);
	if($db -> NumRow() > 0){ $row = $db -> getAssoc(); }
	$db -> FreeResult();
	return $row;
}

function Get_Array($table, $fields, $condn = '')
{
	global $db, $_conf_vars;
	$row = array();
	if(!empty($condn)) $condn = " where ".$condn;
	$query = "Select ".$fields." from ".$table." ".$condn;	
	//echo "Query - ".$query;die();
	$db -> Query($query); 
	if($db -> NumRow() > 0){ while($rs = $db -> getData()) $row[] = $rs[0]; }
	$db -> FreeResult();
	return $row;
}

function Get_An_Array($table, $field, $condn = ''){
	global $db, $_conf_vars;
	$row = array();
	if(!empty($condn)) $condn = " where ".$condn;
	$query = "Select ".$field." from ".$table." ".$condn; //echo $query;
	$db -> Query($query);
	if($db -> NumRow() > 0){ while($rs = $db -> getData()) $row[] = $rs[0]; }
	$db -> FreeResult();
	return $row;
}

function Get_Records($table, $fields, $condn = '', $limit = ''){
	global $db, $_conf_vars;
	$row = array();
	if(!empty($condn)) $condn = " where ".$condn;
	if(!empty($limit)) $limit = " limit 0,".$limit;
	$query = "Select ".$fields." from ".$table." ".$condn." ".$limit; //echo "<br /><br />".$query;die;	
	//
        //echo "<br/><br/>Query - ".$query;
	//echo "<br/><br/>";die();
	$db -> Query($query);
	if($db -> NumRow() > 0){ while($rs = $db -> getAssoc()) $row[] = $rs; }
	$db -> FreeResult();
	return $row;
}

function Smarty_Arr($table, $fields, $condn = ''){
	global $db, $_conf_vars;
	$row = array();
	if(!empty($condn)) $condn = " where ".$condn;
	$query = "Select ".$fields." from ".$table." ".$condn; //echo $query;
        //echo "<br/><br/>Query - ".$query;
	//echo "<br/><br/>";die();
	$db -> Query($query);
	if($db -> NumRow() > 0){ while($rs = $db -> getData()) $row[$rs[0]] = $rs[1]; }
	$db -> FreeResult();
	return $row;
}

function Generate_OrderNo($user_id){
	global $db;
	$order_no = randomPrefix(12);
	$ord_arr = Get_An_Array(prefix("user_payment"), "order_no");
	if(!empty($ord_arr)){
		while(in_array($order_no, $ord_arr)) $order_no = $user_id.randomPrefix(8);
	}
	return $order_no;
}

function Declare_Variable($table, $condn = ''){
	global $db;
	$arr = array();
	if(!isEmpty($condn)) $condn = " and ".$condn;
	$db -> Query("Select * from ".$table." ".$condn." limit 0, 1");
	for($f=0; $f < $db -> NumField(); $f++){
		$field_name = $db -> GetField($f);
		$field_name = $field_name -> name;
		$arr[$field_name] = "";
	}
	$db -> FreeResult();
	return $arr;
}
function Valid_Username($username){
	global $db, $_conf_vars;
	$char_arr = array('a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '_');
	$flag = 1;
	for($s=0; $s < strlen($username); $s++){
		$char = $username.substr($s, 1);
		if(!in_array(+$char, $char_arr)){//echo $char."<br />";
			$flag = 0;
			break;
		}
	}
	if($flag == 0) return false;
	else return true;
}

function checkUserLogin(){
	if(isset($_SESSION["USERNAME"]) && !isEmpty($_SESSION["USERNAME"])){
		$user_id = Retrieve_Field(prefix("user"), "user_id", "user_email = '".$_SESSION['USERNAME']."' and user_status = '1'");
		return $user_id;
	}else{ return false; }
}

function isLogin($next_page = ''){
	global $_conf_vars, $db;
	$clt_id = checkUserLogin();
	if(isEmpty($clt_id)){
		if(!isEmpty($next_page)) $_SESSION['NEXT_PAGE'] = $next_page;
		Redirect_To($_conf_vars['LOGIN'].$_conf_vars['FILE_EXTN']);
	}
	else return $clt_id;
}

function Specified_Field($table, $field, $condn = ''){
	global $db, $_conf_vars;
	$val = '';
	if(!empty($condn)) $condn = " where ".$condn;
	$query = "Select ".$field." from ".$table." ".$condn; #echo "<br /><br />".$query;
	//echo $query;
	$db -> Query($query);
	if($db -> NumRow() > 0)
	{
		for($i=0;$i<$db -> NumRow();$i++)
		{
			$resultSet[]  = $db -> getData(); 
		}

	}
	$db -> FreeResult();
	return $resultSet;
}

function Get_category()
{
	global $db, $_conf_vars;
	$cat_arr = Get_Records(prefix('category').' c ' , 'c.cat_id,c.cat_name',  "  parent_id = '0' ");
	if(!empty($cat_arr)){
		for($cc=0; $cc < sizeof($cat_arr); $cc++)
		{
			$cat_arr[$cc]['sub_arr'] = Get_Records(prefix('category'),'cat_name, cat_id',"parent_id = '".$cat_arr[$cc]['cat_id']."' order by cat_id");
		}
	}
	return $cat_arr;
}

function Update_Data($table, $query, $cond){
	global $db;
	if($cond !='')
	{
		$sql_query = "UPDATE ".$table." set ".$query." where ".$cond;
                //die();
		if($db -> Query($sql_query))
			return true;
		else
			return false;
	}
	return false;
}
function Insert_Data($table, $field){
	global $db;
	$status ='';
	$sql_query = "INSERT INTO ".$table." set ".$field;
	
	if($db -> Query($sql_query))
		$status = "true";
	else
		$status = "false";

	return $status;
}
function Delete_Data($table,$cond){
	global $db;
	if($cond !='')
	{
		$sql_query = "DELETE FROM ".$table." where ".$cond;
		if($db -> Query($sql_query))
			return true;
		else
			return false;
	}
	return false;
}
function Show_TextBox($name, $val = '', $attrib = ''){
	global $_conf_vars, $db;
	$textbox = '<input type="text" name="'.$name.'" id="'.$name.'" value="'.$val.'" '.$attrib.'>';
	return $textbox;
}

function Show_Textarea($name, $val = '', $attrib = ''){
	global $_conf_vars, $db;
	$textarea = "<textarea name='$name' id='$name' cols='50' rows='4'  $attrib />".$val."</textarea>";
	return $textarea;
}

function IsResellerExists($tableName, $columnName, $columnValue)
{
        global $_conf_vars, $db;
        $condn = " $columnName='".$columnValue."'";
        //if(!empty($condn)) $condn = " where ".$condn;
	$query = "Select * from $tableName where $condn";
        $db -> Query($query);
	if($db -> NumRow() > 0)      
                 return true;
        else 
                return false;
        
}
?>