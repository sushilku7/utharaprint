<?php
// SITE FUNCTIONS
//include "functions_db.php";
global $_conf_vars;
function displayMSG($MSG, $STATUS){return "<div class=".$STATUS.">".$MSG."</div>";}
function prefix($tblname){
	global $_conf_vars;
	return $_conf_vars["PREFIX"]."".$tblname;
}
function Curent_Date($format = 'Y-m-d H:i:s'){
	return date($format);
}
function CheckFile($fName){
	if(is_file($fName)){ return true; }else{ return false; }
}

function DeleteFile($fName){
	if(CheckFile($fName)){ unlink($fName); return true; }else{ return false; }
}

function securePass($password){return sha1($password);}
function isEmail($email){
	if (!eregi("^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$", $email)){ return false;}
	else return true;
}
function isURL($url){
	if (preg_match ("/^[a-z0-9][a-z0-9\-]+[a-z0-9](\.[a-z]{2,4})+$/i", $url)) return true; 
	else return false;
}
function isDate($date){ //--mm-dd-yyyy or mm/dd/yyyy---
	if (!eregi("^[0-1]{1,1}[0-2]{1,1}[\-|\/]{1,1}[0-3]{1,1}[0-9]{1,1}[\-|\/]{1,1}[0-9]{4,4}$", $date)){ return false;}
	else return true;
}
function genPassword($len = 6){
    $r = '';
    for($i=0; $i<$len; $i++){
		$letter = chr(rand(0, 25) + ord('a'));
		$digit = chr(rand(0, 8) + ord('1'));
		$arr = array($letter, $digit);
		$r .= $arr[rand(0, 1)];
	}
    return $r;
}

function isValidURL($url)
{
return preg_match('|^http(s)?://[a-z0-9-]+(.[a-z0-9-]+)*(:[0-9]+)?(/.*)?$|i', $url);
}
function is_valid_image($filename) {
	$ext = strtolower(substr(strrchr($filename, "."), 1));
	return in_array($ext, array('jpg','jpeg','gif','png','psd','cdr'));
}

function is_valid_AI($filename) {
	$ext = strtolower(substr(strrchr($filename, "."), 1));
	return in_array($ext, array('ai', 'AI'));
}

function is_valid_PDF($filename) {
	$ext = strtolower(substr(strrchr($filename, "."), 1));
	return in_array($ext, array('pdf', 'PDF'));
}

function is_valid_IN($filename) {
	$ext = strtolower(substr(strrchr($filename, "."), 1));
	return in_array($ext, array('indd', 'INDD'));
}

function is_valid_document($filename) {
	$ext = strtolower(substr(strrchr($filename, "."), 1));
	return in_array($ext, array('jpg','jpeg','gif','png','doc','xls', 'xlsx', 'txt', 'docx', 'tiff'));
}

function is_valid_doc($filename) {
	$ext = strtolower(substr(strrchr($filename, "."), 1));
	return in_array($ext, array('doc','pdf'));
}


function is_valid_prductFile($filename) {
	$ext = strtolower(substr(strrchr($filename, "."), 1));
	return in_array($ext, array('csv'));
}

function is_valid_video($filename) {
	$ext = strtolower(substr(strrchr($filename, "."), 1));
	return in_array($ext, array('avi','mpeg','mov','mpg','wmv','mp4','flv'));
}
function is_valid_audio($filename) {
	$ext = strtolower(substr(strrchr($filename, "."), 1));
	return in_array($ext, array('wmv','mp3'));
}
function is_valid_file($filename) {
	$ext = strtolower(substr(strrchr($filename, "."), 1));
	return in_array($ext, array('jpg','jpeg','gif','png','doc','pdf', 'eps', 'tiff', 'docx','psd','zip','rar'));
}
function is_valid_csv($filename) {
	$ext = strtolower(substr(strrchr($filename, "."), 1));
	return in_array($ext, array('csv','CSV'));
}
function stringReplace($search,$replace,$companyUrlFirst) {
	$companyUrlFirst = str_replace($search, $replace, $companyUrlFirst);
	return $companyUrlFirst;
}			
function ChkVar($var, $chk_val = '', $reqd){
	if(isset($_REQUEST[$var]) && TrimText($_REQUEST[$var]) != $chk_val){return TrimText(StripSlash($_REQUEST[$var]));}
	else{
		if($reqd == "1") return false;
		else return '';
	}
}
function ChkVar_Post($var, $reqd, $chk_val = ''){
	if(isset($_POST[$var]) && !empty($_POST[$var])){return TrimText(StripSlash($_POST[$var]));}
	else{
		if($reqd == "1") return false;
		else return '';
	}
}

function Var_In_Array($array_name, $var_name, $var_value){eval('\$\_$array_name\[$var_name\] = $var_value; ') ;}
function AddSlash($txt){return addslashes(trim($txt));}
function StripSlash($txt){return stripslashes(trim($txt));}
function TrimText($txt){
	if(is_array($txt)) return false;
	return trim($txt);
}

function Check_Extension($img, $reqd = 0, $valid_extn = array('jpg', 'jpeg', 'gif', 'png')){
	if(isset($_FILES[$img]['name']) && $_FILES[$img]['name'] != NULL && !empty($_FILES[$img]['name'])){
		$fname = $_FILES[$img]['name'];
		$file_info = pathinfo($fname);
		$extn = strtolower($file_info['extension']);
		if(!in_array($extn, $valid_extn)) return false;
		else return $extn;
	}
	else{
		if($reqd == 1) return false;
		else return true;
	}
}

function Check_Size($img, $max_size = 1048576){
	if(isset($_FILES[$img]['name']) && $_FILES[$img]['name'] != NULL && !empty($_FILES[$img]['name'])){
		$size = $_FILES[$img]['size'];
		if($size > $max_size) return false;
		else return $size;
	}
	else return true;
}

function Image_Extension($img)
{
	$extn ='';
	if(isset($_FILES[$img]['name']) && $_FILES[$img]['name']!=NULL && !empty($_FILES[$img]['name'])){
		$fname=$_FILES[$img]['name'];
		$file_info=pathinfo($fname);
		$extn=strtolower($file_info['extension']);
	}
	return $extn;
}

function Get_Extension($fname){
	$file_info=pathinfo($fname);
	$extn=strtolower($file_info['extension']);
	return $extn;
}

function Display_Val($val){ $val = str_replace(chr(13), "<br />", StripSlash(Trimtext($val))); return $val;}
function treeOption($cat = 0, $indent = 0){
	global $g_tree, $ret_tree;
	$tt = array();
	$x = 0;
	$loop = 0;
	foreach($g_tree as $n){         
		if( $n['parent_link'] == $cat) { $tt[$x++] = $loop; }  
		$loop++;
	}
	/*-- if there are some parent ids --*/
	if( $x != 0){             
		foreach($tt as $d){
			$tmp = array();
			foreach($g_tree[$d] as $key => $value){ $tmp[$key] = $value; }
			$tmp['indent'] = $indent;
			$ret_tree[] = $tmp;
			treeOption($tmp['id'], $indent+1);
		}
	}
	else { return;}
}
function Requested_Var($var){
	if(isset($_REQUEST[$var]) && !empty($var)) return StripSlash(TrimText($_REQUEST[$var]));
	else return '';
}
function Posted_Var($var){
	if(isset($_POST[$var]) && !empty($_POST[$var])) return StripSlash(TrimText($_POST[$var]));
	else return '';
}

function Today($hr = 0, $min = 0, $sec = 0, $day = 0, $mnth = 0, $yr = 0){
	return mktime(date("H") + $hr, date("i") + $min, date("s") + $sec, date("m") + $mnth, date("d") + $day, 
					date("Y") + $yr);
}


function Catpcha($ctr = 5){
	// generate 5 digit random number
	$rand = '';
	$arr = array("A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", "2", "3", "4", "5", "6", "7", "8", "9" );
	$rand = "";
	for($i=0; $i<$ctr; $i++) {
		$rd = rand(0, 33);
		$rand.= $arr[$rd];
	}
	return $rand;
}

function isEmpty($var){
	if(empty($var) || TrimText($var) == "" || $var == NULL) return true;
	else return false;
}

function Session_Var($var){
	if(isset($_SESSION[$var]) && is_array($_SESSION[$var])){
		if(!empty($_SESSION[$var])) return $_SESSION[$var];
		else return false;
	}
	//elseif(isset($_SESSION[$var]) && !isEmpty($_SESSION[$var]))  return StripSlash($_SESSION[$var]);
	elseif(isset($_SESSION[$var]) && !empty($_SESSION[$var]))  return StripSlash($_SESSION[$var]);
	else return false;
}

function Str_To_Time($date, $hr = '', $min = '', $sec = '', $format = 'mm/dd/yyyy'){
	if(isEmpty($hr)) $hr = 0;
	if(isEmpty($min)) $min = 0;
	if(isEmpty($sec)) $sec = 0; //echo $hr." -" .$min." - ".$sec."<br /><br />";
	if(isEmpty($date)) return false;
	list($mm, $dd, $yyyy) = split("/", $date); //echo $dd."-".$mm."-".$yyyy;
	$timestamp = mktime($hr, $min, $sec, $mm, $dd, $yyyy);
	return $timestamp;
}

function Check_Request_Var($var){
	if(isset($_REQUEST[$var])) return true;
	else return false;
}

function Redirect_To($url = ''){
	global $_conf_vars;	
	echo "URL - ".$_conf_vars['SITE_ROOT_DIR'].$url;
	//die();
	header("location:".$_conf_vars['SITE_ROOT_DIR'].$url);
	exit();
}
// Validate email address format in case client-side validation "fails"
// Validate email address format in case client-side validation "fails"
function validateEmail($email) {
	$at = strrpos($email, "@");

	// Make sure the at (@) sybmol exists and  
	// it is not the first or last character
	if ($at && ($at < 1 || ($at + 1) == strlen($email)))
		return false;

	// Make sure there aren't multiple periods together
	if (preg_match('/(\.{2,})/', $email))
		return false;

	// Break up the local and domain portions
	$local = substr($email, 0, $at);
	$domain = substr($email, $at + 1);


	// Check lengths
	$locLen = strlen($local);
	$domLen = strlen($domain);
	if ($locLen < 1 || $locLen > 64 || $domLen < 4 || $domLen > 255)
		return false;

	// Make sure local and domain don't start with or end with a period
	if (preg_match('/(^\.|\.$)/', $local) || preg_match('/(^\.|\.$)/', $domain))
		return false;

	// Check for quoted-string addresses
	// Since almost anything is allowed in a quoted-string address,
	// we're just going to let them go through
	if (!preg_match('/^"(.+)"$/', $local)) {
		// It's a dot-string address...check for valid characters
		if (!preg_match('/^[-a-zA-Z0-9!#$%*\/?|^{}`~&\'+=_\.]*$/', $local))
			return false;
	}

	// Make sure domain contains only valid characters and at least one period
	if (!preg_match('/^[-a-zA-Z0-9\.]*$/', $domain) || !strpos($domain, "."))
		return false;	

	return true;
}
###For show message 
function Show_Msg($msg, $class = 'successbox', $style = ''){
	$message = "";
	if(is_array($msg)){
		foreach($msg as $msg_no =>$msg_val) $message .= '<li>'.$msg_val.'</li>'.chr(13);
	}
	else $message = '<li>'.$msg.'</li>';
	if(!isEmpty($style)) $style = ' style="'.$style.'"';
	return '<ul class="'.$class.'"'.$style.'>'.$message.'</ul>';
}
########END

function isSpecialCharExist($str)
{
	$flag = false;
	$specialArr = array("&","'","!","@","~","#","$","^","*","(",")","+","<",">","?");
	foreach($specialArr as $k=>$v)
	{
		$newarr = explode($v,$str);
		if(count($newarr)>1)
		{
			$flag = true;
			break;
		}
	}
	return $flag;
}
function String_WithoutSpace($str){
	$str=strtolower($str);
	$new_str = "";
	$arr = array("A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", 
					"W", "X", "Y", "Z", "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", 
					 "s", "t", "u", "v", "w", "x", "y", "z", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9");
	$str_arr = explode(chr(32), $str);
	for($ss=0;$ss < sizeof($str_arr); $ss++){
		$word = $str_arr[$ss];
		$new_word = "";
		for($i=0;$i<strlen($word);$i++){
			$char = substr($word, $i, 1);
			if(in_array($char, $arr)) $new_word .= $char;
		}
		if(strlen($new_str."-".$new_word) <= 64){
			if(!empty($new_word) && $ss != 0) $new_str .= "-";
			$new_str .= $new_word;
		}
		else break;
	}
	return $new_str;
}

function Images_WithoutSpace($str){
        $nameArr=explode("(", $str);
        $str=$nameArr[0];
	$str=strtolower($str);
	$new_str = "";
	$arr = array("A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", 
					"W", "X", "Y", "Z", "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", 
					 "s", "t", "u", "v", "w", "x", "y", "z", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9");
	$str_arr = explode(chr(32), $str);
	for($ss=0;$ss < sizeof($str_arr); $ss++){
		$word = $str_arr[$ss];
		$new_word = "";
		for($i=0;$i<strlen($word);$i++){
			$char = substr($word, $i, 1);
			if(in_array($char, $arr)) $new_word .= $char;
		}
		if(strlen($new_str."-".$new_word) <= 64){
			if(!empty($new_word) && $ss != 0) $new_str .= "-";
			$new_str .= $new_word;
		}
		else break;
	}
	return $new_str;
}
function cityDropdowm($txtCity)
{
	global $_conf_vars;
	$city_list 		= "";
	$table			= prefix("city");
	$field			= "city_id,city_name";
	$where			= "1=1 order by city_name asc";
	$mod_record		= Get_Records($table,$field,$where);
	$city_list .= '<select name="txtCity" id="txtCity"><option value="">-- Select --</option>';
	foreach($mod_record as $ck=>$cv)
	{
		if($txtCity==$cv['city_id'])
			$slt = 'selected="selected"';
		else
			$slt = '';
			
		$city_list .= '<option value="'.$cv['city_id'].'" '.$slt.'>'.$cv['city_name'].'</option>';
	}
	$city_list .= '</select>';
	return $city_list;
}

function stateDropdowm($mem_state='')
{
	global $_conf_vars;
	$state_list 	= "";
	$table			= prefix("state");
	$field			= "state_id,state_title";
	$where			= "1=1 order by state_title asc";
	$mod_record		= Get_Records($table,$field,$where);
	$state_list .= '<select name="companyState" id="companyState" style="width:200px;"><option value="">-- Select --</option>';
	foreach($mod_record as $ck=>$cv)
	{
		if($mem_state==$cv['state_id'])
			$slt = 'selected="selected"';
		else
			$slt = '';
			
		$state_list .= '<option value="'.$cv['state_id'].'" '.$slt.'>'.$cv['state_title'].'</option>';
	}
	$state_list .= '</select>';
	return $state_list;
}

############# Create dropdown list #######################
function countryDropdowm($country_code='')
{
	global $_conf_vars;
	
	$country_list 	= "";
	$table			= prefix("country");
	$field			= "ctry_code,ctry_name,ctry_title";
	$where			= "1=1";
	$mod_record		= Get_Records($table,$field,$where);
	$country_list .= "<select name='companyCountryCode' id='companyCountryCode'><option value=''>-- Select --</option>";
	foreach($mod_record as $ck=>$cv)
	{
		if($country_code !='' && $country_code == $cv['ctry_code'])
			$country_list .= "<option value='".$cv['ctry_code']."' selected='selected'>".$cv['ctry_title']."</option>";
		else
			$country_list .= "<option value='".$cv['ctry_code']."'>".$cv['ctry_title']."</option>";
	}
	$country_list .= "</select>";
	return $country_list;
}

############# get Country name #######################
function GetCountryname($cntry_code='')
{
	global $_conf_vars;
	$countryname = Retrieve_Field(prefix("country"), 'ctry_title', "ctry_code  = '".$cntry_code ."'");
	return $countryname;
}
############# get state name #######################
function GetStatename($state_code='')
{
	global $_conf_vars;
	$statename = Retrieve_Field(prefix("state"), 'state_title', "state_id  = '".$state_code ."'");
	return $statename;
}
############# get city name #######################
function getCityname($city_id='')
{
	global $_conf_vars;
	$cityname = Retrieve_Field(prefix("city"), 'city_name', "city_id  = '".$city_id."'");
	return $cityname;
}
function checkMemberLogin(){
	global $_conf_vars, $db;
	echo $user_id = Session_Var('memberId'); die;
	if(!isEmpty($user_id)){
		 $adm_arr = Get_Assoc(prefix("users"), "*", "user_id = '".$user_id."'");
		
		 if(!empty($adm_arr)){
	
		 	return $adm_arr['user_id'];
		 }
		 else return false;
	}
	else return false;
}


function isMemberLogin(){
	global $_conf_vars, $db;
	$memberId = Session_Var('memberId');
	if(isEmpty($memberId)) Redirect_To("");
	else return $memberId;
}

function checkMemberStatus(){
	global $_conf_vars, $db;
	$memberRec = Count_Record(prefix("member"),"memberId","memberId='".getCurrentMemberId()."' AND memberStatus='1'");
	if(isEmpty($memberRec)) Redirect_To("");
}
function getSingleValue($table,$field,$where)
{
	global $_conf_vars;
	$singleValue = Retrieve_Field(prefix($table), $field, $where);
	return $singleValue;
}
function get_file_extension($file_name) {
return end(explode('.',$file_name));
}

function getCurrentMemberId()
{
  global $opt_main;
 
  $memberId = Retrieve_Field(prefix("alias"), "rec_id", "alias = '".$opt_main."'");
  return  $memberId;
}





##########Function for delete Industry######

function getStaticContents($id)
{
	global $db, $prefix;
	$data = "";
	$page_arr = Get_Assoc(prefix("page"), '*', "page_id= '".$id."' and page_status='1'");	
	if(count($page_arr)>0)
	{
		$data = $page_arr['page_body'];
	}
	
	return $data;
}
##########Function for delete Industry######


function resizeMarkup($markup, $dimensions)
{
	$w = $dimensions['width'];
	$h = $dimensions['height'];
	
	$patterns = array();
	$replacements = array();
	if( !empty($w) )
	{
	$patterns[] = '/width="([0-9]+)"/';
	$patterns[] = '/width:([0-9]+)/';
	
	$replacements[] = 'width="'.$w.'"';
	$replacements[] = 'width:'.$w;
	}
	
	if( !empty($h) )
	{
	$patterns[] = '/height="([0-9]+)"/';
	$patterns[] = '/height:([0-9]+)/';
	
	$replacements[] = 'height="'.$h.'"';
	$replacements[] = 'height:'.$h;
	}
	
	return preg_replace($patterns, $replacements, $markup);
}

function getExtension($str) {
         $i = strrpos($str,".");
         if (!$i) { return ""; }
         $l = strlen($str) - $i;
         $ext = substr($str,$i+1,$l);
         return $ext;
 }

?>