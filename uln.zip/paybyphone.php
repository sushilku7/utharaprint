<?php
ob_start();
session_start();
error_reporting (E_ALL ^ E_NOTICE);
include('includes/top_header.php');
$tempProductDAO    = new ProductDAO();
$tempProductMainCatDAO = new ProductMainCategoryDAO();
$tempProductCatDAO = new ProductCatDAO();
$tempFinalorderDAO = new FinalorderDAO();
$arra1 = explode('?',$_SERVER['REQUEST_URI']);
$orderId = base64_decode($arra1[1]);
unset($_SESSION['shoppingCart']);
if(isset($_POST['submit']) && $_POST['submit']!='')
{
                                $orderId = $_POST['ordId'];
                                $artworkfile1	=	$_FILES['artwork1']['name'];
                                $artworkfile2	=	$_FILES['artwork2']['name'];
                                $artworkfile3	=	$_FILES['artwork3']['name'];
                                $artworkfile4	=	$_FILES['artwork4']['name'];
                                $extArr= array('jpg','jpeg','gif','png','bmp','tiff','pdf','cdr','psd','ai');

	
	if(isset($artworkfile1) && $artworkfile1!='')
	{
                    $rowId = $tempFinalorderDAO->addArtwork($orderId);

		$userFile_name = $artworkfile1;
		$userFile_extn = substr($userFile_name, strpos($userFile_name, '.')+1);
		if(in_Array($userFile_extn, $extArr))
		{
			$currentDate= date('d-m-Y H:s:i');
			$alias=strtotime($currentDate);
			$fileName="artwork1-".$alias."-".$orderId.".".$userFile_extn;
			$destinawtion = "upload/client-artworks/".$fileName;
			if(move_uploaded_file($_FILES['artwork1']['tmp_name'],$destinawtion))
			{
				//update database;
				$colName="artwork1";
	            $updateId=$tempFinalorderDAO->updateArtwork($rowId, $colName, $fileName);
			}
		}
		else{
		$artword_error="Artwork error";
		}
	}
        if(isset($artworkfile2) && $artworkfile2!='')
	{
		
		$userFile_name = $artworkfile2;
		$userFile_extn = substr($userFile_name, strpos($userFile_name, '.')+1);
		$rowId = $tempFinalorderDAO->addArtwork($orderId);

		if(in_array($userFile_extn, $extArr))
		{
			$currentDate= date('d-m-Y H:s:i');
			$alias=strtotime($currentDate);
			$fileName="artwork2-".$alias."-".$orderId.".".$userFile_extn;
			$destinawtion = "upload/client-artworks/".$fileName;
			if(move_uploaded_file($_FILES['artwork2']['tmp_name'],$destinawtion))
			{
				//update database;
				$colName="artwork2";
	            $updateId=$tempFinalorderDAO->updateArtwork($rowId, $colName, $fileName);
			}
		}
		else{
			$artword_error="Artwork error";
		}
 
	}
	if(isset($artworkfile3) && $artworkfile3!='')
	{
		$rowId = $tempFinalorderDAO->addArtwork($orderId);
		$userFile_name = $artworkfile3;
		$userFile_extn = substr($userFile_name, strpos($userFile_name, '.')+1);
		
		if(in_array($userFile_extn, $extArr))
		{
			$currentDate= date('d-m-Y H:s:i');
			$alias=strtotime($currentDate);
			$fileName="artwork3-".$alias."-".$orderId.".".$userFile_extn;
			$destinawtion = "upload/client-artworks/".$fileName;
			if(move_uploaded_file($_FILES['artwork3']['tmp_name'],$destinawtion))
			{
				//update database;
				$colName="artwork3";
	            $updateId=$tempFinalorderDAO->updateArtwork($rowId, $colName, $fileName);
			}
		}
		else{
			$artword_error="Artwork error";
		}
 
	}
	if(isset($artworkfile4) && $artworkfile4!='')
	{
	        $rowId = $tempFinalorderDAO->addArtwork($orderId);	
		$userFile_name = $artworkfile4;
		$userFile_extn = substr($userFile_name, strpos($userFile_name, '.')+1);
		
		if(in_array($userFile_extn, $extArr))
		{
			$currentDate= date('d-m-Y H:s:i');
			$alias=strtotime($currentDate);
			$fileName="artwork4-".$alias."-".$orderId.".".$userFile_extn;
			$destinawtion = "upload/client-artworks/".$fileName;
			if(move_uploaded_file($_FILES['artworkfile4']['tmp_name'],$destinawtion))
			{
				//update database;
				$colName="artwork4";
	            $updateId=$tempFinalorderDAO->updateArtwork($rowId, $colName, $fileName);
			}
		}
		else{
			$artword_error="Artwork error";
		}
 
	}
}
?> 
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width; initial-scale=1.0; maximum-scale=1.0">
    <!--css-->
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/responsive.css">
    
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
   
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
    <!--css-->
	<script
  src="https://code.jquery.com/jquery-3.3.1.min.js">
  </script>	
	<script src="js/myjava.js"></script>
   
	<style>
		
	* { -webkit-box-sizing: border-box; -moz-box-sizing: border-box; box-sizing: border-box; }
*:before, *:after { -webkit-box-sizing: inherit; -moz-box-sizing: inherit; box-sizing: inherit; }
		.radiobutton{
			width:20px;
			height:20px;
			background: #363535;
			color: #D3D3D3;
		}
		
		.span{
			padding:20px;
			font-family: Gotham, "Helvetica Neue", Helvetica, Arial, "sans-serif";font-size: 20px;
		}

	</style>
    <title>Uthara Print</title>
</head>

<body>
    <!--Start mainContainer-->
    <div class="mainCon">
        <?php
        include 'header.php';
        ?>
        <div class="content">
                
				
			    <div class="lineheight"></div>
           
           <div class="container-sm productOffers">
                
			   <div class="lineheight"></div>
			   	<div class="productContainet">
                    
                    
                    <div class="productBox transition">
					 <div class="productImage" style="height: auto;text-align: left;"><h3 ><span class="shophead" style="padding-left: 10px">Pay By Phone</span></h3>
					<p><span class="shophead"> Contact on  44 20 3239 9280 and proceed payment.</span></p>
					<p><span class="shophead"> Thank you very much for your order. We will contact you within the next working day and confirm a delivery time for your order. A confirmation email has been sent to daisy.designer@utharaprint.co.uk.</span></p>
					 <p><span class="shophead">Please keep a regular check on your email to view the progress of your order and any order updates. All contact will be made via your online account.</span></p>
						<p><span class="shophead">You have choosen "bank transfer/prepayment" as the payment method for your order.Please transfer the invoice amount to our bank account(bank details given below).The job will be printed and despatched as soon as the payment is received.  Please choose immediate bank transfer and always use your order number as reference while making the payment. Do inform us by email when you have made the payment by the bank transfer to expedite the process. Please be aware that bank transfers can sometimes take up to a couple of working days to be registered within our bank account if you have not choosen to  transfer the payment immediately.</span>
						 <table class="tabl">
						<tr class="tri">
							<td class="Product1"><span >Name</span></td><td class="Product1"> Bumboom Ltd. trading as Uthara Print</td>
						</tr>
								
						<tr class="tri">
							<td class="Product1"><span >Bank Name</span></td><td class="Product1"> Barclays</td>
						</tr>
						<tr class="tri">
							<td class="Product1"><span >Account No.</span></td><td class="Product1"> 5380 5638</td>
						</tr>
						<tr class="tri">
							<td class="Product1"><span >Branch Sort COde</span></td><td class="Product1"> 20-11-43</td>
						</tr>		
						<br/>
							</table></p>
						</div>
                        
                        
                    </div>
					
					
                </div>
			   <!--------------------------->
			      
			   <div class="lineheight"></div>
			   	<div class="productContainet">
                    
                    
                    <div class="productBox transition">
                        <form name="artwork" method="post" action="" enctype="multipart/form-data">
                            <input type="hidden" name="ordId" value="<?php echo $orderId;?>">
                            <div class="productImage" style="height: auto;text-align: left;"><h3 ><span class="shophead" style="padding-left: 10px">Artwork files</span><span style="text-align:center;color: red;font-size:18px;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php if(isset($colName) && $colName!='') { echo "Artwork files uploaded Successfully.";} ?></span></h3>
					<p><span class="shophead">We prefer the artwork file as a print ready pdf format with a  minimum of 3mm bleed . The bleed must be applied after the finished size for us to do the cutting very efficiently.To get very good result on your printing please ensure the artwork is in cnyk, any images used must be minimum of 300 dpi.</span></p>
					 <p><span class="shophead">All artwork files are checked free of cost before we proceed to print and we will notify you if there is a major issue that we might anticipate on your final printed product.</span></p>
						<label style="width: 95%;text-align: left;padding-left: 10px"> <h4 ><span class="shophead">Choose your option below to transfer your artwork file to print</span></h4>
						 <input type="radio" name="artwork"><span class="shophead">Upload 24/7 to our server totally  free</span><br/>
						 <input type="radio" name="artwork"><span class="shophead">Heavy files 24/7 free</span><br/>
						 <input type="radio" name="artwork"><span class="shophead">Email 24/7 free</span>
						 </label>
						 <br/>
						 <div  style="height: auto;margin-top: 20px;">
							 <span class="shophead" style="padding:40px 10px; font-size: 16px;">Upload 24/7 to our server totally  free</span><br/> <table class="tabl">
						<tr class="tri">
                                                    <td class="Product1"><span >Uplaod File 1</span></td><td class="Product1"> <input type="file" name="artwork1" accept="application/pdf, image/png, image/jpg"/></td>
						</tr>
								
						<tr class="tri">
							<td class="Product1"><span >Uplaod File 2</span></td><td class="Product1"> <input type="file" name="artwork2" accept="application/pdf, image/png, image/jpg"/></td>
						</tr>
						<tr class="tri">
							<td class="Product1"><span >Uplaod File 3</span></td><td class="Product1"> <input type="file" name="artwork3" accept="application/pdf, image/png, image/jpg"/></td>
						</tr>
						<tr class="tri">
							<td class="Product1"><span >Uplaod File 4</span></td><td class="Product1"> <input type="file" name="artwork4" accept="application/pdf, image/png, image/jpg"/></td>
						</tr>		
						
							</table>
					   <br/>
					  
					
						
                                           <div><input type="submit" name="submit" class="productPrice" value="File upload"/> &nbsp; &nbsp;
                                               <a href="thanks-you.php" class="productPrice" >Next</a></div>	
					</div>

						</div>
                    </form>
                        
                    </div>
					
					
                </div>
			   <!--------------------------------------------->
			
			   
                    
				   
				   
				   <!-------------------->
				   
					<!------------------->
				   					
			 
				   <!-------------------------->
			   <div class="lineheight"></div>
			   	<div class="productContainet">
                    
                    
                    <div class="productBox transition">
					<div class="productImage" style="height: auto;">
                                        <h4 ><span class="shophead">Phone Number: 44 20 3239 9280</span></h4>			
					<h4 ><span class="shophead">Heavy FIle 24/7 Free</span></h4>
					<p style="text-align: left;"><span class="shophead"><span style="text-transform: uppercase">Send your artwork file via the link below</span>
					<br/>
					Please do mention  the order number while sending files through Free File Trasfer</span><br/><span style="color:coral"><strong>E Mail id: </strong>info@utharaprint.co.uk</span>
						<br/>
						<span style="color:blueviolet">CLICK HERE to transfer www.freefiletransfer.com</span></p>
					</div>
                        
                        
                    </div>
					<!-- --------------------------------->
					<div class="productBox transition">
						                     <div class="productImage" style="height: auto;">
                                        <h4 ><span class="shophead">Phone Number: 44 20 3239 9280</span></h4>			
                                        <h4 ><span class="shophead">Email 24/7 Free</span></h4>
					<p style="text-align: left;"><span class="shophead"><span style="text-transform: uppercase">Send your artwork file to the email address below</span>
					<br/>
					Please do mention  the order number while sending your files</span><br/><span style="color:coral"><strong>E Mail id: </strong> info@utharaprint.co.uk</span>
						<br/><br/>
					</p>
						</div>
                        
                        
                    </div>
					
					
                </div>
			   
<!---------------------------------------------->
			   
			   <!------------------------>
			   </div>
            </div>
			
           
        </div>
	<?php
        include 'footer.php';
        ?>
    </div>
    <!--End mainContainer-->
    <!--script-->
    
    <script type="text/javascript" src="js/jquery.min.js"></script>
    <script type="text/javascript" src="js/function.js"></script>

</body>
</html>