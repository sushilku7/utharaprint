<?php
ob_start();
session_start();
error_reporting (E_ALL ^ E_NOTICE);
include('includes/top_header.php');
$tempProductDAO    = new ProductDAO();
$tempProductMainCatDAO = new ProductMainCategoryDAO();
$tempProductCatDAO = new ProductCatDAO();
$tempDesignFinalorderDAO = new DesignFinalorderDAO();
$tempMemberDAO     = new MemberDAO();
$tempBannerDAO      = new BannerDAO();
$tempArr           = array();
$productCart       = array();
$productId         = $_POST['proId'];
$productDeliveTime = $_POST['productDeliveTime'];
$memberId=$_SESSION['memberId'];
$tempOurbrandDAO = new OurbrandDAO();
$tempOurbrandResult = $tempOurbrandDAO->OurbrandList();
$tempMemberVO = $tempMemberDAO->getMemberDetails($memberId);
//print_r($tempMemberVO);
//$memberName=$tempMemberVO->getFirstName();
$memberEmail=$tempMemberVO->getMemberEmail();
$memberAddress=$tempMemberVO->getMemberAddress1();
$memberPostalCode=$tempMemberVO->getMemberPostalCode();
$totalProductAmt=$_POST['productAmount'];
$item_name =$_POST['productName'];
$item_amount=$_POST['productPrice'];
$paymentMethod = $_POST['payment'];

if(empty($_SESSION['memberId']) && $_SESSION['memberId']=='')
    {           
     header('location:login.php');
    }
    
       if(isset($_POST['paypal']))
        {
				
			    $item_name = $_POST['productName'];
				$totalPriceWithVat = $_POST['productPrice'];
				$packageName = $_POST['packageName'];
                $totalAmountWithVat=$totalPriceWithVat;
				$vatAmt="";
                $finalPrice = $totalAmountWithVat+($totalAmountWithVat*3.5)/100;
	        	$item_amount = number_format($finalPrice, 2, '.', '');
                $orderId =  $tempDesignFinalorderDAO->addDesignOrder($memberId, $memberName, $item_name, $item_amount, $vatAmt, $paymentMethod, $memberEmail);
                $custom = $orderId;
				$customId = base64_encode($orderId);
                $paypal_email = "sales@utharaprint.co.uk";
                $return_url   = "https://utharaprint.co.uk/order-design-artwork.php?$customId";
                $cancel_url   = "https://utharaprint.co.uk/payment-unsuccess.php?cusId=".$orderId;
                $notify_url   = "https://utharaprint.co.uk/payment-success.php";
                // Check if paypal request or response
                if(!isset($_POST["txn_id"]) && !isset($_POST["txn_type"]))
                {	
                        $querystring .= "?business=".urlencode($paypal_email)."&";								
                        $querystring .= "item_name=".urlencode($item_name)."&";
                        $querystring .= "amount=".urlencode($item_amount)."&";
                        $querystring .= "cmd=_xclick&currency_code=AUD&first_name=".$firstName."&last_name=".$lastName."&payer_email=".$memberEmail."&item_number=".$orderId."&";
                        $querystring .= "notify_url=".urlencode($notify_url)."&";
                        $querystring .= "cancel_return=".urlencode($cancel_url)."&";
                        $querystring .= "custom=".urlencode($custom)."&";
                        $querystring .= "return=".urlencode($return_url);
						//header('location: https://www.sandbox.paypal.com/cgi-bin/webscr'.$querystring);
                        header('location: https://www.paypal.com/cgi-bin/webscr'.$querystring);
                        exit();					
                }
       }
	   
      if(isset($_POST['bankpayment'])&& $_POST['bankpayment']!='')
       {
            
			$item_name = $_POST['productName'];
			$totalPriceWithVat = $_POST['productPrice'];
			$packageName = $_POST['packageName'];
			$item_amount=$totalPriceWithVat;
			$vatAmt="";
            $paymentMethod="Bank Transfer";
		    $banktransId = $_POST['banktransId'];
            $orderId =  $tempDesignFinalorderDAO->addDesignOrder($memberId, $memberName, $item_name, $item_amount, $vatAmt, $paymentMethod, $memberEmail);
            $custom = base64_encode($orderId);
           //die();
           header("Location:order-design-artwork.php?$custom");
           exit();
       }
	   
	   if(isset($_POST['paybyphone'])&& $_POST['paybyphone']!='')
       {
			$item_name = $_POST['productName'];
			$totalPriceWithVat = $_POST['productPrice'];
			$packageName = $_POST['packageName'];
			$item_amount=$totalPriceWithVat;
			$vatAmt="";
           $paymentMethod="Pay by Phone";
            $orderId =  $tempDesignFinalorderDAO->addDesignOrder($memberId, $memberName, $item_name, $item_amount, $vatAmt, $paymentMethod, $memberEmail);
           $custom = base64_encode($orderId);
          
           header("Location:order-design-artwork.php?$custom");
           exit();
       }
  
   ?>