<?php
ob_start();
session_start();
error_reporting (E_ALL ^ E_NOTICE);
include('includes/top_header.php');
$tempProductDAO = new ProductDAO();
$tempProductCatDAO = new ProductCatDAO();
$tempProductMainCatDAO = new ProductMainCategoryDAO();
$tempBannerDAO = new BannerDAO();
$prodcutCatAlias      = $_GET['alias'];
//echo $prodcutCatAlias;

$tempProductCatVO   = $tempProductCatDAO->getProductCatDetailsByAlias($prodcutCatAlias);
//echo count($tempProductCatVO);die();
$productCatId        = $tempProductCatVO->getProductCatId();
$productCatName      = $tempProductCatVO->getCatName();
$video1              = $tempProductCatVO->getVideo1();
$video2              = $tempProductCatVO->getVideo2();
$catDesc             = $tempProductCatVO->getPageDesc();
$catTitle             = $tempProductCatVO->getCatMainDescHead();
$pageTitle            = $tempProductCatVO->getPageTitle();
$pageMetaTitle        = $tempProductCatVO->getPageMetaTitle();
$pageMetaDesc         = $tempProductCatVO->getPageMetaDesc();
$pageKeyword          = $tempProductCatVO->getPageKeyword();
$ogTitle              = $tempProductCatVO->getPageRobots();
$ogDescription           = $tempProductCatVO->getPageAuthor();
$url = $_SERVER['REQUEST_URI'];
$urlArray = explode('/', $url);
$lastUrl  = end($urlArray);
$tempOurbrandDAO = new OurbrandDAO();
$tempOurbrandResult = $tempOurbrandDAO->OurbrandList();
$tempProductCatResult = $tempProductCatDAO->ProductCatListByCatId($productCatId);
$tempRelevantProductCatResult = $tempProductCatDAO->RelevantProductCatList($productCatId);

$samplePackBanner1=6;


?>


<!DOCTYPE html>
<html lang="en">

<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    
    <meta name="robots" content="noodp, noydir" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width; initial-scale=1.0; maximum-scale=1.0">
    <meta name="description" itemprop="description" content="<?php echo $pageMetaDesc;  ?>" />
    <meta name="keywords" content="<?php echo $pageKeyword;  ?>" />
    <meta property="og:title" content="<?php echo $ogTitle; ?>" />
    <meta property="og:description" content="<?php echo $ogDescription; ?>" />
    <meta name="google-site-verification" content="9C_dievVwvBOqgAyN1DyW5kWPkmIrEF-tFI-mt2G-qk" />
<!-- Global site tag (gtag.js) - Google Analytics -->

<script async src="https://www.googletagmanager.com/gtag/js?id=UA-124567498-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', 'UA-124567498-1');

</script>
    <!--css-->
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/responsive.css">
    
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
   
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
    <!--css-->
   
	<style>
		
	* { -webkit-box-sizing: border-box; -moz-box-sizing: border-box; box-sizing: border-box; }
*:before, *:after { -webkit-box-sizing: inherit; -moz-box-sizing: inherit; box-sizing: inherit; }

		.disable{
			pointer-events: none;
			background: rgba(255,255,255,25);
			opacity: 0.0;
			max-width: 160px;
		}

	</style>
    <title><?php echo $pageTitle; ?></title>
</head>

<body>
    <!--Start mainContainer-->
    <div class="mainCon">
        <?php include 'header.php'; 
        
        #### url fix start  ####
        $res        = mysql_query("select * from tbl_product_cat where dirName='$prodcutCatAlias' AND parent='0' AND catStatus='1' ");
        $count      = mysql_num_rows($res);
        
        if($count>0 && $count!=0)
        {
        ?>
        <div class="content">
                
			<div class="lineheight" id="line"></div>	
			
           
			<div class="lineheight"></div>
           <div class="container-sm productOffers">
                <h1 class="mainHd"><?php echo $productCatName; ?></h1>
                <div class="productContainet flex">
                    <?php
                            
                              if(count($tempProductCatResult)>0)
                                                         {
                                                               $count = 1;
                                                               for($i=0;$i<count($tempProductCatResult);$i++)
                                                                {
                                                                   $tempProductCatVO = $tempProductCatResult[$i];
                                                                   $productName      = $tempProductCatVO->getcatName();
                                                                   $productCatId     = $tempProductCatVO->getProductCatId();
                                                                   $productImg       = $tempProductCatVO->getImagePath();
                                                                   $dirName          = $tempProductCatVO->getDirName();
                                                                   $aliasName        = $tempProductCatVO->getCatAlias();
                                                                   $shortCatDesc     = $tempProductCatVO->getShortDesc();
                                                                   $pageDesc     = $tempProductCatVO->getPageDesc();
                                                                   $arrayName   = explode('(', $productName);
                                                                   $productName = $arrayName[0];
                                                                   if($productImg=="" || $productImg==NULL)
                                                                   {
                                                                       $productImg = "no-preview.jpg";
                                                                   }
                                                             echo "<div class='productBox transition width'>
                        <div class='productImage' style='height: auto;'> <a href='$lastUrl/$dirName.html' class='productLink'><img src='upload/productcategory/$productImg' alt='$productName'/ ></a>
						
                        </div>
			
                            <div class='productitle'>
                                <a href='$lastUrl/$dirName.html' class='first'>$productName</a>
                               
                            </div>
                       
			<a href='$lastUrl/$dirName.html'><div class='productPrice' >Order Now</div></a>
                       
                    </div>";  
                                                          /*   if($count%5==0 & $count!=0)
                                                             {
                                                                 echo "</div><div class='lineheight'> </div><div class='productContainet flex'>";
                                                             }*/
                                                             $count=$count+1;
                                                                }
                                                         }
                                  ?>                       
                    
                    
             	</div>
                </div>
                        <div class="container-sm productOffers">
			   <div class="lineheight"></div>
			   <div class="productContainet">
                     
					<!------------------>
					 <div class="productBox transition">
                        <div class="productImage" style="height: auto;"><?php echo "<h3 style='padding-left: 13px;'>$productCatName</h3>$catDesc";?>
				
						</div>
                    </div>
					
					 
					
             	
                </div>
		<div class="lineheight"></div>
		
	<div class="row">
<div class="col-sm-6 col-xs-12">
	<div class="productImage">
		<div class="videoWrapper">
    <?php echo $video1; ?>
</div>
		</div>

</div>
<div class="col-sm-6 col-xs-12">
	<div class="productImage">
<div class="videoWrapper">
    <?php echo $video2; ?>
</div>
</div>
</div>
</div>
<script>
	// Find all YouTube videos
var $allVideos = $("iframe[src^='//www.youtube.com']"),

    // The element that is fluid width
    $fluidEl = $("body");

// Figure out and save aspect ratio for each video
$allVideos.each(function() {

  $(this)
    .data('aspectRatio', this.height / this.width)

    // and remove the hard coded width/height
    .removeAttr('height')
    .removeAttr('width');

});

// When the window is resized
$(window).resize(function() {

  var newWidth = $fluidEl.width();

  // Resize all videos according to their own aspect ratio
  $allVideos.each(function() {

    var $el = $(this);
    $el
      .width(newWidth)
      .height(newWidth * $el.data('aspectRatio'));

  });

// Kick off one resize to fix all videos on page load
}).resize();</script>

			   
           
			</div>
            
	
                </div>
                <?php  }
                else{
                include'404file.php';
                }
                #### url fix end  #### 
                ?>
        </div>
	
        <?php
            include 'footer.php';
        ?>
    </div>
    <!--End mainContainer-->
    <!--script-->
    
    <script type="text/javascript" src="js/jquery.min.js"></script>
    <script type="text/javascript" src="js/function.js"></script>

</body>

</html>