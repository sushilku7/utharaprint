<?php
ob_start();
session_start();
error_reporting (E_ALL ^ E_NOTICE);
define("base_url","https://utharaprint-london.co.uk/");
include('includes/top_header.php');
$tempProductDAO     = new ProductDAO();
$tempProductCatDAO  = new ProductCatDAO();
$tempVatDAO         = new VatDAO();
$tempBannerDAO      = new BannerDAO();
$tempProductMainCatDAO = new ProductMainCategoryDAO();

$prodcutMainCatAlias      = $_GET['alias'];
//print_r($prodcutMainCatAlias);

$tempOurbrandDAO = new OurbrandDAO();
$tempTailormadDesignDAO = new TailormadDesignDAO();
$tempOurbrandResult = $tempOurbrandDAO->OurbrandList();
$CatAlias           = $_GET['alias'];
$aliasArra=explode('/',$CatAlias);
$productUrl = $aliasArra[0];
//print_r($aliasArra);die();
//For Products' Main Category
$mainProductCatAlias = $aliasArra[0];
$tempProductMainCatVO     = $tempProductCatDAO->getProductCatDetailsByAlias($aliasArra[0]);
$productMainCatId         = $tempProductMainCatVO->getProductCatId();
$productMainCatName       = $tempProductMainCatVO->getCatName();

$tempRelevantProducMaintCatResult = $tempProductCatDAO->RelevantProductCatList($productMainCatId);

//For Products' Paper Category
$prodcutCatAlias=end($aliasArra);
$url = $_SERVER['REQUEST_URI'];
$urlArray = explode('/', $url);
$firstUrl  = $urlArray[0];
$secondUrl  = $urlArray[2];
$thirdUrl  = $urlArray[3];
$lastUrl  = end($urlArray);
//echo $prodcutCatAlias;
$tempProductVO            = $tempProductDAO->getDefaultProductSizeBasedOnProductCat($prodcutCatAlias);
//print_r($tempProductVO);die();
$prodcutMainCatId         = $tempProductVO->getProductCatId();
$thumbImage               = $tempProductVO->getImagePath();
$productCatId             = $prodcutMainCatId;
$prodcutCatId             = $tempProductVO->getProductSize();
$defaultProductSubCatId   = $tempProductVO->getProductSize();
$MainProductParentId      = $tempProductVO->getParent();
$tempProductCatResult     = $tempProductCatDAO->getProductMainCatDetails($prodcutMainCatId);
//echo $prodcutCatId;
//print_r($tempProductCatResult);die();
$productDesign = $tempProductCatResult->getPageContent();
//echo $productCatId;die();
$templateFiles = $tempProductCatResult->getAnotherImagePath();
$ArtworkGuideLine = $tempProductCatResult->getProductCatDesc();
$vedio              = $tempProductCatResult->getPageVarify();
$tempProductCatVO         = $tempProductCatDAO->getProductCatDetails($defaultProductSubCatId);
//print_r($tempProductCatVO);die();
$productCatName   = $tempProductCatVO->getCatName();
//echo $prodcutMainCatId;die();
$parentId   = $tempProductCatVO->getParent();

$productCatDesc   = $tempProductCatVO->getPageDesc();
$video1              = $tempProductCatVO->getVideo1();
$video2              = $tempProductCatVO->getVideo2();

$templateForArt = $tempProductCatVO->getAnotherImagePath();
$HeadpageTitle = $tempProductCatVO->getPageTitle();
$pageMetaTitle        = $tempProductCatVO->getPageMetaTitle();
$pageMetaDesc         = $tempProductCatVO->getPageMetaDesc();
$pageKeyword          = $tempProductCatVO->getPageKeyword();
$jsonScript           = $tempProductCatVO->getPageRobots();
$ogDescription           = $tempProductCatVO->getPageAuthor();
$pageTitle            = $tempProductCatVO->getPageTitle();

$dirName            =  ucfirst($tempProductCatVO->getDirName());
$productCatDesc     = $tempProductCatVO->getPageDesc();
$productCatSpec     = $tempProductCatVO->getProductSpec();
$productCatArtReq   = $tempProductCatVO->getProductReqrmnt();

$tempTailormadDesignVO = $tempTailormadDesignDAO->getDesignDetails($parentId);
$taylorMadeId = $tempTailormadDesignVO->getTaylorId();
$designPrice = $tempTailormadDesignVO->getDesignCharges();
$designProdCatId = $tempTailormadDesignVO->getProductCatId();
$designDetails = $tempTailormadDesignVO->getProductDesc(); 
//print_r($designDetails);die();
$productVatStatus = $tempProductCatVO->getVat();

 $tempNProductVO                =  $tempProductDAO->getDefaultProductPaperSize($defaultProductSubCatId,$prodcutMainCatId);
 $defaultProductPaperSize       =  $tempNProductVO->getProductSize();
 $defaultProductPaperType       =  $tempNProductVO->getProductPaper(); 
 $defaultProductPrintType       =  $tempNProductVO->getProductPages(); 
 $defaultProductFinishSize       =  $tempNProductVO->getFinishSize();
 //echo $defaultProductFinishSize;die();
 $tempNProductPrintingType      =  $tempProductDAO->getDefaultProductPrintType($prodcutMainCatId,$defaultProductSubCatId,$defaultProductPrintType);
 $tempProductResult             =  $tempProductDAO->getDefaultProductPaperType($prodcutMainCatId,$defaultProductSubCatId,$defaultProductPaperType);

 $tempProductPriceVO            =  $tempProductDAO->getDefaultProductPriceList($prodcutMainCatId,$defaultProductSubCatId,$defaultProductPaperType,$defaultProductPrintType);
 $defaultProductQty             =  $tempProductPriceVO->getProductQty(); 
 $defaultProductId              =  $tempProductPriceVO->getProductId(); 
 $defaultProductPrice           =  $tempProductPriceVO->getProductPrice();
 $defaultProdfitMargin          =  $tempProductPriceVO->getProfiteMargine();
 
 $tempProductQtyResult                =  $tempProductDAO->getProductQuantityList($defaultProductSubCatId);
 $request_uri=$_SERVER['REQUEST_URI'];
 $host_uri=$_SERVER['HTTP_HOST'].$_SERVER['REQUEST._URI'];
 $url = "http://".$host_uri.$request_uri;
 $tempProductCatResult = $tempProductCatDAO->ProductCatList();
 $tempProductCatVO      = $tempProductCatDAO->getParentProductName($parentId);
 $ParentProduct   = $tempProductCatVO->getCatName();
 $printoption="free";
 $samplePackBanner1=6;
 
$tempProductCatRes     = $tempProductCatDAO->ProductCatListforMetaTag($prodcutMainCatId);

//print_r($tempProductCatRes);


 $tempRelevantProductCatResult = $tempProductCatDAO->RelevantProductCatList($prodcutMainCatId);
$description= strip_tags($productCatDesc);
?>
<!DOCTYPE html>
<html lang="en">

<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
   
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width; initial-scale=1.0; maximum-scale=1.0">
	 <link rel="icon" type="image/png" href="favicon-32x32.png" sizes="32x32" />
	
    <meta name="description" itemprop="description" content="<?php echo $pageMetaDesc;  ?>" />
    <meta name="keywords" content="<?php echo $pageKeyword;  ?>" />
    <meta property="og:title" content="<?php echo $ogTitle; ?>" />
    <meta property="og:description" content="<?php echo $ogDescription; ?>" />
    <!--css-->
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    <link rel="stylesheet" href="<?php echo base_url;?>/css/style.css">
    <link rel="stylesheet" href="<?php echo base_url;?>/css/responsive.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    
	 <script type="text/javascript" src="<?php echo base_url;?>/js/jquery.min.js"></script>	
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
    
    
	<link rel="stylesheet" href="<?php echo base_url;?>css/owl.carousel.css" />
	<link rel="stylesheet" href="<?php echo base_url;?>css/owl.theme.default.css" />
    
    <!--css-->
	<script src="<?php echo base_url;?>/js/myjava.js"></script>
   <script type="text/javascript">
jQuery(document).ready(function(e){
	
      jQuery('#showProductPrintType1 .radio_c_print_type').click(function(e){
            jQuery('#showProductPrintType1 .radio_c_print_type label').removeClass('selected');
            jQuery(this).children('.radio_button').addClass('selected');
      });

	jQuery('.tabs .tab-links a').on('click', function(e) {
		var currentAttrValue = jQuery(this).attr('href');

		// Show/Hide Tabs
		jQuery('.tabs ' + currentAttrValue).slideDown(400).siblings().slideUp(400);
		// Change/remove current tab to active
		jQuery(this).parent('li').addClass('active').siblings().removeClass('active');

		e.preventDefault();
	});
});
</script>
	
	 <script type="text/javascript">
jQuery(document).ready(function(e){
	
      jQuery('#showProductPrintType1 .radio_c_print_type').click(function(e){
            jQuery('#showProductPrintType1 .radio_c_print_type label').removeClass('selected');
            jQuery(this).children('.radio_button').addClass('selected');
      });

	jQuery('.tabs .tab-links a').on('click', function(e) {
		var currentAttrValue = jQuery(this).attr('href');

		// Show/Hide Tabs
		jQuery('.tabs ' + currentAttrValue).slideDown(400).siblings().slideUp(400);
		// Change/remove current tab to active
		jQuery(this).parent('li').addClass('active').siblings().removeClass('active');

		e.preventDefault();
	});
});
</script>
	
	  <script type="text/javascript">
            $(document).ready(function() {                
                $('.form-control').on('change', function(event) {                    
                   var newData = new FormData(document.getElementById('productfrm'));
                   // var servername = "http://localhost/utharaprint-australia/showPriceForProductSubCat.php"; //For Localhost
                   var servername = "<?php echo base_url;?>/showPriceForProductSubCat.php"; //For Localhost
                   //alert(servername);
                   
                    $.ajax({        
                        type: "POST",
                        url: servername,
                        data: newData,
                        processData: false,
                        contentType: false,
                        success: function(data) 
                         {            
                                //alert(data);
                                var res = data.split("--------------------");
                                
                                $('#showProductPaperType').html(res[0]);   //Quantiy Price
                                $('#showProductPrintType').html(res[1]);    //Price Div                             
                                $('#ProductDetailDiv').html(res[3]);      //Artwork Charges   
                                $('#turnArnd').html(res[2]);          //Turn Around
                         }
                    }); 
                });
            });

        </script>
        
      <script type="text/javascript">            
            function submitProductDesignForm(val)
            {        
                //alert(val);
                  var printoption;
                   if(val=='1')
                        printoption = 'free';
                   if(val=='2')
                        printoption = 'paid';                    
                    var productCatName        = $('#productCatName').val();
                    var prodcutSubCatId       = $('#prodcutSubCatId').val();
                    var productPaperSize      = $('#productPaperSize').val();
                    var productPrintType      = $('#productPrintType').val();
                    var productPaperType      = $('#productPaperType').val();
                    var productLaminationType = $('#productLaminationType').val();
                    var productNumSets        = $('#productNumSets').val();
		    var designCharges         = $('#designCharges').val();
                    //alert(designCharges);
                    var productFoldType        = $('#productFoldType').val(); 
                    var productPrintPageNum    = $('#productPrintPageNum').val();
                    var productCoverType       = $('#productCoverType').val();
                    var productCutType         = $('#productCutType').val();                   
                    var workingDays           = $('#workingDays').val();
                    var defaultQty            = $('#defaultQty').val();
                    var vatStatus             = $('#vatStatus').val();
                    var prodCatId             = $('#prodCatId').val(); 
					//alert(prodcutSubCatId);					
                    $('#printoption').val(printoption);
					//alert(printoption);
                    var frmData = new FormData(document.getElementById('productfrm'));                   
                    frmData.append("printoption", printoption);
                //var servername = "http://localhost/utharaprint-australia/showPriceForProductSubCat.php"; //For Localhost
                   var servername = "<?php echo base_url;?>/showPriceForProductSubCat.php"; //For Localhost
                   //alert(servername);
                    
                   $.ajax({        
                        type: "POST",
                        url: servername,
                        data: frmData,
                        processData: false,
                        contentType: false,
                        success: function(data) 
                         {                                
                                var res = data.split("--------------------");
                             //   $('#showQtyNPrice').html(res[0]);   //Quantiy Price
                             //   $('#productCartDiv').html(res[1]);  //Price Div
                             //   $('#turnArnd').html(res[2]);        //Turn Around
                             //   $('#upload-allow').html(res[3]);    //Artwork Charges           
                                 $('#showProductPaperType').html(res[0]);   //Quantiy Price
                                $('#showProductPrintType').html(res[1]);  //Price Div
                                $('#ProductDetailDiv').html(res[2]);    //Artwork Charges  
                                $('#showQtyNPrice').html(res[3]);        //Turn Around
                                $('#productCartDiv').html(res[4]);  //     //Turn Around
                                $('#ProductPagesDiv').html(res[5]);
                                $('#ProductFinishSize').html(res[6]);
                         }
                    });                   
            }
            
            
            function submitPriceForm()
            {    
                    //alert('design');
                    var val       = $('#productPrice').val();
					
                    var vatAmt       	= $('#vatAmt').val();
		    var productPrice1   = $('#sushil').val();
				    //var designCharges   = $('#kumar').val();
		   var designc         = $('#designc').val();
					
                    var productId = val;                    
                    var printoption     = $('#printoption').val();
                    var designCharges     = $('#designCharges').val();
                    var vatStatus       = $('#vatStatus').val();
                    var workingDays     = $('#workingDays').val(); 
                    var productDeliveTime = $('#productDeliveTime').val();
		    var prodCatId             = $('#prodCatId').val();
		    var producQty1             = $('#producQty1').val();
		    var prodImage             = $('#prodImage').val();
		    var prodDescription             = $('#prodDescription').val();
		    var prodUrl             = $('#prodUrl').val();
		    var productionTime1             = $('#productionTime1').val();
		    
			//alert('productDeliveTime');		
                   var dataString = 'productId='+ productId + '&printoption=' + printoption +'&vatStatus=' + vatStatus + '&prodCatId=' + prodCatId + '&designCharges=' + designCharges+ '&vatAmt=' + vatAmt + '&productDeliveTime=' + productDeliveTime + '&producQty1=' + producQty1 + '&prodImage=' + prodImage + '&prodDescription=' + prodDescription + '&prodUrl=' + prodUrl + '&productionTime1=' + productionTime1; //workingDays;
                   //var servername = "http://localhost/utharaprint-australia/showprice.php"; //For Localhost
                    var servername = "<?php echo base_url;?>/showprice.php"; //For Localhost
                   //alert(servername + ' - ' + val );
                   //alert(dataSetring);
                   $.ajax({        
                        type: "POST",
                        url: servername,
                        data: dataString,
                        cache: false,
                        success: function(data) 
                         {  
                                //alert(data);
                                var res = data.split("--------------------");
                                $('#showQtyNPrice').html(res[0]); 
                                $('#productCartDiv').html(res[1]);  //Price Div 
                                $('#defaultQtyDiv').html(res[2]);   //Set Default Quantity
                                $('#turnArnd').html(res[3]);
		                        $("#prodId1").val($("#productPrice").val());
		                        
		                        $("#producQty1").val($("#productPrice").find(':selected').text());
		                        $('#showOrderQty').html($("#productPrice").find(':selected').text());
                                /*
                                $('#turnArnd').html(res[4]);        //Turn Around
                                */
                                                           
                         }
                    });                   
            }
            
            function submitForm(productPaperType)
            {    
                 //alert('hi');
                    var prodcutSubCatId       = $('#prodcutSubCatId').val();
                    var productCatName        = $('#productCatName').val();
                    var productPaperSize      = $('#productPaperSize').val();
                    var productPrintType      = $('#productPrintType').val();
                    var productFinishSize      = $('#productFinishSize').val();
                    var productLaminationType = $('#productLaminationType').val();
                    var productNumSets        = $('#productNumSets').val();
                    var productFoldType        = $('#productFoldType').val(); 
                    var productPrintPageNum    = $('#productPrintPageNum').val();
                    var productCoverType       = $('#productCoverType').val();
                    var productCutType         = $('#productCutType').val();                    
                    var defaultQty            = $('#defaultQty').val();
                    var vatStatus             = $('#vatStatus').val();
                   // alert(productPaperSize);
                  
                    $('#productPaperType').val(productPaperType);
		            $("#prodId1").val('');
                    var printoption           = $('#printoption').val();
                    var prodCatId             = $('#prodCatId').val();
                   
                   var newFrmData = new FormData(document.getElementById('productfrm'));  
                   //var servername = "http://localhost/utharaprint-australia/showPriceForProductSubCat.php"; //For Localhost
                   var servername = "<?php echo base_url;?>/showPriceForProductSubCat.php"; //For Localhost
                   //alert(servername);                 
                  $.ajax({        
                        type: "POST",
                        url: servername,
                        data: newFrmData,
                        cache: false,
                        processData: false,
                        contentType: false,
                        success: function(data) 
                         {                                
                                var res = data.split("--------------------");
                            //alert(res);
                                $('#showProductPaperType').html(res[0]);   //Quantiy Price
                                $('#showProductPrintType').html(res[1]);  //Price Div
                                $('#ProductDetailDiv').html(res[2]);    //Artwork Charges  
                                $('#showQtyNPrice').html(res[3]);        //Turn Around
                                $('#productCartDiv').html(res[4]);  //
                                $('#ProductPagesDiv').html(res[5]);
		                        $("#prodId1").val($("#productPrice").val());
                         }
                    });
        
                   
            }
            
            function submitProductPrintTypeForm(productPrintType)
            {    
                 
                    var prodcutSubCatId       = $('#prodcutSubCatId').val();
                    var productCatName        = $('#productCatName').val();
                    var productPaperSize      = $('#productPaperSize').val();
                    var productId             = $('#productId').val();
                    var productLaminationType = $('#productLaminationType').val();
                    var productNumSets        = $('#productNumSets').val();
                    var productFoldType        = $('#productFoldType').val(); 
                    var productPrintPageNum    = $('#productPrintPageNum').val();
                    var productCoverType       = $('#productCoverType').val();
                    var productCutType         = $('#productCutType').val();                    
                    var defaultQty            = $('#defaultQty').val();
                    var vatStatus             = $('#vatStatus').val();
                    $('#productPrintType').val(productPrintType);
                    var printoption           = $('#printoption').val();
                    var prodCatId             = $('#prodCatId').val();
		            $("#prodId1").val('');
                    
                   var newFrmData = new FormData(document.getElementById('productfrm'));  
                   //var servername = "http://localhost/utharaprint-australia/showPriceForProductSubCat.php"; //For Localhost
                   var servername = "<?php echo base_url;?>/showPriceForProductSubCat.php"; //For Localhost
                   //alert(servername);
                  $.ajax({        
                        type: "POST",
                        url: servername,
                        data: newFrmData,
                        cache: false,
                        processData: false,
                        contentType: false,
                        success: function(data) 
                         {                                
                                var res = data.split("--------------------");
                            //alert(res);
                                $('#showProductPaperType').html(res[0]);   //Quantiy Price
                                $('#showProductPrintType').html(res[1]);  //Price Div
                               $('#ProductDetailDiv').html(res[2]);    //Artwork Charges 
                               $('#showQtyNPrice').html(res[3]); //Turn Around
                               $('#productCartDiv').html(res[4]); //Turn Around
                               $('#ProductPagesDiv').html(res[5]);
                               $('#ProductFinishSize').html(res[6]);
                               //alert('hii');
		                       $("#prodId1").val($("#productPrice").val());

                            // alert(html(res[0]));
                         }
                    });
        
                   
            }
			
            function submitProductFinishSizeForm(productFinishSize)
            {    
                 
                    var prodcutSubCatId       = $('#prodcutSubCatId').val();
                    var productCatName        = $('#productCatName').val();
                    var productPaperSize      = $('#productPaperSize').val();
                    var productPrintType      = $('#productPrintType').val();
                    var productId             = $('#productId').val();
                    var productLaminationType = $('#productLaminationType').val();
                    var productNumSets        = $('#productNumSets').val();
                    var productFoldType        = $('#productFoldType').val(); 
                    var productPrintPageNum    = $('#productPrintPageNum').val();
                    var productCoverType       = $('#productCoverType').val();
                    var productCutType         = $('#productCutType').val();                    
                    var defaultQty            = $('#defaultQty').val();
                    var vatStatus             = $('#vatStatus').val();
                    $('#productFinishSize').val(productFinishSize);
                    var printoption           = $('#printoption').val();
                    var prodCatId             = $('#prodCatId').val();
                    
		            $("#prodId1").val($("#productPrice").val());
                    //alert(productFinishSize);
                   var newFrmData = new FormData(document.getElementById('productfrm'));  
                   //var servername = "http://localhost/utharaprint/showPriceForProductSubCat.php"; //For Localhost
                   var servername = "<?php echo base_url;?>/showPriceForProductSubCat.php"; //For Localhost
                   //alert(servername);
                  $.ajax({        
                        type: "POST",
                        url: servername,
                        data: newFrmData,
                        cache: false,
                        processData: false,
                        contentType: false,
                        success: function(data) 
                         {                                
                                var res = data.split("--------------------");
                            //alert(res);
                                $('#showProductPaperType').html(res[0]);   //Quantiy Price
                                $('#showProductPrintType').html(res[1]);  //Price Div
                               $('#ProductDetailDiv').html(res[2]);    //Artwork Charges 
                               $('#showQtyNPrice').html(res[3]); //Turn Around
                               $('#productCartDiv').html(res[4]); //Turn Around
                               $('#ProductPagesDiv').html(res[5]);
                                $('#ProductFinishSize').html(res[6]);
                            
                              var qty= document.getElementById('qty').value;
                              $('#showOrderQty').html(qty);
                            // alert(html(res[0]));
                         }
                    });
        
                   
            }     
			
    function submitProductDeliveryTime()
            {    
               
                   var productDeliveTime       = $('#productDeliveTime').val();
                   var vatAmt1                 = $('#vatAmt').val();
                   var productPrice1       	   = $('#sushil').val();
		   var designCharges1          = $('#kumar').val();
                    var productCatName        = $('#productCatName').val();
                    var prodcutSubCatId       = $('#prodcutSubCatId').val();
                    var productPaperSize      = $('#productPaperSize').val();
                    var productPrintType      = $('#productPrintType').val();
                    var productPaperType      = $('#productPaperType').val();
                    var productLaminationType = $('#productLaminationType').val();
                    var productNumSets        = $('#productNumSets').val();
                  
                    var productFoldType        = $('#productFoldType').val(); 
                    var productPrintPageNum    = $('#productPrintPageNum').val();
                    var productCoverType       = $('#productCoverType').val();
                    var productCutType         = $('#productCutType').val();
                    
                    var workingDays           = $('#workingDays').val();
                    var defaultQty            = $('#defaultQty').val();
                    var vatStatus             = $('#vatStatus').val();
                    var prodCatId             = $('#prodCatId').val();   
                     					
                    //$('#productionTime').val(productDeliveTime);
                    var frmData = new FormData(document.getElementById('productfrm'));
                    
                   
                   //var servername = "https://localhost/utharaprint-australia/showprice.php"; //For Localhost
                   var servername = "<?php echo base_url;?>/showprice.php"; //For Localhost
                   //alert(servername);
                  $.ajax({        
                        type: "POST",
                        url: servername,
                        data: newFrmData,
                        cache: false,
                        processData: false,
                        contentType: false,
                        success: function(data) 
                         {                                
                                var res = data.split("--------------------");
                          //  alert(res);
                                 $('#showProductPaperType').html(res[0]);   //Quantiy Price
                                $('#showProductPrintType').html(res[1]);  //Price Div
                                $('#ProductDetailDiv').html(res[2]);    //Artwork Charges  
                                $('#showQtyNPrice').html(res[3]);        //Turn Around
                                $('#productCartDiv').html(res[4]);  //     //Turn Around
                         }
                    });
        
                   
            }
            
          </script>
      
	
	<style>
		
	* { -webkit-box-sizing: border-box; -moz-box-sizing: border-box; box-sizing: border-box; }
*:before, *:after { -webkit-box-sizing: inherit; -moz-box-sizing: inherit; box-sizing: inherit; }
	
		
		.width1 img{
					   width: 96%;padding-left: 10px;border-radius: 5px;border: 2px #ddd solid
			   }
		input[type="radio"]{
			padding-bottom: 5px;-webkit-appearance:none;width:15px;height: 15px; border: 2px solid #294b8a;border-radius: 1em
			
		}
		input[type="radio"]:checked{
	 border-radius: 1em;	background: radial-gradient( #294b8a , #fff);border: 4px solid #294b8a;/*border-image: radial-gradient(#1e75b3, #fff);*/
		}
		button{
		border: none;border-radius: 10px;
		}
		
</style>
		
			
    <title><?php if($productMainCatId==$MainProductParentId){ echo $pageTitle;}else{ echo "404";}?></title>
</head>

<body id="myFrame">
    <!--Start mainContainer-->
	
    <div class="mainCon">
        <?php include 'header.php'; ?>
        
		<!--url fix start--->
		
		<?php if($productMainCatId==$MainProductParentId){ ?>
        <div class="content">
    	<div class="lineheight"></div>	
			
		<div class="lineheight"></div>
           <div class="container-sm productOffers">
			   <span class="pagelink">
			   
			   <ul >

			 <ul >

				<li style="display: inline"><a href="<?php echo base_url;?>">Home</a></li>  
				<li style="display: inline">></li>  
				<li style="display: inline"><a href="<?php echo base_url.$productUrl;?>"><?php echo $productMainCatName; ?></a></li>   
				<li style="display: inline">></li>   
				<li style="display: inline" id="active"><?php echo $productCatName;?></li>   
				   
				   
			   </ul> 
			   </ul>
			   
			   </span>
           <h2 class="detailhead"><?php echo $productCatName;?> </h2>
			<div class="lineh"></div>
			<div class="lineh"></div>
               <div class="productContainet" style="border: #cccccc 1px solid; border-radius: 5px; box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);">
               <div class="productBox width1" style="background: #dedede;margin-top: 0px; min-height:488px;">
                       <img src="<?php echo base_url;?>/upload/productcategory/<?php echo $thumbImage;?> "  alt=' London' style="padding-bottom:40px"/>
						
					
					
			   </div>
                  
	           <div class="productBox width2" style="padding-left: 10px;border-right: 1px solid">
						
						<h4 style="xtext-align: left;color:#294b8a;font-weight: 550;padding-left: 17px"> Choose your Order </h4>
						
				   <form name="productfrm" id="productfrm">  
                 <input type="hidden" name="productCatName" id="productCatName" value="<?php echo  $productCatName; ?>" />
                 <input type="hidden" name="prodcutSubCatId" id="prodcutSubCatId" value="<?php echo  $defaultProductSubCatId; ?>" />
                 <input type="hidden" name="productPaperSize" id="productPaperSize" value="<?php echo  $defaultProductPaperSize; ?>" />
                 <input type="hidden" name="productPrintType" id="productPrintType" value="<?php echo  $defaultProductPrintType; ?>" />
                 <input type="hidden" name="productPaperType" id="productPaperType" value="<?php echo  $defaultProductPaperType; ?>" />
                 <input type="hidden" name="productLaminationType" id="productLaminationType" value="<?php echo  $defaultProductLaminationType; ?>" />
                 <input type="hidden" name="productNumSets" id="productNumSets" value="<?php echo  $defaultProductNumSets; ?>" />
                 <input type="hidden" name="productCutType" id="productCutType" value="<?php echo  $defaultProductCutType; ?>" />
                 <input type="hidden" name="productFinishSize" id="productFinishSize" value="<?php echo  $defaultProductFinishSize; ?>" />
                 <input type="hidden" name="printoption" id="printoption" value="<?php echo  $printoption; ?>" />
                 <input type="hidden" id='prodId1' name="prodId1" value='<?php echo $defaultProductId;  ?>'  />
                 <input type="hidden" id='producQty1' name="producQty1" value='<?php echo $defaultProductQty;  ?>'  />
                 <input type="hidden" id='prodCatId' name="prodCatId" value='<?php echo $prodcutMainCatId;  ?>'  />    
                 <input type="hidden" id='vatStatus' name="vatStatus" value='<?php echo $productVatStatus;  ?>'  /> 
                 <input type="hidden" id='productDeliveTimeVal' name="productDeliveTimeVal" value='0'  /> 
				 <input type='hidden' id='prodImage' name='prodImage' value='<?php echo $thumbImage ;  ?>'>
				 <input type='hidden' id='prodDescription' name='prodDescription' value='<?php echo $productDesc ;  ?>'>
                 <input type='hidden' id='prodUrl' name='prodUrl' value='<?php echo $url ;  ?>'>
                 <input type='hidden' id='productionTime1' name='productionTime1' value=''  />

				   
				   <div class="option">
							<h5>Choose your Option for Paper Type</h5>
						<ul id="showProductPaperType">
						
                        <?php  echo Dropdown::getDefaultProductPaperType($prodcutMainCatId, $defaultProductSubCatId, $defaultProductQty, $defaultProductPaperType);  ?>	
						
						</ul>
						</div>	
						 
						 <div class="option">
							<h5>Choose your Option</h5>
						<ul id="showProductPrintType">
							<?php  echo Dropdown::getDefaultProductPrintType($prodcutMainCatId, $defaultProductSubCatId, $defaultProductQty, $defaultProductPrintType, $defaultProductPaperType);  ?>							
						</ul>
						</div>
                        
                        <?php if($defaultProductFinishSize!=="" || $defaultProductFinishSize!== null) { ?>
						 <div class="option">
							<h5>Choose your Option</h5>
    						<ul id="ProductFinishSize">
    							<?php  echo Dropdown::getDefaultProductFinishSize($prodcutMainCatId, $defaultProductSubCatId, $defaultProductQty, $defaultProductPrintType, $defaultProductPaperType ,$defaultProductFinishSize);  ?>						
    						</ul>
						</div>
						<?php } ?>
							 </form>
							 <div>
								  <div class="option">
				<span style="padding-right: 30px;padding-left: 17px">Quantity : </span>
							 <span id='showQtyNPrice'><?php           
                                      echo Dropdown::showProductQtyNPriceInTabularFormat($prodcutMainCatId, $defaultProductSubCatId, $defaultProductPrintType, $defaultProductPaperType, $defaultProductFinishSize, $defaultProductQty, $productVatStatus);
                                                        ?>
                                  </span>                      
								 </div>

						 
								  <div id='deliveryEstTime'>
			
<span style="padding-left: 17px">Delivery time : </span>
  <?php
                                           echo Dropdown::showProductDeliveryTime($productCatName);
                                          ?>
                                          </div>
 			</div>			 

							 
				
					</div>
					
					
			   <div class="productBox width3" style="margin-right: 0px;padding-left: px;">
               
               <script type="text/javascript">
               		$(document).ready(function(e) {
                            $('#showOrderDelivery').html($('#productDeliveTime').find(':selected').text());
                            $('#productionTime').html($('#productDeliveTime').find(':selected').text());
                            $('#productionTime1').html($('#productDeliveTime').find(':selected').text());
                            $('#productDeliveTimeVal').val($('#productDeliveTime').find(':selected').val());
                            
                        $('#productPrice').change(function(e) {
                            $('#showOrderQty').html($(this).find(':selected').text());
                        });
						
                        $('#productDeliveTime').change(function(e) {
                            $('#showOrderDelivery').html($(this).find(':selected').text());
                            $('#productionTime1').html($(this).find(':selected').text());
                            $('#productDeliveTimeVal').val($(this).find(':selected').val());
                        });
                    });
               </script>    			
				   
                   <?php
                        
                        echo "<input type='hidden' name='productPriceWOutVat' value='$productPriceWOutVat'>
                             <input type='hidden' name='productPriceWithVat' value='$finalPriceWithVat'>";
                        ?>	
                       
				   <form name='productPricefrm' id='productPricefrm' action='<?php echo base_url;?>shopping-cart.php' method='post' enctype='multipart/form-data'>


				<h4 style="margin-bottom: 10px;color:#294b8a;font-weight: 550" > Your Choosen Item(s)</h4>
				   
  				<div >
					<strong>Product: </strong><span id="showOrderProduct"><?php echo $productCatName; ?></span><br/>
                    <strong>Quantity: </strong><span id="showOrderQty"><?php echo $defaultProductQty; ?></span><br/>
                    <strong>Delivered: </strong><span id="showOrderDelivery">250 Express Delivery</span>
					
				
				</div>
				<br/>
				<?php 
							$productId             = $defaultProductId;
							$pCatId                = $defaultProductSubCatId;
							$productName           = $productCatName;
							$quantity              = $defaultProductQty;
							$productDesc           = $productCatDesc;
							$productPaperSize      = $defaultProductPaperSize;
							$productPrintType      = $defaultProductPrintType;
							$productPaperType      = $defaultProductPaperType;
							$productFinishSize     = $defaultProductFinishSize;                   
							$proBuyPrice           = $defaultProductPrice;
							$profitMargin          = $defaultProdfitMargin;
							
							//Add margin in buying price 
							$margin                = ($proBuyPrice * $profitMargin)/100;
							$finalPriceWithOutVat  =  $proBuyPrice + $margin;
							
							
							$designCharges  = 0.00;                                                                        
							if($productVatStatus=="Yes")
							{
								$qryForVatDetail   = "SELECT rId, vatvalue FROM tbl_vat";
								$result2           = mysql_query($qryForVatDetail);
								$rs2               = mysql_fetch_array($result2);
								$vatRate           = $rs2['vatvalue'];
								$productVatPrice   = ($finalPriceWithOutVat*$vatRate)/100;
								$productVatPrice   = round($productVatPrice, 2);
								
								$finalPriceWithVat = $finalPriceWithOutVat + $productVatPrice;
								//echo "Product Price - ".$productPrice;
							}
							else
							{
								$finalPriceWithVat = $finalPriceWithOutVat;
							}
							
							$totalPrice = $finalPriceWithVat + $designCharges;
							
							$productDesc = $productCatName;
					
										?>
										
		     <div id="showProductPrintType1">
 
    <span class="radio_c_print_type"><input type="radio" name="paperTypeOption" id="r1"  checked><label for="r1" value="1"  onclick="javascript: submitProductDesignForm(1);"  class="radio_button selected">Upload Artwork</label></span>
    <span class="radio_c_print_type"><input type="radio" name="paperTypeOption" id="r2" value="2"  onclick="javascript: submitProductDesignForm(2);"  checked><label for="r2" class="radio_button">Create Artwork</label></span>
    <!--<span class="radio_c_print_type"><input type="radio" name="paperTypeOption" id="r3" checked><label for="r3" class="radio_button">Option 3</label></span>-->
			</div>
			<br/>
			<div class="detailprice" id="productCartDiv">
			    <?php
			    echo   "<input type='hidden' name='proId'                   value='$productId'>
							<input type='hidden' name='qty'                     value='$quantity'>   
							<input type='hidden' name='pCatId'                  value='$pCatId'>    
							<input type='hidden' name='productName'             value='$productCatName'>
							<input type='hidden' name='productImage'            value='$thumbImage'>
							<input type='hidden' name='productPaperSize'        value='$productPaperSize'>
							<input type='hidden' name='productPrintType'        value='$productPrintType'>
							<input type='hidden' name='productPaperType'        value='$productPaperType'>
							<input type='hidden' name='productFinishSize'        value='$productFinishSize'>
							<input type='hidden' name='url'                     value='$url'>
						 
							<input type='hidden' name='productPriceWOutVat'     value='$finalPriceWithOutVat'>
							<input type='hidden' name='productPriceWithVat'     value='$finalPriceWithVat'>
							<input type='hidden' name='vatStatus'   			value='$productVatStatus'>
							<input type='hidden' name='vatFlag'                 value='$productVatStatus'>
							<input type='hidden' name='vateRate'                value='$vatRate'>
							<input type='hidden' name='vatAmount'               value='$productVatPrice'>
						   <input type='hidden' name='designCharges'   			value='$designCharges'>
							<input type='hidden' name='vatFlag'                 value='No'>
							<input type='hidden' name='vateRate'                value='0'>
							<input type='hidden' name='productDeliveTime' id='productionTime'  	   value=''  />
							<input type='hidden' name='productDescription'      value='$productDesc'>";
							
							?>
			    
			<div class='productInfo' style='padding-left: 16px;'>
                                <div class='productLink' > 
								<span> Design Fee : <strong><?php echo "&#163;".number_format($designCharges, 2); ?></strong></span><br/>
								<span> Product  Price : <strong><?php echo "&#163;".number_format($finalPriceWithOutVat, 2); ?></strong></span><br/>
								<span> VAT : <strong><?php echo "&#163;".number_format($productVatPrice, 2); ?></strong></span><br/><br/>
                                </div>
                               
							   <label class='pricelit' style='margin-bottom: 0px'>Total Amount:</label>
							   
		    <span class='pricing' style='padding-top: 0px'><?php echo "&#163;".number_format($totalPrice, 2); ?></span>
							   </div>
				
				
			</div>
			<button type='submit'	class="order" style="margin-top: 10px" name='cart' value='addtocart'><i class="fa fa-shopping-basket" style="font-size: 25px"></i>Order Now</button>
		<button type='submit'	class="order" style="margin-top: 10px; margin-bottom: 10px;" name='quote' value='quote'><i class="fa fa-envelope-open" style="font-size: 25px"></i>Send Quotation</button>
		
			
		</div>
				   </form>
				  <br> 
		      </div>
			
            <!-- The Modal -->
                        <?php
                        $string = strip_tags($productCatDesc);
                        $totallenth = strlen($string);
                        //echo $totallenth;die();
                        if (strlen($string) > 1000) {

                            // truncate string
                            $stringProd = substr($productCatDesc, 0, 1000);
                            $stringMore = substr($productCatDesc, 1000, $totallenth);
                            $endPoint = strrpos($stringCut, ' ');

                        }
                        $stringShort = substr($productCatDesc, 0, 290);
                        $stringTotal = substr($productCatDesc, 1000, $totallenth);
//echo $stringTotal;die();
                        ?> 
                        	 <div class="lineh"></div>
                        	 <div class="lineh"></div>
                        	  <div class="lineh"></div>
                        
			 <div class="productContainet" style="border:#cccccc 1px solid;border-radius:10px; margin-bottom: 5px; box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1)">
			<div class="col-sm-4" style ="margin-bottom: 5px;">			
				    <?php echo $productDesign;?>
							<div class="buttongroup" >
     						    
							<form name="designorder" method="post" action="<?php echo base_url;?>design-payment-proceed.php">
                            <input type="hidden" name="porductName" value="<?php echo $productCatName; ?>">
                            <input type="hidden" name="productPrice" value="<?php echo $designPrice; ?>"> 
                            <input type="hidden" name="designProdCatId" value="<?php echo $designProdCatId; ?>"> 						
                            <label style="float: left;position: relative;">
                                <button type="submit" name="BriefDesigner"  value="Brief Designer" class="designleft" > Brief Designer</button>&nbsp;&nbsp;
				            </label>
                               </form>			
                             <form name="designorder" method="post" action="<?php echo base_url;?>portfolio.php">
                            <input type="hidden" name="porductName" value="<?php echo $productCatName; ?>">
                            <input type="hidden" name="productPrice" value="<?php echo $designPrice; ?>"> 
                            <input type="hidden" name="designProdCatId" value="<?php echo $designProdCatId; ?>"> 						
                            <label style="float: left;position: relative;">
                                <button  type="submit" name="portfolio" value="Portfolio" class="designright" > View Portfolio</button>
                            </label>			
                        </form>
                        </div>
     					<!--	<div class="buttongroup" >
     						    
        						<a href="<?php echo base_url;?>order-design.php" target="_blank" class="designleft" style="border-radius: 10px"> Breif Designer</a>
                                <a href="<?php echo base_url;?>portfolio.php" target="_blank" class="designright" style="border-radius: 10px"> View Portfolio</a>
                                
    				        </div> -->
    				        <br/><br/><br/>
					   	<div class="space" style="background: #294b8a"></div>
    				        <div> <img src="<?php echo base_url;?>images/banner_03.jpg" alt="Custom Designer Order Now in London"> </div>
				
			</div>
			<div class="col-sm-8">
			<img class="img-fluid" alt="Custom Designer Banner Australia" src="<?php echo base_url;?>images/banner_02.jpg">
			</div>
			
		</div>
            
			 <div class="lineh"></div>
			<div class="lineh"></div>
				   
				   <!------------------->
				   <div class="productContainet" style="">
              
			    
			   <div class="productBox width2" style="margin-top: 20px;border: 1px solid #ccc">
						
			   <span class="order" style="border-radius: 0;background: #255d9c"> You may also like to Buy </span>
			   <div class="options">
						<ul>
			       <?php //print_r($tempProductMainCatResult);
			       
                            $tempProductCatResultNew = $tempProductCatDAO->ProductCatListByCatId($prodcutMainCatId);
                            
                              if(count($tempProductCatResultNew)>0)
                                                         {
                                                            // echo count($tempProductCatResult);
                                                             
                                                               $count = 1;
                                                               for($i=0;$i<count($tempProductCatResultNew);$i++)
                                                                {
                                                                   $tempProductCatVO = $tempProductCatResultNew[$i];
                                                                   $productName      = $tempProductCatVO->getcatName();
                                                                   $productImg       = $tempProductCatVO->getImagePath();
                                                                   $productsubCatID       = $tempProductCatVO->getProductCatId();
                                                                   $dirName          = $tempProductCatVO->getDirName();
                                                                   $aliasName        = $tempProductCatVO->getCatAlias();
                                                                   $arrayName   = explode('(', $productName);
                                                                   $productName = $arrayName[0];
                                                                   if($productImg=="" || $productImg==NULL)
                                                                   {
                                                                       $productImg = "no-preview.jpg";
                                                                   }
                                                                   if($productsubCatID == $defaultProductSubCatId)
                                                                        echo "";
                                                                   else
                                                             echo "<li>
                        <label class='productImage'><a href='".base_url.$mainProductCatAlias."/".$dirName.".html'><img src='".base_url."upload/productcategory/$productImg' style='box-sizing: border-box;justify-content: center' alt='$productName Australia' /> <br/><span>$productName</span></a></label>
			            </li>";  
                                       
								
								
							                      
                                                             $count=$count+1;
                                                                }
                                                         }
                                  ?>   
							
						</ul>
						</div>	
						 
					
			   </div>	   
					   
			 		
			   <div class="productBox width4" style="margin-right: 0px;margin-left: 0px;padding-left: px;">
				<div class="tabs">
	<ul class="tab-links" style="margin-bottom: 0px;margin-top: 0px;">
		<li class="active"><a href="#tab1">Description </a></li>
		<li><a href="#tab2">Artwork Guideline</a></li>
		<li><a href="#tab3">Templates</a></li>
	
	</ul>

	<div class="tab-content" style="margin-top: 0px">
		<div id="tab1" >
			<p><?php echo $productCatDesc; ?><br/>
					   
				 <!--<br/><a href="#" id="myBtn" style="font-size: 12px">Read More...</a> -->
					  </p>
		</div>

		<div id="tab2" class="tab">
		
				
			<p><p><?php echo $jsonScript; ?><br/></p>
		</div>

		<div id="tab3" class="tab">
				<a href="<?php echo base_url; ?>upload/artworkdesigns/<?php echo $templateForArt;?>" class="order" target="_blank"><div  style="text-align: center;width:80%;justify-content: center;">Templates</div></a>
				<div class="lineh"></div>			
                                <div class="productImage col-sm-12" style="height:150px;"><a href="<?php echo base_url; ?>upload/artworkdesigns/<?php echo $templateForArt;?>" style="text-align:center;" target="_blank"><img src="<?php echo base_url;?>images/pdf.png" width="250px" alt="artwork guideline" /></a></div>
			<p></p>
		</div>

	</div>
</div>
	</div>
		    </div>
				  

	<!--------------------------popupstart-------------------------------------->
		
 <div id="myModal1" class="modal" >

  <!-- Modal content -->
	 <div style="padding-top: ;">
      <span class="close1">&times;</span>
    <!--  <h4 class="productPrice"> ProductNAme Design </h4>-->
    </div>
  <div class="modal-content" style=" background: #fff" >
    
    <div class="modal-body" style="display:block;height:100%;">
      <!------------------------------------------->
	
	<div class="productBox transition">
			
				<div class="col-sm-4">			
				  <?php echo $productDesign;?>
							<div class="buttongroup" >
     						    
							<form name="designorder" method="post" action="<?php echo base_url;?>design-payment-proceed.php">
                            <input type="hidden" name="porductName" value="<?php echo $productCatName; ?>">
                            <input type="hidden" name="productPrice" value="<?php echo $designPrice; ?>"> 
                            <input type="hidden" name="designProdCatId" value="<?php echo $designProdCatId; ?>"> 						
                            <label style="float: left;position: relative;">
                                <button type="submit" name="BriefDesigner"  value="Brief Designer" class="designleft" > Brief Designer</button>&nbsp;&nbsp;
				            </label>
                               </form>			
                             <form name="designorder" method="post" action="<?php echo base_url;?>portfolio.php">
                            <input type="hidden" name="porductName" value="<?php echo $productCatName; ?>">
                            <input type="hidden" name="productPrice" value="<?php echo $designPrice; ?>"> 
                            <input type="hidden" name="designProdCatId" value="<?php echo $designProdCatId; ?>"> 						
                            <label style="float: left;position: relative;">
                                <button  type="submit" name="portfolio" value="Portfolio" class="designright" > View Portfolio</button>
                            </label>			
                        </form>
                        </div>
     					<!--	<div class="buttongroup" >
     						    
        						<a href="<?php echo base_url;?>order-design.php" target="_blank" class="designleft" style="border-radius: 10px"> Breif Designer</a>
                                <a href="<?php echo base_url;?>portfolio.php" target="_blank" class="designright" style="border-radius: 10px"> View Portfolio</a>
                                
    				        </div> -->
    				        <br/><br/><br/>
					   	<div class="space" style="background: #294b8a"></div>
    				        <div> <img src="<?php echo base_url;?>images/banner_03.jpg" alt="Custom Designer Order Now in Australia"> </div>
				
			
			    </div>
			    <div class="col-sm-8">
			        <img class="img-fluid" alt="Custom Designer Banner Australia" src="<?php echo base_url;?>images/banner_02.jpg">
			        </div>
						 
		</div>
			
		 </div>


	 
	  
	  <!------------------------------------------>
  </div>

</div>

<script>
	document.getElementById("myFrame").onload = function() {myFunction()};
function myFunction() {
   modal1.style.display = "block";
}
// Get the modal
var modal1 = document.getElementById('myModal1');

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close1")[0];

// When the user clicks on the button, open the modal 
/*btn1.onclick = function() {
  modal1.style.display = "block";
}*/

// When the user clicks on <span> (x), close the modal
span.onclick = function() {
  modal1.style.display = "none";
}

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
  if (event.target == modal1) {
    modal1.style.display = "none";
  }
}
					   </script>
		<!------------------------popupend---------------------------------------->
 

			
</div>

    <div class="lineh"></div>
    		<div class="lineh"></div>
    		<div class="container mt-4">
    		<div class="row">
    			<div class="col-md-12 text-center " ><div class="mainHd" > What Clients Say
    				<span class="space1"> </span>
    				<h4 style="color: #AAA8A8;margin-top: -3px">Review form our happy clients.</h4></div>
    				
    				
    				
    			</div> 	
    		</div>
    	</div>
          <div class="lineh"></div>
          
          <div class="container-sm mt-3" >
	 <div class="row">
		<div class="owl-carousel owl-theme" >
			
		  <div class="item" >
			  
			<div class="card">
				<i class="fa fa-quote-left" style="font-size: 28px;position: absolute;top: -1px;left: 10px;color: #294b8a;z-index: 20"></i>
		
				 	<img src="https://lh3.googleusercontent.com/-aIVXOJ_aefA/AAAAAAAAAAI/AAAAAAAAAAA/NDegIERvrzM/w60-h60-p-rp-mo-ba2-br100/photo.jpg" alt="" class="productImage1" style="width: 63px"/>
				<h4 class="reviewname">
							Sean Kavanagh<br/>
						   <small style="font-size: 12px"> London | 2018</small></h4>
					
				<div class="card-body" >
					<h5 class="reviewhead">	Good price and quick to supply</h5>
					<p style="">
					Very happy with our print job. Good price and quick to supply with a good quality product. Also very quick to 
					communicate as well as friendly.</p>
					
				</div>
				
		    </div>
	      </div> 
			
			
			<div class="item">
			<div class="card">
				 <i class="fa fa-quote-left" style="font-size: 28px;position: absolute;top: -1px;left: 10px;color: #294b8a;z-index: 2"></i>
				<img src="https://lh3.googleusercontent.com/-qvjNUCd6ojA/AAAAAAAAAAI/AAAAAAAAAAA/b96qhObxp0I/w60-h60-p-rp-mo-br100/photo.jpg" alt="" class="productImage1" style="width: 63px"/>
				<h4 class="reviewname">Mario Alfonso <br/>
						   <small style="font-size: 12px">London | 2017</small></h4>

		
				<div class="card-body">
			
				<h5 class="reviewhead">
								Quality was very high delivered to our door</h5>
					<p style="">" 
					We ordered Bizz Cards and we paid a fraction of the price of our regular printer in Sydney for Laminated Cards  and the quality was very high delivered to our door cant complain and will use again."</p>
						
					
				</div>
		    </div>
	      </div> 
			
			<div class="item">
			<div class="card">
		    <i class="fa fa-quote-left" style="font-size: 28px;position: absolute;top: -1px;left: 10px;color: #294b8a;z-index: 2"></i>
			 <img src="https://lh4.googleusercontent.com/-49UB7UQg5UI/AAAAAAAAAAI/AAAAAAAAAAA/9GCaY8XvBpg/w60-h60-p-rp-mo-br100/photo.jpg" alt="" class="productImage1" style="width: 63px"/>
				<h4 class="reviewname">Ron Hammond<br/>
			   <small style="font-size: 12px"> London | 2018</small></h4>
				<div class="card-body">
				<h5  class="reviewhead">
					Very pleased with the quality!</h5>
					<p style="">
					We were extremely happy with the service and price offered by Uthara. When the product arrived in a timely manner we were very pleased with the quality.</p>
						
					

				</div>
		    </div>
	      </div> 
			
			<div class="item">
			<div class="card">
				 <i class="fa fa-quote-left" style="font-size: 28px;position: absolute;top: -1px;left: 10px;color: #294b8a;z-index: 2"></i>
			 <img src="https://lh6.googleusercontent.com/-Wmtzi72Ye14/AAAAAAAAAAI/AAAAAAAAAAA/YLfVrNMO8c8/w60-h60-p-rp-mo-br100/photo.jpg" alt=""  class="productImage1" style="width: 63px"/>
			<h4 class="reviewname">Sharron Lodge<br/>
						   <small style="font-size: 12px"> London | 2018 </small><br/>
								
			</h4>
				<div class="card-body">
				<h5 class="reviewhead">
					Exceeded my expectation</h5>
					<p style="">
					Thank you for our note pads they are fabulous and exceeded my expectation</p>
						
					
				</div>
		    </div>
	      </div> 
			
			<div class="item">
			<div class="card">
			 
				<div class="card-body">
					<i class="fa fa-quote-left" style="font-size: 28px;position: absolute;top: -1px;left: 10px;color: #294b8a;z-index: 2"></i>
					<img src="https://lh4.googleusercontent.com/-hEgDxSKdESk/AAAAAAAAAAI/AAAAAAAAAAA/G1OETiujlow/w60-h60-p-rp-mo-br100/photo.jpg" alt=""  class="productImage1" style="width: 63px"/>
							<h4 class="reviewname">Sarah Baker <br/>
						   <small style="font-size: 12px">London | 2017</small></h4>
						
				<h5 class="reviewhead">
					Fantastic experience with Uthara Print</h5>
					<p style="">
					I have had such a fantastic experience with Uthara Print, they were very patient with me and offered great pricing. John and Sana did exceptionally well with following my requests. Thank You :)</p>
						
					
				</div>
		    </div>
	      </div> 
			
			<div class="item">
			<div class="card">
				<i class="fa fa-quote-left" style="font-size: 28px;position: absolute;top: -1px;left: 10px;color: #294b8a;z-index: 2"></i>
			
			 <img src="https://lh6.googleusercontent.com/-qB5GRuhow9A/AAAAAAAAAAI/AAAAAAAAAAA/_QjEnn5dER8/w60-h60-p-rp-mo-ba2-br100/photo.jpg" alt=""  class="productImage1" style="width: 63px"/>
					<h4 class="reviewname">Mike A  <br/>
						   <small style="font-size: 12px"> London | 2019</small></h4>	
				<div class="card-body">
					<h5 class="reviewhead">
					Received services has been professional</h5>
					<p style="">
					So far the service I have received by John has been friendly, professional, not pushy yet courteously provides recommendations. He is knowledgeable and answers my questions in a matter of fact way, which I appreciate.</p>
						
					
				</div>
		    </div>
	      </div> 
			
			<div class="item">
			<div class="card">
				<i class="fa fa-quote-left" style="font-size: 28px;position: absolute;top: -1px;left: 10px;color: #294b8a;z-index: 2"></i>
			
			 <img src="https://lh3.googleusercontent.com/-JDVsWhXigUY/AAAAAAAAAAI/AAAAAAAAAAA/SA9wqMxLNfM/w60-h60-p-rp-mo-br100/photo.jpg" alt="" class="productImage1" style="width: 63px"/>
							<h4 class="reviewname">
							AirBorn Insight<br/>
						   <small style="font-size: 12px"> London | 2018</small></h4>
				<div class="card-body">
				<h5 class="reviewhead">
					Great service with quick turnaround</h5>
					<p style=""> 
					Great service with quick turnaround on our new business cards. Thankyou!  :)</p>
						
								
				</div>
		    </div>
	      </div> 
			
			<div class="item">
			<div class="card">
				<i class="fa fa-quote-left" style="font-size: 28px;position: absolute;top: -1px;left: 10px;color: #294b8a;z-index: 2"></i>
			
			<img src="https://lh4.googleusercontent.com/-vujsUZrRrXw/AAAAAAAAAAI/AAAAAAAAAAA/mGWBtB5GfuU/w60-h60-p-rp-mo-br100/photo.jpg" alt="" class="productImage1" style="width: 63px"/>
					<h4 class="reviewname">
							Arkag<br/>
						   <small style="font-size: 12px"> London | 2018</small></h4>
				<div class="card-body">
				<h5 class="reviewhead">
					Excellent</h5>
					<p style="padding: 10px">
					Good value business cards. Quick delivery. Good job!</p>
						
								
				</div>
		    </div>
	      </div> 
			
			
	    </div>
	 </div>
	 
	<div class="lineh"></div>
	<div class="lineh"></div>
	
	</div>
      
           
        </div>
        <?php }
        else {
            include'404file.php';
        }
        
         #### url fix start  ####
            include 'footer.php';
        ?>
  
    <!--End mainContainer-->
    <!--script-->
    
    
<script type="text/javascript" src="<?php echo base_url;?>js/owl.carousel.js" ></script>
<script type="text/javascript" src="<?php echo base_url;?>js/owl.carousel.min.js" ></script>

    <script type="text/javascript" src="<?php echo base_url;?>/js/function.js"></script>
	
	<script>
    	$('.owl-carousel').owlCarousel({
        loop:true,
        margin:10,
    	responsiveClass:true,
        nav:false,
    		autoplay:100,
       responsive:{
            0:{
                items:1
            },
            600:{
                items:2
            },
            1000:{
                items:3
            }
        }
    });
	
	</script>
	<style>
	
	responsive:{
    // breakpoint from 0 up
    0 : {
        option1 : value,
        option2 : value,
        ...
    },
    // breakpoint from 480 up
    480 : {
        option1 : value,
        option2 : value,
        ...
    },
    // breakpoint from 768 up
    768 : {
        option1 : value,
        option2 : value,
        ...
    }
}
		.card-body{
			text-align: center;
		
		}
		.item:nth-child(n){
			background: #fff;border: #fff solid 1px ;
			
		}
		.item:nth-child(3n){
			background: #eee;border: #fff solid 1px ;
			
		}
		
		

		.card-body p{
			width:100%;float: left;text-align: center;padding:0px 10px 10px 10px;font-size: 14px; color: #827E7E
			
		}
		.card{
			border:#BFBEBE solid 1px ;border-radius: 10px;padding: 10px;height:230px;justify-content: center
				
			
		}
	</style>

</body>

</html>