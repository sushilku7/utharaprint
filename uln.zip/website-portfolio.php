<?php
ob_start();
session_start();
error_reporting (E_ALL ^ E_NOTICE);
include('includes/top_header.php');
$tempProductDAO    = new ProductDAO();
$tempProductMainCatDAO = new ProductMainCategoryDAO();
$tempPortfolioDAO = new PortfolioDAO();
$tempProductCatDAO = new ProductCatDAO();
$arra1 = explode('?',$_SERVER['REQUEST_URI']);
$orderId = ($arra1[1]);
$orderNo=base64_decode($orderId);

        $serial=$_POST['serial'];
	$designName="designName".$serial;
	$designPrice="designPrice".$serial;
	$packageName="packageName".$serial;
	$portfolio="portfolio".$serial;       
        $productCatId="productCatId".$serial;
	$productCatId=$_POST[$productCatId];
	$productName=$_POST[$designName];
	$productPrice=$_POST[$designPrice];
	$packageName = $_POST[$packageName];
	$portfolio = $_POST[$portfolio];
	$designProdCatId = "2";
    $tempPortfolioResult = $tempPortfolioDAO->portfolioListing($designProdCatId);
    $tempProductCatVO = $tempProductCatDAO->getProductCatDetails($designProdCatId);
    $pageContent = $tempProductCatVO->getPageContent();
if(isset($_SESSION['memberId']) && $_SESSION['memberId']!='')
    {           
    $paymentProceed="design-payment-proceed.php";
    }
 else {
       $paymentProceed="order-design-login.php"; 
    }
?>
<!DOCTYPE html>
<html>
<head>
    <title>Uthara Print Portfolio</title>
    <meta charset="utf-8">
    <meta name="robots" content="noodp, noydir" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/png" href="favicon-32x32.png" sizes="32x32" />
	
	 <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/responsive.css">
 <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
	<style>
		
/* The Modal (background) */
.modal {
  display: none;
  position: fixed;
  z-index: 1;
  padding-top: 100px;
  left: 0;
  top: 0;
  width: 100%;
  height: 100%;
  overflow: auto;
  background-color: rgba(0,0,0,.4);
}

/* Modal Content */
.modal-content {
  position: relative;
  background-color: #fefefe;
  margin: auto;
  padding: 0;
  width: 75%;
  max-width: 800px;
}

/* The Close Button */
.close {
  color: white;
  position: absolute;
  top: 10%;
  right: 25px;
  font-size: 35px;
  font-weight: bold;
}

.close:hover,
.close:focus {
  color: #999;
  text-decoration: none;
  cursor: pointer;
}

.mySlides {
  display: none;
}

.cursor {
  cursor: pointer;
}

/* Next & previous buttons */
.prev,
.next {
  cursor: pointer;
  position: absolute;
  top: 50%;
  width: auto;
  padding: 16px;
  margin-top: -50px;
  color:#fff;
  font-weight: bold;
  font-size: 20px;
  transition: 0.6s ease;
  border-radius: 0 3px 3px 0;
  user-select: none;
  -webkit-user-select: none;
}

/* Position the "next button" to the right */
.next {
  right: 0;
  border-radius: 3px 0 0 3px;
}


/* Number text (1/3 etc) */
.numbertext {
  color: #f2f2f2;
  font-size: 12px;
  padding: 8px 12px;
  position: absolute;
  top: 0;
}

img {
  margin-bottom: -4px;
}

.caption-container {
  text-align: center;
  background-color: black;
  padding: 2px 16px;
  color: white;
}

.demo {
  opacity: 0.6;
}

.active,
.demo:hover {
  opacity: 1;
}

img.hover-shadow {
  transition: 0.3s;
}

.hover-shadow:hover {
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);border: 3px solid #fff;
}
</style>
</head>
<body style="padding:0px; margin:0px; background-color:#fff;font-family:arial,helvetica,sans-serif,verdana,'Open Sans'">
	<?php include 'header.php' ?>
	<div class="lineheight" ></div>
	<div class="lineh"></div>

    <form name="designorder" method="post" action="<?php echo $paymentProceed;?>">	
    <input type="hidden" name="productName" value="<?php echo $productName; ?>">
        <input type="hidden" name="productCatId" value="<?php echo $productCatId; ?>">
   	<input type="hidden" name="packageName" value="<?php echo $packageName; ?>"> 
	<input type="hidden" name="productPrice" value="<?php echo $productPrice; ?>">
    <input type="hidden" name="orderId" value="<?php echo $orderNo; ?>">
	 <div class="productContainet " id="marginall">
<div id="productImage">
	
	<div class="portfoliopara">
		
		<div class="block1">
			<img src="images/portfolio.jpg" alt="portfolio" width="300px" height="300px"/>
			
		<div class="block">
			
			<h1 ><?php echo $productName; ?>
			<span class="space"></span>
			</h1>
			
			<p>Take a closer look at what we could do for your business. 
			It all starts with a well explained brief to our graphic designer. 
			Please cover as much information possible as a good creative design work is only 
			possible when we have all the details about your business. 
			The more information we could get about your project requirement, 
			the better it becomes creating your ideas into a dream reality. 
			We strongly believe in creating things that are out of the box, 'There is no point in advert- ising if you don't get noticed! '
 <br/><br/> 
			<span class="whyus">Why us ?</span><br/><br/>

 &raquo; We have a proven track record for creating fantastic ideas into a design reality.
<br/> &raquo; Experience with Big brands.
<br/> &raquo; Open Pricing Policy- No hidden costs.
<br/> &raquo; High End Design work at very Low Cost.
<br/> &raquo; Dedicated Team for your Projects.
<br/> &raquo;  State of the Art studio using latest softwares for high impact creation. 


			
			</p>
			
			<span class="spaces"></span>
				
			<div style="float:left; width:90%; display: flex; justify-content: flex-end;margin-top:30px;">
		 <ul>
		 <li style="display:inline"><b></b></li>  
        <li style="display:inline"><button type="submit" name="BriefDesigner"  value="Brief Designer" class="brief1" > Next</button></li>
                            <!--<a href="#" class="brief1">Brief Designer</a>-->
                            
                            </ul>
                            </div>
			</div>
   
		</div>
		</div>
	</div>
	</div>
		</form>

<div class="container-sm productOffers">
	<div class="row">
		 <?php
            
            if(count($tempPortfolioResult)>0)
            {
                for($i=0;$i<count($tempPortfolioResult);$i++)
                {
                    $tempPortfolioVO=$tempPortfolioResult[$i];
                    $image = $tempPortfolioVO->getImage();
                   
                    echo 
					"<div class='column'>
    				<img src='upload/portfolio/$image' style='width:100%' onclick='openModal();currentSlide(1)' class='hover-shadow cursor'>
					</div>";
                }
            }
            
            
            ?>
  
 
</div>
</div>
	<div id="myModal" class="modal">
  <span class="close cursor" onclick="closeModal()">&times;</span>
  <div class="modal-content">
 <?php
            
            if(count($tempPortfolioResult)>0)
            {
                for($i=0;$i<count($tempPortfolioResult);$i++)
                {
                    $tempPortfolioVO=$tempPortfolioResult[$i];
                    $image = $tempPortfolioVO->getImage();
                   
                    echo 
					"<div class='mySlides'>
    				<img src='upload/portfolio/$image' style='width:100%' >
					</div>";
                }
            }
            
            
            ?>
   
	  
    <a class="prev" onclick="plusSlides(-1)">&#10094;</a>
    <a class="next" onclick="plusSlides(1)">&#10095;</a>

   <!-- <div class="caption-container">
      <p id="caption"></p>
    </div>-->

  </div>
</div>

<script>
function openModal() {
  document.getElementById('myModal').style.display = "block";
}

function closeModal() {
  document.getElementById('myModal').style.display = "none";
}

var slideIndex = 1;
showSlides(slideIndex);

function plusSlides(n) {
  showSlides(slideIndex += n);
}

function currentSlide(n) {
  showSlides(slideIndex = n);
}

function showSlides(n) {
  var i;
  var slides = document.getElementsByClassName("mySlides");
  var dots = document.getElementsByClassName("demo");
  var captionText = document.getElementById("caption");
  if (n > slides.length) {slideIndex = 1}
  if (n < 1) {slideIndex = slides.length}
  for (i = 0; i < slides.length; i++) {
      slides[i].style.display = "none";
  }
  for (i = 0; i < dots.length; i++) {
      dots[i].className = dots[i].className.replace(" active", "");
  }
  slides[slideIndex-1].style.display = "block";
  dots[slideIndex-1].className += " active";
  captionText.innerHTML = dots[slideIndex-1].alt;
}
</script>
    <!-- #region Jssor Slider Begin -->
    <!-- Generator: Jssor Slider Maker -->
    <!-- Source: https://www.jssor.com -->
   
	
	<?php include 'footer.php' ?>

	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<script type="text/javascript" src="js/jquery.min.js"></script>
    <script type="text/javascript" src="js/function.js"></script>

</body>
</html>
