 <!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width; initial-scale=1.0; maximum-scale=1.0">
    <!--css-->
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/responsive.css">
    
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
   
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
    <!--css-->
	<script src="js/html5.js"></script>
	<style>
	
		* { -webkit-box-sizing: border-box; -moz-box-sizing: border-box; box-sizing: border-box; }
*:before, *:after { -webkit-box-sizing: inherit; -moz-box-sizing: inherit; box-sizing: inherit; }

.center{
	
			position:relative;
	margin-top: 30px;
			top: 25%;left:50%;
			transform: translate(-50%, -50%);
		}
		.center span{
			font-size: 16px;font-family:Segoe, "Segoe UI", "DejaVu Sans", "Trebuchet MS", Verdana, "sans-serif";color: #ff6347;padding-left: 20px;font-style: normal;
		}
		input[type="checkbox"]{
			position: relative;width: 100px;height: 30px;
			-webkit-appearance:none;
		background: linear-gradient(0deg, #333 , #000);
			outline: none;border-radius: 20px;
			box-shadow: 0 0 0 4px #353535, 0 0 0 5px #3e3e3e, inset 0 0 10px rgba(0,0,0,1), 0 5px 15px rgba(0,0,0,.5), inset 0 0 15px rgba(0,0,0,.2);
		}
		input:checked[type="checkbox"]{
		background: linear-gradient(0deg, #ff6347 , #800000);
		}
		input[type="checkbox"]:before{
			position: absolute;content: '';width: 70px;height: 30px;top:0;left:0;
			background: linear-gradient(0deg, #000 , #6b6b6b);
			border-radius: 20px;box-shadow: 0 0 0 1px #232323;
			transform: scale(.98, .96);
			transition: .5s;
		}
		input:checked[type="checkbox"]:before{
			left:30px;
		}
		input[type="checkbox"]:after{
			position: absolute;content: '';width: 4px;height: 4px;top:calc(50% - 2px);left:55px;
			background: linear-gradient(0deg, #6b6b6b , #000);
			border-radius: 50%;
			
			transition: .5s;
		}
		input:checked[type="checkbox"]:after{
			background: #ff6347;
			left:85px;box-shadow: 0 0 5px #ff6347,0 0 15px #ff6347;
		}

	</style>
</head>

<body>

    <body><div class="mainCon">
        <div class="header" >
            <div class="topHeader" >
				 <div class="container">
					 
                    <a href="index.html"><img src="images/logo4.png" alt="logo" ></a>
				</div>
            </div>
            <div class="container midHeader">
            <ul>
				
				<li class="topHeader_link">
					<a href="#" ><i class="fa fa-search" style="font-size:20px; color:#eee; padding-left:20px;" > </i></a>

				</li>
            <li class="topHeader_link"><a href="#">Order Design</a></li>
            <li class="topHeader_link"><a href="#">Browse all Product</a>
            	<div class="sub">
                <ul >
                <h4>Office</h4>
                <li><a href="#">Compliment Slips</a></li>
                <li><a href="#">Business Cards</a></li>
                <li><a href="#">NCR Pads</a></li>
                <li><a href="#">Letterheads</a></li>
                <li><a href="#">Notepads</a></li>
                <li><a href="#">Envelops</a></li>
                <li><a href="#">Business Card Dispensers</a></li>
                <li><a href="#">Self Linking Stamps</a></li>
                <li><a href="#">Unfinished Printing Sheets</a></li>
                            
                <li><a href="#">Pavement Sign</a></li>
             
                </ul>
                <ul >
                <h4>Marketing</h4>
                <li><a href="#">Leaflet</a></li><li><a href="#">Flyer</a></li>
                <li><a href="#">Laminated Flyer</a></li>
                <li><a href="#">Folded Leaflets</a></li>
                <li><a href="#">Postcards</a></li><li><a href="#">Promocards</a></li><li><a href="#">Booklets</a></li>
               <li><a href="#">Folders</a></li><li><a href="#">Brochure Holders</a></li><li><a href="#">Magnetic Signs</a></li><li><a href="#">Ballot Tickets</a></li>
               <li><a href="#">Perforated Flayers</a></li><li><a href="#">Board Printing</a></li><li><a href="#">Polypropylene Presentation Boxes</a></li><li><a href="#">Magazine Design</a></li>
                </ul>
                <ul >
              	<h4>Promotional</h4>
                <li><a href="#">Sticky Notes</a></li>
                <li><a href="#">Pen</a></li>
                <li><a href="#">Bottle Opener Keyrings</a></li>
                <li><a href="#">Keyring Torches</a></li>
                <li><a href="#">Ballon Printing</a></li>   <li><a href="#">Mugs</a></li>
                <li><a href="#">A3 Desk Pads</a></li>   <li><a href="#">Chritmas Cards</a></li>
                <li><a href="#">Multi tool Keyrings</a></li>   <li><a href="#">Carabiners Keyring </a></li>
                <li><a href="#">Usb Printing</a></li> <li><a href="#">Business Card Holders</a></li>
          
                </ul>
                
          
                <ul >
                <h4>Display Exhibition</h4>
                <li><a href="#">Roll Up Banner Stands</a></li><li><a href="#">Real Estate Sign</a></li>
                <li><a href="#">Pop Up Banner Stands</a></li>
                <li><a href="#">Floor Dumpbins</a></li>
                <li><a href="#">Printed Gazebo Packages</a></li><h4></h4><li><a href="#">Plastic Cards</a></li><li><a href="#">Sticker Printing</a></li><li><a href="#">Ticket Wallet Printing</a></li><li><a href="#">CD & DVD</a></li><li><a href="#">Posters</a></li><li><a href="#">Retail</a></li><li><a href="#">Self Inking Stamps</a></li><li><a href="#">Clothing & Fabrics</a></li><li><a href="#">Photo Print</a></li>
                </ul>
                
                
                
                </div>
            </li>
            <li class="logobox"><a href="#"><img src="images/logo4.png"/></a></li>
            <li class="topHeader_link"><a href="#">Login /Register</a></li>
            <li class="topHeader_link"><a href="#">Upload Your Artwork</a></li>
			<li class="topHeader_link">	<a href="#" ><i class="fa fa-phone-square" style="font-size:20px; color:#eee; " > </i></a>
				<div class="about">
				<ul>
					<li><a href="">About Us</a></li>
					<li><a href="">Contact Us</a></li>
					<li><a href="">Business - Opportunity</a></li>
					
					</ul>
				</div>
				</li>
            </ul>
                
                </div>
            <span class="menuicon" >
                        <i></i>
                        <i></i>
                        <i></i>
                    </span>
          <div class="navCon container">
                <ul class="nav">
                    <li class="nav__item"><a href="#" class="nav-link isActive">Home</a></li>
                    <li class="nav__item"><a href="#" class="nav-link">About Us</a></li>  
                    <li class="nav__item"><a href="https://www.utharaprint-london.co.uk/login.php" class="topHeader_link" class="nav-link">Login/Register</a></li>
                    <li class="nav__item"><a href="https://www.utharaprint-london.co.uk/contactus.php" class="nav-link">Contact Us</a></li>
                    <li class="nav__item"><a href="https://www.utharaprint-london.co.uk/talair-made-design.php" class="topHeader_link" class="nav-link">DesignOrder</a></li>
                    <li class="nav__item"><a href="#" class="nav-link">Product by Category</a>
                        <ul class="subNav transition">
                            <li class="subNav__item"><a href="#" class="subNav-link">Office</a></li>
                            <li class="subNav__item"><a href="#" class="subNav-link">Market</a></li>
                            <li class="subNav__item"><a href="#" class="subNav-link">Out Vision</a></li>
                            <li class="subNav__item"><a href="#" class="subNav-link">About Company</a></li>
                            <li class="subNav__item"><a href="#" class="subNav-link">Our Mision</a></li>
                            <li class="subNav__item"><a href="#" class="subNav-link">Out Vision</a></li>
                            <li class="subNav__item"><a href="#" class="subNav-link">About Company</a></li>
                            <li class="subNav__item"><a href="#" class="subNav-link">Our Mision</a></li>
                            <li class="subNav__item"><a href="#" class="subNav-link">Out Vision</a></li>
                        </ul>
                    </li>
                 </ul>
            </div>
        </div>
                
    
			
             	   
			
		  	<div class="content">
				
				<div class="lineheight"></div>
			
			
			<img src="images/billing.jpg" alt="Online delivery" />
				
				
				
				<div class="productContainet">
                    
                  
			    <div class="productBox transition">
					<center><h3>Billing Address</h3></center>
                        <div class="productImage" style="height: auto; margin: 15px; padding-top: 20px;padding-bottom: 20px">
					<form action="/action_page.php" class="subform">
					
							
 						<input type="text" name="name" class="put1" placeholder="Full Name" required>
						
						<input type="text" name="name" class="put1" placeholder="Comapny Name(Optional)" >	
						
						<br/>
					<input type="text" name="add" class="put1" placeholder="Address" required>
						<input type="text" name="add2" class="put1" placeholder="Address Line 2" ><br/>
						<input type="text" name="city" class="put1" placeholder="City" required>
						<input type="text" name="country" class="put1" placeholder="Country" required><br/>
						<input type="text" name="county" class="put1" placeholder="County" >
						<input type="text" name="postal" class="put1" placeholder="Post Code" required><br/>
						<input type="number" name="phone" class="put1" placeholder="Phone Number(for Courier)" >
						<input type="number" name="mobile" class="put1" placeholder="Mobile Number(for Courier)" required><br/>
						
<br/><br/>
						
						<input type="submit" class="productPrice" value="Save Details">
					
</form>
					</div> 
					
                        
                    </div>
 
					
					<!----------------------------->
					                  
			    <div class="productBox transition">
					 <center><h3>Shipping Address</h3></center>
                        <div class="productImage" style="height: auto; margin: 15px; padding-top: 20px;padding-bottom: 20px">
					<form action="/action_page.php" class="subform">
					
							
 						<input type="text" name="name" class="put1" placeholder="Full Name" required>
					
						<input type="text" name="name" class="put1" placeholder="Comapny Name(Optional)" >	
						
						<br/>
					<input type="text" name="add" class="put1" placeholder="Address" required>
						<input type="text" name="add2" class="put1" placeholder="Address Line 2" ><br/>
						<input type="text" name="city" class="put1" placeholder="City" required>
						<input type="text" name="country" class="put1" placeholder="Country" required><br/>
						<input type="text" name="county" class="put1" placeholder="County" >
						<input type="text" name="postal" class="put1" placeholder="Post Code" required><br/>
						<input type="number" name="phone" class="put1" placeholder="Phone Number(for Courier)" >
						<input type="number" name="mobile" class="put1" placeholder="Mobile Number(for Courier)" required><br/>
						
<br/><br/>
						
						<input type="submit" class="productPrice" value="Save Details">
					
</form>
					</div> 
					
                        
                    </div>
					<!---------------------------------------->
                    
                        
                </div>
			<div class="lineheight"></div>
			<div class="center">
	<input type="checkbox" name="yes"/><span class="Product3">Check if your billing and shipping address are same.</span>
	</div>
			
			<div class="visaCard">
            <img src="images/worldpay.jpg"/>
            <div style="display:flex-start;">
                <img src="images/visa.png">
                </div>
            </div>
        </div>
	
        <div class="footer">
            <div class="container-sm footercon">
                <div class="footerbox">
                    <a href="#" class="footerLink">Lithographic Printing</a>
                    <a href="#" class="footerLink">Digital Printing</a>
                    <a href="#" class="footerLink">Offset Single Printing</a>
                    <a href="#" class="footerLink">Flex and Large Format Printing</a>
                    <a href="#" class="footerLink">Plastic Printing</a>
                    <a href="#" class="footerLink">Packaging Printing</a>
                    <a href="#" class="footerLink">Promotional Printing</a>
                    <a href="#" class="footerLink">Clothing Printing</a>
					<a href="#" class="footerLink">Fabric Printing</a>
                    <a href="#" class="footerLink">Letterheads Printing</a>
                    
                </div>
                <div class="footerbox">
                    <a href="#" class="footerLink">Photo Printing</a>
                    <a href="#" class="footerLink">Screen Printing</a>
                    <a href="#" class="footerLink">Label and Sticker Printing</a>
                    <a href="#" class="footerLink">Signage</a>
                    <a href="#" class="footerLink">Self Ink Stamp</a>
                    <a href="#" class="footerLink">Retail Printing</a>
                    <a href="#" class="footerLink">About Printing in London</a>
                    <a href="#" class="footerLink">Directories of Universities in London</a>
					<a href="#" class="footerLink">Pen Printing</a>
                    <a href="#" class="footerLink">Leaflets Printing</a>
                    </div>
                <div class="footerbox">
					<a href="#" class="footerLink">Custom and  Gifts</a>
                    <a href="#" class="footerLink">DVD CD Printing</a>
                    <a href="#" class="footerLink">Pre Press in London</a>
                    <a href="#" class="footerLink">Printing Press in London</a>
					<a href="#" class="footerLink">Art School in London</a>
                    <a href="#" class="footerLink">Graphic Course in London</a>
					<a href="#" class="footerLink">Diaries Printing</a>
                    <a href="#" class="footerLink">Calendars Printing</a>

                    </div>
                <div class="footerbox footerboxContactinfo">
                    <div class="footerlogo"><a href="index.html"><img src="images/logo4.png" alt="logo"></a></div>
                    <div class="footercontactinfo">
                        <div class="contactInfo__title">Need More Information 24/7 Online Support </div>
                        <a href="mailto:Sales@utharprint-manchester.co.uk" class="contactInfo__email">sales@utharprint.co.uk</a>
                        <div class="contactInfo__phone">Call: <a href="#">020 3239 9280</a></div>
                    </div>
                    <div class="sociaIcon">
                        <a href="#"><img src="images/facebook.png"></a>
                        <a href="#"><img src="images/twitter.png"></a>
                        <a href="#"><img src="images/linkdin.png"></a>
                        <a href="#"><img src="images/youtube.png"></a>
                        <a href="#"><img src="images/instagram.png"></a>
                    </div>
                </div>
            </div>
            <div class="copright">Copyright © 2018 Bumboom Limited. All rights reserved. Website by Uthara Print</div>
        </div>
		</div>
		<script type="text/javascript" src="js/jquery.min.js"></script>
    <script type="text/javascript" src="js/function.js"></script>

		</body>

</html>