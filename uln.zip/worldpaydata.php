<form name="contactForm" id="contactForm" method="post" action="https://secure.worldpay.com/wcc/purchase" target="_self" >

	
<input type="hidden" name="instId" value="1255583">
	
<input type="hidden" name="Amount" value="{$finalPrice}" />     
<input type="hidden" name="currency" value="GBP" />0

<input type="hidden" name="cartId" value="10">
				
<input type="hidden" name="accId1" value="10" />
			
<input type="hidden" name="MC_callback" value="https://bumboomprint.co.uk/success.php" />
			   
<input type="hidden" name="testMode" value="0">
			    
<input type="hidden" name="authMode" value="A">
				
<input type="hidden" name="desc" value="{$item_name|@StripSlash}" />
				
<input type="hidden" name="name" value="{$custmerName|@StripSlash}" />
			
<input type="hidden" name="address1" value="{$Address1Mandatory|@StripSlash}" />
			
<input type="hidden" name="town" value="{$CityMandatory|@StripSlash}" /> 
				
<input type="hidden" name="postcode" value="{$PostCodeMandatory|@StripSlash}" />


</form>

				
<input type="hidden" name="country" value="{$CountryMandatory|@StripSlash}" />
                     