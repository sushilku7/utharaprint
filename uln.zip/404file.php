 <div class="content">
    	<div class="lineheight"></div>	
			
		<div class="lineheight"></div>
           <div class="container-sm productOffers">
			   <span class="pagelink">
			   
			   <h2 class="detailhead" style='text-align:center;'>OOPS !! 404  </h2>
			   
			   <p style="margin:auto; text-align:center;">
			       <img src="https://assets.materialup.com/uploads/d46700cc-9573-4f37-b204-dd1f74eedd9e/animated_teaser.gif" width="600px" height="455px"/>
			       </p>
			   
			   </span>
           <h2 class="detailhead" style='text-align:center;'>WE COULDN'T FIND THE PAGE YOU SEARCHED FOR</h2>
           </div>
           </div>