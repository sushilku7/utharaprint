<?php
ob_start();
session_start();
error_reporting (E_ALL ^ E_NOTICE);
include('includes/top_header.php');
$tempProductDAO    = new ProductDAO();
$tempProductMainCatDAO = new ProductMainCategoryDAO();
$tempProductCatDAO = new ProductCatDAO();

if(isset($_POST['webenquiry']) && $_POST['webenquiry']!='')
{
   $name  = $_POST['memberName'];
   $companyName = $_POST['companyName'];
   $memberEmail = $_POST['memberEmail'];
   $memberPhone = $_POST['memberPhone'];
   $memberMobile = $_POST['memberMobile'];
   $website = $_POST['website'];
   $msg = $_POST['message'];
   
   
   
    $message ="<table width='560' border='0' cellspacing='1' cellpadding='4' align='center' style='font-family:Verdana, Arial, Helvetica, sans-serif; font-size:12px;' bgcolor='#DBDBDB'>
						<tr>
						<td width='700px' colspan='2' align='left' bgcolor='#FFFFFF'>Dear $name,
						<br/><br/>
						Online Design Enquiry Details :</td>
						</tr>

						<tr>
						<td colspan='2' align='left' bgcolor='#FFFFFF'><b> Name: $name</b></td>
						</tr>
						<tr>
						<td colspan='2' align='left' bgcolor='#FFFFFF'><b>Email Id: $memberEmail</b></td>
						</tr>
						<tr>
						<td colspan='2' align='left' bgcolor='#FFFFFF'><b>Phone Number: $memberPhone</b></td>
						</tr>
						<tr>
						<td colspan='2' align='left' bgcolor='#FFFFFF'><b>Mobile Number: $memberMobile</b></td>
						</tr>
						<tr>
						<td colspan='2' align='left' bgcolor='#FFFFFF'><b>webiste: $website</b></td>
						</tr>
						<tr>
						<td colspan='2' align='left' bgcolor='#FFFFFF'><b>Message: $msg</b></td>
						</tr>
						
						<tr>
						<td colspan='2'  align='left' bgcolor='#FFFFFF'>
						 Uthara Print Team <br /> 

						<img src='images/$logo' alt='' border='0' width='100px' />
						</td>
						</tr>


						<tr>
						<td  style='background-color:#FFFFFF; padding-top:10px; padding-bottom:10px;'><b>Thanks,</b></td>
						</tr>
						<tr>
						<td colspan='2' bgcolor='#FFFFFF'>Uthara Print</td>
						</tr>
                                </table>";
                   //echo $message;die();                                     
                  $email_from     = $memberEmail;
                  $email_to	= "sales@utharaprint-london.co.uk";						
				  $email_subject= "Uthara Print London Online Design Enquiry";
				  $headers  = "From: Uthara Print <".$email_from.">\r\n";
				  $headers .= "Reply-To: " . $email_from . "\r\n";
				  $headers .= "Content-type: text/html";
				  
		  $sent = mail($email_from, $email_subject, $message, $headers);
		  
		   $msg = "Thank you for approching us, we'll use these details to contact you shortly";
		 // header('location:thankyou-quote.php');
}

?> 
<!DOCTYPE html>
<html lang="en">

<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    
    <meta name="robots" content="noodp, noydir" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width; initial-scale=1.0; maximum-scale=1.0">
    <!--css-->
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/responsive.css">
    
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
   
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
    <!--css-->
	<script src="js/html5.js"></script>
	<style>
	
		* { -webkit-box-sizing: border-box; -moz-box-sizing: border-box; box-sizing: border-box; }
*:before, *:after { -webkit-box-sizing: inherit; -moz-box-sizing: inherit; box-sizing: inherit; }



	</style>
</head>

<body>

    <body><div class="mainCon">
        <?php
        include 'header.php';
            ?>
                
    
			
             	   
			
		  	<div class="content">
				<div class="lineheight"></div>
				<div class="lineheight"></div>
			
			<div class="container-sm productOffers">
			<h2 style="margin-bottom: 30px; font-family:Impact, Haettenschweiler, 'Franklin Gothic Bold', 'Arial Black', 'sans-serif' "><center><?php if(isset($msg) && $msg!=''){ echo $msg;} ?></center></h2>
				<div class="productContainet">
                    
                  
			    <div class="productBox transition">
					
                        <div class="productImage" style="height:auto; margin: 5px; padding: 20px; border-radius: 3em; border: 5px solid #393737; ">
					<form action="" method="post">
					
							
 						<input type="text" name="memberName" class="put1" placeholder="Name" required>
						<input type="email" name="memberEmail" class="put1" placeholder="Email" required><br/>
						<input type="number" name="memberPhone" class="put1" placeholder="Phone number" >
						<br/>
						<input type="number" name="memberMobile" class="put1" placeholder="Mobile number" required>
						<br/> 
						<input type="text" name="website" class="put1" placeholder="Website" >
						<br/>
                                                <textarea class="put1" name="message" placeholder="Requirements"></textarea>
						<br/>
						<br/>
                                                <input type="submit" name="webenquiry" value="Submit" class="productPrice">
					
</form>
					</div> 
					
                        
                    </div>
                  
                    
                        <!--<div class="productImage" >
							
						</div>-->
                        <div class="productContent" >
                         
                            
                        </div>
                         
						   
                    
					
					
                </div>
			</div>
			
	
        </div>
	
        <?php
        include 'footer.php';
            ?>
		</div>
		<script type="text/javascript" src="js/jquery.min.js"></script>
    <script type="text/javascript" src="js/function.js"></script>

		</body>

</html>