<?php

ob_start();

session_start();

error_reporting (E_ALL ^ E_NOTICE);
include('includes/top_header.php');
$tempProductDAO    = new ProductDAO();
$tempProductMainCatDAO = new ProductMainCategoryDAO();
$tempProductCatDAO = new ProductCatDAO();
unset($_SESSION['shoppingCart']);
?>

<!DOCTYPE html>

<html lang="en">



<head>

    <meta charset="utf-8">
    <meta name="robots" content="noodp, noydir" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <meta name="viewport" content="width=device-width; initial-scale=1.0; maximum-scale=1.0">

    <!--css-->
	<link rel="icon" type="image/png" href="favicon-32x32.png" sizes="32x32" />
	
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/responsive.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">

    <!--css-->

	<style>

* { -webkit-box-sizing: border-box; -moz-box-sizing: border-box; box-sizing: border-box; }

*:before, *:after { -webkit-box-sizing: inherit; -moz-box-sizing: inherit; box-sizing: inherit; }


#video-viewport{ position: relative; top:30px; left: 0; width: 100%; height: auto; overflow: hidden; z-index: -1; background-color: #fff; }

.fullsize-video-bg { height: auto; }



.fullsize-video-bg:before { content: "";  position: absolute; top:30px; left: 0; width: 100%; height: auto; z-index: 0; }

.fullsize-video-bg:after { content: "";  background-size: 3px 3px; position: absolute; top:30px; left: 0; width: 100%; height: auto; z-index: 1; }




		input[type="button"]{

			position: relative;width: 200px;height: 60px;

			-webkit-appearance:none;

		background: linear-gradient(0deg,#809cb2, #bbc0c4 , #809cb2);

			outline: none;border-radius: 20px;

			box-shadow: 0 0 0 4px #353535, 0 0 0 5px #3e3e3e, inset 0 0 10px rgba(0,0,0,1), 0 5px 15px rgba(0,0,0,.5), inset 0 0 15px rgba(0,0,0,.2);

			content:'Became a Uthara Print Partner';color: #333;

  text-shadow: 1px 1px 1px #333;

	}

		.midiv{

			position:relative; top:40%;z-index: 1;color: #333;

		}

		
	</style>
	<title>Thank You for Your Business | Uthara Print | London</title>

</head>



<body>



    <body><div class="mainCon">

    <?php   include 'header.php';   ?>

         
    <div class="lineh"></div>
    <div class="lineh"></div>

            <section class="fullsize-video-bg">

			<div id="video-viewport">

            

			<br/><br/><br/><br/><br/>

				
			</div> 

			</section>		   

            <p style="margin-left:80px; font-family: Montserrat;">Thank you For Your Business</p>                    
            <p style="font-weight: 600; color: #294b8a; font-size: 22px; font-family: Montserrat; margin-left:80px;">Your order is completed!</p>
			
		  	<div class="content">

				<div class="lineh"></div>
				<div class="lineh"></div>

			
			<div class="container-sm productOffers" style="border: 1px solid #ccc; border-radius: 10px; padding:1%;">
            <img src="images/thankyou4-london.png" alt=""/>
            <hr/>
            <p style="font-weight: 600; color: #294b8a; font-size: 22px; font-family: Montserrat; margin-left:60px;">Like us on social <i class="fa fa-thumbs-up" aria-hidden="true"></i></p>
            
            <ul id="tankyousocial" style="font-family: Montserrat;font-size:22px; font-weight:600;">
                <li style="display:inline; padding-left:60px;"><a href="#" style="font-family: Montserrat;"> <i class="fa fa-facebook-square" aria-hidden="true"></i> Facebook</a></li>
                <li style="display:inline; padding-left:3%;"><a href="#" style="font-family: Montserrat;"><i class="fa fa-twitter-square" aria-hidden="true"></i> Twitter</a></li>
                <li style="display:inline; padding-left:3%;"><a href="#" style="font-family: Montserrat;"><i class="fa fa-linkedin-square"></i> Linkedin</a></li>
                <li style="display:inline; padding-left:3%;"><a href="#" style="font-family: Montserrat;"><i class="fa fa-pinterest-square" aria-hidden="true"></i> Pinterest</a></li>
                
                <li style="display:inline; padding-left:3%;"><a href="#" style="font-family: Montserrat;"><i class="fa fa-instagram" aria-hidden="true"></i> Instagram</a></li>
            </ul>
            <p style="margin-left:60px; font-family: Montserrat;">
            Like our Social page for more greate offers!<br/>
            5% Discount and Promotion code available for all your future orders. Also get weekly print offers on Social.<p>
            <hr/>
        <div></div>
						
		<div class="productContainet">
				
		<div class="productContainet" style="background-color:#00c2e5; color:#fff; border-radius:10px; font-family: Montserrat; box-shadow: 0 5px 1px rgba(0, 0, 0, 0.1);">

         
                    <div class="productBox shopwidth" style="font-family: Montserrat; padding:2%;">

 				<div class="">

				<h3 style="color: #fff; font-family: Montserrat;">Dreaming to be an entrepreneur?</h3>

				<span ><p style="text-align:left; font-family: Montserrat;">Start your own design and Print-Territory Agency. It`s one of the most popular, highly rewarding business opportunities available in the industry, We can help you build a territory of your own in joint venture.This is ideal for sales or marketing professionals, a joint venture Territory Agency will test your entrepreneurial skills.

				We have not only the best reseller trade printing prices to offer, infact we have also developed all the necessary platforms backed by a team of print specialist that will add value to your business and change your life style as a business owner. You could became more of a brand ambassador of your business and be focused on bringing in new customers , while we support your business and serve your clients representing your territory. The list of business solutions are as follows:

				<br/><br/>

				<i class="fa fa-check" aria-hidden="true"></i> Best trade prices to re-sell the printing products we do at Uthara Print.<br/>
				<i class="fa fa-check" aria-hidden="true"></i> E-commerce , on-time printing portal.<br/>
				<i class="fa fa-check" aria-hidden="true"></i> State of the art CRM software to see reports and manage your clients.<br/>
				<i class="fa fa-check" aria-hidden="true"></i> Full fledge back office support to support your end customers truly representing your business.<br/>

				<br/>Our back office support covers your business for:<br/>

				<i class="fa fa-check" aria-hidden="true"></i> Chat-online support system.<br/>

				<i class="fa fa-check" aria-hidden="true"></i>Introduction and Sales follow-up on new leads.<br/>

				<i class="fa fa-check" aria-hidden="true"></i> Sending out Quotes and Invoices to your clients.<br/>

				<i class="fa fa-check" aria-hidden="true"></i> Payment collection.<br/>

				<i class="fa fa-check" aria-hidden="true"></i> Order updates to all your customers.<br/>

				<i class="fa fa-check" aria-hidden="true"></i> Collecing reviews and feedbacks for your business<br/>

				<i class="fa fa-check" aria-hidden="true"></i> Retargeting via email-marketing to all your existing clients to retain business and maximise your revenue.<br/><br/>

					Find out more with us. Simply email us to vinod@utharaprint.com<br/>

					If you already have a design and print business, you could join our team of resellers. It costs absolutely nothing to became a reseller and can continue to run your business.

					</p>
				</span>

			</div>

 </div>
				<div class="productBox shopwidth">

                <div class="#" style="height:auto;padding: 10px 0px; ">

				<img src="images/Boss4-uk.png" alt="" />

				</div>

				</div>

     </div>


				<div class="lineh"></div>
				<div class="lineh"></div>

				
				<h1 style="display: flex; padding: 10px; font-family: Montserrat;" class="head">And this is what it means to people locally nationally and globally...</h1>

			
				<div class="productContainet ">

					<div class="productBox thankwidth">

                   	<img src="images/img11.png" alt="" class="productImage1"/>

					</div>

					<div class="productBox thankwidth">


                   	<img src="images/img12.png" alt="" class="productImage1" />

				

                    </div>

					<div class="productBox thankwidth">



                   	<img src="images/img13.png" alt="" class="productImage1"/>

				

                    </div>

					<div class="productBox thankwidth">

				
                   	<img src="images/img14.png" alt="" class="productImage1"/>

				
                    </div>

					<div class="productBox thankwidth">


                   	<img src="images/img15.png" alt="" class="productImage1"/>


                    </div>

					<div class="productBox thankwidth">

                   	<img src="images/img16.png" alt="" class="productImage1"/>

                    </div>

               
                </div>

		<!------------------------------->

				<div class="lineh"></div>
				<div class="lineh"></div>

				<div class="productContainet">

				<div class="productBox ">

				<div class="productImage"  >

						<p style="text-align: left;padding:15px ;font-size: 14px; font-family: Montserrat;">
						    <img src="images/sir.png" alt="UtharaPrint CEO" class="CEO"/><b>I just wanted to thank you for working with Uthara Print.</b>

							<br/><br/>I also wanted to tell you just how much your business means not just to us but to many, many others.<br/>

							Because when you work with Uthara Print - you are supporting a business with a commitment to  the wider community.<br/><br/>

							You are not lining the pocket of some fat bull CEO - I know because I am the CEO! You`re helping a little girl go to dance and drama, or a boy pull on his team jersey and Mums and Dads put food on the table . You are supporting people to work not only in London but also helping people abroad to earn a living.

							<br/><br/>

							As we are expanding to every city. You are helping Uthara Print to support local cricket and football that players can be proud of. You are building local causes.<br/>

							You are supporting charity Uthara - because for every new sale , for every repeat order and many other daily business transactions Uthara will support education in India , fund money to educate a girl child  and empower women in poor countries, support health care in Bangladesh, Africa and more.<br/><br/>

							And for every 1000 printing orders we make , we fund 10 trees to be planted to counter our carbon emission.<br/><br/>

							I`d like to thank you very sincerely from all of us for your support. Your business means a lot to us at Uthara Print and the world to others.

							<br/><br/>

							<b>Warm Regards</b><br/>

							<b>Vinod Chakrapani</b></p>

				</div>

				</div>

				</div>

			</div>
        </div>

	

        <?php

    include 'footer.php';

        ?>

		</div>

		<script type="text/javascript" src="js/jquery.min.js"></script>

                <script type="text/javascript" src="js/function.js"></script>

		</body>



</html>