<?php
ob_start();
session_start();
error_reporting (E_ALL ^ E_NOTICE);
include('includes/top_header.php');
$tempProductDAO    = new ProductDAO();
$tempProductMainCatDAO = new ProductMainCategoryDAO();
$tempProductCatDAO = new ProductCatDAO();
$tempArr        = array();
$productCart    = array();
$productId      = $_POST['proId'];
$productDeliveTime = $_POST['productDeliveTime'];
$tempOurbrandDAO = new OurbrandDAO();
$tempOurbrandResult = $tempOurbrandDAO->OurbrandList();
$tempMemberDAO = new MemberDAO();
$memberId=$_SESSION['memberId'];
$tempMemberVO = $tempMemberDAO->getMemberDetails($memberId);
$name=$tempMemberVO->getFirstName();
$memberEmail=$tempMemberVO->getMemberEmail();
$samebs=$tempMemberVO->getSamebs();
$tempOurbrandDAO = new OurbrandDAO();
$tempOurbrandResult = $tempOurbrandDAO->OurbrandList();


if(isset($_POST['SendQuotation']) && $_POST['SendQuotation']!='')
{
   header('Content-Type: text/html;charset=utf-8');
   //$newtitle = html_entity_decode($newtitle, ENT_QUOTES, "UTF-8")
   $name        = $_POST['memberName'];
   $companyName = $_POST['companyName'];
   $memberEmail = $_POST['memberEmail'];
   $memberPhone = $_POST['memberPhone'];
    
                        if(isset($_SESSION['shoppingCart'])  && count($_SESSION['shoppingCart'])>0)
                                                 {
                                                         $shoppingCart     = $_SESSION['shoppingCart'];
                                                         $totalNetAmount   = 0.00;
                                                         $totalVatPrice    = 0.00;
                                                         $designCharges    = 0.00;
                                                         $ttllDsgnChrges   = 0.00;
                                                         //$productNumSets = "NA";
                                                         for($j=0;$j<count($shoppingCart);$j++)
                                                         {
                                                                 $productId                  = $shoppingCart[$j]['PID'];
                                                                 $productName                = $shoppingCart[$j]['PNAME'];
                                                                 $productImage                = $shoppingCart[$j]['PIMAGE'];
                                                                 $productFinish              = $shoppingCart[$j]['PFINISH'];
                                                                 $productPrintType           = $shoppingCart[$j]['PPRINTTYPE'];
                                                                 $productPaperType           = $shoppingCart[$j]['PPAPERTYPE'];
                                                                 $productDeliveryTime      = $shoppingCart[$j]['PDTIME'];
                                                                 $productNumSets             = $shoppingCart[$j]['PNOFSETS'];
                                                                 $url                   = $shoppingCart[$j]['PRODUCTURL'];
                                                                 $productQty        = $shoppingCart[$j]['PQTY'];

                                                                 $productDesc       = $shoppingCart[$j]['PRODUCTDESCRIPTION'];

                                                                 $designCharges     = $shoppingCart[$j]['DESIGNCHARGES'];
                                                                 $ttllDsgnChrges   += $shoppingCart[$j]['DESIGNCHARGES'];

                                                                 $productPrice      = $shoppingCart[$j]['PPRICEWOUTVAT'];
                                                                 $totalNetAmount   += $shoppingCart[$j]['PPRICEWOUTVAT'];

                                                                 $prdcttprcewthvt   = $shoppingCart[$j]['PPRICEWITHVAT'];
                                                                 $totalAmount      += $shoppingCart[$j]['PPRICEWITHVAT'];
                                                                 $vatflag           = $shoppingCart[$j]['VATFLAG'];
                                                                 $totalVatAmt      += $shoppingCart[$j]['VATAMT'];

                                                                 $ttlPrice         =  $productPrice;
                                                                 $netTotal        += $ttlPrice;
                                                                 $ttlPrice         = number_format($ttlPrice, 2);

                                                                 if($vatflag=="Yes")
                                                                     $vatRate        = $shoppingCart[$j]['VATRATE'];

                                                                 //$vatAmount          = $totalAmount - $totalNetAmount;



                                                                 $totalPriceWithVat  = $netTotal+$totalVatAmt;

                                                                 $productNameWOsize  = explode("_", $productName);
                                                                 $productName = $productNameWOsize[0];
                                                                 if(isset($productNameWOsize[1]) && $productNameWOsize[1]!="")
                                                                 {
                                                                              $productSize = $productNameWOsize[1];
                                                                 }
                                                                 else
                                                                 {
                                                                                             if(strstr($productName, "("))
                                                                                             {
                                                                                                 $ftbkt       = strpos($productName, "(");                                                    
                                                                                                 $ltbkt       = strpos($productName, ")");
                                                                                                 $ltbkt       = $ltbkt - $ftbkt;
                                                                                                 $productSize = substr($productName,$ftbkt+1,$ltbkt-1);                                                    
                                                                                                 $hidProductSize = substr($productName,$ftbkt,$ltbkt+1);
                                                                                                 $productName = str_replace($hidProductSize, " ", $productName);
                                                                                             }
                                                                                             else
                                                                                             {
                                                                                                 $productSize = $productName;
                                                                                             }

                                                                 }

                                                               if($productNumSets=="")
                                                               {
                                                                   $productNumSets = "NA";
                                                               }
															   
								 if($productDeliveryTime==0)
									{
									$productDeliveryTime="Standard Delivery 5/6 working days";
                                                                        }
                                                                        elseif($productDeliveryTime==15)
									{
									$productDeliveryTime="3-5 working days ";  
									}
									else
									{
									$productDeliveryTime="Express same day ";   
									}
                                                           
                                                            $netTotal    = number_format($totalNetAmount, 2);
                                                            $totalVatAmt = number_format($totalVatAmt, 2);
                                                            $totalPriceWithVat = number_format($totalPriceWithVat, 2);
              $message ="<table width='560' border='0' cellspacing='1' cellpadding='4' align='center' style='font-family:Verdana, Arial, Helvetica, sans-serif; font-size:12px;' bgcolor='#DBDBDB'>
						<tr>
						<td width='700px' colspan='2' align='left' bgcolor='#FFFFFF'>Dear $name,
						<br/><br/>
						Your Quotation Details :</td>
						</tr>
						<tr>
						<td colspan='2' align='left' bgcolor='#FFFFFF'><b>Product Name: $productName</b></td>
						</tr>
						<tr>
						<td colspan='2' align='left' bgcolor='#FFFFFF'><b>Product Size: $productSize</b></td>
						</tr>
						<tr>
						<td colspan='2' align='left' bgcolor='#FFFFFF'><b>Product Paper: $productPrintType</b></td>
						</tr>
						<tr>
						<td colspan='2' align='left' bgcolor='#FFFFFF'><b>Product Pages: $productPaperType</b></td>
						</tr>
						<tr>
						<td colspan='2' align='left' bgcolor='#FFFFFF'><b>Product Quantity: $productQty</b></td>
						</tr>
						<tr>
						<td colspan='2' align='left' bgcolor='#FFFFFF'><b>Artwork Check: Free</b></td>
						</tr>
						<tr>
						<td colspan='2' align='left' bgcolor='#FFFFFF'><b>Delivery Time: $productDeliveryTime</b></td>
						</tr>
						<tr>
						<td colspan='2' align='left' bgcolor='#FFFFFF'><h3>End price including delivery :</h3></td>
						</tr>
						<tr>
						<td colspan='2' align='left' bgcolor='#FFFFFF'><b>Net Amount: &#163;$netTotal</b></td>
						</tr>
						<tr>
						  <td colspan='2'  align='left' bgcolor='#FFFFFF'><b>Vat Amount: &#163;$totalVatAmt</b></td>
						</tr>
						<tr>
						<td colspan='2'  align='left' bgcolor='#FFFFFF'><b>Gross Amount : &#163;$totalPriceWithVat</b></td>
						</tr>
						<tr>
						<td colspan='2'  align='left' bgcolor='#FFFFFF'><b><a href='$url' target='_blank'>To Buy this quote, Click here Now : </a></b></td>
						</tr>
						<tr>
						<td colspan='2'  align='left' bgcolor='#FFFFFF'>
						 Uthara Print Team <br /> 
						</td>
						</tr>
						<tr>
						<td  style='background-color:#FFFFFF; padding-top:10px; padding-bottom:10px;'><b>Thanks,</b></td>
						</tr>
						<tr>
						<td colspan='2' bgcolor='#FFFFFF'>Uthara Print</td>
						</tr>
                                </table>";
                                
                $ClientMessage ="<table width='560' border='0' cellspacing='1' cellpadding='4' align='center' style='font-family:Verdana, Arial, Helvetica, sans-serif; font-size:12px;' bgcolor='#DBDBDB'>
						<tr>
						<td width='700px' colspan='2' align='left' bgcolor='#FFFFFF'>Dear $name,
						<br/><br/>
						Your Quotation Details :</td>
						</tr>
						<tr>
						<td colspan='2' align='left' bgcolor='#FFFFFF'><b>Product Name: $productName</b></td>
						</tr>
						<tr>
						<td colspan='2' align='left' bgcolor='#FFFFFF'><b>Product Size: $productSize</b></td>
						</tr>
						<tr>
						<td colspan='2' align='left' bgcolor='#FFFFFF'><b>Product Paper: $productPrintType</b></td>
						</tr>
						<tr>
						<td colspan='2' align='left' bgcolor='#FFFFFF'><b>Product Pages: $productPaperType</b></td>
						</tr>
						<tr>
						<td colspan='2' align='left' bgcolor='#FFFFFF'><b>Product Quantity: $productQty</b></td>
						</tr>
						<tr>
						<td colspan='2' align='left' bgcolor='#FFFFFF'><b>Artwork Check: Free</b></td>
						</tr>
						<tr>
						<td colspan='2' align='left' bgcolor='#FFFFFF'><b>Delivery Time: $productDeliveryTime</b></td>
						</tr>
						<tr>
						<td colspan='2' align='left' bgcolor='#FFFFFF'><h3>End price including delivery :</h3></td>
						</tr>
						<tr>
						<td colspan='2' align='left' bgcolor='#FFFFFF'><b>Net Amount: &#163;$netTotal</b></td>
						</tr>
						<tr>
						  <td colspan='2'  align='left' bgcolor='#FFFFFF'><b>Vat Amount: &#163;$totalVatAmt</b></td>
						</tr>
						<tr>
						<td colspan='2'  align='left' bgcolor='#FFFFFF'><b>Gross Amount : &#163;$totalPriceWithVat</b></td>
						</tr>
						<tr>
						<td colspan='2'  align='left' bgcolor='#FFFFFF'><b><a href='$url' target='_blank'>To Buy this quote, Click here Now : </a></b></td>
						</tr>
						<tr>
						  <td width='700px' colspan='2' align='left' bgcolor='#FFFFFF'><br>
                          <b>Below the client Details! </b><br /></td>
                          </tr>
                          <tr>
                          <td  align='left' bgcolor='#FFFFFF'><b>Name: $name</b></td> <td  align='left' bgcolor='#FFFFFF'><b>Company Name: $companyName</b></td>
                          </tr>
                          <tr>
                           <td  align='left' bgcolor='#FFFFFF'><b>Email Id: $memberEmail</b></td><td  align='left' bgcolor='#FFFFFF'><b>Contact Number: $memberPhone</b></td>
                          </tr>
						<tr>
						<td colspan='2'  align='left' bgcolor='#FFFFFF'>
						 Uthara Print Team <br /> 
						</td>
						</tr>
						<tr>
						<td  style='background-color:#FFFFFF; padding-top:10px; padding-bottom:10px;'><b>Thanks,</b></td>
						</tr>
						<tr>
						<td colspan='2' bgcolor='#FFFFFF'>Uthara Print</td>
						</tr>
                                </table>";            
                   //echo $message;die();                                     
                  $email_to     = $memberEmail;
                  $email_from 	= "sales@utharaprint-london.co.uk";						
				  $email_subject= "Utharaprint London - Your Online Quotation";
				  $headers  = "From: Uthara Print <".$email_from.">\r\n";
				  $headers .= "Reply-To: " . $email_from . "\r\n";
				  $headers .= "Content-type: text/html";
				  
		  $sent = mail($email_to, $email_subject, $message, $headers);
		  $sent = mail($email_from, $email_subject, $ClientMessage, $headers);
		  unset($_SESSION['shoppingCart']);
		  header('location:quotation-thankyou.php');
                                                         }
                                                 }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="robots" content="noodp, noydir" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width; initial-scale=1.0; maximum-scale=1.0">
    <!--css-->
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/responsive.css">
    
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
   
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
    <!--css-->
	<script src="js/html5.js"></script>
	<style>
	
		* { -webkit-box-sizing: border-box; -moz-box-sizing: border-box; box-sizing: border-box; }
*:before, *:after { -webkit-box-sizing: inherit; -moz-box-sizing: inherit; box-sizing: inherit; }



	</style>
        <title>Uthara Print online Quotation</title>
</head>

<body>

    <body><div class="mainCon">
        <?php include'header.php';
        ?>
             	   
			
		  	<div class="content">
				<div class="lineheight"></div>
				<div class="lineheight" id="line"></div>
				<div class="lineheight" id="line"></div>
			
			<div class="container-sm productOffers">
			
				<div class="productContainet">
                    
                  
			    <div class="productBox transition">
					
                        <div class="productImage" style="height: auto; padding-top: 0px;padding-bottom: 20px; padding:1%;"> <h3 style="font-family:Montserrat; font-weight:600;">Your Quotation</h3>
                            <form method="post" action="" enctype="multipart/form-data" style="width:100%;float: left">
                                <input type="hidden" name="memberName" value="<?php echo $_POST['memberName'];?>">
				<input type="hidden" name="companyName" value="<?php echo $_POST['companyName'];?>">
                                <input type="hidden" name="memberEmail" value="<?php echo $_POST['memberEmail'];?>">
 						 <?php
                                                 if(isset($_SESSION['shoppingCart'])  && count($_SESSION['shoppingCart'])>0)
                                                 {
                                                         $shoppingCart     = $_SESSION['shoppingCart'];
                                                         $totalNetAmount   = 0.00;
                                                         $totalVatPrice    = 0.00;
                                                         $designCharges    = 0.00;
                                                         $ttllDsgnChrges   = 0.00;
                                                         //$productNumSets = "NA";
                                                         for($j=0;$j<count($shoppingCart);$j++)
                                                         {
                                                                 $productId                  = $shoppingCart[$j]['PID'];
                                                                 $productName                = $shoppingCart[$j]['PNAME'];
                                                                 $productImage                = $shoppingCart[$j]['PIMAGE'];
                                                                 $productFinish              = $shoppingCart[$j]['PFINISH'];
                                                                 $productPrintType           = $shoppingCart[$j]['PPRINTTYPE'];
                                                                 $productPaperType           = $shoppingCart[$j]['PPAPERTYPE'];
                                                                 $productDeliveryTime      = $shoppingCart[$j]['PDTIME'];
                                                                 $productNumSets             = $shoppingCart[$j]['PNOFSETS'];
                                                                 $url                   = $shoppingCart[$j]['PRODUCTURL'];
                                                                 $productQty        = $shoppingCart[$j]['PQTY'];

                                                                 $productDesc       = $shoppingCart[$j]['PRODUCTDESCRIPTION'];

                                                                 $designCharges     = $shoppingCart[$j]['DESIGNCHARGES'];
                                                                 $ttllDsgnChrges   += $shoppingCart[$j]['DESIGNCHARGES'];

                                                                 $productPrice      = $shoppingCart[$j]['PPRICEWOUTVAT'];
                                                                 $totalNetAmount   += $shoppingCart[$j]['PPRICEWOUTVAT'];

                                                                 $prdcttprcewthvt   = $shoppingCart[$j]['PPRICEWITHVAT'];
                                                                 $totalAmount      += $shoppingCart[$j]['PPRICEWITHVAT'];
                                                                 $vatflag           = $shoppingCart[$j]['VATFLAG'];
                                                                 $totalVatAmt      += $shoppingCart[$j]['VATAMT'];

                                                                 $ttlPrice         =  $productPrice;
                                                                 $netTotal        += $ttlPrice;
                                                                 $ttlPrice         = number_format($ttlPrice, 2);

                                                                 if($vatflag=="Yes")
                                                                     $vatRate        = $shoppingCart[$j]['VATRATE'];

                                                                 //$vatAmount          = $totalAmount - $totalNetAmount;



                                                                 $totalPriceWithVat  = $netTotal+$totalVatAmt;

                                                                 $productNameWOsize  = explode("_", $productName);
                                                                 $productName = $productNameWOsize[0];
                                                                 if(isset($productNameWOsize[1]) && $productNameWOsize[1]!="")
                                                                 {
                                                                              $productSize = $productNameWOsize[1];
                                                                 }
                                                                 else
                                                                 {
                                                                                             if(strstr($productName, "("))
                                                                                             {
                                                                                                 $ftbkt       = strpos($productName, "(");                                                    
                                                                                                 $ltbkt       = strpos($productName, ")");
                                                                                                 $ltbkt       = $ltbkt - $ftbkt;
                                                                                                 $productSize = substr($productName,$ftbkt+1,$ltbkt-1);                                                    
                                                                                                 $hidProductSize = substr($productName,$ftbkt,$ltbkt+1);
                                                                                                 $productName = str_replace($hidProductSize, " ", $productName);
                                                                                             }
                                                                                             else
                                                                                             {
                                                                                                 $productSize = $productName;
                                                                                             }

                                                                 }

                                                               if($productNumSets=="")
                                                               {
                                                                   $productNumSets = "NA";
                                                               }
															   
								 if($productDeliveryTime==0)
									{
									$productDeliveryTime="Standard Delivery 5/6 working days";
                                                                        }
                                                                        elseif($productDeliveryTime==15)
									{
									$productDeliveryTime="3-5 working days ";  
									}
									else
									{
									$productDeliveryTime="Express same day ";   
									}
                                                                        
                                                             $netTotal    = number_format($totalNetAmount, 2);
                                                            $totalVatAmt = number_format($totalVatAmt, 2);
                                                            $totalPriceWithVat = number_format($totalPriceWithVat, 2);
                                                      echo "<div>
                                                
                                    <section class='formlabel'><span >Name</span><input type='text' name='name' class='put1' value=' $_POST[memberName]' required></section>
                                    <section class='formlabel'><span >Company name</span><input type='text' name='cname' class='put1' value='$_POST[companyName]' required></section>
                                    <section class='formlabel'><span >Email</span><input type='email' name='email' class='put1' value=' $_POST[memberEmail]' required></section>
                                    <section class='formlabel'><span >Product</span><input type='text' name='product' class='put1' value=' $productName' required></section>
 						            <section class='formlabel'><span >Size</span><input type='text' name='Size' class='put1' value='$productSize' required></section>
 						            <section class='formlabel'><span >Pages</span ><input type='text' name='paper' class='put1' value='$productPaperType' required></section>
                                    <section class='formlabel'><span >Paper</span ><input type='text' name='paper' class='put1' value='$productPaperType' required></section>
                                    <section class='formlabel'><span >Quantity</span><input type='text' name='Quantity' class='put1' value='$productQty'  required></section>
 						 			<section class='formlabel'><span >Delivery Time</span><input type='text' name='Dtime' class='put1' value='$productDeliveryTime' required></section><br/>
 					
                                                <label style='width:100%;float:left'>	<h4 style='font-family:Montserrat; font-weight:600;'>End price including delivery</h4></label>
					   <section class='formlabel'><span >NET Amount in &pound</span><input type='number' name='net' class='put1' value='$netTotal' ></section>
						<section class='formlabel'><span >VAT Amount in &pound</span><input type='number' name='vat' class='put1' value='$totalVatAmt' required></section>
						<section class='formlabel'><span >GROSS Amount in &pound</span><input type='number' name='gross' class='put1' value='$totalPriceWithVat' required></section><br/>
						<p style='width:100%;float:left'><a href='#'>To Buy this quote click here now.</a></p></div>
						<span style='text-align: left;width:100%;float:left;padding-top:10px'><p >All-Inclusive-Guarantee: incl. printing, further processing, delivery and statutory VAT. </p>

<p>We are looking forward to completing your order on time and to a high quality production standard. Order directly online or contact us by telephone or email with your enquiries. </p>

<p>Should your wishes extend the range of products offered by the print portal, we will happily make out an individual offer for you. We are bound to this offer for a period of 2 weeks. </p><p>

The general terms and conditions of Uthara Print Ltd apply. 
If you have queries or proposals do not hesitate to contact our team via <br/> email:<a href='mailto:sales@utharaprint-london.com'> <b>sales@utharaprint-london.com</b></a> or by phone: <a href'#'><b>0845 337 0251.</b></a> <br/><br/>

Yours sincerly <br/>
Your team at Uthara Print Ltd</p></span>";
                                                            }
                                                 }
                                                ?>
 						
                                                <br/><br/><section style="width:100%;float:left;justify-content:center">
						
                                                
                                                <a href="https://utharaprint-london.co.uk/thank-you.php"><input type="submit" class="productPrice" name="SendQuotation" value="Send Quotation" style="margin: 10px;padding:4px 15px"></a>
                                                <a href="https://utharaprint-london.co.uk"><input type="button" class="productPrice" value="Go Back Home" style="margin: 10px;padding:4px 15px"></a>
                                                </section>
				</form>
					</div> 
					    
                    </div>
                  
                    
                        
                </div>
			</div>
			
			
			
        </div>
	
        <?php include 'footer.php'; ?>
		</div>
		<script type="text/javascript" src="js/jquery.min.js"></script>
                <script type="text/javascript" src="js/function.js"></script>
		</body>
</html>