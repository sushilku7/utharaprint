<?php
include('DAO/VatDAO.php');
include('valueobjects/VatVO.php');
include('library/Dropdown.php');
include('DAO/ProductDAO.php');
$tempVatDAO   = new VatDAO();
$tempProductDAO = new ProductDAO();
$productId             = $_POST['productId'];
$printoption           = $_POST['printoption'];
$prodCatId         = $_POST['prodCatId'];
$vatStatus         = $_POST['vatStatus'];
$designCharges         = $_POST['designCharges'];
$productVatStatus      = $_POST['vatStatus'];

//echo $productpCatId;
include('DAO/DbConnection.php');
DbConnection::CreateConnection();

$productDeliveTime       = $_POST['productDeliveTime'];
$productVatPrice         = $_POST['vatAmt'];

$productCatQuery = "select pc.catName, pc.parent, pc.pageDesc, p.productId, p.productSize, p.productPaper, p.productPages, p.productQty, p.productPrice, p.profiteMargine from tbl_product as p  inner join tbl_product_cat as pc  on p.productSize=pc.productCatId where productId='$productId' ";
$productCatResult = mysql_query($productCatQuery);

if($res=mysql_fetch_array($productCatResult))
{
    $prodcutSubCatId       = $res['productSize'];
    $productName           = $res['catName'];   
    $productCatId           = $res['parent'];   	
    $quantity              = $res['productQty'];
    $productDesc           = substr($res['pageDesc'], 0, 300);
    $productPrintType      = $res['productPages'];
    $productPaperType      = $res['productPaper'];
    
    $proBuyPrice           = $res['productPrice'];
    $profitMargin          = $res['profiteMargine'];
}


        $ddstr = "";
       // "select DISTINCT productQty, productId, productPrice, profiteMargine  from tbl_product where productSubCat='$prodcutSubCatId' and productPaperSize='$productPaperSize'  and productPrintType='$productPrintType'  and productPaperType='$productPaperType' order by productQty asc";
      
               // echo "select DISTINCT productQty, productId, productPrice, profiteMargine  from tbl_product where productId='$productId' and productSubCat='$prodcutSubCatId' and productPrintType='$productPrintType'  and productPaperType='$productPaperType'  order by productQty asc";
//die();
        $qury  = "select DISTINCT productQty, productId, productPrice, profiteMargine  from tbl_product where productSize='$prodcutSubCatId' and productPages='$productPrintType' and productPaper='$productPaperType' order by productQty asc";
         $rs    = mysql_query($qury);
        $ddstr = "<select class='put1' name='productPrice' id='productPrice' onchange='javascript: submitPriceForm($productId);'>";
        $count = 0;
        while($rows=  mysql_fetch_array($rs))
        {             
                $product_id       = $rows['productId'];
                $productId        = $rows['productId'];
                $qty              = $rows['productQty'];
                $proBuyPrice      = $rows['productPrice'];
                $profitMargin     = $rows['profiteMargine'];
                
                //Add margin in buying price 
                $margin                = ($proBuyPrice * $profitMargin)/100;
                $finalPriceWithOutVat  =  $proBuyPrice + $margin;
                
                if($productVatStatus=="Yes")
                {
                    $qryForVatDetail   = "SELECT rId, vatvalue FROM tbl_vat ";
                    $result2           = mysql_query($qryForVatDetail);
                    $rs2               = mysql_fetch_array($result2);
                    $vatRate           = $rs2['vatvalue'];
                    $productVatPrice   = ($finalPriceWithOutVat*$vatRate)/100;
                    $productVatPrice   = round($productVatPrice, 2);

                    $finalPriceWithVat = $finalPriceWithOutVat + $productVatPrice;
                    //echo "Product Price - ".$productPrice;
                }
                else
                {
                    $finalPriceWithVat = $finalPriceWithOutVat;
                }
                
                $finalPrice = number_format($finalPriceWithVat, 2);                
                
                              
                if($quantity==$qty)
                {
                 $select="selected";
                }
                else
                {
                 $select="";
                }
               
                $ddstr   .="<option value='$productId' $select>$qty</option>";
                $count = $count + 1;
        }
        $ddstr   .= "</select>";
        
echo $ddstr;
?>
<?php 
echo "--------------------";
//$productId             = $_POST['productId'];
$productVatStatus   = $_POST['vatStatus'];
$productPrice      = $_POST['productPrice'];
$productDeliveTime  = $_POST['productDeliveTime'];


$finalPriceWithOutVat="0.00";
$designCharges="0.00";
$productVatPrice="0.00";
$totalPrice="0.00";


?>
<?php
/*
$productCatQuery = "select pc.catName, pc.parent, pc.pageDesc, p.productId, p.productPaper, p.productSize, p.productPages, p.productQty, p.productPrice, p.profiteMargine from tbl_product as p inner join tbl_product_cat as pc  on p.productSize=pc.productCatId where productId='$productId' ";
$productCatResult = mysql_query($productCatQuery);

if($res=  mysql_fetch_array($productCatResult))
{
    $prodcutSubCatId       = $res['productSize'];
    $productCatId           = $res['parent'];
    $productName           = $res['catName'];    
    $quantity              = $res['productQty'];
    $productDesc           = substr($res['pageDesc'], 0, 300);
    $productPrintType      = $res['productPages'];
    $productPaperType      = $res['productPaper'];
   
    $proBuyPrice           = $res['productPrice'];
    $profitMargin          = $res['profiteMargine'];
}
        $margin       = ($proBuyPrice * $profitMargin)/100;
        $finalPriceWithOutVat  =  $proBuyPrice + $margin;
		
		  if($printoption=="free") 
                    {
                        $designCharges  = 0;
                    }
					
         if($printoption=="paid")
          {
			//  echo $productCatId;
         $designCharges  = $tempProductDAO->getDesignCharges($productCatId);
          }

$margin                = ($proBuyPrice * $profitMargin)/100;*/
$finalPriceWithOutVat  =  $productPrice ;

//echo $finalPriceWithOutVat;


if($productVatStatus=="Yes")
		{
        $qryForVatDetail   = "SELECT rId, vatvalue FROM tbl_vat ";
        $result2           = mysql_query($qryForVatDetail);
        $rs2               = mysql_fetch_assoc($result2);
        $vatRate           = $rs2['vatvalue'];
        $productVatPrice   = ($finalPriceWithOutVat*$vatRate)/100;
        $productVatPrice   = round($productVatPrice, 2);
        $finalPriceWithVat = $finalPriceWithOutVat;
         }
         else
         {
         $finalPriceWithVat = $finalPriceWithOutVat;
         }
         $totalPricewithdesigncharges = $finalPriceWithOutVat+$productDeliveTime;
         $totalPriceWithDesignCharge= $finalPriceWithVat+$productDeliveTime;  
         $finalPrice = number_format($totalPriceWithDesignCharge, 2);
         $totalPrice = $totalPriceWithDesignCharge+$productVatPrice;
         //echo $productDeliveTime;
         //echo $productVatPrice;
echo   "<form name='productPricefrm' id='productPricefrm' action='shopping-cart.php' method='post' enctype='multipart/form-data'>
        <input type='hidden' name='proId'                   value='$productId'>
        <input type='hidden' name='totalpricewithdesign' value='$totalPricewithdesigncharges'>
        <input type='hidden' name='vatAmount'   value='$productVatPrice'>
        <input type='hidden' name='productPriceWOutVat'     value='$totalPricewithdesigncharges'> 
        <input type='hidden' name='productPriceWithVat'     value='$finalPriceWithVat'> 
        <input type='hidden' name='totalPrice'     value='$totalPrice'>            
        <input type='hidden' name='productDeliveTime'     value='$productDeliveTime'>                        
            <div class='rightdiv'>
                            <div class='productInfo' style='padding-left: 16px;'>
                                <a href class='productLink' > Product  Price  + VAT = Net Amount</a>
                               <div class='productshortInfo' style='text-align: left'>&pound;".number_format($totalPricewithdesigncharges, 2)."+&pound;".number_format($productVatPrice, 2)." = <strong>&pound;".number_format($totalPrice, 2)."</strong></div>
                            </div>
                            <br/>
                            <br/>
							
                            <table class='tabl' style='margin-bottom: 10px'>
                                <tr class='tri' >
                                <td class='in'><a href='#'><div class='productPrice'  style='text-align: center'><button type='submit' class='productPrice' name='cart' value='buynow' class='formbutton'>Buy Now</button></div></a></td>
							</tr>		
			    </table>
                    </div>

</form>";

echo "--------------------";
?>
<input type="hidden" name="defaultQty" id="defaultQty" value="<?php echo $quantity; ?>" />
<?php

echo "--------------------";

echo $workingDays           = $_POST['designCharges'];
//echo  "select DISTINCT productPrice from tbl_product where productSubCat='$prodcutSubCatId' and productPages='$productPrintType'  and productPaper='$productPaperType' and productQty='$quantity' order by productId asc";
//die();
$productTurnArndQuery  = "select DISTINCT productPrice from tbl_product where productSubCat='$prodcutSubCatId' and productPrintType='$productPrintType'  and productPaperType='$productPaperType' and productQty='$quantity' order by productId asc";
$productTurnArndResult = mysql_query($productTurnArndQuery);
$dropDown = "";
        while($row1=mysql_fetch_assoc($productTurnArndResult))
        { 
    
                 $proTurnAround = $row1['productTurnAround'];
                 $price         = $row1['productPrice'];
                 
                 $dropDown     .='<div class="turnAround" style="float: left;">
                                 <a style="cursor: pointer;"  onclick="javascript: submitForm('."'".$proTurnAround."'".')">';   
                        if($workingDays==$proTurnAround)
                        {
                               $dropDown   .="<p style='width: auto; background-color: #F8C801; color: #fff; padding:  5px 10px; margin-right: 10px;'>$proTurnAround</p>";
                        }
                        else
                        {
                               $dropDown   .="<p style='width: auto; height: auto; background-color: #D9DBDA; padding:  5px 10px;  margin-right: 10px;'>$proTurnAround</p>";
                        }
                 $dropDown     .='</a>
                               </div>';
        }
echo $dropDown;
echo "--------------------";
 
?>

