<?php 

class TailorMadeMemberLoginVO {
    var $memberId;  
    var $memberName;
    var $memberEmail;
    var $memberContact;
    var $status;
    function getMemberId() {
        return $this->memberId;
    }

    function getMemberName() {
        return $this->memberName;
    }

    function getMemberEmail() {
        return $this->memberEmail;
    }

    function getMemberContact() {
        return $this->memberContact;
    }

    function getStatus() {
        return $this->status;
    }

    function setMemberId($memberId) {
        $this->memberId = $memberId;
    }

    function setMemberName($memberName) {
        $this->memberName = $memberName;
    }

    function setMemberEmail($memberEmail) {
        $this->memberEmail = $memberEmail;
    }

    function setMemberContact($memberContact) {
        $this->memberContact = $memberContact;
    }

    function setStatus($status) {
        $this->status = $status;
    }


}
?>