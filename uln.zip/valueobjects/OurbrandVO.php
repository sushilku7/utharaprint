<?php 
class OurbrandVO {
   
    var $ourbrandId;  
    var $ourbrandName;
    var $image;
    var $status;
   
    function getOurbrandId() {
        return $this->ourbrandId;
    }

    function getOurbrandName() {
        return $this->ourbrandName;
    }

    function getImage() {
        return $this->image;
    }

    function getStatus() {
        return $this->status;
    }

    function setOurbrandId($ourbrandId) {
        $this->ourbrandId = $ourbrandId;
    }

    function setOurbrandName($ourbrandName) {
        $this->ourbrandName = $ourbrandName;
    }

    function setImage($image) {
        $this->image = $image;
    }

    function setStatus($status) {
        $this->status = $status;
    }


}
?>