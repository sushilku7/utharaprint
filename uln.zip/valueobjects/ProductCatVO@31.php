<?php 

class ProductCatVO {
    
    var $productCatId;  
    var $dirName;      
    var $catName;   
    var $catAlias;
    var $supplierName;  
    var $catMainDescHead;      
    var $inCalc;   
    var $vat;  
    var $imagePath;      
    var $pageDesc;   
    var $shortDesc;
    
    var $productSpec;
    var $productReqrmnt;
    var $artworkAi;
    var $artworkPdf;
    var $artworkId;    
    
    var $flag;  
    var $mainIndex;      
    var $extra;  
    var $parent;  
    var $pageContent;      
    var $pageTitle; 
    var $pageMetaTitle;      
    var $pageMetaDesc;   
    var $pageKeyword;  
    var $pageRobots;      
    var $pageAuthor;   
    var $pageVarify;  
    var $catStatus;      
    var $anotherImagePath;   
    var $productCatDesc;  
    var $featureStatus;    
    var $thumbImage1;
    var $thumbImage2;
    var $thumbImage3; 
    

        function getThumbImage3() {
        return $this->thumbImage3;
    }

    function setThumbImage3($thumbImage3) {
        $this->thumbImage3 = $thumbImage3;
    }

        function getProductSpec() {
        return $this->productSpec;
    }

    function getProductReqrmnt() {
        return $this->productReqrmnt;
    }

    function getArtworkAi() {
        return $this->artworkAi;
    }

    function getArtworkPdf() {
        return $this->artworkPdf;
    }

    function getArtworkId() {
        return $this->artworkId;
    }

    function setProductSpec($productSpec) {
        $this->productSpec = $productSpec;
    }

    function setProductReqrmnt($productReqrmnt) {
        $this->productReqrmnt = $productReqrmnt;
    }

    function setArtworkAi($artworkAi) {
        $this->artworkAi = $artworkAi;
    }

    function setArtworkPdf($artworkPdf) {
        $this->artworkPdf = $artworkPdf;
    }

    function setArtworkId($artworkId) {
        $this->artworkId = $artworkId;
    }

    
    function getThumbImage1() {
        return $this->thumbImage1;
    }

    function setThumbImage1($thumbImage1) {
        $this->thumbImage1 = $thumbImage1;
    }

     function getThumbImage2() {
        return $this->thumbImage2;
    }

    function setThumbImage2($thumbImage2) {
        $this->thumbImage2 = $thumbImage2;
    }     
	 
    public function getProductCatId() {
        return $this->productCatId;
    }

    public function getDirName() {
        return $this->dirName;
    }

    public function getCatName() {
        return $this->catName;
    }
    
    function getCatAlias() {
        return $this->catAlias;
    }    

    public function getSupplierName() {
        return $this->supplierName;
    }

    public function getCatMainDescHead() {
        return $this->catMainDescHead;
    }

    public function getInCalc() {
        return $this->inCalc;
    }

    public function getVat() {
        return $this->vat;
    }

    public function getImagePath() {
        return $this->imagePath;
    }

    public function getPageDesc() {
        return $this->pageDesc;
    }
    
    function getShortDesc() {
        return $this->shortDesc;
    }

    public function getFlag() {
        return $this->flag;
    }

    public function getMainIndex() {
        return $this->mainIndex;
    }

    public function getExtra() {
        return $this->extra;
    }

    public function getParent() {
        return $this->parent;
    }

    public function getPageContent() {
        return $this->pageContent;
    }

    public function getPageTitle() {
        return $this->pageTitle;
    }

    public function getPageMetaTitle() {
        return $this->pageMetaTitle;
    }

    public function getPageMetaDesc() {
        return $this->pageMetaDesc;
    }

    public function getPageKeyword() {
        return $this->pageKeyword;
    }

    public function getPageRobots() {
        return $this->pageRobots;
    }

    public function getPageAuthor() {
        return $this->pageAuthor;
    }

    public function getPageVarify() {
        return $this->pageVarify;
    }

    public function getCatStatus() {
        return $this->catStatus;
    }

    public function getAnotherImagePath() {
        return $this->anotherImagePath;
    }

    public function getProductCatDesc() {
        return $this->productCatDesc;
    }

    public function getFeatureStatus() {
        return $this->featureStatus;
    }

    public function setProductCatId($productCatId) {
        $this->productCatId = $productCatId;
    }

    public function setDirName($dirName) {
        $this->dirName = $dirName;
    }

    public function setCatName($catName) {
        $this->catName = $catName;
    }
    
    function setCatAlias($catAlias) {
        $this->catAlias = $catAlias;
    }

    public function setSupplierName($supplierName) {
        $this->supplierName = $supplierName;
    }

    public function setCatMainDescHead($catMainDescHead) {
        $this->catMainDescHead = $catMainDescHead;
    }

    public function setInCalc($inCalc) {
        $this->inCalc = $inCalc;
    }

    public function setVat($vat) {
        $this->vat = $vat;
    }

    public function setImagePath($imagePath) {
        $this->imagePath = $imagePath;
    }

    public function setPageDesc($pageDesc) {
        $this->pageDesc = $pageDesc;
    }   
    

    function setShortDesc($shortDesc) {
        $this->shortDesc = $shortDesc;
    }

    public function setFlag($flag) {
        $this->flag = $flag;
    }

    public function setMainIndex($mainIndex) {
        $this->mainIndex = $mainIndex;
    }

    public function setExtra($extra) {
        $this->extra = $extra;
    }

    public function setParent($parent) {
        $this->parent = $parent;
    }

    public function setPageContent($pageContent) {
        $this->pageContent = $pageContent;
    }

    public function setPageTitle($pageTitle) {
        $this->pageTitle = $pageTitle;
    }

    public function setPageMetaTitle($pageMetaTitle) {
        $this->pageMetaTitle = $pageMetaTitle;
    }

    public function setPageMetaDesc($pageMetaDesc) {
        $this->pageMetaDesc = $pageMetaDesc;
    }

    public function setPageKeyword($pageKeyword) {
        $this->pageKeyword = $pageKeyword;
    }

    public function setPageRobots($pageRobots) {
        $this->pageRobots = $pageRobots;
    }

    public function setPageAuthor($pageAuthor) {
        $this->pageAuthor = $pageAuthor;
    }

    public function setPageVarify($pageVarify) {
        $this->pageVarify = $pageVarify;
    }

    public function setCatStatus($catStatus) {
        $this->catStatus = $catStatus;
    }

    public function setAnotherImagePath($anotherImagePath) {
        $this->anotherImagePath = $anotherImagePath;
    }

    public function setProductCatDesc($productCatDesc) {
        $this->productCatDesc = $productCatDesc;
    }

    public function setFeatureStatus($featureStatus) {
        $this->featureStatus = $featureStatus;
    }


}
?>