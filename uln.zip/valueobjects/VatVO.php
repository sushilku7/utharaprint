<?php 

class VatVO {
   var $rId;  
   var $vatvalue;
   
/**
	 * @return the $rId
	 */
	public function getVatId() {
		return $this->rId;
	}

/**
	 * @return the $vatvalue
	 */
	public function getVatValue() {
		return $this->vatvalue;
	}

/**
	 * @param field_type $rId
	 */
	public function setVatId($rId) {
		$this->rId = $rId;
	}

/**
	 * @param field_type $vatvalue
	 */
	public function setVatValue($vatvalue) {
		$this->vatvalue = $vatvalue;
	}
 
   
   
}
?>