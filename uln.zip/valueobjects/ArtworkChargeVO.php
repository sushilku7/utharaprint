<?php 

class ArtworkChargeVO {
    
    var $dcId;  
    var $designCharges;      
    var $productCatId;   
    var $isActive;  
    var $catName;
    
    function getCatName() {
        return $this->catName;
    }

    function setCatName($catName) {
        $this->catName = $catName;
    }

        function getDcId() {
        return $this->dcId;
    }

    function getDesignCharges() {
        return $this->designCharges;
    }

    function getProductCatId() {
        return $this->productCatId;
    }

    function getIsActive() {
        return $this->isActive;
    }

    function setDcId($dcId) {
        $this->dcId = $dcId;
    }

    function setDesignCharges($designCharges) {
        $this->designCharges = $designCharges;
    }

    function setProductCatId($productCatId) {
        $this->productCatId = $productCatId;
    }

    function setIsActive($isActive) {
        $this->isActive = $isActive;
    }


}
?>