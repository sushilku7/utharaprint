<?php 
class FeaturesVO {
   
    var $id;  
    var $featuresName;
    var $featuresDesc;
    var $image;
    var $status;
    
    function getId() {
        return $this->id;
    }

    function getFeaturesName() {
        return $this->featuresName;
    }

    function getFeaturesDesc() {
        return $this->featuresDesc;
    }

    function getImage() {
        return $this->image;
    }

    function getStatus() {
        return $this->status;
    }

    function setId($id) {
        $this->id = $id;
    }

    function setFeaturesName($featuresName) {
        $this->featuresName = $featuresName;
    }

    function setFeaturesDesc($featuresDesc) {
        $this->featuresDesc = $featuresDesc;
    }

    function setImage($image) {
        $this->image = $image;
    }

    function setStatus($status) {
        $this->status = $status;
    }


}
?>