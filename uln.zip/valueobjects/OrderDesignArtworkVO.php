<?php 
class OrderDesignArtworkVO {
   
    var $orderDesignId;  
    var $orderId;
    var $projectId;
    var $projectName;
    var $firstName;    
    var $lastName;
    var $memberEmail;
    var $memberMobile;
    var $date;  
    var $additionInfo;
    var $logoText;
    var $logoBaseLine;
    var $logoStyle;    
    var $logoTextColor;
    var $logoBaselineColor;
    var $logoBackgroundColor;
    var $uploadFiles;
    var $designDesc;
    var $briefDesc;
    var $additionComment;
    
    function getOrderDesignId() {
        return $this->orderDesignId;
    }

    function getOrderId() {
        return $this->orderId;
    }

    function getProjectId() {
        return $this->projectId;
    }

    function getProjectName() {
        return $this->projectName;
    }

    function getFirstName() {
        return $this->firstName;
    }

    function getLastName() {
        return $this->lastName;
    }

    function getMemberEmail() {
        return $this->memberEmail;
    }

    function getMemberMobile() {
        return $this->memberMobile;
    }

    function getDate() {
        return $this->date;
    }

    function getAdditionInfo() {
        return $this->additionInfo;
    }

    function getLogoText() {
        return $this->logoText;
    }

    function getLogoBaseLine() {
        return $this->logoBaseLine;
    }

    function getLogoStyle() {
        return $this->logoStyle;
    }

    function getLogoTextColor() {
        return $this->logoTextColor;
    }

    function getLogoBaselineColor() {
        return $this->logoBaselineColor;
    }

    function getLogoBackgroundColor() {
        return $this->logoBackgroundColor;
    }

    function getUploadFiles() {
        return $this->uploadFiles;
    }

    function getDesignDesc() {
        return $this->designDesc;
    }

    function getBriefDesc() {
        return $this->briefDesc;
    }

    function getAdditionComment() {
        return $this->additionComment;
    }

    function setOrderDesignId($orderDesignId) {
        $this->orderDesignId = $orderDesignId;
    }

    function setOrderId($orderId) {
        $this->orderId = $orderId;
    }

    function setProjectId($projectId) {
        $this->projectId = $projectId;
    }

    function setProjectName($projectName) {
        $this->projectName = $projectName;
    }

    function setFirstName($firstName) {
        $this->firstName = $firstName;
    }

    function setLastName($lastName) {
        $this->lastName = $lastName;
    }

    function setMemberEmail($memberEmail) {
        $this->memberEmail = $memberEmail;
    }

    function setMemberMobile($memberMobile) {
        $this->memberMobile = $memberMobile;
    }

    function setDate($date) {
        $this->date = $date;
    }

    function setAdditionInfo($additionInfo) {
        $this->additionInfo = $additionInfo;
    }

    function setLogoText($logoText) {
        $this->logoText = $logoText;
    }

    function setLogoBaseLine($logoBaseLine) {
        $this->logoBaseLine = $logoBaseLine;
    }

    function setLogoStyle($logoStyle) {
        $this->logoStyle = $logoStyle;
    }

    function setLogoTextColor($logoTextColor) {
        $this->logoTextColor = $logoTextColor;
    }

    function setLogoBaselineColor($logoBaselineColor) {
        $this->logoBaselineColor = $logoBaselineColor;
    }

    function setLogoBackgroundColor($logoBackgroundColor) {
        $this->logoBackgroundColor = $logoBackgroundColor;
    }

    function setUploadFiles($uploadFiles) {
        $this->uploadFiles = $uploadFiles;
    }

    function setDesignDesc($designDesc) {
        $this->designDesc = $designDesc;
    }

    function setBriefDesc($briefDesc) {
        $this->briefDesc = $briefDesc;
    }

    function setAdditionComment($additionComment) {
        $this->additionComment = $additionComment;
    }




}
?>