<?php 

class DesignCatVO {
   var $designCatId;  
   var $designName;
   var $designDesc;
   var $status;
   function getDesignCatId() {
       return $this->designCatId;
   }

   function getDesignName() {
       return $this->designName;
   }

   function getDesignDesc() {
       return $this->designDesc;
   }

   function getStatus() {
       return $this->status;
   }

   function setDesignCatId($designCatId) {
       $this->designCatId = $designCatId;
   }

   function setDesignName($designName) {
       $this->designName = $designName;
   }

   function setDesignDesc($designDesc) {
       $this->designDesc = $designDesc;
   }

   function setStatus($status) {
       $this->status = $status;
   }


}
?>