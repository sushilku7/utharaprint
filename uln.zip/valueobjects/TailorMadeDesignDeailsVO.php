<?php 

class TailorMadeDesignDeailsVO {
   var $rowId;  
   var $orderId;
   var $memberId;
   var $memberCompanyName;
   var $memberAddress;  
   var $memberContactDetails;
   var $option1;
   var $image1;
   var $image2;  
   var $image3;
   var $image4;
   var $orderDate;
   var $orderStatus;
   function getRowId() {
       return $this->rowId;
   }

   function getOrderId() {
       return $this->orderId;
   }

   function getMemberId() {
       return $this->memberId;
   }

   function getMemberCompanyName() {
       return $this->memberCompanyName;
   }

   function getMemberAddress() {
       return $this->memberAddress;
   }

   function getMemberContactDetails() {
       return $this->memberContactDetails;
   }

   function getOption1() {
       return $this->option1;
   }

   function getImage1() {
       return $this->image1;
   }

   function getImage2() {
       return $this->image2;
   }

   function getImage3() {
       return $this->image3;
   }

   function getImage4() {
       return $this->image4;
   }

   function getOrderDate() {
       return $this->orderDate;
   }

   function getOrderStatus() {
       return $this->orderStatus;
   }

   function setRowId($rowId) {
       $this->rowId = $rowId;
   }

   function setOrderId($orderId) {
       $this->orderId = $orderId;
   }

   function setMemberId($memberId) {
       $this->memberId = $memberId;
   }

   function setMemberCompanyName($memberCompanyName) {
       $this->memberCompanyName = $memberCompanyName;
   }

   function setMemberAddress($memberAddress) {
       $this->memberAddress = $memberAddress;
   }

   function setMemberContactDetails($memberContactDetails) {
       $this->memberContactDetails = $memberContactDetails;
   }

   function setOption1($option1) {
       $this->option1 = $option1;
   }

   function setImage1($image1) {
       $this->image1 = $image1;
   }

   function setImage2($image2) {
       $this->image2 = $image2;
   }

   function setImage3($image3) {
       $this->image3 = $image3;
   }

   function setImage4($image4) {
       $this->image4 = $image4;
   }

   function setOrderDate($orderDate) {
       $this->orderDate = $orderDate;
   }

   function setOrderStatus($orderStatus) {
       $this->orderStatus = $orderStatus;
   }


}
?>