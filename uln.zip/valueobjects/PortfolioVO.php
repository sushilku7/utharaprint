<?php 

class PortfolioVO {
   var $portfId;  
   var $productCatId;
   var $image;
   var $thumb;
   var $status;
   function getPortfId() {
       return $this->portfId;
   }

   function getProductCatId() {
       return $this->productCatId;
   }

   function getImage() {
       return $this->image;
   }

   function getThumb() {
       return $this->thumb;
   }

   function getStatus() {
       return $this->status;
   }

   function setPortfId($portfId) {
       $this->portfId = $portfId;
   }

   function setProductCatId($productCatId) {
       $this->productCatId = $productCatId;
   }

   function setImage($image) {
       $this->image = $image;
   }

   function setThumb($thumb) {
       $this->thumb = $thumb;
   }

   function setStatus($status) {
       $this->status = $status;
   }


}
?>