<?php 
class OrderDesignLogoWebVO {
   
    var $odlw;  
    var $orderName;
    var $package;
    var $price;
    var $vatAmt;    
    var $paymentMode;
    var $memberId;
    var $created_On;
    
    function getOdlw() {
        return $this->odlw;
    }

    function getOrderName() {
        return $this->orderName;
    }

    function getPackage() {
        return $this->package;
    }

    function getPrice() {
        return $this->price;
    }

    function getVatAmt() {
        return $this->vatAmt;
    }

    function getPaymentMode() {
        return $this->paymentMode;
    }

    function getMemberId() {
        return $this->memberId;
    }

    function getCreated_On() {
        return $this->created_On;
    }

    function setOdlw($odlw) {
        $this->odlw = $odlw;
    }

    function setOrderName($orderName) {
        $this->orderName = $orderName;
    }

    function setPackage($package) {
        $this->package = $package;
    }

    function setPrice($price) {
        $this->price = $price;
    }

    function setVatAmt($vatAmt) {
        $this->vatAmt = $vatAmt;
    }

    function setPaymentMode($paymentMode) {
        $this->paymentMode = $paymentMode;
    }

    function setMemberId($memberId) {
        $this->memberId = $memberId;
    }

    function setCreated_On($created_On) {
        $this->created_On = $created_On;
    }


}
?>