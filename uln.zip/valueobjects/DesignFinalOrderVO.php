<?php 
class DesignFinalOrderVO {
   
    var $id;  
    var $memberId;
    var $productName;
    var $productPrice;
    var $artwork1;    
    var $artwork2;
    var $artwork3;
    var $artwork4;
    var $artwork5;   
    var $created_on;  
    function getId() {
        return $this->id;
    }

    function getMemberId() {
        return $this->memberId;
    }

    function getProductName() {
        return $this->productName;
    }

    function getProductPrice() {
        return $this->productPrice;
    }

    function getArtwork1() {
        return $this->artwork1;
    }

    function getArtwork2() {
        return $this->artwork2;
    }

    function getArtwork3() {
        return $this->artwork3;
    }

    function getArtwork4() {
        return $this->artwork4;
    }

    function getArtwork5() {
        return $this->artwork5;
    }

    function getCreated_on() {
        return $this->created_on;
    }

    function setId($id) {
        $this->id = $id;
    }

    function setMemberId($memberId) {
        $this->memberId = $memberId;
    }

    function setProductName($productName) {
        $this->productName = $productName;
    }

    function setProductPrice($productPrice) {
        $this->productPrice = $productPrice;
    }

    function setArtwork1($artwork1) {
        $this->artwork1 = $artwork1;
    }

    function setArtwork2($artwork2) {
        $this->artwork2 = $artwork2;
    }

    function setArtwork3($artwork3) {
        $this->artwork3 = $artwork3;
    }

    function setArtwork4($artwork4) {
        $this->artwork4 = $artwork4;
    }

    function setArtwork5($artwork5) {
        $this->artwork5 = $artwork5;
    }

    function setCreated_on($created_on) {
        $this->created_on = $created_on;
    }


}
?>