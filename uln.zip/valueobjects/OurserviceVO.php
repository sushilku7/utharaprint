<?php 
class OurserviceVO {
   
    var $ourserviceId;  
    var $ourserviceName;
    var $ourservice_desc;
    var $ourservice_image;
    var $ourservice_image1;
    var $status;    
    var $ourservicedir;
    var $authorName;
    var $author_image;
    var $createdOn;
    var $author_Desc;
    
    function getAuthor_Desc() {
        return $this->author_Desc;
    }

    function setAuthor_Desc($author_Desc) {
        $this->author_Desc = $author_Desc;
    }

            function getOurservice_image1() {
        return $this->ourservice_image1;
    }

    function setOurservice_image1($ourservice_image1) {
        $this->ourservice_image1 = $ourservice_image1;
    }

        function getOurservicedir() {
        return $this->ourservicedir;
    }

    function getAuthorName() {
        return $this->authorName;
    }

    function getAuthor_image() {
        return $this->author_image;
    }

    function getCreatedOn() {
        return $this->createdOn;
    }

    function setOurservicedir($ourservicedir) {
        $this->ourservicedir = $ourservicedir;
    }

    function setAuthorName($authorName) {
        $this->authorName = $authorName;
    }

    function setAuthor_image($author_image) {
        $this->author_image = $author_image;
    }

    function setCreatedOn($createdOn) {
        $this->createdOn = $createdOn;
    }

        function getOurserviceId() {
        return $this->ourserviceId;
    }

    function getOurserviceName() {
        return $this->ourserviceName;
    }

    function getOurservice_desc() {
        return $this->ourservice_desc;
    }

    function getOurservice_image() {
        return $this->ourservice_image;
    }

    function getStatus() {
        return $this->status;
    }

    function setOurserviceId($ourserviceId) {
        $this->ourserviceId = $ourserviceId;
    }

    function setOurserviceName($ourserviceName) {
        $this->ourserviceName = $ourserviceName;
    }

    function setOurservice_desc($ourservice_desc) {
        $this->ourservice_desc = $ourservice_desc;
    }

    function setOurservice_image($ourservice_image) {
        $this->ourservice_image = $ourservice_image;
    }

    function setStatus($status) {
        $this->status = $status;
    }


    

}
?>