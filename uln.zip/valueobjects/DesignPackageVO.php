<?php 

class DesignPackageVO{
   var $dpId;  
   var $productCatId;
   var $package;
   var $design_name;
   var $design_price;
   var $support;
   var $advance;
   var $storage;
   var $bandWidth;
   var $status;
   var $option5;  
   var $option6;
   var $option7;
   var $option8;
   var $option9;
   var $option10;
   var $option11;
   var $option12;
   var $option13;
   var $option14;
   
   function getDpId() {
       return $this->dpId;
   }

   function getProductCatId() {
       return $this->productCatId;
   }

   function getPackage() {
       return $this->package;
   }

   function getDesign_name() {
       return $this->design_name;
   }

   function getDesign_price() {
       return $this->design_price;
   }

   function getSupport() {
       return $this->support;
   }

   function getAdvance() {
       return $this->advance;
   }

   function getStorage() {
       return $this->storage;
   }

   function getBandWidth() {
       return $this->bandWidth;
   }

   function getStatus() {
       return $this->status;
   }

   function getOption5() {
       return $this->option5;
   }

   function getOption6() {
       return $this->option6;
   }

   function getOption7() {
       return $this->option7;
   }

   function getOption8() {
       return $this->option8;
   }

   function getOption9() {
       return $this->option9;
   }

   function getOption10() {
       return $this->option10;
   }

   function getOption11() {
       return $this->option11;
   }

   function getOption12() {
       return $this->option12;
   }

   function getOption13() {
       return $this->option13;
   }

   function getOption14() {
       return $this->option14;
   }

   function setDpId($dpId) {
       $this->dpId = $dpId;
   }

   function setProductCatId($productCatId) {
       $this->productCatId = $productCatId;
   }

   function setPackage($package) {
       $this->package = $package;
   }

   function setDesign_name($design_name) {
       $this->design_name = $design_name;
   }

   function setDesign_price($design_price) {
       $this->design_price = $design_price;
   }

   function setSupport($support) {
       $this->support = $support;
   }

   function setAdvance($advance) {
       $this->advance = $advance;
   }

   function setStorage($storage) {
       $this->storage = $storage;
   }

   function setBandWidth($bandWidth) {
       $this->bandWidth = $bandWidth;
   }

   function setStatus($status) {
       $this->status = $status;
   }

   function setOption5($option5) {
       $this->option5 = $option5;
   }

   function setOption6($option6) {
       $this->option6 = $option6;
   }

   function setOption7($option7) {
       $this->option7 = $option7;
   }

   function setOption8($option8) {
       $this->option8 = $option8;
   }

   function setOption9($option9) {
       $this->option9 = $option9;
   }

   function setOption10($option10) {
       $this->option10 = $option10;
   }

   function setOption11($option11) {
       $this->option11 = $option11;
   }

   function setOption12($option12) {
       $this->option12 = $option12;
   }

   function setOption13($option13) {
       $this->option13 = $option13;
   }

   function setOption14($option14) {
       $this->option14 = $option14;
   }



}
?>