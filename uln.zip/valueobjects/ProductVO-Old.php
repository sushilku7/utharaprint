<?php 
class ProductVO {
   
    var $productId;  
    var $productCatId;
    var $productSize;
    var $productPaper;
    var $productPages;    
    var $productQty;
    var $productPrice;
    var $profiteMargine;   
    var $productStatus; 
    var $imagePath;
    var $pageContent;
    
    function getProductId() {
        return $this->productId;
    }

    function getProductCatId() {
        return $this->productCatId;
    }

    function getProductSize() {
        return $this->productSize;
    }

    function getProductPaper() {
        return $this->productPaper;
    }

    function getProductPages() {
        return $this->productPages;
    }

    function getProductQty() {
        return $this->productQty;
    }

    function getProductPrice() {
        return $this->productPrice;
    }

    function getProfiteMargine() {
        return $this->profiteMargine;
    }

    function getProductStatus() {
        return $this->productStatus;
    }

    function getImagePath() {
        return $this->imagePath;
    }

    function getPageContent() {
        return $this->pageContent;
    }

    function setProductId($productId) {
        $this->productId = $productId;
    }

    function setProductCatId($productCatId) {
        $this->productCatId = $productCatId;
    }

    function setProductSize($productSize) {
        $this->productSize = $productSize;
    }

    function setProductPaper($productPaper) {
        $this->productPaper = $productPaper;
    }

    function setProductPages($productPages) {
        $this->productPages = $productPages;
    }

    function setProductQty($productQty) {
        $this->productQty = $productQty;
    }

    function setProductPrice($productPrice) {
        $this->productPrice = $productPrice;
    }

    function setProfiteMargine($profiteMargine) {
        $this->profiteMargine = $profiteMargine;
    }

    function setProductStatus($productStatus) {
        $this->productStatus = $productStatus;
    }

    function setImagePath($imagePath) {
        $this->imagePath = $imagePath;
    }

    function setPageContent($pageContent) {
        $this->pageContent = $pageContent;
    }


}
?>