<?php 

class ArtworkOrderVO {
    
    var $orderId;  
    var $memberId;      
    var $memberCompanyName;   
    var $memberAddress;  
    var $memberAddress2;
    var $option1;
    var $option2;
    var $option3;
    var $option4;
    var $image1;      
    var $image2;   
    var $image3; 
    var $image4;      
    var $image5;   
    var $comments; 
    var $orderDate;      
    var $orderStatus;   
   
    function getOrderId() {
        return $this->orderId;
    }

    function getMemberId() {
        return $this->memberId;
    }

    function getMemberCompanyName() {
        return $this->memberCompanyName;
    }

    function getMemberAddress() {
        return $this->memberAddress;
    }

    function getMemberAddress2() {
        return $this->memberAddress2;
    }

    function getOption1() {
        return $this->option1;
    }

    function getOption2() {
        return $this->option2;
    }

    function getOption3() {
        return $this->option3;
    }

    function getOption4() {
        return $this->option4;
    }

    function getImage1() {
        return $this->image1;
    }

    function getImage2() {
        return $this->image2;
    }

    function getImage3() {
        return $this->image3;
    }

    function getImage4() {
        return $this->image4;
    }

    function getImage5() {
        return $this->image5;
    }

    function getComments() {
        return $this->comments;
    }

    function getOrderDate() {
        return $this->orderDate;
    }

    function getOrderStatus() {
        return $this->orderStatus;
    }

    function setOrderId($orderId) {
        $this->orderId = $orderId;
    }

    function setMemberId($memberId) {
        $this->memberId = $memberId;
    }

    function setMemberCompanyName($memberCompanyName) {
        $this->memberCompanyName = $memberCompanyName;
    }

    function setMemberAddress($memberAddress) {
        $this->memberAddress = $memberAddress;
    }

    function setMemberAddress2($memberAddress2) {
        $this->memberAddress2 = $memberAddress2;
    }

    function setOption1($option1) {
        $this->option1 = $option1;
    }

    function setOption2($option2) {
        $this->option2 = $option2;
    }

    function setOption3($option3) {
        $this->option3 = $option3;
    }

    function setOption4($option4) {
        $this->option4 = $option4;
    }

    function setImage1($image1) {
        $this->image1 = $image1;
    }

    function setImage2($image2) {
        $this->image2 = $image2;
    }

    function setImage3($image3) {
        $this->image3 = $image3;
    }

    function setImage4($image4) {
        $this->image4 = $image4;
    }

    function setImage5($image5) {
        $this->image5 = $image5;
    }

    function setComments($comments) {
        $this->comments = $comments;
    }

    function setOrderDate($orderDate) {
        $this->orderDate = $orderDate;
    }

    function setOrderStatus($orderStatus) {
        $this->orderStatus = $orderStatus;
    }


}
?>