<?php 
class FinalOrderVO {
   
    var $orderId;  
    var $cartId;
    var $txnid;
    var $memberId;
    var $memberEmail;    
    var $orderDate;
    var $totalAmout;
    var $totalNetAmount;
    var $paymentStatus;   
    var $orderStats;    
    var $track;
    var $expectDate;    
    var $paymentMode;
    
    function getPaymentMode() {
        return $this->paymentMode;
    }

    function setPaymentMode($paymentMode) {
        $this->paymentMode = $paymentMode;
    }

       function getOrderId() {
       return $this->orderId;
   }

   function getCartId() {
       return $this->cartId;
   }

   function getTxnid() {
       return $this->txnid;
   }

   function getMemberId() {
       return $this->memberId;
   }

   function getMemberEmail() {
       return $this->memberEmail;
   }

   function getOrderDate() {
       return $this->orderDate;
   }

   function getTotalAmout() {
       return $this->totalAmout;
   }

   function getTotalNetAmount() {
       return $this->totalNetAmount;
   }

   function getPaymentStatus() {
       return $this->paymentStatus;
   }

   function getOrderStats() {
       return $this->orderStats;
   }

   function setOrderId($orderId) {
       $this->orderId = $orderId;
   }

   function setCartId($cartId) {
       $this->cartId = $cartId;
   }

   function setTxnid($txnid) {
       $this->txnid = $txnid;
   }

   function setMemberId($memberId) {
       $this->memberId = $memberId;
   }

   function setMemberEmail($memberEmail) {
       $this->memberEmail = $memberEmail;
   }

   function setOrderDate($orderDate) {
       $this->orderDate = $orderDate;
   }

   function setTotalAmout($totalAmout) {
       $this->totalAmout = $totalAmout;
   }

   function setTotalNetAmount($totalNetAmount) {
       $this->totalNetAmount = $totalNetAmount;
   }

   function setPaymentStatus($paymentStatus) {
       $this->paymentStatus = $paymentStatus;
   }

   function setOrderStats($orderStats) {
       $this->orderStats = $orderStats;
   }
   
   function getTrack() {
        return $this->track;
    }
    
    function setTrack($track) {
        $this->track = $track;
    }

    function getExpectDate() {
        return $this->expectDate;
    }

    function setExpectDate($expectDate) {
        $this->expectDate = $expectDate;
    }


}
?>