<?php 

class TailormadDesignVO {
   var $taylorId;  
   var $productName;
   var $productCatId;
   var $designCharges;
   var $tmdStatus;
   var $pMainCatId;
   var $productDesc;
   Var $catName;
   var $orderDesignDesc;
   var $designName;
   
   function getDesignName() {
       return $this->designName;
   }

   function setDesignName($designName) {
       $this->designName = $designName;
   }

   function getOrderDesignDesc() {
       return $this->orderDesignDesc;
   }

   function setOrderDesignDesc($orderDesignDesc) {
       $this->orderDesignDesc = $orderDesignDesc;
   }

      function getCatName() {
       return $this->catName;
   }

   function setCatName($catName) {
       $this->catName = $catName;
   }

      function getTaylorId() {
       return $this->taylorId;
   }

   function getProductName() {
       return $this->productName;
   }

   function getProductCatId() {
       return $this->productCatId;
   }

   function getDesignCharges() {
       return $this->designCharges;
   }

   function getTmdStatus() {
       return $this->tmdStatus;
   }

   function getPMainCatId() {
       return $this->pMainCatId;
   }

   function getProductDesc() {
       return $this->productDesc;
   }

   function setTaylorId($taylorId) {
       $this->taylorId = $taylorId;
   }

   function setProductName($productName) {
       $this->productName = $productName;
   }

   function setProductCatId($productCatId) {
       $this->productCatId = $productCatId;
   }

   function setDesignCharges($designCharges) {
       $this->designCharges = $designCharges;
   }

   function setTmdStatus($tmdStatus) {
       $this->tmdStatus = $tmdStatus;
   }

   function setPMainCatId($pMainCatId) {
       $this->pMainCatId = $pMainCatId;
   }

   function setProductDesc($productDesc) {
       $this->productDesc = $productDesc;
   }


}
?>