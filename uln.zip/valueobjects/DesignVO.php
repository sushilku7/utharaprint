<?php 

class DesignVO {
   var $taylorId;  
   var $productName;
   var $price;
   var $tmdStatus;
   
   function getTaylorId() {
       return $this->taylorId;
   }

   function getProductName() {
       return $this->productName;
   }

   function getPrice() {
       return $this->price;
   }

   function getTmdStatus() {
       return $this->tmdStatus;
   }

   function setTaylorId($taylorId) {
       $this->taylorId = $taylorId;
   }

   function setProductName($productName) {
       $this->productName = $productName;
   }

   function setPrice($price) {
       $this->price = $price;
   }

   function setTmdStatus($tmdStatus) {
       $this->tmdStatus = $tmdStatus;
   }


}
?>