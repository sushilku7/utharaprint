<?php 

class SettingVO {
   var $configID;  
   var $site_name;
    var $site_title;  
   var $site_logo;
    var $admin_email;  
   var $site_christmas_effect;
   var $admin_name;
/**
	 * @return the $rId
	 */
	
        function getConfigID() {
            return $this->configID;
        }
         function getAdmin_name() {
            return $this->admin_name;
        }
        function getSite_name() {
            return $this->site_name;
        }

        function getSite_title() {
            return $this->site_title;
        }

        function getSite_logo() {
            return $this->site_logo;
        }

        function getAdmin_email() {
            return $this->admin_email;
        }

        function getSite_christmas_effect() {
            return $this->site_christmas_effect;
        }

        function setConfigID($configID) {
            $this->configID = $configID;
        }
		function setAdmin_name($admin_name) {
            $this->admin_name = $admin_name;
        }
        function setSite_name($site_name) {
            $this->site_name = $site_name;
        }

        function setSite_title($site_title) {
            $this->site_title = $site_title;
        }

        function setSite_logo($site_logo) {
            $this->site_logo = $site_logo;
        }

        function setAdmin_email($admin_email) {
            $this->admin_email = $admin_email;
        }

        function setSite_christmas_effect($site_christmas_effect) {
            $this->site_christmas_effect = $site_christmas_effect;
        }


}
?>