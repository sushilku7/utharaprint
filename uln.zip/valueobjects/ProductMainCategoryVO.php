<?php 

class ProductMainCategoryVO {
   var $pMainCatId;  
   var $mcatName;
   var $productDes;  
   var $productStatus;
   var $dirName;  
   var $productCatId;
   var $catName;
   
   function getPMainCatId() {
       return $this->pMainCatId;
   }

   function getMcatName() {
       return $this->mcatName;
   }

   function getProductDes() {
       return $this->productDes;
   }

   function getProductStatus() {
       return $this->productStatus;
   }

   function getDirName() {
       return $this->dirName;
   }

   function getProductCatId() {
       return $this->productCatId;
   }

   function getCatName() {
       return $this->catName;
   }

   function setPMainCatId($pMainCatId) {
       $this->pMainCatId = $pMainCatId;
   }

   function setMcatName($mcatName) {
       $this->mcatName = $mcatName;
   }

   function setProductDes($productDes) {
       $this->productDes = $productDes;
   }

   function setProductStatus($productStatus) {
       $this->productStatus = $productStatus;
   }

   function setDirName($dirName) {
       $this->dirName = $dirName;
   }

   function setProductCatId($productCatId) {
       $this->productCatId = $productCatId;
   }

   function setCatName($catName) {
       $this->catName = $catName;
   }


}
?>