<?php 
class ProductVO {
   
    var $productId;  
    var $productCatId;
    var $productSubCat;
    var $productPaperType;
    var $productPaperSize;    
    var $productPrintType;
    var $productPrintPageNum;
    var $productCutType;   
    var $productLaminationType; 
    var $productFoldType; 
    var $productCoverType; 
    var $productTurnAround; 
    var $productQty; 
    var $productNumSets; 
    var $productPrice; 
    var $profiteMargine; 
    var $productStatus;
    var $thumbImage1;
    var $vat;    
    
    function getProductId() {
        return $this->productId;
    }

    function getProductCatId() {
        return $this->productCatId;
    }

    function getProductSubCat() {
        return $this->productSubCat;
    }

    function getProductPaperType() {
        return $this->productPaperType;
    }

    function getProductPaperSize() {
        return $this->productPaperSize;
    }

    function getProductPrintType() {
        return $this->productPrintType;
    }

    function getProductPrintPageNum() {
        return $this->productPrintPageNum;
    }

    function getProductCutType() {
        return $this->productCutType;
    }

    function getProductLaminationType() {
        return $this->productLaminationType;
    }

    function getProductFoldType() {
        return $this->productFoldType;
    }

    function getProductCoverType() {
        return $this->productCoverType;
    }

    function getProductTurnAround() {
        return $this->productTurnAround;
    }

    function getProductQty() {
        return $this->productQty;
    }

    function getProductNumSets() {
        return $this->productNumSets;
    }

    function getProductPrice() {
        return $this->productPrice;
    }

    function getProfiteMargine() {
        return $this->profiteMargine;
    }

    function getProductStatus() {
        return $this->productStatus;
    }

    function getThumbImage1() {
        return $this->thumbImage1;
    }

    function getVat() {
        return $this->vat;
    }

    function setProductId($productId) {
        $this->productId = $productId;
    }

    function setProductCatId($productCatId) {
        $this->productCatId = $productCatId;
    }

    function setProductSubCat($productSubCat) {
        $this->productSubCat = $productSubCat;
    }

    function setProductPaperType($productPaperType) {
        $this->productPaperType = $productPaperType;
    }

    function setProductPaperSize($productPaperSize) {
        $this->productPaperSize = $productPaperSize;
    }

    function setProductPrintType($productPrintType) {
        $this->productPrintType = $productPrintType;
    }

    function setProductPrintPageNum($productPrintPageNum) {
        $this->productPrintPageNum = $productPrintPageNum;
    }

    function setProductCutType($productCutType) {
        $this->productCutType = $productCutType;
    }

    function setProductLaminationType($productLaminationType) {
        $this->productLaminationType = $productLaminationType;
    }

    function setProductFoldType($productFoldType) {
        $this->productFoldType = $productFoldType;
    }

    function setProductCoverType($productCoverType) {
        $this->productCoverType = $productCoverType;
    }

    function setProductTurnAround($productTurnAround) {
        $this->productTurnAround = $productTurnAround;
    }

    function setProductQty($productQty) {
        $this->productQty = $productQty;
    }

    function setProductNumSets($productNumSets) {
        $this->productNumSets = $productNumSets;
    }

    function setProductPrice($productPrice) {
        $this->productPrice = $productPrice;
    }

    function setProfiteMargine($profiteMargine) {
        $this->profiteMargine = $profiteMargine;
    }

    function setProductStatus($productStatus) {
        $this->productStatus = $productStatus;
    }

    function setThumbImage1($thumbImage1) {
        $this->thumbImage1 = $thumbImage1;
    }

    function setVat($vat) {
        $this->vat = $vat;
    }


    
    

}
?>