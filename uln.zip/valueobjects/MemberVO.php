<?php 

class MemberVO {
    var $memberId;  
    var $memberName;
    var $memberCompanyName;
    var $memberEmail;
    var $memberPass;
    var $memberAddress1;
    var $memberAddress2;
    var $memberAddress3;
    var $memberCountry;
    var $memberCounty;   
    var $memberPostalCode;   
    var $memberTelephone;   
    var $memberMobile;   
    var $memberStatus;   
    var $memberDate;
    var $memberIP;
    var $smemberName;
    var $smemberEmail;
    var $smemberCompanyName;  
    var $smemberAddress1;  
    var $smemberAddress2;  
    var $smemberAddress3;
    var $smemberCountry;
    var $smemberCounty;
    var $smemberPostalCode;
    var $smemberTelephone;
    var $smemberMobile;
    var $memberCity;
    var $smemberCity;
    var $firstName;
    var $lastName;
    var $sfirstName;
    var $slastName;
    var $samebs;
    
    function getSmemberAddress3() {
        return $this->smemberAddress3;
    }

    function setSmemberAddress3($smemberAddress3) {
        $this->smemberAddress3 = $smemberAddress3;
    }

        function getSamebs() {
        return $this->samebs;
    }

    function setSamebs($samebs) {
        $this->samebs = $samebs;
    }

    function getSfirstName() {
        return $this->sfirstName;
    }

    function getSlastName() {
        return $this->slastName;
    }

    function setSfirstName($sfirstName) {
        $this->sfirstName = $sfirstName;
    }

    function setSlastName($slastName) {
        $this->slastName = $slastName;
    }

        
	public function getFirstName() {
        return $this->firstName;
    }

    public function getLastName() {
        return $this->lastName;
    }
	
    public function getMemberId() {
        return $this->memberId;
    }

    public function getMemberName() {
        return $this->memberName;
    }

    public function getMemberCompanyName() {
        return $this->memberCompanyName;
    }

    public function getMemberEmail() {
        return $this->memberEmail;
    }

    public function getMemberPass() {
        return $this->memberPass;
    }

    public function getMemberAddress1() {
        return $this->memberAddress1;
    }

    public function getMemberAddress2() {
        return $this->memberAddress2;
    }

    public function getMemberAddress3() {
        return $this->memberAddress3;
    }

    public function getMemberCountry() {
        return $this->memberCountry;
    }

    public function getMemberCounty() {
        return $this->memberCounty;
    }

    public function getMemberPostalCode() {
        return $this->memberPostalCode;
    }

    public function getMemberTelephone() {
        return $this->memberTelephone;
    }

    public function getMemberMobile() {
        return $this->memberMobile;
    }

    public function getMemberStatus() {
        return $this->memberStatus;
    }

    public function getMemberDate() {
        return $this->memberDate;
    }

    public function getMemberIP() {
        return $this->memberIP;
    }

    public function getSmemberName() {
        return $this->smemberName;
    }

    public function getSmemberEmail() {
        return $this->smemberEmail;
    }

    public function getSmemberCompanyName() {
        return $this->smemberCompanyName;
    }

    public function getSmemberAddress1() {
        return $this->smemberAddress1;
    }

    public function getSmemberAddress2() {
        return $this->smemberAddress2;
    }

    public function getSmemberCountry() {
        return $this->smemberCountry;
    }

    public function getSmemberCounty() {
        return $this->smemberCounty;
    }

    public function getSmemberPostalCode() {
        return $this->smemberPostalCode;
    }

    public function getSmemberTelephone() {
        return $this->smemberTelephone;
    }

    public function getSmemberMobile() {
        return $this->smemberMobile;
    }

    public function getMemberCity() {
        return $this->memberCity;
    }

    public function getSmemberCity() {
        return $this->smemberCity;
    }

    public function setMemberId($memberId) {
        $this->memberId = $memberId;
    }

    public function setMemberName($memberName) {
        $this->memberName = $memberName;
    }

    public function setMemberCompanyName($memberCompanyName) {
        $this->memberCompanyName = $memberCompanyName;
    }

    public function setMemberEmail($memberEmail) {
        $this->memberEmail = $memberEmail;
    }

    public function setMemberPass($memberPass) {
        $this->memberPass = $memberPass;
    }

    public function setMemberAddress1($memberAddress1) {
        $this->memberAddress1 = $memberAddress1;
    }

    public function setMemberAddress2($memberAddress2) {
        $this->memberAddress2 = $memberAddress2;
    }

    public function setMemberAddress3($memberAddress3) {
        $this->memberAddress3 = $memberAddress3;
    }

    public function setMemberCountry($memberCountry) {
        $this->memberCountry = $memberCountry;
    }

    public function setMemberCounty($memberCounty) {
        $this->memberCounty = $memberCounty;
    }

    public function setMemberPostalCode($memberPostalCode) {
        $this->memberPostalCode = $memberPostalCode;
    }

    public function setMemberTelephone($memberTelephone) {
        $this->memberTelephone = $memberTelephone;
    }

    public function setMemberMobile($memberMobile) {
        $this->memberMobile = $memberMobile;
    }

    public function setMemberStatus($memberStatus) {
        $this->memberStatus = $memberStatus;
    }

    public function setMemberDate($memberDate) {
        $this->memberDate = $memberDate;
    }

    public function setMemberIP($memberIP) {
        $this->memberIP = $memberIP;
    }

    public function setSmemberName($smemberName) {
        $this->smemberName = $smemberName;
    }

    public function setSmemberEmail($smemberEmail) {
        $this->smemberEmail = $smemberEmail;
    }

    public function setSmemberCompanyName($smemberCompanyName) {
        $this->smemberCompanyName = $smemberCompanyName;
    }

    public function setSmemberAddress1($smemberAddress1) {
        $this->smemberAddress1 = $smemberAddress1;
    }

    public function setSmemberAddress2($smemberAddress2) {
        $this->smemberAddress2 = $smemberAddress2;
    }

    public function setSmemberCountry($smemberCountry) {
        $this->smemberCountry = $smemberCountry;
    }

    public function setSmemberCounty($smemberCounty) {
        $this->smemberCounty = $smemberCounty;
    }

    public function setSmemberPostalCode($smemberPostalCode) {
        $this->smemberPostalCode = $smemberPostalCode;
    }

    public function setSmemberTelephone($smemberTelephone) {
        $this->smemberTelephone = $smemberTelephone;
    }

    public function setSmemberMobile($smemberMobile) {
        $this->smemberMobile = $smemberMobile;
    }

    public function setMemberCity($memberCity) {
        $this->memberCity = $memberCity;
    }

    public function setSmemberCity($smemberCity) {
        $this->smemberCity = $smemberCity;
    }
    public function setFirstName($firstName) {
        $this->firstName = $firstName;
    }

    public function setLastName($firstName) {
        $this->firstName = $firstName;
    }

}
?>