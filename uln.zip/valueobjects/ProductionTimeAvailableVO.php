<?php

class ProductionTimeAvailableVO {

    var $productionTimeId;
    var $productionTime;
    var $delTime;
    var $status;
    var $productionPerc;
    
    
    function getProductionTimeId() {
        return $this->productionTimeId;
    }

    function getProductionTime() {
        return $this->productionTime;
    }

    function getDelTime() {
        return $this->delTime;
    }

    function getStatus() {
        return $this->status;
    }

    function getProductionPerc() {
        return $this->productionPerc;
    }

    function setProductionTimeId($productionTimeId) {
        $this->productionTimeId = $productionTimeId;
    }

    function setProductionTime($productionTime) {
        $this->productionTime = $productionTime;
    }

    function setDelTime($delTime) {
        $this->delTime = $delTime;
    }

    function setStatus($status) {
        $this->status = $status;
    }

    function setProductionPerc($productionPerc) {
        $this->productionPerc = $productionPerc;
    }


}

?>