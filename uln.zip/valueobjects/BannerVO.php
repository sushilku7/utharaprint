<?php 
class BannerVO {
   
    var $bannerId;  
    var $bannerName;
	var $bannerDesc;
	var $bannerUrl;
    var $image;
    var $status;
   
    function getBannerId() {
        return $this->bannerId;
    }

    function getBannerName() {
        return $this->bannerName;
    }
    function getBannerDesc() {
        return $this->bannerDesc;
    }
	function getBannerUrl() {
        return $this->bannerUrl;
    }
    function getImage() {
        return $this->image;
    }

    function getStatus() {
        return $this->status;
    }

    function setBannerId($bannerId) {
        $this->bannerId = $bannerId;
    }

    function setBannerName($bannerName) {
        $this->bannerName = $bannerName;
    }
    function setBannerDesc($bannerDesc) {
        $this->bannerDesc = $bannerDesc;
    }
	function setBannerUrl($bannerUrl) {
        $this->bannerUrl = $bannerUrl;
    }
    function setImage($image) {
        $this->image = $image;
    }

    function setStatus($status) {
        $this->status = $status;
    }


}
?>