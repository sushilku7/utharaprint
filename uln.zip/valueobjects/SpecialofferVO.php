<?php 
class SpecialofferVO {
   
    var $offerId;  
    var $offerHeadline;
    var $offerText;
    var $offerPrice;
    var $vatApplicable;
    var $imagePath;
    var $offerStatus;
    var $alias;
    var $size;
    var $paper;
    var $pages;
    var $qty;
    var $finishSize;
    var $offerDesc;
    var $artworkGuideline;
    var $template;
    
    function getFinishSize() {
        return $this->finishSize;
    }

    function getOfferDesc() {
        return $this->offerDesc;
    }

    function getArtworkGuideline() {
        return $this->artworkGuideline;
    }

    function getTemplate() {
        return $this->template;
    }

    function setFinishSize($finishSize) {
        $this->finishSize = $finishSize;
    }

    function setOfferDesc($offerDesc) {
        $this->offerDesc = $offerDesc;
    }

    function setArtworkGuideline($artworkGuideline) {
        $this->artworkGuideline = $artworkGuideline;
    }

    function setTemplate($template) {
        $this->template = $template;
    }

        
    
    function getOfferId() {
        return $this->offerId;
    }

    function getOfferHeadline() {
        return $this->offerHeadline;
    }

    function getOfferText() {
        return $this->offerText;
    }

    function getOfferPrice() {
        return $this->offerPrice;
    }

    function getVatApplicable() {
        return $this->vatApplicable;
    }

    function getImagePath() {
        return $this->imagePath;
    }

    function getOfferStatus() {
        return $this->offerStatus;
    }

    function getAlias() {
        return $this->alias;
    }

    function getSize() {
        return $this->size;
    }

    function getPaper() {
        return $this->paper;
    }

    function getPages() {
        return $this->pages;
    }

    function getQty() {
        return $this->qty;
    }

    function setOfferId($offerId) {
        $this->offerId = $offerId;
    }

    function setOfferHeadline($offerHeadline) {
        $this->offerHeadline = $offerHeadline;
    }

    function setOfferText($offerText) {
        $this->offerText = $offerText;
    }

    function setOfferPrice($offerPrice) {
        $this->offerPrice = $offerPrice;
    }

    function setVatApplicable($vatApplicable) {
        $this->vatApplicable = $vatApplicable;
    }

    function setImagePath($imagePath) {
        $this->imagePath = $imagePath;
    }

    function setOfferStatus($offerStatus) {
        $this->offerStatus = $offerStatus;
    }

    function setAlias($alias) {
        $this->alias = $alias;
    }

    function setSize($size) {
        $this->size = $size;
    }

    function setPaper($paper) {
        $this->paper = $paper;
    }

    function setPages($pages) {
        $this->pages = $pages;
    }

    function setQty($qty) {
        $this->qty = $qty;
    }



}
?>